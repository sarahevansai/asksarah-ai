# The Personas

Seven adversarial vantage points. Each one is a person with a real incentive, not a mood.

Pick the three most relevant to the idea in front of you. A persona with nothing genuine to say about this particular idea stays quiet. Silence from a persona is information: it usually means the idea is aimed somewhere else.

Every worked example below shows the critique AND the fix, because a critique without a fix is half a deliverable.

---

## 1. The Discerning Buyer

**Who they are.** They have the budget and the authority. They have bought something like this before and it did not go well. They are comparing you against two alternatives and against the option of doing nothing, which is free and always available.

**What they attack.**
- The gap between the promise and what is contractually guaranteed
- Anything that sounds like every other option they are looking at
- The absence of proof from someone like them
- Switching cost, which you have not priced and they have
- What happens when it does not work

**The questions they ask.**
- What exactly am I buying, and what am I not buying?
- Who else like me has done this, and what actually happened?
- What does this cost me in the second year?
- What do I have to do for this to work? How much of my team's time?
- What happens if I do nothing for six months?
- If this underdelivers, what do I get?

**Worked example.**

*Idea:* A commercial HVAC contractor adds a "preventive maintenance membership": a flat annual fee covering two scheduled service visits, priority scheduling, and 15 percent off any repair.

*Critique (Discerning Buyer, STRUCTURAL):* A facilities manager who has been burned before does not read "priority scheduling" as a benefit. They read it as an admission that normal scheduling is bad, and they ask the obvious follow up: priority over whom, and by how many hours. The offer has no number attached to its most emotionally important promise, which is the one that matters at 6am when a rooftop unit is down and the building is opening at 8. Nothing here is guaranteed, so nothing here is comparable, so the buyer defaults to price and the offer competes with the cheapest quote in the stack.

*Fix (written language):*

Original: "Members receive priority scheduling."

Replacement: "Members get a technician on site within 4 business hours of an emergency call, or the visit is free. Non-members are scheduled next available, typically 1 to 3 business days."

Structural note attached to the fix: before publishing that sentence, confirm the 4 hour window against last year's actual dispatch times. If the team cannot hit it in 90 percent of cases, publish the number they can hit. A guarantee you miss twice creates a worse buyer than the one you had.

---

## 2. The Angry Customer

**Who they are.** They already bought. Something failed at the worst possible moment. They are now rereading everything they were promised, and the gap between the promise and the experience is where the anger lives.

**What they attack.**
- Promises that read as guarantees in the moment of failure
- The absence of a defined path when things break
- Whoever they reach first, and what that person is allowed to do
- Anything that sounds automated when they need a human

**The questions they ask.**
- Who do I call, and will a human answer?
- You said this would not happen. What do you mean, it is not covered?
- How long has this been broken and when were you going to tell me?
- What are you doing to make this right, specifically?
- Why am I finding out about this from someone else?

**Worked example.**

*Idea:* A payroll software company adds a self-serve tier with no phone support, email only, 24 hour response target.

*Critique (Angry Customer, FATAL):* Payroll fails on a deadline. That is the only way it fails. A customer discovering at 4pm on a Thursday that direct deposits did not fund is not a support ticket, they are a business owner whose staff will not be paid on Friday and who is legally exposed in some jurisdictions. A 24 hour email response arrives after the damage is final. The tier is not underpriced support, it is a product that cannot serve the moment it exists for. Every one of these customers becomes a public review written in the worst hour of their year.

*Fix (structural change, plus the language):* Keep the self-serve tier and email support for everything except funding and filing failures. Add one exception path, staffed, and put it in the product where the failure happens.

In-product language at the point of failure: "Deposits did not fund. This is time sensitive. Call [number] now. This line is staffed [hours] and is available on every plan."

Cost of the change: one on-call rotation covering payroll processing windows. That is the price of the tier existing at all. If that cannot be staffed, the tier does not ship.

---

## 3. The Skeptical CFO

**Who they are.** They are not against the idea. They are against unmodeled things. They have seen the last four initiatives that were going to pay for themselves. They want to know what this displaces, because the budget is not growing.

**What they attack.**
- Revenue claims with no mechanism attached
- Costs that stop at the obvious line item
- The assumption that current conditions hold
- Anything with no measurable failure point
- Opportunity cost, which is never in the deck

**The questions they ask.**
- What is the fully loaded cost, including the people already on payroll?
- Where does the revenue actually come from, and when does the cash arrive?
- What are we not doing in order to do this?
- What is the downside case, and what does it cost us to be wrong?
- How will we know at 90 days whether this is working?
- What are we assuming stays the same?

**Worked example.**

*Idea:* A regional accounting firm opens a second office in a nearby metro to serve clients closer to where they are.

*Critique (Skeptical CFO, STRUCTURAL):* The plan prices the lease, the buildout, and two hires. It does not price the thing that actually determines the outcome: who staffs it during the ramp. The named lead is currently the firm's highest utilization partner, and the model still counts their existing billable hours in the base business while also assuming they build the new office. That partner cannot be in both columns. The real cost of the second office is the revenue that leaves the first one, and it is not in the model. There is also no stated kill criterion, which means this decision has no exit.

*Fix (structural change and the missing model):* Rebuild the model with three inputs the current version does not have.

1. The lead partner's hours, split explicitly: what percent goes to the new office in each of the first four quarters, and what that removes from current billings.
2. Backfill cost for those hours in the existing office, at the real rate to replace them, not the average.
3. Client transfer assumptions, named: which existing clients move to the new office, and whether that is new revenue or relocated revenue. Relocated revenue is not growth.

Add a kill criterion in one line, before the lease is signed: "If the second office has not reached [X] in recurring monthly billings by month 12, we sublease and consolidate." Fill X with the number that makes the lease survivable, not the number that makes the plan look good.

---

## 4. The Disgruntled Employee

**Who they are.** They have to execute this on top of the job they already have. They were not consulted. They know exactly which step breaks, because they are the step that breaks.

**What they attack.**
- Plans with no named owner per step
- Work that has been added without anything being removed
- Handoffs between teams that do not talk
- Training and documentation, which nobody has scheduled
- Incentives that punish the behavior the plan requires

**The questions they ask.**
- Who is actually doing this, and what are they dropping to do it?
- Has anyone asked the people who do this today?
- What happens when the person who knows this is out?
- Am I measured on this? Because I am measured on something else.
- What do I do when the system says one thing and the customer says another?

**Worked example.**

*Idea:* A veterinary practice group rolls out a new client intake process across six clinics: every new patient gets a 15 minute pre-visit phone consult booked by the front desk.

*Critique (Disgruntled Employee, STRUCTURAL):* Front desk staff at these clinics are the same people checking in patients, taking payments, and fielding the phones during the exact hours the consults would have to be booked and conducted. The plan adds a task inside the busiest window and removes nothing. It also assumes the front desk can answer clinical questions that will inevitably come up on those calls, which they cannot, so every call either escalates to a technician who is mid-appointment or produces an answer nobody wants given. Front desk turnover in this group is already the operational constraint. This plan makes the worst job in the building worse.

*Fix (structural change, with the sequence):* Do not have the front desk conduct the consult. Split the task.

1. Front desk books the slot only. That is a 20 second action inside an existing workflow.
2. A designated technician conducts the consults in one blocked window per day, batched, not on demand.
3. Write the escalation rule before launch, in one line posted at the desk: "Clinical questions on intake calls go to [role] and are answered same day, not on the call."
4. Pilot at one clinic for 60 days before the other five. The pilot answers the question this plan cannot answer on paper: how many of these calls actually change the visit.

Removal required, not optional: name the one task coming off the front desk to make room, or the rollout does not proceed.

---

## 5. The Burned Out Journalist

**Who they are.** They see claims like this constantly. Their bar is not "is this interesting to you." It is "is this new, is it provable, and what is the story if it is wrong." They are not hostile. They are tired, and tired is worse.

**What they attack.**
- The word "first," and the word "only"
- Claims with no verifiable proof behind them
- Something described as a trend on the evidence of one example
- Anything where the interesting version of the story is the one you are avoiding

**The questions they ask.**
- What is genuinely new here, and compared to what?
- Who says so besides you?
- Can I see the data, the filing, the study, the customer?
- Who is harmed if this is true?
- What are you not telling me, and why did I have to ask?

**Worked example.**

*Idea:* A food manufacturer plans an announcement that its new packaging is "the first fully recyclable format in the category."

*Critique (Burned Out Journalist, FATAL as written):* "First" is a claim about everyone else, and it requires proving a negative across an entire category, which almost nobody can do. "Fully recyclable" is a second claim, and it is not a property of the package, it is a property of the package and the local recycling system together. A reporter will ask which category definition is being used, who verified it, and whether the material is actually accepted at curbside in the markets where the product sells. If the honest answer to the last question is "in some places," the announcement becomes a story about a company overstating its environmental claims, which is a worse story than no story. This is also the exact class of claim that draws regulatory attention in multiple jurisdictions.

*Fix (rewritten language plus the substantiation file):*

Original: "the first fully recyclable format in the category."

Replacement: "packaging made from [material], which is accepted for curbside recycling in [X] of our [Y] largest markets, verified by [third party or standard]."

Before that sentence goes anywhere, assemble a substantiation file with three items: the category definition and its source, the acceptance data by market with its date, and the name of whoever verified the material claim. If any of the three does not exist, the sentence does not exist. If the company genuinely is first and can prove it, the proof goes in the same file and "first" can stay, sourced.

---

## 6. The Competitor

**Who they are.** They read everything you publish. They are looking for the screenshot, the overclaim, the admission, and the gap they can price against.

**What they attack.**
- Anything you said that you cannot defend under scrutiny
- The weakness you just disclosed by defending it
- Claims they can beat on a spec sheet
- Positioning that is easy to copy and expensive to keep

**The questions they ask.**
- What did they just tell the market they are worried about?
- Which of these claims can I make too, tomorrow, for less?
- Where is their price undefended?
- What would I put next to this in a side by side?
- What did they leave out that I can put in?

**Worked example.**

*Idea:* An industrial parts distributor publishes a page positioning itself on "the largest inventory in the region."

*Critique (Competitor, STRUCTURAL):* Inventory size is a claim any competitor with capital can match, and it is also a claim that invites a side by side comparison the distributor may not win on every category. Worse, it is the wrong axis. A buyer with a line down does not want the largest inventory, they want the part today. A competitor with a smaller catalog and a same day courier can put two columns next to each other, lose on catalog size, win on the thing that determines the purchase, and use this page as the setup. The claim also has an operational tail: the moment it is public, every stockout becomes a broken promise rather than a normal event.

*Fix (rewritten positioning plus the proof):*

Original: "the largest inventory in the region."

Replacement: "In stock and out the door same day on [X] of the [Y] parts our customers order most. If we do not have it, we tell you in [time] and where to get it."

That claim is harder to copy, aims at the actual buying moment, and is defensible with the distributor's own fill rate data. Pull the fill rate before publishing and use the real number. If the real number is not good, the fix is operational and the page waits.

---

## 7. The Lawyer

**Who they are.** They are not trying to ruin it. They are trying to keep it from being the exhibit. They read every sentence as something that will be read back under different circumstances.

**What they attack.**
- Absolutes, guarantees, and outcome promises
- Comparative claims about named competitors
- Regulated language in regulated categories
- Anything asserted that cannot be substantiated on demand
- Missing sign-off, and unclear who approved what

**The questions they ask.**
- Can we substantiate this today, with a document?
- Does this promise an outcome we do not control?
- Who approved this claim, and where is that recorded?
- What does the contract say when this does not happen?
- Are we saying something about a named third party?
- Does this category have specific rules, and did anyone check?

**Worked example.**

*Idea:* A staffing agency's new client agreement includes a "guaranteed 30 day replacement" on any placement that does not work out.

*Critique (Lawyer, FATAL as drafted):* The word "guaranteed" is doing work nobody has defined. The draft does not say what triggers the guarantee, who decides whether it was triggered, what "replacement" means if no suitable candidate exists in 30 days, or what the client receives in that case. As written, a client can invoke it for any reason including their own hiring manager changing the requirements, and the agency has committed to an outcome it does not control. There is also no stated remedy cap, which means the exposure is undefined. A guarantee with undefined triggers and undefined remedies is not a marketing benefit, it is an open-ended obligation.

*Fix (rewritten clause):*

Original: "Guaranteed 30 day replacement on any placement."

Replacement: "If a placed candidate resigns or is terminated for performance within 30 calendar days of start date, [Agency] will conduct a replacement search at no additional fee. If no suitable candidate is presented within 30 days of the replacement request, [Client] receives a credit of [percent] of the original fee. This guarantee does not apply where the role requirements change materially after placement, or where the placement ends for reasons of role elimination or budget."

Attached process fix: name who at the agency approves invocation of the guarantee, and record it. An undefined approver is how a defined clause becomes an undefined one in practice.

---

## Choosing personas

- **New offer or pricing:** Discerning Buyer, Skeptical CFO, Lawyer
- **Operational plan or rollout:** Disgruntled Employee, Skeptical CFO, Angry Customer
- **Public claim or announcement:** Burned Out Journalist, Lawyer, Competitor
- **Strategy or market move:** Skeptical CFO, Competitor, Discerning Buyer
- **Product or service change:** Angry Customer, Disgruntled Employee, Discerning Buyer
- **Contract or agreement:** Lawyer, Discerning Buyer, Skeptical CFO

These are starting points, not rules. The right three are the three with something real to say.
