# Worked Pressure Tests

Four complete reviews, end to end, in four different industries. Use these to calibrate severity and to see what a finished fix looks like.

Every number that appears inside a fix is either the user's own operating data or a bracket telling them which number to insert. Nothing external is asserted as fact. That is the standard.

---

## Example 1: Manufacturing

**What the user submitted.** A 40 person precision machine shop wants to launch a "Machine Health Subscription": for a flat monthly fee per machine, the shop's technicians perform quarterly preventive maintenance on customers' CNC equipment, monitor a vibration sensor package, and guarantee 24 hour response on any covered failure. Pitch deck says "manufacturers lose an average of $260,000 per hour of unplanned downtime" and "studies show preventive maintenance reduces downtime by up to 45 percent."

---

**STEELMAN**

The shop already has technicians who know these machines and already visits these customers, so the marginal cost of a maintenance visit is low and the relationship exists. If downtime is genuinely expensive for these customers, converting unpredictable emergency spend into predictable monthly spend is something a plant manager would actually want to buy.

**THE HOLES**

**1. SKEPTICAL CFO · FATAL**
The subscription is priced per machine per month, but the cost driver is not machines, it is technician hours, and technician hours are the shop's binding constraint. Every hour a technician spends on a customer's maintenance contract is an hour not spent on the shop's own billable production work, which carries a higher margin. The model as submitted does not contain a single line for the production revenue displaced. At any volume where the subscription is meaningful, it cannibalizes the more profitable business. The economics do not close, and adding customers makes it worse rather than better.

**2. DISGRUNTLED EMPLOYEE · STRUCTURAL**
The 24 hour response guarantee has no staffing model behind it. The shop has a small number of technicians qualified on this equipment, and they are scheduled against production. A guarantee that can only be honored by pulling someone off a job means the guarantee is funded by missed internal deadlines, and the person who absorbs that is the shop floor lead who did not agree to any of this. The first month with two simultaneous failures breaks both the guarantee and the schedule.

**3. DISCERNING BUYER · STRUCTURAL**
A plant manager who has bought a service contract before immediately asks what is covered and what is not. The offer says "any covered failure" without defining covered. It also does not say what happens when the diagnosis is that the machine needs a part with a six week lead time, which is the actual failure mode that costs them money. Undefined coverage means the buyer either assumes everything is covered, and is furious later, or assumes nothing is, and does not buy.

**FACT PATROL**

- "manufacturers lose an average of $260,000 per hour of unplanned downtime" → **UNVERIFIED, likely DISTORTED.** No source given. A figure in this range circulates widely and generally traces to surveys of very large automotive and heavy industry plants, which are not the customers this shop serves. An average across an unrepresentative population is not an average that applies to a 12 machine job shop.
  **Verify:** find the original study, its publication year, and the size and industry of the plants surveyed. If those plants are not comparable to this shop's customers, the number cannot be used. Do not substitute a different figure. Replace it with the customer's own number, gathered in the sales conversation.

- "studies show preventive maintenance reduces downtime by up to 45 percent" → **UNVERIFIED.** "Studies show" with no named study, plus "up to," which converts a ceiling into an implied expectation. This is the standard shape of a claim nobody checked.
  **Verify:** name the study, the year, and the equipment class. If no primary source exists, cut the sentence.

- "24 hour response" → **STRUCTURAL, not a fact problem.** Verify against the shop's own dispatch records for the last 12 months before this appears in writing anywhere.

**THE FIXES**

**1. Closes hole 1 (FATAL). Reprice on the real cost driver, or do not launch.**
The subscription cannot be priced per machine. Rebuild it priced on committed technician hours per quarter, with a stated cap. Before pricing, compute one number: the shop's average gross margin per technician hour on production work. That number is the floor. If the subscription cannot clear it, the correct answer is that this is not a subscription business for this shop, and the alternative approach is an annual scheduled maintenance agreement sold as a fixed number of visits with no response guarantee, which does not consume the constraint unpredictably.

**2. Closes hole 2 (STRUCTURAL). Staff the guarantee or shrink it.**
Cap total subscribed machines at the number one designated technician can cover, and name that technician. Add a second only when the first is at capacity. Write the internal rule in one line: "Subscription response takes priority over internal production scheduling. Production leads are notified same day." If nobody will sign that sentence, the guarantee is not real and comes out of the offer.

**3. Closes hole 3 (STRUCTURAL). Define coverage in writing.**

Original: "24 hour response on any covered failure."

Replacement: "A qualified technician is on site within 24 business hours of a reported failure on a covered machine. Covered: diagnosis, labor, and any repair completable with parts we stock. Not covered: parts, third party service, and repairs requiring components on manufacturer lead time. Where a part is on lead time, we provide the order confirmation and the estimated date within 24 hours of diagnosis."

**4. Closes both Fact Patrol findings.**

Original: "Manufacturers lose an average of $260,000 per hour of unplanned downtime, and studies show preventive maintenance reduces downtime by up to 45 percent."

Replacement: "What does an hour of downtime cost you on your highest utilization machine? Most of the shops we work with have never calculated it. We will build that number with you in the first visit, and we will price this against it."

That version is stronger than the statistic, because it makes the buyer produce the number that sells the deal, and it cannot be fact checked into a credibility problem.

**CALL:** Does not survive as written. Survives as a fixed visit maintenance agreement with defined coverage and a capped technician commitment.

**COACHING NOTE**
The pattern to fix: pricing on the unit the customer counts instead of the unit that consumes your constraint. Machines are how the customer thinks about their plant. Technician hours are how this business actually works. Any time those two diverge, price on yours and explain in theirs.

---

## Example 2: Education

**What the user submitted.** A community college wants to launch a 14 week data analytics certificate with a job placement guarantee: if a graduate does not have a qualifying job within 180 days, tuition is refunded. Target price $6,500. Landing page draft says "94 percent of our graduates are employed within six months" and quotes "As Peter Drucker said, if you can't measure it, you can't manage it."

---

**STEELMAN**

A refund guarantee transfers risk from the student to the institution, which is exactly the right direction for a population that cannot afford to be wrong, and a college has the employer relationships and the credibility that independent bootcamps have to buy.

**THE HOLES**

**1. LAWYER · FATAL**
"Qualifying job" is undefined and the guarantee is therefore unbounded. As drafted, the college has no stated definition of qualifying, no stated obligations on the student, no documentation requirement, no exclusions, and no cap. A student who applies to nothing, declines two offers, and moves out of state can invoke it. The guarantee also creates exposure under the rules that govern educational outcome claims and refunds in most jurisdictions, and there is no evidence anyone has checked which of those apply. This is not a marketing feature. It is an open liability attached to every enrollment.

**2. SKEPTICAL CFO · STRUCTURAL**
The refund liability is not modeled anywhere. At $6,500 and a target cohort, the college needs to know the placement rate at which the program breaks even, and that number does not appear. Worse, the refund lands roughly 11 months after enrollment, so the cash timing is a second problem on top of the first: revenue is recognized early and clawed back into a later fiscal period. Nobody has asked what happens to the program budget in a year when the local employment market softens, which is precisely the year the refunds cluster.

**3. DISCERNING BUYER · STRUCTURAL**
A 34 year old considering this is not primarily worried about the $6,500. They are worried about 14 weeks of their life and whether the certificate is recognized by the employers they would actually apply to. The offer answers the money question and ignores the time question, which is the expensive one. No employer is named anywhere. A guarantee that returns money does not return the semester.

**FACT PATROL**

- "94 percent of our graduates are employed within six months" → **FABRICATED as used.** The program does not exist yet, so it has no graduates. Whatever this number came from, it is not this program's outcome data, and stating it as such is a false claim about educational results, which is among the most heavily regulated categories of claim there is.
  **Verify:** nothing to verify. Cut it. If the figure came from a different program at the same institution, it can only be used with that program named, its cohort defined, and its measurement method stated.

- "As Peter Drucker said, if you can't measure it, you can't manage it" → **MISATTRIBUTED, disputed.** This line is very widely attributed to Drucker and the attribution is widely disputed, with no commonly cited primary source in his published work. Quotes that are famous, pithy, and sourced only to a name are the highest risk category.
  **Verify:** locate the book, edition, and page. If it cannot be found, the quote comes out or the attribution does. A misattributed quote on a page selling an analytics credential is a small error that does a specific kind of damage.

- "180 days," "qualifying job," "tuition refunded" → **UNVERIFIED against policy.** These are institutional commitments, not facts.
  **Verify:** confirm with the office that owns refund policy and with counsel which state and accreditor rules govern outcome guarantees for this credential type.

**THE FIXES**

**1. Closes hole 1 (FATAL). Rewrite the guarantee with defined terms, or replace it.**

Original: "If a graduate does not have a qualifying job within 180 days, tuition is refunded."

Replacement: "Complete the program, meet the participation requirements below, and if you have not accepted a role in a data or analytics function paying at least [$X] within 180 days of your completion date, we refund your tuition in full.

Participation requirements: attend at least [X] of [Y] sessions, complete all [X] portfolio projects, submit at least [X] applications per month documented in the career portal, and attend the scheduled employer sessions. The guarantee does not apply where an offer meeting the above is declined, or where you relocate outside [region] during the guarantee period."

Then: send that language to counsel before it is published, and confirm the outcome claim rules for this credential in this state. That is a gate, not a task.

**2. Closes hole 2 (STRUCTURAL). Model and cap the liability.**
Compute the break-even placement rate at $6,500 and the planned cohort size, using fully loaded delivery cost including instructor time. Then set a refund reserve as a percent of tuition collected, held to the later period where the refunds actually land. Add one kill criterion: "If the placement rate for the first two cohorts is below [X], the guarantee is withdrawn from future cohorts before enrollment opens." A guarantee with no exit is a liability with no end.

**3. Closes hole 3 (STRUCTURAL). Answer the time question with employers, not with money.**
Before launch, secure written participation from at least [X] regional employers: interview commitments, curriculum review, or guest sessions. Name them on the page. Then add the line the buyer is actually looking for.

Add: "Curriculum reviewed by hiring managers at [Employer], [Employer], and [Employer]. Every cohort ends with scheduled interviews, not just a certificate."

**4. Closes both Fact Patrol findings.**
Cut the 94 percent line entirely. Cut the Drucker quote entirely. Replace the top of the page with the employer names from fix 3, which is the proof the statistic was pretending to be.

**CALL:** Does not survive as written. The guarantee and the outcome claim are both live liabilities. Survives once the guarantee is defined and gated by counsel, the liability is reserved, and the fabricated placement figure is removed.

**COACHING NOTE**
The pattern to fix: reaching for a borrowed statistic when you have not yet earned your own. The 94 percent was standing in for proof this program cannot have yet. Named employers are proof you can actually get, they are harder for a competitor to copy, and they survive a fact check.

---

## Example 3: Financial services

**What the user submitted.** A credit union with 60,000 members wants to launch earned wage access: members can draw up to 50 percent of accrued earnings before payday for a flat $3 fee per transfer, with no interest and no credit check. Internal memo frames it as "a member benefit, not a loan product."

---

**STEELMAN**

Members who currently reach for overdraft or a payday lender when they are short before payday would be better off with a $3 flat fee product from an institution that is not trying to trap them, and the credit union already sees the deposit history that makes underwriting unnecessary.

**THE HOLES**

**1. LAWYER · FATAL**
"A member benefit, not a loan product" is a characterization, not a legal conclusion, and it is exactly the characterization regulators have been scrutinizing in this category. Whether an advance repaid on payday for a fee constitutes credit depends on the structure and the jurisdiction, and the answer determines whether disclosure requirements, fee limits, and lending rules apply. The memo asserts the favorable answer without evidence that anyone qualified has reached it. If the answer comes back the other way after launch, the product is not adjusted, it is unwound, with every transaction already made sitting on the books.

**2. ANGRY CUSTOMER · STRUCTURAL**
The failure mode is a member who draws 50 percent, then has an unexpected expense, then finds their payday deposit halved, then draws again the following period, and is now structurally short every cycle. That member did not do anything wrong and the product did exactly what it was designed to do. When they call, they will describe it as the credit union putting them in a hole. There is nothing in the design that notices this pattern or intervenes, which means the institution learns about it from the complaint rather than from the data it already has.

**3. SKEPTICAL CFO · STRUCTURAL**
A flat $3 fee is revenue that does not scale with the risk or the cost. The cost of this product is not the transfer, it is the recovery cases, the support volume, and the members whose repeated use eventually shows up as a charged off deposit account. None of that is modeled. There is also an unstated assumption that this displaces overdraft usage, and overdraft is currently non-trivial income. If this product succeeds, it may reduce net revenue, and nobody has put a number on that.

**4. DISCERNING BUYER · COSMETIC**
"Up to 50 percent of accrued earnings" is the kind of phrase a member reads as a promise and experiences as a denial. The actual available amount will vary by pay cycle timing and deposit history, and the first time a member is offered less than they expected, the product feels like a bait.

**FACT PATROL**

- "no interest" → **DISTORTED.** A flat fee on a short duration advance carries an implied annualized cost, and describing it as having no interest while charging a fee is the specific framing regulators have flagged in this product category.
  **Verify:** compute the effective annualized cost at the typical advance size and duration, and confirm with counsel what must be disclosed. Whatever the disclosure requirement turns out to be, the sentence "no interest" is doing work it has not earned.

- "no credit check" → **VERIFIABLE and probably accurate, but incomplete.** It is true that no bureau pull occurs. It is not true that no assessment occurs, since eligibility depends on deposit history.
  **Verify:** confirm with the product owner what determines eligibility, and state it.

- "60,000 members" → **UNVERIFIED in the memo, trivially verifiable internally.**
  **Verify:** confirm against the current member count of record before this number appears in any external material.

- No external statistics appear in the memo. Noted, and it is the strongest thing about the document.

**THE FIXES**

**1. Closes hole 1 (FATAL). Get the legal characterization before anything else moves.**
Do not proceed on the memo's assertion. Send the structure to counsel with the specific question written out: "Under [state] law and applicable federal regulation, does an advance of accrued wages repaid by payroll deduction for a flat fee constitute credit, and what disclosure and fee rules attach." Everything below is contingent on that answer. If it comes back as credit, the product is redesigned around the applicable rules, not relabeled.

**2. Closes hole 2 (STRUCTURAL). Build the pattern intervention into the product.**
Add a usage rule before launch: if a member draws in [X] consecutive pay periods, the product pauses and triggers an outreach from a financial counselor. Write the member-facing language now.

Add: "You have used an advance in [X] pay periods in a row. We are pausing advances for one cycle and a counselor will reach out. This is not a penalty. Repeated advances usually mean the pay cycle is the problem, and we can help with that."

That rule is also the strongest possible answer to the regulatory question in fix 1.

**3. Closes hole 3 (STRUCTURAL). Model the full picture, including what it displaces.**
Three inputs the model needs: support cost per advance at expected volume, expected recovery and charge-off rate on paused accounts, and the projected reduction in overdraft income. Present the net, not the fee revenue. If the net is negative and the institution wants to do this anyway as a mission decision, that is a legitimate answer, but it has to be made deliberately by the people who own the budget.

**4. Closes hole 4 (COSMETIC). Rewrite the eligibility language.**

Original: "Members can draw up to 50 percent of accrued earnings."

Replacement: "Your available amount is calculated from your direct deposit history and the days remaining in your pay period, up to 50 percent of what you have already earned. You will see your exact available amount before you request anything."

**5. Closes the Fact Patrol finding on "no interest."**

Original: "No interest, no credit check."

Replacement: "A flat $3 fee per advance. No interest is charged, and there is no credit bureau check. Eligibility is based on your deposit history with us. [Required disclosure of effective cost, per counsel.]"

**CALL:** Does not survive as written, because the central legal characterization is asserted rather than determined. The product design is sound and the fixes are known. This is a sequencing failure, not a strategy failure.

**COACHING NOTE**
The pattern to fix: writing the favorable answer to an open question into the memo as if it were settled, and then building the plan on top of it. "A member benefit, not a loan product" is one sentence, and every other decision in the document inherits it. Whenever a plan rests on a characterization, mark it as an open question and name who resolves it, or the whole plan is resting on a sentence somebody wrote hopefully.

---

## Example 4: Hospitality

**What the user submitted.** A three location restaurant group wants to launch two delivery-only brands out of its existing kitchens, using current staff during slow hours, listed on the major delivery apps. Projection assumes each brand adds meaningful incremental revenue per location with "no additional labor cost since we're using existing downtime."

---

**STEELMAN**

The kitchens are already staffed and already paid for during the hours between lunch and dinner, so any revenue produced in that window drops toward the margin line faster than revenue that requires new capacity.

**THE HOLES**

**1. DISGRUNTLED EMPLOYEE · FATAL**
"Existing downtime" is not downtime. The window between services is prep, cleaning, receiving, and the only break the line gets in a 12 hour day. Filling it with a second and third menu does not use idle labor, it removes the recovery period that makes the dinner service possible. The people who will absorb this are the same line cooks the group is already struggling to retain, and they will experience it as two more concepts and no more pay. The plan does not survive contact with the kitchen, and the cost of being wrong is not a bad quarter, it is losing the cooks and closing early.

**2. SKEPTICAL CFO · STRUCTURAL**
"No additional labor cost" is the load-bearing assumption of the entire projection and it is asserted rather than calculated. Even accepting the downtime premise, the plan adds ticket time, packaging labor, order management across multiple apps, and a second and third inventory to count and order. The projection also appears to use gross order value rather than what actually lands in the bank after the delivery platform commission, which is the largest single line item in this business model and is not visible anywhere in the numbers.

**3. ANGRY CUSTOMER · STRUCTURAL**
Delivery-only brands fail in public and in writing. An order that arrives cold, late, or wrong produces a permanent one star review on a platform where the restaurant group has no relationship with the customer and limited ability to make it right. Worse, if any of the three brands share an address, customers will connect them, and a bad experience with the delivery brand becomes a review problem for the flagship restaurant that took ten years to build.

**4. COMPETITOR · COSMETIC**
Delivery-only concepts are cheap to copy and cheap to launch. Any advantage from menu design lasts one ordering cycle. Whatever moat exists here is operational, not creative, and the plan is written as though the concept is the asset.

**FACT PATROL**

- "no additional labor cost since we're using existing downtime" → **UNVERIFIED, and it is the claim the whole projection rests on.** No labor study, no time in motion estimate, no input from any kitchen manager.
  **Verify:** shadow one kitchen for one week and record what actually happens between 2pm and 4pm, hour by hour. That single week of observation settles this. Do not proceed on the assumption.

- The revenue projection per location → **UNVERIFIED.** No stated basis, no comparable, no source. A projection is not a fact, but it becomes one the moment it is presented to a lender or a partner.
  **Verify:** state the assumptions underneath it explicitly, including average ticket, orders per day, and platform commission rate. A projection with visible assumptions is a model. A projection without them is a wish with a number on it.

- No delivery platform commission rate appears anywhere in the material. **Flag as a material omission, not a false claim.**
  **Verify:** pull the actual commission and fee schedule from each platform contract, including promoted placement costs, and put it in the model as a line.

**THE FIXES**

**1. Closes hole 1 (FATAL). Do the labor study before anything else, and let it decide.**
One kitchen, one week, observed, before any concept work continues. If the window is genuinely open, the plan proceeds with a defined labor allocation and a pay adjustment for the added scope. If it is not open, the alternative approach is one delivery brand at one location, launched with a dedicated part time cook covering the window, priced to carry that cost. The moment the plan requires the labor to be free, the plan is wrong.

**2. Closes hole 2 (STRUCTURAL). Rebuild the model on net, not gross.**
Three inputs the projection needs: platform commission and fee rate per order taken from the actual contracts, packaging cost per order, and incremental labor from fix 1. Present contribution margin per order, not revenue per location. Add the break-even orders per day per brand. That single number will do more to settle this decision than the entire concept discussion.

**3. Closes hole 3 (STRUCTURAL). Protect the flagship and define the service recovery.**
Two changes. First, write the recovery rule before launch: who monitors reviews daily, what they are authorized to refund without approval, and the response time standard. Second, decide deliberately whether the delivery brands are publicly associated with the flagship, and if they are not, confirm what each platform requires you to disclose about the kitchen address before you assume you can keep them separate.

**4. Closes hole 4 (COSMETIC). Reframe the asset in the plan.**
The plan should state in one line what the actual advantage is: existing kitchen, existing supply chain, existing food cost discipline, and the ability to kill a concept in a week with no sunk buildout. That is the real case and it is a better case than the menu.

**CALL:** Does not survive as written. The labor assumption is doing all the work and nobody has checked it. Survives as a single brand at a single location, modeled on net revenue with real labor, if the week of observation supports it.

**COACHING NOTE**
The pattern to fix: an assumption that makes the math work, stated as a fact, in the sentence everyone skims. "No additional labor cost" is eleven words carrying an entire business case. Whenever a plan contains a phrase that would collapse the projection if it turned out to be false, that phrase gets tested first, not last.
