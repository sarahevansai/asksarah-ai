# The Logic Police™

A Claude skill that finds what is wrong with your idea before a customer, an investor, a regulator, or the market finds it. Then it hands you the fix, written.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most AI agrees with you. Colleagues soften. Friends encourage. So the first real pressure your idea meets is a buyer who does not sign, a customer who churns, a CFO who kills the budget, or a reporter who asks the one question you never rehearsed.

This moves that pressure earlier, where it is cheap.

Hand it an idea, an offer, a plan, a price, a document, or a pitch, and Claude will:

1. State the strongest honest version of your idea, so the critique lands on the real thing
2. Poke at least three holes, each from a different adversarial persona, each tagged by severity
3. Run Fact Patrol on every checkable claim, hunting invented statistics, fabricated studies, and misattributed quotes
4. Write the fix for every hole, in language you can use today
5. Give you one coaching note that generalizes past this one idea

**You always get the fix.** A critique with no repair attached is half a deliverable. Every hole comes back with rewritten language, a named structural change, the cheapest test that would settle it, or the exact question to go answer and who holds the answer.

**It never opens with praise.** No "great idea." No compliment sandwich. No reassuring closer.

## The seven personas

Every review runs at least three, chosen for the idea in front of you:

- **The Discerning Buyer**: has budget, has been burned, is comparing you against two alternatives and against doing nothing
- **The Angry Customer**: already bought, something failed at the worst moment, is rereading everything you promised
- **The Skeptical CFO**: wants the revenue link, the fully loaded cost, the downside case, and what this displaces
- **The Disgruntled Employee**: has to execute this on top of their real job and knows which step breaks
- **The Burned Out Journalist**: asks what is genuinely new, what is provable, and what the story is if you are wrong
- **The Competitor**: reads this in public and looks for the screenshot
- **The Lawyer**: hunts absolutes, guarantees, comparative claims, and anything you cannot substantiate on demand

## Severity, defined

Every hole gets tagged, with definitions concrete enough that two people would tag the same hole the same way:

- **FATAL**: kills the idea. The plan is not modified, it is replaced. No meeting fixes it.
- **STRUCTURAL**: fixable, but the plan changes. Pricing, sequence, scope, staffing, or timeline moves. A meeting fixes it.
- **COSMETIC**: fix before it ships. The problem lives in the expression. A rewrite fixes it.

No downgrading a FATAL to soften the blow. No upgrading a COSMETIC to look thorough.

## Fact Patrol

Runs on every review, on your own material and on anything you were sent.

It extracts every checkable claim and hunts the patterns that give away a number nobody verified: no source, cited to "studies show," suspiciously round, suspiciously precise with no method, or circulating for years through articles that each cite another article. It checks quotes that are famous and pithy and sourced only to a name. It checks studies named by institution with no author, no journal, and no year. It checks absolutes, outcome promises, and facts about a company that the company itself has never said.

Then it does the only useful thing: flags the claim, says what would need to be true, and tells you exactly what to go verify.

**It will never replace a shaky number with a different invented number.** That is the cardinal rule of this section, and it is the exact failure most tools commit while appearing to help.

## What it will not do

- **It is not cruelty.** It attacks the idea, the numbers, and the language. Never the person.
- **It is not contrarianism.** Objecting on reflex is as useless as agreeing on reflex, and more expensive because it looks like rigor.
- **It does not manufacture objections.** No inventing a hole to reach three. If a persona has nothing real to say, that persona stays quiet.
- **If your idea is genuinely sound, it says so**, then attacks the execution and the assumptions instead, because those are almost never sound at the same time.

Finding nothing is a legitimate outcome. It should be rare.

## Modes

- **Pressure test** an idea, plan, or strategy
- **Review an offer** or a price, led by the buyer, the CFO, and the lawyer
- **Fact patrol a document**, skipping the personas and sweeping every claim
- **Run a single persona** at twice the depth: "run this past the CFO"
- **Objection prep** for something you are about to face live, with the answers written as spoken responses
- **Rematch** after you revise, showing which holes closed, which are open, and which ones your revision created

## Try it

Once installed, say any of these:

- "Poke holes in this" and paste your idea
- "Pressure test this pricing"
- "Be brutal. What's wrong with this plan?"
- "Fact check this document"
- "What would a skeptical CFO ask about this?"
- "Tell me why this won't work"
- "Prep me for the objections I'll get on Thursday"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `logic-police.zip` in your skills settings. Claude loads it automatically whenever something needs pressure testing.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/logic-police/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, describe any idea, and say "poke holes in this." You should get a steelman, at least three holes with severity tags, a Fact Patrol section, the fixes written out, and one coaching note. If the first line is praise, it did not load.

## What is in the package

```
logic-police/
├── SKILL.md                The framework, severity scale, Fact Patrol, output format
├── README.md               This file
├── LICENSE
└── references/
    ├── personas.md         All 7 personas: what they attack, what they ask, worked critiques with fixes
    └── examples.md         4 complete pressure tests across 4 industries, end to end
```

## Notes

Claude will never invent a statistic, a source, a study, or a quote inside a review, including in the fixes it writes for you. Anything it cannot verify comes back flagged with the exact source that would settle it. That is deliberate. A confident critique built on a made-up number is the same failure it was hired to catch.

It asks at most one question, and only after the holes, the Fact Patrol findings, and the fixes are already in front of you. Nothing is held back waiting for an answer.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
