---
name: company-boilerplate
description: >
  Writes the standing "About [Company]" paragraph that goes at the bottom of every press
  release, in every media kit, and in every pitch email. Produces both lengths finished and
  ready to approve: a roughly 100 word standard version and a roughly 300 word extended
  version, plus a one-line and a two-sentence variation on request. Use whenever someone
  needs a company description written, rewritten, shortened, or checked. Trigger on "write
  our boilerplate," "we need a boilerplate," "about us paragraph," "the blurb at the bottom
  of a press release," "company description," "rewrite our about section," "we need a
  standard company paragraph," "what should our about paragraph say," "our boilerplate is
  out of date," "shorten our company description," "one-line version of our company
  description," "company bio for a byline," "media kit paragraph," "how do we describe
  ourselves," "audit our boilerplate," or any request to describe a company in a paragraph
  for external use. Also trigger unprompted when someone is drafting a press release, a
  media kit, a speaker bio, an award submission, or a pitch email and the company
  description in it is vague, superlative-heavy, or reads like a mission statement. When in
  doubt, run it. Most companies have four versions of this paragraph in circulation and no
  idea which one is current.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Company Boilerplate

Every company needs one paragraph that says what it is. Most companies have four, none of them current, and all of them written by committee.

The boilerplate is the most reused piece of writing a company owns. It sits at the bottom of every press release, in the media kit, in the conference program, in the award submission, and in the first paragraph of the article a journalist writes about you. It gets copied more often than anything on the website. And almost nobody writes it on purpose.

This skill produces the paragraph a journalist can paste without editing, in both lengths, ready for sign-off.

---

## The #1 rule: always deliver both finished boilerplates

**Every run ends with two written, approval-ready paragraphs. The roughly 100 word standard version and the roughly 300 word extended version. No exceptions.**

Not questions. Not an outline. Not a list of what you need to know first. Not "tell me more about your company and I will write it." Two finished paragraphs, written out, ready to send to whoever signs off.

This holds even when:

- The user gives you a company name and one line about what it does. That is enough. Write both versions from it.
- The user only asked for the short one. Write both. The extended version costs them nothing and they will need it inside a month.
- The user asked a narrow question about one sentence. Answer the question, then deliver both full versions with the fix in place.
- Half the facts are missing. Write both versions with `[BRACKETS]` for the facts you cannot responsibly guess, and name what to go get.
- The user pasted an existing boilerplate and asked whether it is any good. Say so in one line, then hand them the rewritten versions anyway.
- The company is early and has no numbers, no customers, and no founding story worth telling. Write the version that works without them. A boilerplate with no proof line is still a boilerplate.

**Never end a response with a question instead of the paragraphs.** If a missing fact would change the writing, deliver both versions first, then ask the one question that would sharpen them.

**A structure is not a boilerplate.** Handing back "[Company] is a [category] company that [does thing] for [audience]" is the most common way this rule gets broken while looking like it was followed. If the user told you the company name and what it sells, the paragraph is about THAT company, in real sentences, with their actual category and audience in it. Fill-in skeletons live in `references/patterns.md` and are raw material for you, never output for the user.

### Infer conservatively, bracket honestly

Infer the things a competent writer would infer from what you were told: the category, who they serve, the plain-English version of what they do, the sensible sentence order, the tone. Write those.

Bracket only the facts that would be wrong to guess. Those are almost always the same five:

- Founding year
- Headquarters city and state or country
- Employee count
- Customer, user, or unit numbers
- The website URL

Everything else is your job. A version with four brackets and real sentences around them is a deliverable. A version with twelve brackets is a form, and a form is what the user came here to avoid.

Never bracket something the user already told you, even loosely. If they said "we work with hospitals mostly," write "for hospitals and health systems," not "[target market]."

---

## The honesty rule

**Never invent a fact that could end up in a press release, a regulatory filing, an investor deck, or a court document.**

A boilerplate is not marketing copy that lives and dies on a landing page. It gets pasted into wire distribution, quoted by reporters, attached to funding announcements, and read by regulators. An invented detail in a boilerplate does not stay a writing problem. It becomes a real one.

**Never invent, under any circumstance:**

- A founding date or founding year
- An employee count or headcount range
- A customer count, user count, unit volume, or any scale number
- Revenue, funding raised, valuation, or growth percentage
- An award, a ranking, or a list placement
- A certification, an accreditation, a license, or a compliance standard
- A named client, customer, partner, or investor
- A claim of market leadership, market share, or being first, largest, or only

If you do not have it, bracket it and name what to go get. Say it plainly under the drafts: "Two things to fill in: the year you started and the number of clients you can say publicly. Get the client number from whoever would defend it in a deposition, not from the website."

Three more rules that live under this one:

- **A number in a boilerplate needs a source and usually a timeframe.** "Serves more than 400 clients" is fine if it is true today. "Has served more than 400 clients since 2015" is better, because it does not go stale the week someone churns.
- **Only name a customer, partner, or investor who is publicly and currently disclosed.** Not one who agreed verbally. Not one who was fine with it two years ago.
- **When the user hands you a number that sounds inflated, use it and flag it.** "Using your 10,000 number. Make sure whoever signs off can back that one up, because this paragraph will get quoted."

---

## What a boilerplate is actually for

Most people write this paragraph wrong because they think it is a chance to say who they really are. It is not. It is a utility.

**A boilerplate is the standing company description that appears at the bottom of every press release and in every media kit, written so a journalist can paste it into an article without editing a word.**

That is the whole job. It gets used by people who are not you, in a hurry, to explain your company to someone who has never heard of it. The test of a good one is not whether it inspires. It is whether a reporter on deadline can drop it in and move on.

Here is what it is not, and why the confusion is expensive.

**It is not a mission statement.** A mission statement says what you are trying to do in the world. A boilerplate says what you are. "We believe every small business deserves enterprise-grade tools" is a mission. "Northgate Systems builds accounting software for construction contractors" is a boilerplate. A reporter can use the second one. The first one tells them nothing they can print.

**It is not a manifesto.** Nobody reading the bottom of a press release wants your worldview. They want to know what your company does so the rest of the release makes sense.

**It is not a sales pitch.** A pitch is aimed at a buyer and written to persuade. A boilerplate is aimed at a stranger and written to inform. Persuasion in a boilerplate reads as puffery, and puffery is exactly what an editor cuts first.

**It is not your About page.** The About page can be 800 words, tell the founding story, have photos, and speak in the first person. The boilerplate is one paragraph in third person that has to survive being copied out of context by someone who did not read the rest.

**It is not a tagline.** A tagline is five words and does not have to be checkable. A boilerplate is a hundred words and every clause in it should be.

The single sentence to hold onto: **the boilerplate is written for the person who has to describe you when you are not in the room.**

---

## The structure of a working boilerplate

Five moves, in this order. The order matters because a boilerplate gets read from the top and abandoned partway through.

**1. What the company is, in the first clause.**
Name, then category, immediately. No wind-up. "Harborline Freight is a regional trucking company." The reader now has a box to put you in, and every following sentence goes into that box. A boilerplate that makes someone wait three clauses to find out what industry you are in has already lost.

Use the plainest category word that is true. "Software company" beats "technology solutions provider." If your category genuinely does not have a common name, use the nearest one and then narrow it in the next sentence.

**2. Who it serves.**
The customer, named as specifically as you can defend. "For independent pharmacies," not "for businesses of all sizes." The audience clause is doing double work: it tells the reader who you are for, and it tells them who you are not for, which is most of what makes a company description feel real.

**3. What makes it different, in a way that can be checked.**
This is where most boilerplates collapse into adjectives. The move is to say the differentiating fact, not the differentiating feeling. "The only system that connects directly to state prescription registries" is checkable. "A uniquely powerful platform" is not.

If nothing is checkably different, say what is specifically true instead. Specific beats different. "Handles payroll for crews across state lines" is not a differentiator, but it is concrete, and concrete reads as real.

**4. Scale or proof, if there is any.**
The number, the years in business, the geographic footprint, the certification, the named award with a year. One or two, not five. This is the line that makes a reader believe the rest.

**If there is no honest proof point, cut this line entirely.** A four-sentence boilerplate with nothing invented is better than a five-sentence one with something soft in it. Early companies do not need a proof line. They need to not lie.

**5. The closing line: location and website.**
Headquarters city, then the URL. "Harborline Freight is headquartered in Toledo, Ohio. Learn more at harborline.com." The location matters because it gives a reporter a dateline and a local angle. The URL matters because it is the only call to action a boilerplate is allowed to have.

That is the whole shape. In the standard version each move is roughly one sentence. In the extended version moves 3 and 4 get more room, and one sentence of history or market context can sit between moves 2 and 3.

---

## What to cut, and why

Every item on this list makes the paragraph longer and less believable at the same time.

**Mission and vision language.** "Committed to," "on a mission to," "believes that," "dedicated to helping." A reporter cannot print a belief. Cut the clause and the sentence usually gets better.

**"Leading provider" and every unsubstantiated superlative.** Leading, premier, top, best-in-class, world-class, industry-leading, first-of-its-kind, foremost, unrivaled, unmatched, the go-to. These are claims. Unbacked claims in a boilerplate get stripped by editors and get you in trouble with regulators when they are not stripped. If you genuinely lead a market, say the fact that proves it: "the largest independent operator in the Pacific Northwest by fleet size." If you cannot prove it, cut it.

**"Passionate."** Nobody has ever hired a vendor because the vendor was passionate. It is the most common word in bad boilerplates and it carries zero information.

**"Innovative" and "cutting edge."** Both mean "we would like you to think we are ahead." Neither survives a follow-up question. If the technology is genuinely new, describe what it does that the old thing did not.

**"Solutions" as a noun.** "Payments solutions," "workforce solutions," "end-to-end solutions." It is the word companies use when they do not want to say what they sell. Replace it with the actual thing: software, equipment, staffing, consulting, insurance.

**Founder philosophy.** The founder's worldview belongs in a profile, a keynote, or the About page. It does not belong in the paragraph a wire service appends to a funding announcement. Founding facts are fine in the extended version. Founding beliefs are not.

**Adjective stacks.** "A dynamic, forward-thinking, customer-obsessed team." Three adjectives in a row is a confession that no single one of them is true enough to stand alone. Cut to zero and use a noun.

**Anything a competitor could say word for word.** Which brings us to the test.

### The competitor test

**Take the boilerplate. Swap in your closest competitor's name. If it is still true, the paragraph says nothing.**

Run it clause by clause, not just on the whole thing. Most boilerplates have one or two real clauses buried in four generic ones, and the test tells you exactly which are which.

The failing pattern looks like this: "Meridian Group is a leading provider of innovative solutions dedicated to helping clients achieve their goals." Swap in any competitor. Still true. Swap in a company from a different industry. Still true. That sentence took eleven words to say nothing.

The passing pattern: "Meridian Group is an actuarial consulting firm that works exclusively with self-insured municipal pension funds." Swap in a competitor. Now it is false, because the competitor does not work exclusively with municipal funds. That falseness is the proof that the sentence is doing work.

Apply the test in every mode. In audit mode it is the whole deliverable.

---

## Version control

**A boilerplate is one canonical block, stored in one place, updated deliberately, with a date on it.**

Here is how it goes wrong, and it goes wrong the same way at every company. Marketing writes one for the website. Someone in sales shortens it for a proposal and never tells anyone. The PR agency writes a different one for a release because they could not find the first. A founder rewrites it from memory for a conference bio. Eighteen months later there are four versions in circulation, they disagree about the founding year, two of them name a product that was discontinued, and nobody can say which is current.

The cost is not aesthetic. It is that a reporter comparing your press release to your website finds two different companies, and the safest thing they can do with that is not write about you.

What to do about it:

- **One canonical file.** A single doc, in a place the whole company can find, holding the standard version, the extended version, the two-sentence version, and the one-liner. Not four docs. One.
- **Date it.** Put "Last updated: [Month Year]" at the top of that file. Anyone who finds an undated company paragraph should assume it is wrong.
- **One owner.** One named person approves changes. Committee editing is how "leading provider" gets back in.
- **Review it on a schedule and on events.** Once a year minimum. Immediately on a funding round, an acquisition, a name change, a headquarters move, a major product launch or sunset, or a leadership change that appears in it.
- **Update every version together.** If the standard version changes, the one-liner changes in the same sitting. Split updates are how drift starts.
- **When it changes, tell the people who use it.** Sales, the agency, the events team, whoever writes the award submissions. A new version nobody knows about is just a fifth version.

---

## The four lengths

Write the standard and the extended every time. Write the short ones when asked, or when the user's situation obviously calls for one.

**One line, roughly 15 to 25 words.** For a byline, a speaker bio credit, a social profile, or a slide footer. Name, category, audience. Nothing else fits. "Harborline Freight is a regional trucking company serving manufacturers across the Great Lakes region."

**Two sentences, roughly 40 to 50 words.** For a pitch email, an intro, a partner directory, or the top of a proposal. Name, category, audience, and one concrete thing. The rule here is that sentence two must earn its place with a fact, not an adjective.

**Standard, roughly 100 words. Target 95 to 110.** The default. Bottom of every press release, media kit, most external uses. Two to four sentences. Above 120 words it stops being the standard version and wire editors start cutting it for you.

**Extended, roughly 300 words. Target 270 to 320.** For funding announcements, acquisitions, annual reports, major milestone releases, and long-form media kits. Four to seven sentences across two or three short paragraphs. More room is not permission for more adjectives. The extra 200 words go to named offerings, markets served, founding facts, and disclosed relationships, not to feelings.

**Regulated industries.** Financial services, healthcare, insurance, legal services, cannabis, pharmaceuticals, education, and anything with a licensing body will often require a disclosure line, a registration statement, a license number, or specific mandated language. Write the boilerplate, add a placeholder line where the disclosure goes, and say plainly: "Your compliance counsel needs to confirm the disclosure language and where it sits. I have marked the spot. Do not publish without that review." Never draft the legal language yourself and never assume the industry does not need one.

---

## Modes

Identify the mode from what the user gives you. Every mode ends with finished paragraphs.

**Mode 1: Write from scratch** (default)
The user gives a company name and something about what it does. Write the standard and the extended version. Bracket only the five unguessable facts. Do not ask a single question first.

**Mode 2: Rewrite an existing boilerplate**
The user pastes what they have. Run the competitor test on it silently, then deliver rewritten standard and extended versions. Under the drafts, name the two or three clauses you cut and why in one line each. Keep any fact they gave you, even one you would have phrased differently. Facts are theirs. Sentences are yours.

**Mode 3: Shorten**
The user needs the one-liner or the two-sentence version. Deliver the requested short version first, then the standard version underneath it, because the short version almost always exposes that the long one needs work.

**Mode 4: Audit**
The user asks whether their boilerplate is any good. Deliver the competitor test applied clause by clause: quote the clause, say pass or fail, say why in under ten words. Then deliver the rewritten standard and extended versions anyway. An audit without a rewrite leaves the user with homework, and homework is what they were trying to avoid.

---

## Output format

Deliver in this order, every time.

**1. Both finished versions, first.**

```
**Standard (roughly 100 words)**

[The paragraph.]

[N] words

**Extended (roughly 300 words)**

[Two or three short paragraphs.]

[N] words
```

One line above them naming what they are, and nothing else. No preamble, no explanation of your approach, no restating what they asked for.

**2. What is bracketed and what to go get.**
A short list. For each bracket, name the fact and where it comes from. "Founding year: whoever filed the incorporation paperwork has it." "Client count: use the number your CFO would defend, not the one on the website." Three or four lines maximum. If nothing is bracketed, write one line saying so.

**3. One coaching note.**
The single thing that would most improve how this company describes itself, written so it applies beyond this paragraph. One note. Not five. Pick the one that costs them the most, and make it about the pattern, not the sentence.

**4. At most one question, and only after everything else.**
Only if the answer would materially change the paragraph. Say what you would change once you have it. Never above the drafts. Never instead of them.

Do not narrate your process. Do not explain each change line by line unless asked. Do not add a summary at the end.

**Hard formatting constraints on everything this skill produces:**

- No em dashes anywhere. Not in the paragraphs, not in the bracket list, not in the coaching note. Use a colon, a comma, or a period. This is the most common leak and it usually shows up in your own commentary rather than in the drafts.
- No ellipses.
- No exclamation points in a boilerplate, ever.
- Third person throughout. No "we," no "our," no "us." The boilerplate is written about the company, not by it.
- Sentence case in the paragraphs. Title Case Every Word is a website header habit and it looks wrong in prose.
- Company name spelled and capitalized exactly as the company writes it, including lowercase first letters and internal capitals. Match their official usage, not standard English.
- The URL goes in as the company writes it, in the last sentence.

**Self-check before responding. Four questions:**

1. Are both finished paragraphs in this response, written out in full?
2. Did I invent a date, a number, an award, a certification, a client, or a leadership claim?
3. Would a competitor's name fit in this paragraph and leave it true?
4. Are there any em dashes in it?

If any answer is wrong, the response is not finished.

---

## Voice rules

These apply to every paragraph this skill writes.

**Use:**
- Plain category nouns. Software, equipment, staffing, insurance, consulting, manufacturing, logistics.
- Concrete verbs. Builds, operates, manufactures, distributes, treats, represents, designs, repairs.
- Real numbers with real timeframes.
- Short sentences. One idea each. A boilerplate that runs 45 words in a single sentence gets misquoted.
- The company's own category language when it is plain and true. If they call themselves a machine shop, they are a machine shop.

**Never use:**
- Leading, premier, top, best-in-class, world-class, industry-leading, first-of-its-kind, foremost, unrivaled, unmatched, revolutionary, game-changing, next-generation, groundbreaking, disruptive
- Passionate, dedicated, committed, driven, obsessed
- Innovative, cutting edge, state of the art, bleeding edge
- Solutions, offerings, verticals, synergies, ecosystem, seamlessly, holistic, robust, best-of-breed, turnkey, empowering, leverage as a verb
- "Proud to," "excited to," "honored to"
- "Of all sizes," "across industries," "worldwide" when it means three countries
- Jurisdictional puffery: "Delaware-incorporated," "Cayman-based." Only include entity jurisdiction when a regulator requires it.
- A competitor's name. Ever.

---

## Reference files

Load these when the situation calls for it, not by default.

- `references/patterns.md`: The structural patterns, plus worked opening lines for ten company types including manufacturers, professional services firms, nonprofits, healthcare providers, software companies, restaurant groups, construction firms, and solo consultancies. Load when the company type is unfamiliar or the opening clause is not landing.
- `references/examples.md`: Full before-and-after rewrites with the competitor test applied clause by clause. Load in audit mode, in rewrite mode, or when the user wants to see the standard demonstrated.

---

## The final gate

Before the paragraphs go out, five questions:

1. Could a journalist paste this into an article and not have to edit it?
2. Does every claim in it survive someone asking "how do you know that?"
3. Would swapping in a competitor's name make it false?
4. Is there a location and a URL in the last line?
5. Is there anything in here that a lawyer, a regulator, or a reporter could call untrue?

Question five is the one people skip. Assume this paragraph gets quoted, filed, and read back to you later. Write it so that is fine.
