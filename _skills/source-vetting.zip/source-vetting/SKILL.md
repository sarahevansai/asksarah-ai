---
name: source-vetting
description: >
  Thesis-first research and source vetting. Turns any topic, claim, draft, or list of links
  into a research brief built on real, named, checkable sources, each one validated against
  publisher incentive, primary-versus-retelling, age, methodology, traceable numbers, and
  editorial standard. Every run also returns a rejection log naming what was thrown out and
  why. Use whenever someone has to write something defensible: an analyst, a consultant, a
  policy writer, a journalist, a student, a founder, a researcher, an investigator. Trigger on
  "find sources for this," "is this source credible," "fact check these claims," "research
  brief," "back this up with data," "where did this statistic come from," "can i cite this,"
  "vet these links," "is this study any good," "find me evidence for," "what is the primary
  source," "audit this draft for unsupported claims," "pull the stats out of this," "is this
  outlet trustworthy," "how old is too old for this citation," "did i make this number up,"
  or any request to research, source, verify, or defend a written claim. Also trigger
  unprompted when a user pastes a draft that asserts numbers with no citation, cites a source
  that sells the thing it measures, or repeats a statistic with no visible origin. When in
  doubt, run it. An unsourced claim is a liability the moment it is published.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Source Vetting

Most bad writing is not badly written. It is badly sourced.

The failure is almost never a sentence. It is a number nobody can trace, a study that says something different from what the article claimed it said, an outlet that turned out to be selling the product it was measuring, or a statistic that has been passed hand to hand for six years and originated in a vendor's marketing deck.

This skill does two things. It builds research briefs that start from what you are arguing rather than what you are searching, and it kills sources that cannot survive a hostile reader.

---

## The #1 rule: always deliver the brief

**Every run ends with an actual research brief containing real, named, checkable sources and a rejection log. No exceptions.**

Not a search strategy. Not a list of places to look. Not "try Google Scholar, government statistics portals, and industry associations." Those are not deliverables. They are the homework this skill exists to remove.

This holds even when:

- The topic the user gave you is thin. **Form the thesis yourself, say so in one line, and produce the brief.** One line, like this: "You gave me a topic, not an argument, so I am arguing that [thesis]. Tell me if you wanted a different angle and I will re-source it." Then the brief.
- The user only asked whether one link was any good. Answer that, then deliver the brief section it belongs to, or the replacement sources if it failed.
- The user asked a process question. Answer it in three lines, then do the research and hand over the brief.
- You could only source four of the six sections. Deliver the four with sources and put the other two in the unsourced-claims section by name. A partial brief that is honest about its gaps is a deliverable. A promise to research later is not.
- Nothing could be sourced at all. Then the brief is the rejection log plus the unsourced-claims section, and it is still a real answer, because it tells the user their argument currently has no evidentiary base. That is expensive information delivered cheaply.

**Never end a response with a question instead of a brief.** If a question would sharpen the work, deliver the brief first and ask it at the very bottom.

**Never hand back an empty template.** A brief with headings and blank source slots is the most common way this rule gets broken while appearing to be followed.

---

## THE HARD HONESTY RULE

**This is the most important thing in this file. Everything else is secondary to it.**

**Never fabricate a source, a URL, a study, a statistic, a quote, an author, a date, a journal, an institution, or a finding. Not once. Not as a placeholder. Not as an illustration. Not to make a section look complete.**

If a source cannot be verified, it does not go in the brief.

If a claim needs support you cannot find, the brief says so explicitly, in its own section, and names what would need to be found to close the gap.

### Why this rule outranks everything else

A single invented citation destroys the credibility of the entire document and of the person who published it.

Not the paragraph. The document, and the author. A reader who catches one fake reference does not conclude that one reference was wrong. They conclude that nothing in the piece was checked, and they are right to. Every other number in the piece now has to be independently re-verified by the reader, which nobody does. They stop reading and they tell other people to stop reading.

The damage is asymmetric and it is permanent. Ninety-nine verified sources plus one fabricated one is not a 99% score. It is a retraction, and in some settings a career.

This is the specific failure mode this skill exists to prevent. Every other rule in this file is a way of enforcing this one.

### What fabrication actually looks like

It rarely looks like lying. It looks like helpfulness. Watch for these:

- **The plausible citation.** A real-sounding journal, a real-sounding author, a real-sounding year, assembled rather than retrieved. This is the most dangerous output there is, because it survives a skim.
- **The confident round number.** A statistic that fits the argument perfectly and has no source attached. If you cannot say where a number came from, it is not a number, it is a guess wearing a percent sign.
- **The upgraded finding.** A real study that said something adjacent, restated as if it said the thing the thesis needs. This is fabrication even though every proper noun is real.
- **The reconstructed URL.** A link built from a pattern rather than retrieved from an actual page. A URL you did not open is not a citation.
- **The borrowed statistic.** A number lifted from an article that cited it, presented as though you read the underlying source. If you did not open the primary source, say so.
- **The invented quote.** A paraphrase presented in quotation marks. Quotation marks are a promise that these are the exact words. Keep it or drop the marks.

### How to tell a real source from a plausible-sounding one

Run these before anything enters the brief:

1. **Did you open it in this session?** Not "does it exist." Did you retrieve the page and read what it says. If not, it does not go in.
2. **Does the link resolve to the specific page, and does that page contain the claim?** A live homepage for a real institution is not evidence that the study exists.
3. **Can you name the author, the publishing body, and the publication date from the page itself?** If any of those three had to be inferred, flag it in the brief.
4. **Does the number on the page match the number you wrote down, exactly, including the unit and the population it describes?** A figure about one country, one industry, or one year quoted as though it were universal is a misuse even when the digits are right.
5. **Does the source say the thing, or does it merely sit near the thing?** Read the sentence you are relying on, in context, including the paragraph after it. Findings are often hedged in the very next line.
6. **Would this survive a hostile reader with a search bar?** Assume someone motivated to discredit the piece will click every link. Write for that reader.

### Verify the primary source, never the article citing it

**Always chase a statistic to its origin and cite the origin.**

News coverage, industry blogs, consultancy summaries, and aggregator posts are maps, not destinations. Use them to find the underlying study, report, dataset, filing, or release. Then open that, confirm the figure, and cite that.

Three reasons this is non-negotiable:

- **Retellings drift.** A figure gets rounded, then a qualifier gets dropped, then a subgroup finding becomes a general one. By the fourth retelling the number means something the original authors would not recognize.
- **Retellings die.** Secondary articles get deleted, paywalled, or rewritten. Primary sources persist and are archived.
- **Retellings hide the method.** You cannot judge a survey you have not seen the methodology for, and the article citing it almost never reproduces the sample size, the population, or the question wording.

If the primary source cannot be located, that is itself a finding. Say so in the brief: the claim circulates widely, the origin is not locatable, treat it as unsupported. That sentence is worth more than a citation to whoever repeated it most recently.

---

## The one flip: thesis first, then sources

Generic topic research returns a reading list. Thesis-first research returns a citable brief.

The flip is this. Do not begin with "what is out there about this topic." Begin with **"what am I arguing, specifically, in this sentence."** Then go find whether it is true and who established it.

This ordering does three things at once. It makes searches specific enough to succeed. It makes the brief usable, because every source is already attached to the place it is needed. And it exposes the argument you cannot support, early, while there is still time to change the argument instead of defending an unsupportable one in public.

**Decide what you are arguing before you go looking.** If the user has not decided, decide for them, say so in one line, and proceed.

One honest warning about the failure mode of thesis-first work: it can slide into looking only for confirmation. The guard is simple and it is mandatory. **Search for the strongest disconfirming evidence for every thesis, and record what you find.** If the disconfirming evidence is stronger than the supporting evidence, the brief says the thesis is wrong and proposes the corrected one. A brief that never contradicts the user is a brief that was not really researched.

---

## Thesis per section, not sources per topic

**Every section of the piece gets its own argument and its own sources.** Not a pile of links assigned to a subject.

One thesis per section, heading, chapter, slide, or numbered point. Six headings means six theses. Each thesis is a single declarative claim that the section is trying to establish, written as a full sentence, in a form that could be true or false.

The theses must be genuinely different claims, not one claim rephrased. That is what separates a piece that builds an argument from one that circles a topic.

**The same source can support several sections. The same thesis cannot appear twice.** A single strong study often supports three different sections, each pulling a different finding out of it. That is the ideal pattern: fewer sources, more angles, all of them checkable.

### Example

Take a report section on hospital nurse staffing.

**Right. Three sections, three distinct claims, one shared primary source plus corroboration:**

- Section 1 thesis: "Nurse staffing shortfalls concentrate in night and weekend shifts rather than spreading evenly across the week." Supported by a national health workforce survey, shift-level breakdown.
- Section 2 thesis: "The shortfall is driven more by attrition within the first two years of practice than by insufficient graduates entering the field." Supported by the same survey's tenure data, corroborated by a nursing licensure body's annual registration figures.
- Section 3 thesis: "Facilities that changed scheduling practice saw retention move before compensation changes took effect." Supported by a peer-reviewed cohort study.

Each section now has an argument, a source, and a reason to exist.

**Wrong. Same claim three times:**

- Section 1: "There is a nursing shortage."
- Section 2: "Hospitals do not have enough nurses."
- Section 3: "Nurse staffing is a problem."

**Wrong. A topic, not a thesis:** "Nursing workforce." Research drifts and returns a reading list.

**Wrong. A claim only the subject can prove:** "Our facility has the best retention program in the region." No third party has established this, so no third party can support it. Either find an external comparative measure or move the claim to the unsourced section and label it as a position rather than a finding.

---

## The six vetting questions

Every source answers all six before it enters the brief. Record the answers in the brief's validation line, compressed. Full criteria and borderline judgments are in `references/vetting-rules.md`.

**1. Who published it, and what is their incentive?**
Name the publishing body, not just the website. Then ask what outcome benefits them. A trade association measuring the growth of its own industry, a consultancy sizing a market it sells advice into, a government agency reporting on a program it administers, an advocacy group counting the problem it was founded to address: none of these are automatically disqualified, and all of them need the incentive stated in the brief. Incentive does not mean dishonesty. It means the reader deserves to know who paid and who benefits.

**2. Is this a primary source or a retelling?**
Primary means the body that produced the data is the one publishing it: the agency that ran the survey, the researchers who ran the study, the company filing its own regulatory disclosure, the archive holding the original document. Everything else is a retelling. Retellings are for navigation only. Cite the origin.

**3. How old is it, and does age matter for this specific claim?**
Not "is it recent." Ask whether the underlying reality has changed since publication. See the age rule below.

**4. Is the methodology stated?**
For anything empirical you should be able to find the sample size, who was sampled and how, what was actually asked or measured, over what period, and what the authors say the limitations are. A finding with no visible method is an assertion with a chart. If the method is not stated, either find the technical appendix or downgrade the source and say why in the brief.

**5. Does the number have a traceable origin?**
Follow it back until you reach the body that generated it, or until the trail dies. If the trail dies, the number does not go in the brief as fact. Statistics that circulate without an origin are the single most common contaminant in professional writing, and they are almost always older, narrower, or more qualified than the way they are being used.

**6. Does the outlet have an editorial standard?**
Look for a named author with a traceable identity, a stated corrections or retraction policy, a masthead or editorial team, disclosure of funding and conflicts, and evidence that corrections actually get issued. An outlet that has never corrected anything has either never been wrong or does not correct. Assume the second.

### Soft signals that raise a source without being gates

These do not admit or reject on their own. They rank.

- A named author with relevant, verifiable expertise
- Peer review, and where relevant, the fact that the data is available for reinspection
- Preregistration for studies designed to test a hypothesis
- Independent replication or corroboration from an unrelated body
- Data density: figures, tables, and appendices rather than assertion
- Being cited by other work that is itself credible
- Plain acknowledgment of limitations, which is a strong honesty signal

---

## The age rule

**Default cutoff: nothing older than three years. Prefer two.**

The reasoning is not that old work is wrong. It is that the reader cannot tell whether the world moved, so a stale citation forces them to do work you should have done. It also signals that the newer literature was not checked, which is exactly the impression a defensible document cannot afford.

Tighten to eighteen months when the subject is fast moving: technology adoption, pricing, regulation in flight, labor markets in a disrupted period, anything measuring behavior that changed recently.

**Exceptions, each of which must be labeled in the brief as an explicit age exception with one line of justification:**

- **The foundational work.** The paper or dataset that established the concept, where nothing has superseded it. Cite it and, where one exists, cite a recent source confirming it still holds.
- **Legally or historically fixed material.** A statute as enacted, a court ruling, a treaty, an archival record, a historical event. These do not age, though their current status can change, so check whether they were amended, overturned, or superseded.
- **Long-cycle phenomena.** Demographic, geological, epidemiological, and climate series where the meaningful interval is decades. Recency here would be a mistake, not a virtue.
- **Deliberate historical comparison.** When the age is the point, because you are showing change over time. Say so in the brief.
- **The only thing that exists.** Sometimes one study is the entire literature. Use it, state its age, state that it is unreplicated, and put the missing replication in the unsourced-claims section.

Always distinguish the **publication date** from the **data collection date**. A report published this year using survey data gathered four years ago is a four-year-old finding. Record both dates in the brief whenever they differ.

---

## The exclusion gates

Each of these is a rejection. Each one has a defined next move, because rejecting a source without replacing it is half a job.

**1. A vendor page selling the thing it is measuring.**
A seller's own measurement of the need for what they sell is marketing, whatever the design of the page. Reject.
*What to do:* Read the page for the sources it cites, follow those to the origin, verify, and cite the origin. Never cite the seller. A seller's page is useful as a map and never as evidence.

**2. Content marketing dressed as research.**
The signals: a report with a download form in front of it, no methodology section, round numbers, a conclusion that maps exactly onto a product category, no named researcher, and a design budget larger than its evidence base. Reject.
*What to do:* Same as above. Mine it for citations and discard the wrapper. If it contains original data with a real method and the sponsor is disclosed, it can be admitted with the sponsorship stated inline, which is a downgrade rather than a pass. Say in the brief that the finding is sponsor-funded so the reader can weigh it.

**3. A survey run by the company that benefits from the result.**
Includes surveys commissioned by a company and executed by a third party, which is the same conflict with a subcontractor attached. Reject as an independent finding.
*What to do:* If the underlying result is important, look for an independent measurement of the same thing. If none exists, that is a real finding: report that the only available measurement is interested, and put the independent measurement in the unsourced-claims section as what would need to be found.

**4. An outlet with no named author or corrections policy.**
No byline, no masthead, no way to contact anyone, no record of ever correcting anything. Includes most content farms and syndicated listicles. Reject.
*What to do:* Take the underlying claim and re-source it from an outlet that can be held responsible. If the claim exists nowhere accountable, it is not a fact yet.

**5. A statistic circulating with no primary source anyone can find.**
The tell: many pages assert it, all of them cite each other or nothing, and the trail ends in the air. Reject.
*What to do:* Say so explicitly in the brief: this figure is widely repeated and has no locatable origin. Do not use it. Then either find a real measurement of the same phenomenon or list it as an open gap. Naming an orphan statistic as an orphan is one of the most valuable things a brief can do, because it stops the piece from repeating it.

**6. Anything behind a claim the user cannot check.**
Paywalls with no accessible abstract or method, private datasets, unpublished internal figures, off-the-record conversation, a document you can see but the reader cannot. Reject as a load-bearing citation.
*What to do:* Find the public equivalent: the preprint, the press release with the method attached, the regulatory filing, the archived version, the agency's own data portal. If nothing public exists, the claim can still appear in the piece, but it must be labeled as unverifiable by the reader, and it cannot be the sole support for anything important. A reader who cannot check a claim is being asked to take it on faith, and the whole point of a brief is to not require faith.

**Also reject on sight:** announcement-style promotional copy, aggregator listicles with no original data, anonymous individual posts with no institutional affiliation and no original data, circular citation chains where two sources cite each other, and any source you could not actually open.

---

## The rejection log

**Every run produces one. An empty rejection log is a red flag, not a clean bill of health.**

If nothing was rejected, either the search was too narrow or the gates were not applied. Retrace.

Format, one line per rejected source:

```
| Source (name and link) | Why rejected | What replaced it |
```

Keep the reason short and specific: "vendor selling the category," "sponsored survey, sponsor benefits from the result," "2019 data, subject moved," "no locatable primary source," "no named author, no corrections policy," "retelling, cited the origin instead."

### Why it matters more than it looks

**It stops the same bad source from being re-found next week.** This is the whole point. Bad sources are usually well optimized and sit at the top of every search. Without a written record, the next person on the topic, including you in a month, finds the same attractive vendor report and has to re-run the same evaluation. Half the time they will not, and it goes in.

It also does three other jobs:

- **It proves the work happened.** A brief with a rejection log demonstrates that alternatives were considered. A brief without one might just be the first page of results.
- **It answers the challenge before it arrives.** When an editor, a reviewer, a client, or an opposing analyst asks why you did not use the obvious source everyone else uses, the answer is already written down with a date on it.
- **It compounds.** Over a few months the log becomes a map of which bodies in a subject area are reliable and which are marketing. That map is worth more than any single brief.

Carry the log forward between runs on the same subject. Never re-evaluate a source that was already rejected for a durable reason, and do re-evaluate when the reason was age, because age expires.

---

## Modes

Determine the mode from what the user gives you. Every mode ends with a brief and a rejection log.

**Mode 1: Build a research brief from a thesis.** The default. The user has an argument, an outline, a draft, or a topic. Break it into one thesis per section, source each thesis, log rejections, and name what could not be sourced. If they gave you a topic rather than an argument, form the thesis yourself and say so in one line.

**Mode 2: Vet a list of sources the user already has.** Run all six questions and all six gates on each. Return a verdict per source: use, use with a stated caveat, or reject with the reason. For every rejection, find a replacement rather than leaving a hole. Deliver the surviving sources as a brief organized by what each one supports, not as a list of links in their original order.

**Mode 3: Find support for a specific claim.** The user has one sentence they need to defend. Restate the claim precisely, including the population and time period it implicitly covers, because most claims are broader than the evidence for them. Find the primary source. Then report one of three outcomes: supported, supported only in a narrower form (and give the narrower form as a rewritten sentence they can use), or unsupported. Unsupported is a legitimate and valuable answer. Deliver it plainly.

**Mode 4: Extract the checkable statistics from a document.** Pull every number that makes an empirical claim. For each: the figure with its unit, what it actually measures, the population and time period, the stated source, whether that source is primary, and whether you could verify it. Sort into verified, misstated (the source says something different, and give the correct version), and unsourced. Be exhaustive rather than selective. The user decides which ones matter.

**Mode 5: Audit a finished piece for unsupported claims.** Read for assertions that a hostile reader would demand support for: numbers, comparisons, superlatives, causal claims, characterizations of what a group believes or does, and predictions stated as facts. For each, say whether it is supported, supported by something weaker than it appears, or unsupported. Then source what can be sourced and list the rest. Flag causal language sitting on correlational evidence separately, because it is the most common and most damaging error in otherwise careful work.

---

## Output format

Deliver in this order, every time.

**1. The brief, first.**

Organized by section, in the order the piece runs. For each section:

```
### Section [n]: [Section name]

**Thesis:** [One declarative sentence. The claim this section establishes.]

**Source:** [Title], [publishing body], [publication date] ([data collection date if different])
**Link:** [Live URL, retrieved this session]
**Type:** Primary / Retelling used to reach a primary source
**What it supports:** [The specific finding, quoted or precisely paraphrased.]
**Key figures:** [Each number with its unit, and what it measures, and the population it covers.]
**Validation:** Publisher and incentive / primary status / age and whether age matters here / method stated / number traceable / editorial standard. One compressed line.
**Caveats:** [Sample limits, scope limits, conflicts, anything the reader deserves to know. Write "none noted" only if you looked.]

[Second source for this section if one exists, same shape.]

**Counter-evidence checked:** [What contradicting work you looked for and what you found. "None located" is a valid answer only if you actually searched.]
```

Where a section needs it, add a **Link priority** line naming which source is the one to cite inline and which is supporting.

**2. The rejection log.**

The table. Every source evaluated and thrown out, the reason, and the replacement.

**3. What could not be sourced.**

Its own section, never buried and never omitted. For each unsupported claim:

- The claim, quoted as it currently stands
- Why it could not be supported: nothing exists, only interested parties measure it, the primary source is not locatable, the only evidence is behind a wall the reader cannot pass, the evidence contradicts the claim
- **What would need to be found** to close the gap, named specifically: which body would have to publish what, or which measurement would have to exist
- The recommended action: cut it, soften it to the version the evidence supports (give that sentence), label it as opinion, or go get primary information such as an interview, a records request, or original analysis

This section is the honest core of the deliverable. Never pad it out of existence and never let a brief ship without it, even when it is one line saying every claim was sourced.

**4. One coaching note.**

The single research habit that would most improve their next piece. One note, not five. Pick the one that costs them the most. This is what the user is actually paying for.

**5. At most one question, and only after everything above.**

Only if the answer would materially change the brief. Say what you would change once you have it. Never above the brief. Never instead of it.

**Hard formatting constraints:**

- No em dashes anywhere. Not in the brief, not in the log, not in the coaching note. Use a colon, a comma, or a period.
- Every URL is a link that was actually opened in this session.
- Quotation marks mean exact words. Paraphrase without them.
- Every figure carries its unit and the population it describes.
- Distinguish "the source says" from "this implies." Never blur them.

**Self-check before responding. Four questions:**

1. Is every source in this brief one I actually retrieved and read?
2. Is there a rejection log with real entries in it?
3. Is there an unsourced-claims section that honestly reflects the gaps?
4. Are there any em dashes?

If any answer is wrong, the response is not finished.

---

## Language rules

**Cut on sight:**

- "Studies show," "research suggests," "experts say," and "it is widely known." Name the study, the researcher, the expert. If you cannot name them, you do not have them.
- "Up to," which quietly converts a ceiling into a typical value.
- Percentages with no base. Forty percent of what, out of how many.
- "Leading," "top," and "best in class" as descriptions of a source's authority.
- Causal verbs attached to correlational findings: causes, drives, leads to. Use "is associated with" until a study design earns the stronger verb.
- Ranges presented as points, and points presented without their confidence interval when the source gave one.

**Keep:**

- The publishing body's actual name.
- Both dates when publication and data collection differ.
- The population a figure describes, every time.
- The word "unsupported" when a claim is unsupported. It is a normal word and it protects the user.

---

## Reference files

Load these when the situation calls for it. Do not load both by default.

- `references/vetting-rules.md`: The full criteria and gates, with worked judgments on borderline cases. Load when a source is genuinely arguable, when a whole class of sources is in question, or when the user challenges a rejection.
- `references/examples.md`: Three complete research briefs on different subjects, showing thesis per section, sourced sections, the rejection log, and the unsourced-claims section. Load for calibration on what finished output looks like.

Both reference files describe sources generically for illustration. A real run must use real, retrieved, verifiable sources with live links.

---

## The final gate

Before a brief goes out, five questions. If any answer is no, it is not ready.

1. Did I open every source I am citing, in this session?
2. Does every section have its own distinct claim rather than a share of one topic?
3. Did I chase every statistic to its origin and cite the origin?
4. Is the rejection log populated, and does it name the replacement for each rejection?
5. Does the unsourced-claims section name what would need to be found, specifically enough that someone could go find it?

The one people skip is the third. Assume a hostile reader with a search bar and unlimited patience will click every link in the finished piece. Write the brief for that reader, and the piece will survive anyone.
