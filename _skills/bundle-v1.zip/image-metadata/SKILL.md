---
name: image-metadata
description: >
  Writes all four image attachment fields (Alt Text, Title, Caption, Description) plus a
  clean filename for any image, ready to paste into WordPress or any CMS, store, or site
  builder. Accessibility comes first: alt text is written for the person using a screen
  reader, not for a keyword tool. Use whenever an image is going onto a website, blog
  post, product page, email, or media library. Trigger on "write alt text for this,"
  "fill in the image fields," "wordpress image metadata," "what should the caption be,"
  "rename this image," "make this image accessible," "audit my image metadata," or any
  request about alt attributes, captions, or image titles. Also trigger unprompted when
  a user shares an image headed for a website, or pastes alt text that says "image of,"
  is keyword-stuffed, or is empty on a meaningful image. When in doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Image Metadata

Every image uploaded to a website has four text fields attached to it, and almost nobody fills them in properly. They get skipped, or worse, they get stuffed with keywords by someone who thinks alt text is an SEO field.

It is not. Alt text is how a blind person experiences your image. That is the entire point of it, and it is the reason this skill exists.

This skill writes all four fields, plus the filename, for any image, in a form you can paste straight in. It works for WordPress, which is where the four-field structure comes from, and it works just as well for Shopify, Squarespace, Webflow, Wix, Drupal, Ghost, HubSpot, Contentful, or a hand-built HTML page. The field names shift between platforms. The thinking does not.

---

## The #1 rule: always deliver all four fields

**Every run ends with all four fields written out, filled in, and ready to paste. Plus the filename. No exceptions.**

Not a question about where the image will be used. Not an explanation of what good alt text contains. Not a checklist for the user to apply themselves. The finished fields.

This holds even when:

- The user shared the image with no context at all. Write the fields from what is visible, state the assumption in one line, and offer to adjust.
- The user only asked about alt text. Give them the alt text, then hand them the other three anyway.
- The user asked whether their existing metadata is any good. Answer the question in one line, then deliver the corrected version.
- The image is decorative. Then the deliverable is an empty alt attribute plus the reason, and the other fields still get written for the media library.
- The user shared five images. Five blocks, one per image.

**Never end a response with a question instead of the fields.** If a missing detail would change the answer, deliver the fields first, then ask the one question that would sharpen them, and say what you would change.

**Never describe what alt text should contain instead of writing it.** "Your alt text should describe the product and its key features" is not a deliverable. "Navy wool overcoat with notched lapels, shown from the front on a plain grey background" is.

### The one-line assumption

When you do not know where the image is going, do not stall. Pick the most likely use, write the fields for it, and say so in one line underneath:

"Wrote this as a blog post header. If it is a product page image, say the word and I will rewrite the alt around the product."

One assumption line. Not three. Not a list of scenarios.

---

## Accessibility first

This is the heart of the skill, and it is the part everything else is built around.

Alt text exists for people who cannot see the image. Screen reader users, people on slow connections where images fail to load, people whose browsers block images. Treating alt text as a place to put keywords is why most alt text on the internet is useless to the people it was invented for.

**The test:** if you read the alt text aloud to someone who cannot see the screen, do they now know what the sighted reader knows? If yes, it works. If they get a list of search terms, it failed.

The rules, in order of how often they get broken:

**1. Describe what is in the image and what it conveys in context.** Not what you want to rank for. The alt text serves the reader on the page, not the crawler. Relevant words show up naturally when you describe the image honestly, and that is the only SEO benefit worth having.

**2. No "image of," "picture of," "photo of," or "graphic of."** The screen reader already announces that it is an image before it reads your text. "Image of a woman at a podium" is heard as "image, image of a woman at a podium." Start with the subject.

**3. Aim for roughly 125 characters.** That is about one clear sentence. Some screen readers cut off around 125 to 150, and a listener loses the thread in anything longer. If the image genuinely needs more, it needs a long description instead. See rule 6.

**4. Decorative images take an empty alt attribute, not a description.** Write `alt=""`, with nothing inside it. This tells the screen reader to skip the image entirely, which is exactly right, because announcing a background texture interrupts the reader for no benefit.

An image is decorative when:

- It carries no information the surrounding text does not already carry
- It is a background pattern, a divider, a gradient, a texture, or a spacer
- It is an icon sitting directly next to a text label that says the same thing
- It is a stock photo chosen for mood, next to a headline that already states the point
- The same image repeats on every page as pure ornament

An image is NOT decorative when it contains text, shows data, is the only thing communicating a point, is a product, is a person the reader needs to identify, or is a link.

When you call something decorative, say why in one line. Users second-guess an empty alt field, and they should know it was a decision, not an omission.

**5. If the image contains text, that text goes in the alt.** Quote sign copy, slide headlines, chart labels, meme text, and text baked into a banner. A screen reader cannot read pixels. If a poster says "Doors open 7pm, tickets at the gate," those exact words belong in the alt. If the same text is already written out next to the image, the image is decorative and takes an empty alt instead of repeating it.

**6. Complex images need the data, not a label.** Charts, graphs, infographics, maps, diagrams, and org charts fail with a one-line description. "Bar chart of quarterly revenue" tells a blind reader nothing a sighted reader gets in a second.

Two options, and you should give both:

- Short alt naming the chart type and the headline finding: "Bar chart: quarterly revenue rose from $1.2M in Q1 to $2.8M in Q4." That single sentence carries the point.
- A long description elsewhere on the page, in a caption, an expandable panel, or a linked page, with the actual numbers written out. The alt then points to it: "Bar chart of quarterly revenue. Full data in the table below."

Never leave a chart with a decorative empty alt. Never leave it with a label alone.

**7. Alt text on a linked image describes the destination, not the picture.** This is the rule almost nobody knows. When an image is wrapped in a link, the alt text becomes the link text, and the screen reader announces it as a link. So an arrow icon that opens the next article should not be "orange right arrow." It should be "Next article: How we cut load time in half." A logo in the header that links home should be "Acme Home," not "Acme logo." A product photo linking to the product page should name the product.

If the image sits next to text that is already the link, the image is decorative and takes an empty alt so the reader does not hear the same link announced twice.

**8. Describe what is relevant to why the image is there.** A photo of a person at a whiteboard on a hiring page and the same photo on a product page are doing different jobs. Describe the part that matters here.

---

## The honesty rule

Describe only what is actually visible, or what the user has told you.

**Never invent:**

- A person's name, unless the user gave it or it is legible in the image
- A location, a city, a venue, or a building name
- A brand, a product name, or a company, unless the logo or label is readable
- A date, a year, an event name, or an occasion
- A price, a spec, a material, or a measurement
- What someone is thinking or feeling beyond what their expression plainly shows

**Never guess at:** race, ethnicity, gender, age, disability status, religion, nationality, or relationship. If those details matter to the page, the user tells you and you write them in. Otherwise describe the person by what they are doing and what is visible: "a person in a hard hat inspecting scaffolding," not an inventory of their identity.

Two exceptions worth naming. When the image is about a specific person the reader needs to identify, the user supplies the name. When identity is the actual subject of the page, a campaign about women in trades, for example, the user supplies that framing and you use their words for it.

If a detail would make the metadata better and you cannot see it, put it in `[BRACKETS]` and move on. A field with one bracket is a deliverable. A question is not.

---

## The four fields are not the same field

Almost everyone treats these as four boxes for the same sentence. They are four different jobs.

| Field | Who sees it | What it is for | How to write it |
|---|---|---|---|
| **Alt text** | Screen reader users, and anyone whose image fails to load | Accessibility. It replaces the image. | One clear sentence, about 125 characters, describing the image in its context. Empty if decorative. |
| **Title** | Editors in the media library. Sometimes a hover tooltip. | Internal identification. Behaves inconsistently, so never rely on it. | A short headline that makes the file findable in a search six months from now. |
| **Caption** | Every reader on the page, below the image | Editorial. It adds something the image does not say. | One or two sentences of real writing. Can be omitted. |
| **Description** | Editors, internal search, some plugins | Media library context and retrieval | Two to four sentences: what is in it, where it is used, what it is for. |

### Alt text

Covered above. It is the field that matters most and the one most likely to be wrong.

### Title

The title is internal. It is what an editor sees when scrolling the media library, and on some platforms it becomes a hover tooltip, which is a problem, because tooltip behavior is inconsistent across browsers and invisible on touchscreens and to screen reader users.

So: **never put information in the title that the reader needs.** If it only exists in the title, it does not exist.

Write it as a short headline, five to twelve words, no file extension, capitalized like a document name. The job is findability. "Screenshot 47" is a failure. "Checkout Flow Error State Mobile" is not.

If the user provides a filename, mine it. The person who named the file signaled the topic.

### Caption

The caption is the only one of the four that a regular reader actually reads, and it sits directly under the image where the eye lands after the headline. It is prime editorial space.

So do not waste it restating what the reader can see. A caption that says "A woman speaking at a conference" under a photo of a woman speaking at a conference is dead space.

A good caption does one of these:

- Adds the fact the image cannot show: who, where, when, what happened next
- Carries a point the article makes, in one line, so a skimmer gets it
- Credits a photographer, a source, or a data provider where required
- Provides the long description for a chart or an infographic

Keep it to one or two sentences. Write it in the voice of the page it sits on.

Caption can be legitimately empty, and you should say so when it is: a decorative header, a repeating icon, a product gallery thumbnail where a caption would clutter the grid. When you leave it blank, say why in the block.

**Do not duplicate alt text into the caption.** If they are identical, a screen reader user hears the same sentence twice. Write them differently on purpose.

### Description

The description is the media library's memory. It is for the editor who inherits this site in two years and needs to find "that photo from the warehouse tour."

Two to four sentences: what is physically in the image, the setting and any notable visual details, where it is used, and any rights or credit information. This is the field where subject terms belong, written as real sentences, because internal search runs on them. Not a keyword list.

---

## The filename rule

Rename the file before you upload it. This is the field people forget, and unlike the title it is permanent, because it lives in the URL forever.

The rules:

- **Lowercase.** Some servers are case sensitive and mixed case breaks links.
- **Hyphens between words, never underscores or spaces.** Spaces become `%20` and look broken everywhere they are pasted.
- **Descriptive, three to six words.** `navy-wool-overcoat-front.jpg`
- **No camera or phone defaults.** `IMG_4471.JPG`, `DSC00231.jpg`, `Screenshot 2026-03-04 at 11.42.18.png`, and `Untitled-1.png` are all failures.
- **No dates or sequence numbers unless they carry meaning.** `q3-2026-revenue-chart.png` is useful. `image-7.jpg` is not.
- **No stuffing.** `best-cheap-mens-coats-buy-online-uk.jpg` is spam, and it does not work.
- **Keep the right extension.** Photos as `.jpg`, graphics and screenshots with flat color or text as `.png`, either as `.webp` where supported, logos and icons as `.svg` where possible.

Always deliver the suggested filename with the extension. If you cannot tell the original format, use `.jpg` for photographs and `.png` for anything with text or flat graphics.

---

## Context changes the answer

The same photograph needs different alt text depending on the page it sits on. This is the concept that separates real alt text from generated alt text, and it is worth showing rather than explaining.

**The image:** a close-up overhead shot of a cast iron pan on a stovetop holding four seared salmon fillets, lemon wedges and dill scattered around them.

**On a product page for the pan:**
`Cast iron skillet with four salmon fillets searing, showing the pan's flat cooking surface and pour spout`
The pan is the subject. The salmon is there to show the pan in use. A shopper needs to know what the product looks like.

**In a news article about farmed salmon prices:**
`Four salmon fillets cooking in a pan, illustrating a story on rising retail salmon prices`
Neither the pan nor the recipe matters. The image is illustrating a topic, and the alt says so.

**In a recipe post for seared salmon:**
`Four salmon fillets seared skin-side up with crisp golden crusts, garnished with lemon and dill`
The cook needs the visual cue: what does done look like. The doneness and the crust are the information.

**As a decorative banner across the top of a food blog homepage:**
`alt=""`
The homepage headline already says what the site is. The image is mood. Announcing it interrupts the reader for nothing.

Same file. Four different correct answers. This is why "just describe the image" is not enough, and why you always establish, or assume out loud, what page the image is on.

The three questions that set the answer:

1. **What page is this on, and what is it doing there?** Selling, illustrating, instructing, or decorating.
2. **What does the surrounding text already say?** Never repeat it. If the caption below already names the speaker and the event, the alt does not have to.
3. **Is the image a link?** If yes, the alt describes the destination.

---

## Batch handling

A set of images is not just several single images. Consistency across the set is a quality signal in itself, and inconsistency is what makes a media library unusable.

When the user gives you more than one image:

- **One complete block per image**, numbered, in the order they were given. Never a table that truncates the fields, and never a summary that covers three images at once.
- **Establish the set's context once**, at the top, in one line. "All ten are product shots for the spring outerwear collection." Then do not repeat it in every block.
- **Do not repeat the same sentence eleven times.** If every alt begins "Product shot of," the set has failed. Vary the structure while keeping the pattern.
- **Do not number the alt text.** "Product image 3 of 8" is meaningless to a screen reader user. Describe image 3.

The consistency rules that matter across a set:

**Filenames use one pattern.** Pick the pattern from the set's own logic and apply it to every file: `product-color-view.jpg`, so `overcoat-navy-front.jpg`, `overcoat-navy-back.jpg`, `overcoat-camel-front.jpg`. Sortable, predictable, obvious what is missing.

**Titles use one shape.** All headline case, all the same field order. If one is "Navy Overcoat Front View," none of them is "back view of the camel coat."

**Alt text uses one level of detail.** If the first product alt names the fabric and the collar type, they all do. A set where alt text ranges from three words to forty reads as unfinished.

**Vocabulary is fixed.** One word per thing, chosen once. Not "sofa" in one and "couch" in the next. Not "team member" here and "employee" there. Name the choice at the top of a batch so the user can carry it forward.

**Repeated subjects are described the same way.** The same person across an event set gets the same descriptor every time.

**Variants differ only in what actually differs.** For eight angles of one product, the fields should be near identical except for the angle. Reinventing the description for each one creates noise.

For a set over roughly fifteen images, ask once whether they want all of them or a pattern plus the first three, then proceed with all of them if there is no answer.

---

## How to run this skill

Pick the mode from what you are given. Every mode ends with fields the user can paste.

**Mode 1: Full metadata for one image** (the default)
One image, in a conversation or as a file. Deliver all four fields, the filename, one coaching note, and at most one question.

**Mode 2: Batch a set**
Two or more images. Set context once, then one full block per image, then the consistency rules you applied, then one coaching note for the whole set.

**Mode 3: Audit and fix**
The user pastes existing metadata, or points at a live page, and asks whether it is any good. Give the verdict in one line, list what is wrong in no more than three bullets, then deliver the corrected fields in full. An audit without the fix leaves the user with homework.

Order the problems by severity, and lead with accessibility failures: no alt on a meaningful image, keyword stuffing, "image of," a chart with a label instead of data, a linked image describing the picture rather than the destination, a decorative image with a full description. Cosmetic issues come last.

**Mode 4: Alt text only**
The user only wants the alt attribute. Lead with it, on its own, clean. Then hand them the other three anyway in a compact block, because they are already written and the user came here to stop thinking about this image. If they explicitly said alt text only and nothing else, respect it.

### What to look at before writing

1. **The image itself.** Subject, action, setting, composition, any text in the frame, any logos, any data. Read text in the image literally and quote it.
2. **The filename.** Hyphens and underscores decode to words, and they usually reveal the topic or the campaign.
3. **The conversation.** What page, what post, what product, what brand, what audience.
4. **The surrounding copy**, if the user pasted any. The alt should not repeat what the paragraph next to it already says.

Ask at most one question, and only after the fields are already delivered.

---

## Output format

Deliver in this order, every time.

**1. The four fields, first, in a copy-ready block.**

```
**Alt Text**
[the alt text, or: (empty) with the one-line reason]

**Title**
[the title]

**Caption**
[the caption, or: (leave blank) with the one-line reason]

**Description**
[two to four sentences]
```

Labeled, values on their own line, nothing above the block except one short line naming what it is. This part is never optional and is never replaced by a description of what the fields should contain.

**2. The suggested filename.**

`**Filename:** navy-wool-overcoat-front.jpg`

**3. One coaching note.**
The single thing that would most improve the user's next image, written so it generalizes past this one. One note, not five. Pick the one that costs them the most, and pick accessibility over polish when both are available.

**4. At most one question, and only after everything else.**
Only if the answer would materially change a field. Say what you would change once you have it.

**For multiple images:** one full block per image, numbered, each with its own filename line. One coaching note at the end for the whole set, not one per image.

**Hard formatting constraints:**

- No em dashes anywhere. Not in the fields, not in the coaching note, not in your commentary. Use a colon, a comma, or a period.
- No ellipses.
- Never wrap alt text in quotation marks unless the quotes are part of the text. People paste the quotes.
- Alt text ends without a period only if it is a fragment. A full sentence takes a period. Be consistent inside a set.
- Do not narrate your process. Do not explain each field unless asked.

**Self-check before responding.** Four questions:

1. Are all four fields written out and pasteable, right now?
2. Would the alt text work for someone who cannot see the image?
3. Is there a filename?
4. Are there any em dashes?

If any answer is wrong, the response is not finished.

---

## Quality checks

Run these before you deliver.

- Alt text answers: what does a sighted reader get from this that a screen reader user would otherwise miss?
- Alt text contains no "image of," "photo of," "picture of," or "graphic of"
- Alt text is about one sentence, near 125 characters, not a paragraph
- Any text visible in the image appears in the alt
- A chart or infographic has the finding in the alt, and the data in the caption or a linked long description
- A linked image describes the destination, not the picture
- A decorative image has an empty alt and a one-line reason
- Nothing is invented: no names, places, brands, dates, or identity guesses that were not visible or supplied
- The caption says something the alt does not
- The title would find this file in a media library search in six months
- The description gives an editor the context they would need
- The filename is lowercase, hyphenated, descriptive, and carries no camera default

---

## Reference files

Load these when the situation calls for it. Do not load both by default.

- `references/patterns.md`: The field pattern for each common image type. Product shot, team headshot, event photo, chart, infographic, screenshot, hero banner, before and after, food, real estate interior, decorative texture, logo, map, team group shot, and stock photo. Load when you know the image type and want the shape fast.
- `references/examples.md`: Fully worked images from different fields, each showing all four fields plus the filename, including a decorative image and a chart. Load when you want to see the standard applied end to end, or when teaching.

---

## The final gate

Five questions before you send.

1. Could a blind reader follow this page using only my alt text?
2. Did I write four different things, or the same sentence four times?
3. Did I invent anything I could not actually see?
4. Is the alt right for THIS page, not just right in general?
5. Can the user paste every one of these fields without editing?

Number four is the one people skip. Correct in general is still wrong on the page.
