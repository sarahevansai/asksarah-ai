# Image Metadata

A Claude skill that writes all four image fields, Alt Text, Title, Caption, and Description, plus a clean filename, for any image you share. Copy-ready. Accessibility first.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Every image on a website has four text fields attached to it, and almost nobody fills them in properly. They get skipped, or they get stuffed with keywords by someone who thinks alt text is an SEO field.

It is not. Alt text is how a blind person experiences your image.

Share an image and Claude will hand you:

1. All four fields, written differently because they do different jobs, ready to paste
2. A suggested filename, lowercase and hyphenated, to rename the file before upload
3. One coaching note that makes your next image better without help

**You always get the fields back.** No questions first. No lecture on what alt text should contain. If you gave no context about where the image is going, Claude writes the fields from what is visible, states the assumption in one line, and offers to adjust.

Built around WordPress, because that is where the four-field structure comes from. Works exactly the same on Shopify, Squarespace, Webflow, Wix, Drupal, Ghost, HubSpot, or hand-written HTML. The field names change between platforms. The thinking does not.

## Accessibility first, which is the whole point

Most alt text on the internet is useless to the people it was invented for. This skill fixes that, and the rules it applies are the ones that actually matter:

- Describe what the image shows and conveys in context, not what you want to rank for
- No "image of" or "photo of," because the screen reader already announced it
- About 125 characters, roughly one clear sentence
- Decorative images get an empty alt attribute, not a description, and you are told why
- Text inside an image goes into the alt, because a screen reader cannot read pixels
- Charts and infographics get the finding in the alt and the data written out elsewhere
- A linked image describes where the link goes, not what the picture looks like

That last one is the rule almost nobody knows, and it is why so many sites announce "orange right arrow" instead of "Next article."

## The four fields are four different jobs

| Field | Who sees it | What it is for |
|---|---|---|
| **Alt text** | Screen reader users, and anyone whose image fails to load | Accessibility. It replaces the image. |
| **Title** | Editors in the media library, sometimes a hover tooltip | Internal identification. Behaves inconsistently, so never put anything important here. |
| **Caption** | Every reader on the page | Editorial. It adds what the image cannot say. |
| **Description** | Editors and internal search | Media library memory, for the person who inherits the site. |

Plus the field everyone forgets: **the filename**, which lives in the URL forever. `IMG_4471.JPG` is a failure. `navy-wool-overcoat-front.jpg` is not.

## Context changes the answer

The same photo of salmon in a cast iron pan needs different alt text on a product page for the pan, in a news article about salmon prices, and in a recipe post. On a decorative homepage banner it needs an empty alt. Same file, four correct answers.

Claude works out which page it is on, or tells you what it assumed in one line so you can flip it.

## What it will not do

Claude describes only what is actually visible. It will never invent a person's name, a location, a brand, a date, or an event, and it will never guess at anyone's race, gender, age, or disability status. Anything it cannot see comes back in `[BRACKETS]` for you to fill.

## Try it

Once installed, share an image and say any of these:

- "Write alt text for this"
- "Fill in the WordPress fields"
- "Here are eight product shots, do all of them"
- "Is this alt text any good?" and paste what you have
- "Rename this file for upload"
- "This is a chart, make it accessible"

Or just drop an image in with no instruction at all. The skill runs on its own whenever an image is headed for a website.

## Four modes

**Full metadata** for one image: four fields, filename, one coaching note.

**Batch** a set: one block per image, plus the consistency rules applied across the set, so your filenames sort, your titles match, and your vocabulary stays fixed.

**Audit and fix** existing metadata: the verdict in one line, what is wrong in three bullets ordered by severity with accessibility failures first, then the corrected fields in full.

**Alt text only** when that is all you want.

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `image-metadata.zip` in your skills settings. Claude loads it automatically whenever an image needs fields.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/image-metadata/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, share any image, and say "fill in the image fields." You should get four labeled fields, a suggested filename, and one coaching note.

## What is in the package

```
image-metadata/
├── SKILL.md                The rules, the accessibility standard, the output format
├── README.md               This file
├── LICENSE
└── references/
    ├── patterns.md         The field pattern for 15 common image types
    └── examples.md         8 fully worked images, including a chart and a decorative one
```

## Notes

The skill delivers first and asks second. At most one question, and only after the fields are already in front of you. Nothing is held back waiting on an answer.

It will tell you when a field should be blank. An empty alt on a decorative image and an omitted caption on a gallery thumbnail are both correct answers, and you get the reason so you know it was a decision and not an oversight.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
