# Field Patterns by Image Type

The shape each of the four fields takes for the image types that come up most. Use the pattern, then fill it with what is actually in the image. Never let the pattern override what you can see.

Every pattern assumes the rules in SKILL.md still apply: no "image of," roughly 125 characters of alt, nothing invented, and a linked image describes its destination.

---

## Product shot

**What matters:** a shopper cannot touch the item. The alt does the job the hands would do.

- **Alt:** product name, then the visible attributes that would affect a buying decision. Color, material, cut, finish, and the angle if the set has multiple angles. Do not repeat the product name that sits in the `<h1>` above it if the page already says it, but do say it if the image stands alone.
- **Title:** Product Name, Attribute, View.
- **Caption:** usually blank on a product page. The spec table and the description already carry the detail, and a caption clutters the gallery. Use one only for a styling note or a scale cue.
- **Description:** full visual account for the library, including the background, the styling, and the shoot it came from.
- **Filename:** `product-color-view.jpg`

Alt shape: `Navy wool overcoat with notched lapels and horn buttons, shown from the front`

**Watch for:** a product photo linked to a product page. Then the alt names the product, because it is the link text.

---

## Team headshot

**What matters:** the reader needs to know who this is. Nothing else about the photo is information.

- **Alt:** name and role, and nothing about the background or the smile. If the name and role are printed directly beside the photo, the image is decorative and takes an empty alt.
- **Title:** Name, Role.
- **Caption:** name and role if not already printed nearby, plus a credential worth carrying.
- **Description:** the visual details for the library, plus where the headshot is used and when it was taken, if the user said.
- **Filename:** `firstname-lastname-headshot.jpg`

Alt shape: `Dana Okafor, Head of Engineering`

**Watch for:** never describe appearance. No age, no race, no attractiveness, no "friendly-looking." A headshot's information content is the identity, and the user supplies the name.

---

## Event photo

**What matters:** what happened, who is in it, and where. Only what the user has confirmed.

- **Alt:** what the subject is doing, at what, in one sentence. Name people only if the user named them.
- **Title:** Event Name, Subject or Session, Year.
- **Caption:** the strongest of the four. Say what was announced, what the moment was, or what came next. This is real editorial space.
- **Description:** setting, crowd size if visible, stage or venue details, the event and date if supplied, photographer credit if known.
- **Filename:** `event-name-year-subject.jpg`

Alt shape: `Speaker at a podium addressing a seated audience at a marketing conference`

**Watch for:** crowd shots where nobody is identifiable. Describe the scale and the scene, not individuals.

---

## Chart or graph

**What matters:** the data. A label is not alt text.

- **Alt:** chart type, what is being measured, and the headline finding in one sentence. The finding is the part people skip.
- **Title:** Metric, Period, Chart Type.
- **Caption:** this is where the long description lives. Write the actual numbers out in prose, or point to a data table below. If the chart has more than about six data points, point to a table rather than listing all of them.
- **Description:** what the chart shows, the axes, the series, the source of the data, and where it is used.
- **Filename:** `metric-period-chart.png`

Alt shape: `Bar chart: quarterly revenue rose from $1.2M in Q1 to $2.8M in Q4 2026`

**Watch for:** never an empty alt on a chart, and never alt that stops at "revenue chart." If the numbers cannot fit, the alt carries the finding and points to where the numbers are.

---

## Infographic

**What matters:** an infographic is a document rendered as a picture. All of its text is invisible to a screen reader.

- **Alt:** the title of the infographic and its one-line purpose, then a pointer to the full text.
- **Title:** Infographic Title.
- **Caption:** short framing plus a link to the accessible version.
- **Description:** the full text content of the infographic, section by section, in order. This is the one case where the description is long on purpose, because it is often the only place the content exists as text.
- **Filename:** `topic-infographic.png`

Alt shape: `Infographic: the five stages of the buying cycle, with each stage described in the text below`

**Watch for:** an infographic is never decorative, and it never survives on alt text alone. If the page has no text version anywhere, say so in the coaching note. That is an accessibility failure, not a metadata problem.

---

## Screenshot

**What matters:** what the interface is showing, and what the reader is supposed to notice in it.

- **Alt:** the app or screen, the state, and the specific element the surrounding text is pointing at. Quote any error text or button label that matters.
- **Title:** Product, Screen, State.
- **Caption:** the instruction or the point. In a tutorial, this is where step context goes.
- **Description:** what is on screen, what version and platform if known, and what the screenshot is illustrating.
- **Filename:** `product-screen-state.png`

Alt shape: `Checkout screen showing the error message "Card declined, try another payment method"`

**Watch for:** screenshots of text. If the screenshot is mostly readable text, the text belongs in the alt or in the surrounding copy, and a real text version is better than any alt string. Also strip or blur personal data before it ships, and flag it if you can see any.

---

## Hero banner

**What matters:** whether it is carrying information or carrying mood. Decide first, and say which.

- **Alt:** if the banner has text baked into it, that text goes in the alt, verbatim. If it is a mood photo behind a headline that already says the point, the alt is empty and the image is decorative.
- **Title:** Page, Hero, Campaign or Season.
- **Caption:** blank. Captions under hero banners are rare and usually break the layout.
- **Description:** the visual for the library, the campaign it belongs to, and the pages it appears on.
- **Filename:** `page-hero-campaign.jpg`

Alt shape, text baked in: `Spring Sale, up to 40% off outerwear, ends April 30`
Alt shape, mood only: `(empty) decorative, the headline above already states the offer`

**Watch for:** text baked into an image is a problem in itself. It does not scale, it does not translate, and it blurs. Note it in the coaching note when you see it.

---

## Before and after

**What matters:** the difference. Not the two states separately.

- **Alt:** name both states and the change between them, in one sentence. If they are two separate files, each alt says which one it is and what it shows.
- **Title:** Subject, Before and After, Project.
- **Caption:** the numbers, the timeline, or the method. What changed, over how long.
- **Description:** both states described, the project, the date range, and the source.
- **Filename:** `subject-before-after.jpg`, or `subject-before.jpg` and `subject-after.jpg`

Alt shape: `Side by side: the same kitchen with dark oak cabinets on the left and white shaker cabinets on the right`

**Watch for:** before and after images of people, especially bodies and skin. Describe the visible change only, never the person, and never imply a result the user did not state.

---

## Food

**What matters:** on a recipe, doneness and technique. On a menu or a product, appeal and portion.

- **Alt:** the dish, its visible state, and the cue that matters. Crust, sear, rise, sauce, garnish.
- **Title:** Dish Name, Preparation or Step.
- **Caption:** the cook's note. What to look for, what it should smell like, what happens next.
- **Description:** the dish, the styling, the props and surface, and where it is used.
- **Filename:** `dish-name-step.jpg`

Alt shape: `Four salmon fillets seared skin-side up with crisp golden crusts, garnished with lemon and dill`

**Watch for:** the difference between an appetite shot and an instructional shot. An appetite shot on a menu can be brief. A step photo in a recipe carries information a cook needs, and the alt has to carry it too.

---

## Real estate interior

**What matters:** the room, its size, its light, and its features. A buyer is building a floor plan in their head.

- **Alt:** room type, then the two or three features that would matter to a buyer. Windows, flooring, fixtures, layout.
- **Title:** Property or Address, Room, View.
- **Caption:** the fact the photo cannot show. Square footage, orientation, what is through the door, recent work.
- **Description:** full room account, finishes, light direction, staging notes, and the listing it belongs to.
- **Filename:** `address-room-view.jpg`

Alt shape: `Open-plan kitchen with white quartz island, stainless appliances and two south-facing windows`

**Watch for:** wide-angle distortion. Do not describe a room as spacious. Describe what is in it and let the buyer judge. Never state square footage the user did not give you.

---

## Decorative texture, pattern, or divider

**What matters:** getting out of the way.

- **Alt:** empty. `alt=""`. Not "decorative image," not a space, not a description. Empty.
- **Title:** a plain library name so an editor can find it. Texture, Style, Color.
- **Caption:** blank.
- **Description:** a short line for the library so someone can search for it later, plus where it repeats.
- **Filename:** `texture-style-color.png`

Alt shape: `(empty) decorative background texture, carries no information`

**Watch for:** something that looks decorative but is not. A pattern containing a word, an icon with no adjacent label, a divider that separates two meanings. Check for text and check for a link before you call anything decorative.

---

## Logo

**What matters:** whether it is a link, and whether the company name is already in text nearby.

- **Alt:** if the logo links to the homepage, the alt is the destination: `Acme Home`. If it is a standalone brand mark in body content, the alt is the company name: `Acme`. If the company name is printed right next to it, empty alt.
- **Title:** Company, Logo, Variant.
- **Caption:** blank, except in a press or brand asset page.
- **Description:** the mark, the color variant, the format, and the usage rules if supplied.
- **Filename:** `company-logo-variant.svg`

Alt shape: `Acme Home` for a linked header logo

**Watch for:** never "Acme logo" on a linked logo, and never a description of the shapes and colors in the mark. Nobody needs "blue circle with a white A."

---

## Map or diagram

**What matters:** the relationship being shown, not the picture of it.

- **Alt:** what the map or diagram shows and the one thing it demonstrates.
- **Title:** Subject, Map or Diagram, Region or System.
- **Caption:** the detail, or a pointer to a text version. A map showing locations needs those locations written out as an address list somewhere.
- **Description:** the full content, the labels, the legend, and the source.
- **Filename:** `subject-map.png`

Alt shape: `Map of the eastern United States with twelve distribution centers marked, listed in the text below`

**Watch for:** maps are almost always incomplete without a text alternative. Give directions and addresses as text, not as a picture of a map.

---

## Group or team photo

**What matters:** the scene, and only the names the user supplied.

- **Alt:** the group, what they are doing, and the setting in one sentence. Names only if given, left to right, and only if the reader needs them.
- **Title:** Team or Department, Occasion, Year.
- **Caption:** names in order, or the occasion.
- **Description:** the scene, the size of the group, the setting, and the event.
- **Filename:** `team-name-occasion-year.jpg`

Alt shape: `Twelve members of the engineering team standing together in the office lobby`

**Watch for:** counting people is fine. Describing them is not. No demographics, no appearance.

---

## Stock photo used for mood

**What matters:** whether it is doing any work at all. Usually it is not.

- **Alt:** if the headline and body next to it already carry the point, empty alt, decorative. If the image is the only thing carrying a concept, describe the scene plainly and briefly.
- **Title:** Concept, Stock, Source.
- **Caption:** blank in almost every case. A caption on a stock photo draws attention to the fact that it is a stock photo.
- **Description:** the scene, the license, the source, and the pages it appears on. License information matters here, so include it whenever the user provides it.
- **Filename:** `concept-stock.jpg`

Alt shape: `(empty) decorative, the headline beside it already states the point`

**Watch for:** the instinct to write something for the sake of filling the box. A decorative stock photo with a paragraph of alt text is worse than no alt text, because now the screen reader user has to sit through it.
