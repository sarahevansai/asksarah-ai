# Worked Examples

Eight complete images from different fields, each described in words, each with all four fields and a filename, in exactly the format the skill delivers. Use these to see the standard applied, or to show someone the difference between the four fields.

Read the reasoning under each one. That is where the skill actually lives.

---

## 1. Product shot, e-commerce

**The image:** a navy wool overcoat photographed straight on against a plain light grey seamless background. Notched lapels, three horn buttons, welt pockets at the hip, hem falling just below the knee. No model, no styling props. The page it sits on is a product page with the product name in the heading above and a spec table below. The image is one of six in a gallery.

**Alt Text**
Navy wool overcoat with notched lapels, three horn buttons and welt pockets, shown from the front

**Title**
Navy Wool Overcoat Front View

**Caption**
(leave blank) The spec table below carries the detail, and a caption would clutter the gallery grid.

**Description**
Product photograph of the navy wool overcoat shot straight on against a light grey seamless background, no model. Shows the notched lapel, the three-button front, the welt pockets and the below-knee hem. First of six gallery images on the product page, covering front, back, side, collar detail, lining and cuff.

**Filename:** `overcoat-navy-front.jpg`

**Why:** the alt names the attributes a shopper cannot judge without touching the coat. It does not say "product image of" and it does not repeat the price or the brand, which are already on the page in text. The caption is deliberately empty and the reason is stated, so the user knows it was a decision. The filename follows a set pattern so the other five sort next to it.

---

## 2. Decorative image, homepage banner

**The image:** a soft-focus photograph of a linen tablecloth in warm morning light, shot from directly above, filling the full width behind the homepage headline of a food blog. No dishes, no people, no text. The headline in front of it reads "Seasonal cooking for people with no time."

**Alt Text**
(empty) Decorative. The headline in front of it already states what the site is, so a description would interrupt a screen reader user for no benefit.

**Title**
Linen Texture Homepage Hero Warm

**Caption**
(leave blank) Hero banners do not take captions in this layout.

**Description**
Soft-focus overhead photograph of a cream linen tablecloth in warm morning light, no subject. Used as the full-width homepage hero behind the site headline, purely for mood. Also used as the background on the newsletter signup block.

**Filename:** `linen-texture-hero-warm.jpg`

**Why:** this is the field people get wrong in both directions. They either leave the alt off entirely, which some tools then auto-fill with the filename, or they write a paragraph about linen. The right answer is an empty alt attribute with the reason on the record. The other three fields are still written, because the media library still needs to find this file.

---

## 3. Chart, quarterly revenue

**The image:** a vertical bar chart with four bars. X axis labeled Q1 through Q4 2026, Y axis in millions of dollars from 0 to 3. Bars read 1.2, 1.6, 2.1 and 2.8. Title across the top reads "Revenue by quarter, 2026." Bars are a single blue, values printed above each bar. Sits inside a year-in-review blog post.

**Alt Text**
Bar chart: quarterly revenue rose steadily from $1.2M in Q1 2026 to $2.8M in Q4, a 133% increase across the year

**Title**
Revenue by Quarter 2026 Bar Chart

**Caption**
Revenue by quarter, 2026: Q1 $1.2M, Q2 $1.6M, Q3 $2.1M, Q4 $2.8M. Growth held between 25% and 33% every quarter, with no single quarter carrying the year.

**Description**
Vertical bar chart titled "Revenue by quarter, 2026" showing four blue bars with values printed above each. X axis runs Q1 to Q4 2026, Y axis runs $0 to $3M. Data source is the internal finance dashboard. Used in the 2026 year-in-review post and in the January investor update.

**Filename:** `revenue-by-quarter-2026-chart.png`

**Why:** the alt carries the finding, not the label. "Bar chart of quarterly revenue" would tell a blind reader nothing. The caption carries the actual numbers, which means the data exists as text on the page and everyone can read it, which is the real fix. Four data points fit in a caption. Twenty would need a table below the chart, with the alt pointing to it.

---

## 4. Team headshot, about page

**The image:** a professional headshot of a person from the shoulders up against a mid-grey studio backdrop, slight smile, dark blazer. Appears on the leadership section of an about page. The user says this is Dana Okafor, Head of Engineering. The name and title are printed in text directly beneath the photo on the page.

**Alt Text**
Dana Okafor, Head of Engineering

**Title**
Dana Okafor Head of Engineering Headshot

**Caption**
(leave blank) The name and title are already printed below the photo in the page layout.

**Description**
Studio headshot of Dana Okafor, Head of Engineering, shoulders up against a mid-grey backdrop in a dark blazer. Used in the leadership section of the about page and in the author byline block on engineering blog posts.

**Filename:** `dana-okafor-headshot.jpg`

**Why:** the only information in a headshot is the identity, and the identity came from the user. Nothing about the blazer, the backdrop, or the expression goes in the alt, because none of it is information. Note the honest edge case: because the name and title are printed right beneath the image, a strict reading makes this decorative with an empty alt. Naming the person in the alt is the safer choice here, since the visual association between face and name is real information, but the caption stays empty so nothing is announced twice.

---

## 5. Event photo, conference keynote

**The image:** a woman at a podium on a lit stage, one hand raised mid-gesture, a large screen behind her showing a slide with a headline too small to read. Audience visible as silhouettes in the foreground, several hundred seats. The user says this is from a marketing conference keynote and supplies the speaker's name and the event.

**Alt Text**
Keynote speaker at a lit podium mid-gesture, addressing a seated audience of several hundred

**Title**
Marketing Conference Keynote Stage Wide Shot

**Caption**
The keynote closed with the argument that most brands are optimizing for a search experience their customers have already left behind.

**Description**
Wide shot of a keynote speaker at a podium on a lit conference stage, one hand raised mid-gesture, with a presentation screen behind her and a seated audience of several hundred silhouetted in the foreground. Slide content is not legible at this resolution. Used on the speaking page and in the event recap post.

**Filename:** `marketing-conference-keynote-stage.jpg`

**Why:** two honesty calls. The slide headline is not legible, so it is not quoted, and the description says so instead of guessing. The audience count is given as "several hundred" because that is what is visible, not as a specific number. The caption does the work the alt cannot: it says what was actually argued, which is the reason the image is on the page at all. The alt and the caption say completely different things on purpose.

---

## 6. Screenshot, software tutorial

**The image:** a screenshot of a checkout page in a web app. A red banner across the top of the form reads "Card declined. Try another payment method or contact your bank." Below it, a card entry form with the number field outlined in red. The screenshot sits in a support article about payment failures.

**Alt Text**
Checkout form showing a red error banner reading "Card declined. Try another payment method or contact your bank"

**Title**
Checkout Card Declined Error State

**Caption**
The declined card message appears above the form, and the card number field is highlighted until a new card is entered.

**Description**
Screenshot of the checkout page in the error state after a declined card, showing the red error banner at the top of the payment form and the card number field outlined in red. Card details in the screenshot are test data. Used in the support article on failed payments.

**Filename:** `checkout-card-declined-error.png`

**Why:** the error text is the whole point of the screenshot, so it is quoted word for word in the alt. A screen reader cannot read the pixels of that banner. Note the description confirms the card data is test data, which is the check to run on every screenshot before it ships. If it were real, the coaching note would say to blur it and reshoot.

---

## 7. Real estate interior, listing

**The image:** an open-plan kitchen shot from the doorway. White quartz island with three stools, stainless range and hood on the far wall, pale oak flooring, two tall windows on the right side letting in strong daylight, glass doors at the back showing a garden. Wide angle lens. On a property listing page.

**Alt Text**
Open-plan kitchen with a white quartz island, stainless range, pale oak flooring and two tall windows

**Title**
Kitchen Open Plan Island View From Doorway

**Caption**
The kitchen opens onto the garden through glass doors at the rear, with the island seating three.

**Description**
Wide-angle photograph of the open-plan kitchen taken from the doorway, showing a white quartz island with three stools, a stainless range and extractor hood on the far wall, pale oak flooring, two tall windows on the right and glass garden doors at the rear. Strong natural daylight. One of eighteen images in the listing gallery.

**Filename:** `kitchen-open-plan-island.jpg`

**Why:** the alt lists the features a buyer is scanning for and stops. It does not say spacious, bright, or stunning, because those are the photographer's lens and the agent's opinion, not the room. No square footage appears anywhere, because the user did not give one. The caption adds the two facts the photo cannot carry: what is through the doors and how many the island seats.

---

## 8. Linked image, article card thumbnail

**The image:** a small square thumbnail showing an abstract illustration of interlocking blue and orange shapes. It sits inside a card on a blog index page. The whole card, image included, is a link to an article titled "How we cut page load time in half." The article title is also printed in text inside the card, directly below the image, and is part of the same link.

**Alt Text**
(empty) Decorative. The image is inside the same link as the article title, so a description would make the screen reader announce the link twice.

**Title**
Blog Card Thumbnail Abstract Shapes Blue Orange

**Caption**
(leave blank) Card thumbnails do not display captions.

**Description**
Square thumbnail illustration of interlocking blue and orange abstract shapes, used as the card image for the article "How we cut page load time in half" on the blog index. Part of the abstract thumbnail series used across performance and engineering posts.

**Filename:** `blog-card-abstract-blue-orange.png`

**Why:** this is the linked image rule in its trickiest form. If the image were the only thing inside the link, the alt would have to be "How we cut page load time in half," because the alt becomes the link text. But the title is already inside the same link as text, so the correct answer flips to an empty alt, which stops the reader hearing the same destination announced twice. If that abstract illustration were on its own, linking to the article with no visible title, describing the shapes would leave a screen reader user with a link called "blue and orange shapes" and no idea where it goes.

---

## The pattern across all eight

Look at what the alt text does versus what the caption does in every example above. They never say the same thing.

The alt replaces the image for someone who cannot see it. The caption adds what nobody can see, whether they can see the image or not. The title makes the file findable. The description is the note you leave for whoever inherits the site.

Four fields, four jobs, and the filename underneath all of them, lowercase and hyphenated, living in the URL for as long as the page does.
