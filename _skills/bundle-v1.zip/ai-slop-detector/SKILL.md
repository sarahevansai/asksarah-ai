---
name: ai-slop-detector
description: >
  Edits AI-written copy so it stops reading as AI. Use whenever someone has a draft that
  feels generic, flat, or machine-made: blog posts, LinkedIn posts, newsletters, landing
  pages, product descriptions, internal memos, cover letters, bios, sales emails, case
  studies, About pages, and anything a model wrote or heavily assisted. Trigger on "does
  this sound like ai," "make this sound human," "edit this ai draft," "this reads like
  chatgpt," "humanize this," "clean up this copy," "why does this feel generic," "make
  this less robotic," "score this for ai," "did a bot write this," "rewrite this so it
  sounds like me," "fix my ai draft," "this is too polished," or any draft pasted in with
  a worry that it sounds fake. Also trigger unprompted when a draft under discussion has
  no numbers, no names, no position anyone could argue with, no tradeoff named, and every
  sentence running the same length. When in doubt, run it. Generic copy costs the writer
  credibility whether or not anyone can name why.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# AI Slop Detector

Anyone can produce a thousand competent words in nine seconds now. That is exactly the problem. The copy is clean, grammatical, well organized, and completely interchangeable with everyone else's.

Readers notice. Most of them cannot say what tipped them off, so they do not comment. They just trust the writer a little less and move on, which is a worse outcome than being told.

The tells are specific and repeatable. They are also fixable. This skill finds them at both layers, the obvious one and the one nobody talks about, and hands back copy that reads like a person wrote it because a person is now actually in it.

---

## The #1 rule: always return the rewritten copy

**Every run ends with the full rewritten piece. No exceptions.**

Not a list of flagged phrases. Not a diagnosis. Not an offer to rewrite it if the user says the word.

A flagged draft is homework. The rewrite is the deliverable.

This holds even when:

- The user only asked "does this sound like AI." Answer in one line, then hand over the rewrite anyway.
- The user only asked for a score. Score it, then rewrite it. The score without the rewrite leaves them exactly where they started.
- The copy is long. Rewrite all of it. Do not rewrite the first two paragraphs and describe what you would do to the rest.
- The user asked about one sentence. Fix the sentence, then deliver the whole piece with the fix in place.
- The draft is already decent. Say so, then deliver the sharper version.
- You need facts the user has not given you. Rewrite it with bracketed gaps and tell them which specific to go get.

**Never respond with problems only.** A numbered list of what is wrong, followed by "want me to rewrite it?", is the single most common failure of this skill. The user came here to stop doing the work themselves.

Order of delivery: rewritten copy first, then the score, then one coaching note. Questions go last and only if one would change something material.

---

## The hard rule on facts

**This skill cannot add facts the writer does not have. It never invents one.**

Specifics are the fastest fix for slop, which makes fabrication the most tempting shortcut in the entire process. Do not take it. Never invent:

- A statistic, a percentage, a dollar figure, or a growth number
- A quote, whether attributed to a person, a client, or a study
- A case study, a customer story, or a result
- A source, a report title, a link, or a date
- A credential or an experience the writer never claimed

Where a specific is needed and unknown, mark it in brackets and name what to go get: `[the actual retention number, pull it from the Q2 dashboard]`. Then say it out loud below the rewrite: "Three brackets in there. The middle one is doing the most work, so get that one first."

A bracketed rewrite is finished work. A confident rewrite built on a plausible-sounding invented number is worse than the slop it replaced, because now it is slop that can be fact-checked and disproven.

---

## What this is actually for

The point is not to evade detection.

The same qualities that make writing sound machine-made also make it useless: no stake, no specifics, nothing risked. Copy that could have been written about any company, by any person, for any reader, does no work for the one company that published it. Fixing that makes the writing better. Reading human is the side effect, not the goal.

Two things follow from that, and both matter:

**Never frame the work as beating a detector.** Do not talk about detector scores, detector thresholds, or getting a draft "under" anything. If the user asks, tell them plainly: AI detection tools are unreliable in both directions. They flag careful human writing constantly, and they miss machine writing that has been lightly edited. Nobody should be making decisions off them, and nobody should be writing to please them.

**A rewrite that scores well and still says nothing has failed.** Varied sentence length wrapped around an empty claim is a cosmetic fix. If the copy has no position after your edit, you edited the surface and left the problem.

---

## The two layers

Most people know a handful of surface tells and stop there. They delete the em dashes, swap out "delve," and hand back a draft that is still hollow. The second layer is where the real damage lives.

### Layer 1: surface tells

Easy to spot. Easy to fix. Fix them, but do not mistake this for the job.

**Em dashes everywhere,** especially dropped mid-sentence for emphasis. Bad version: `The strategy worked — and it worked fast — because the team committed early.` Fixed: `The strategy worked, and it worked fast, because the team committed early.` A colon, a comma, or a period covers almost every case.

**The "not X, it is Y" construction.** Bad version: `This is not just a product update. It is a fundamental rethinking of how teams collaborate.` It sounds like a thesis and contains no claim. Cut the setup and state the thing.

**Rule-of-three everywhere.** Three adjectives, three clauses, three items in every list, three examples for every point. Real thinking is lumpy. Sometimes there are two reasons. Sometimes there are seven.

**Vocabulary flags.** delve, leverage, robust, testament, tapestry, landscape, realm, unlock, harness, navigate, foster, underscore, pivotal, crucial, seamless, holistic, myriad, plethora, elevate, empower, journey, ever-evolving, fast-paced, game-changer, deep dive, at the forefront, in the realm of, when it comes to. Full list with plain-word swaps in `references/tells.md`.

**Empty openers.** "In today's fast-paced world." "In an era where." "Whether you are a startup founder or a Fortune 500 executive." These are throat-clearing. Delete the first paragraph and check whether anything was lost. Usually nothing was.

**The summary conclusion.** Starts with "In conclusion," "Ultimately," or "At the end of the day," then restates the piece and adds nothing. Cut it. End on the last real thing you had to say.

**Perfectly symmetrical paragraphs.** Every block four lines. Every section the same weight. Human writing gives more room to what the writer cares about and rushes the parts they find boring.

**Hedging on everything.** "Can often," "may potentially," "in many cases," "tends to." No sentence carries any risk, so no sentence is worth reading. Some hedges are honest. A draft where every single claim is hedged is a draft afraid of being wrong.

**Headings as noun stacks.** "Content Strategy Considerations" tells the reader nothing. "Most content calendars die in week three" tells them something. Headings should make claims.

### Layer 2: structural tells

This is the real problem, and it is where most edits never reach.

**No specifics.** Read the piece and try to find one number, one name, one date, one place, one proper noun that could be checked. If nothing is checkable, nothing is credible.

**No position.** Nothing in the draft that anyone could disagree with. This is the deepest tell. If no reader could argue with it, no reader needs it. "Good communication is important for teams" is not a claim. It is a noise that resembles one.

**No cost.** Every recommendation is upside only, with no tradeoff named. Real advice costs something. If the piece recommends a course of action and never says what you give up to take it, the writer either has not done it or is hiding what it took.

**No source of authority.** Nothing in the draft could only have been written by someone who has actually done the thing. No scar tissue, no detail that comes from the ninth time rather than the first.

**Even rhythm.** Every sentence lands within a few words of every other sentence. This is the single most reliable machine tell and the least discussed, because people read for words and not for cadence. Human writing runs long, then stops short. Then it runs long again. Read the draft out loud. If your breathing does not change, that is the tell.

**Explains the obvious, skips the hard part.** The draft spends three paragraphs defining a term the reader already knows, then handles the genuinely difficult question in one sentence. Expertise spends its words where the difficulty is. Slop distributes attention evenly because it does not know which part is hard.

---

## The fixes, in priority order

Work down this list. The first four change the piece. The last three make it read right.

1. **Add one specific.** A number, a name, a date. One real detail resets the credibility of everything around it.
2. **Take one position someone could argue with.** Find the sentence closest to a claim and push it until a reasonable person could push back.
3. **Name one cost.** What this approach gives up, who it is wrong for, when it fails. One honest tradeoff buys more trust than a page of benefits.
4. **Add one thing only a practitioner would know.** The detail you learn on the job, not the one you learn from the summary.
5. **Break the rhythm with a short sentence.** Put it where the point turns. Four words is plenty.
6. **Cut the conclusion entirely.** Almost always an improvement, almost never missed.
7. **Cut the first paragraph and see whether anything was lost.** If the piece still makes sense, that paragraph was warm-up.

If you can only do one, do the first. If you can do two, do the first and the third.

---

## The Slop Score

Report `Slop Score: X/10` before and after.

**10** is unreadable machine prose. Every surface tell present, nothing checkable, no position, perfectly even rhythm.
**7 to 9** is recognizable AI output. A reader clocks it within two sentences even if they cannot name why.
**4 to 6** is edited AI, or a human writing on autopilot. Surface cleaned up, structure still hollow.
**1 to 3** is human writing with soft spots. A stray hedge, a summary conclusion, a section that goes vague.
**0** is clearly human. Specific, positioned, uneven, occasionally awkward in a way no model produces.

Name the two or three tells driving the score, not all of them. Weight structural tells heavier than surface ones: a draft with zero em dashes and zero specifics still scores above a 7.

A good rewrite typically moves a piece from the 8 range to the 2 range. If you cannot get below 4, the reason is almost always that the source material has nothing in it, and the honest thing to say is that the writer needs to go get a fact before this piece can work.

---

## Length

Cutting is usually the biggest single improvement available.

Expect the rewrite to run 20 to 40 percent shorter than the original. That range is not a target to hit, it is what happens when you remove the throat-clearing opener, the restated conclusion, the hedges, the transitional sentences that only exist to connect two paragraphs, and the definitions of terms the reader already knows.

If your rewrite came back the same length or longer, you added words instead of replacing them. Go again.

---

## Voice preservation

When you are editing someone else's writing, the job is to make it sound more like them, not more like a good writer in general.

Read the original for what is already theirs: the way they open, the words they reach for, whether they are funny, how formal they run, whether they use contractions, how they handle the reader. Keep all of it. The slop sits on top of a voice, not in place of one.

The failure mode is substituting a generic competent voice for a generic machine voice. Both are generic. One of them is just harder to spot.

If the voice is genuinely unclear, deliver the rewrite in your best read of it, then ask one question below the draft: what to preserve, or a link to something they wrote that sounds like them. Never ask first. Never hold the rewrite while waiting.

When the user is writing fresh copy rather than editing, the same rule applies to the brief: write toward their voice, not toward a house style.

---

## Modes

Read what the user gave you and pick. All modes end with full rewritten copy.

**Mode 1: Rewrite** (default when a draft is pasted in)
Fix both layers. Deliver the piece, the before-and-after score, then one note.

**Mode 2: Score**
The user asked how bad it is. Give the number in the first line, then deliver the rewrite anyway. The number without the fixed copy is a diagnosis with no prescription.

**Mode 3: Voice edit**
The user wants it fixed in their own voice, not improved into someone else's. Preserve their patterns aggressively. Cut and sharpen, do not restyle.

**Mode 4: Write fresh**
The user wants new copy that avoids the tells from the start. Get one real specific from them before you write, or write with brackets and tell them what to fill. Take a position in the first hundred words. Vary sentence length deliberately. No conclusion.

**Mode 5: Line edit**
The user asks about one sentence or one headline. Answer the narrow question, then deliver the full piece with the fix in place.

---

## Output format

Every run, in this order.

**1. The rewritten copy, first.**
Complete and copy-ready, in a block, with any bracketed gaps marked. One short line above it naming what it is, nothing more. No preamble, no list of what you changed, no explanation of your approach.

**2. The score.**
`Slop Score: 8/10 → 2/10`, then the tells that drove the original number. Three bullets maximum. Lead with structural tells.

Only give a before-score when the user actually pasted a draft. If they asked for fresh copy, there is nothing to score, so report the after-number alone.

**3. One coaching note.**
The single pattern that would most improve their next draft, written to generalize past this one piece. Pick the one costing them the most. Not five notes. Not a recap of the score.

**4. At most one question, after everything else.**
Only if the answer would change the copy materially. Say what you would change once you have it.

Do not narrate the edit. Do not explain each change line by line unless asked. Do not add a summary at the end, since that is the exact tell you just removed from their draft.

**Hard formatting constraints on everything you produce:**

- No em dashes anywhere, including in your own commentary. Use a colon, a comma, or a period. This leaks most often in the coaching note, not in the rewrite.
- No "not X, it is Y" constructions in your own writing.
- Vary your own sentence length. If your commentary has even rhythm, you failed the standard you are enforcing.
- Do not open your response with "Here is the rewritten version." Just give it.

**Self-check before responding.** Four questions:

1. Is the complete rewritten piece in the response, all of it?
2. Does the rewrite contain at least one checkable specific or a bracketed instruction to go get one?
3. Is there a sentence in it a reader could disagree with?
4. Any em dashes?

---

## Reference files

Load these when the run calls for it, not by default.

- `references/tells.md`: the complete catalog, split by surface and structural, each with a bad example and the fixed version. Includes the full vocabulary flag list with swaps, and the sentence patterns to watch. Load during any rewrite where you want to be thorough.
- `references/examples.md`: four full before-and-after rewrites across different formats and fields, with scores and word counts shown. Load when the user wants to see the standard applied, or when you are teaching rather than editing.

---

## The final gate

Before you send the rewrite, read it once more and ask:

1. Could this have been written about any other company, by any other person? If yes, it is not fixed.
2. Is there one thing in here a reader might push back on?
3. Did the rhythm change anywhere, or does it still hum along at one speed?
4. Did I cut, or did I only swap words?
5. Would the writer recognize this as theirs?

That last one is the one people skip, and it is the one that determines whether they use the copy or quietly rewrite it back.
