# Before and After

Four rewrites in four formats from four unrelated fields. Every "before" is the kind of draft a model produces on a first pass. Every "after" is shorter, and the shortening is not the achievement, it is the evidence: most of what came out was never carrying anything.

Em dashes appear in the before versions on purpose, as part of what is being demonstrated. They appear nowhere else.

---

## 1. LinkedIn post
### Field: commercial construction project management

**Before. Slop Score: 9/10.**

```
In today's fast-paced construction landscape, effective project management has become
more crucial than ever before.

Over the past several years, I've had the privilege of working with numerous teams
across a variety of complex builds. And one thing has become abundantly clear: success
isn't just about timelines and budgets — it's about people, communication, and trust.

Whether you're managing a small residential renovation or a large-scale commercial
development, the fundamentals remain the same. Clear communication prevents costly
delays. Strong relationships with subcontractors foster better outcomes. And a proactive
approach to risk management can help you navigate unexpected challenges before they
escalate.

The most successful projects I've been a part of all shared these qualities. They had
leaders who listened, teams that were empowered to speak up, and a culture that valued
transparency over blame. When something went wrong — and something always goes wrong —
those teams surfaced it early rather than hoping it would resolve itself.

Construction is an industry built on relationships, and I've come to believe that the
technical side, while important, is rarely what separates a smooth project from a
difficult one.

At the end of the day, construction is a people business. The buildings are just what we
leave behind.

What's been your experience? I'd love to hear your thoughts in the comments.
```

**After. Slop Score: 2/10.**

```
The most expensive week of my career cost $310,000 and started with a text nobody
answered.

Six-story build, concrete pour set for a Tuesday. The electrical sub caught a conduit
conflict on Friday and texted the super, who was on another site. We found it when the
trucks were already rolling.

We poured. We chipped it out three weeks later.

The fix was not better communication. We had four channels running. The fix was one
rule: anything that stops a pour becomes a phone call, and you keep calling down the
list until a human says the words back to you.

That rule is slow. It generates calls that turn out to be nothing, and the supers hate
it for about a month. I would take that trade every time.

If your escalation path has never produced a false alarm, it is not working. It is just
quiet.
```

`218 words down to 148. 32 percent shorter.`

**What drove the original score:** no specifics, no position anyone could disagree with, no cost named anywhere. The surface tells were there too, mid-sentence dashes and a stack of triads, but they were the smaller problem.

**Note on the rewrite:** confirm the dollar figure with the writer before this posts. Bracket the city if they want the project anonymized. The rule about phone calls is the only part a reader can steal and use, which is why it gets the most room.

---

## 2. Product page paragraph
### Field: commercial coffee equipment

**Before. Slop Score: 8/10.**

```
Elevate your café's workflow with a grinder engineered for the modern coffee
professional. Our latest model combines cutting-edge burr technology with an intuitive,
responsive interface — delivering consistent, precise, repeatable results shot after
shot.

Whether you're a boutique specialty roaster or a high-volume operation, this grinder is
designed to seamlessly integrate into your existing setup. Its robust construction
ensures years of reliable service, while the streamlined design makes routine
maintenance effortless for even the newest member of your team.

In today's competitive coffee landscape, consistency is everything. That's why we've
obsessed over every detail, from the precision-machined burr chamber to the thoughtfully
designed dosing system. Every component has been rigorously
tested to meet the demands of even the busiest morning service, so you can focus on what
matters most: the coffee, and the people you serve it to. The result is a machine that
adapts to your workflow rather than forcing you to adapt to it.

Unlock the full potential of your beans and empower your baristas to deliver exceptional
experiences, every single time.
```

**After. Slop Score: 1/10.**

```
64mm flat burrs, stepless adjustment, under half a gram of retention between doses.

Built for shops pulling 200 to 500 shots a day. Below that you are paying for throughput
you will not use. Above 600, buy two rather than one of anything bigger. A
grinder that dies mid-service stops the bar.

Burr swap takes 12 minutes with the hex key in the box. A second set ships with it,
since the first pair dulls around month [X] at that volume.

It is loud. Not unusual for the category, but louder than the quiet models, and if your
bar sits four feet from a two-top you will hear about it.
```

`174 words down to 110. 37 percent shorter.`

**What drove the original score:** fourteen flag words, including elevate, cutting-edge, intuitive, seamlessly, robust, streamlined, unlock, and empower. Behind the vocabulary, nothing checkable and no reason given to believe any claim.

**Note on the rewrite:** the bracket on burr life is not optional. That number belongs to the manufacturer, and inventing a plausible one is the fastest route to a warranty claim. Naming the noise is what makes the rest of the copy believable, and it will cost fewer sales than the original did.

---

## 3. Internal memo
### Field: regional logistics and warehousing

**Before. Slop Score: 8/10.**

```
Subject: Important Updates to Our Warehouse Safety Protocols

Team,

As we continue to grow and evolve as an organization, it's important that our
operational practices evolve alongside us. With that in mind, I wanted to take a moment
to share some important updates to our warehouse safety protocols that will be taking
effect in the coming weeks.

Safety has always been — and will always be — one of our core values. Every member of
this team deserves to work in an environment where they feel secure, supported, and
empowered to do their best work. These updates reflect our ongoing commitment to
fostering that kind of culture across every shift and every part of the facility.

Over the coming weeks, we'll be rolling out enhanced training modules, updated signage
throughout the facility, and a refreshed incident reporting process that has been
designed to be more streamlined and accessible for everyone on the floor.

We understand that change can sometimes be challenging, and we sincerely appreciate your
patience and flexibility as we navigate this transition together. Your feedback is
invaluable to us, and we strongly encourage you to reach out to your direct supervisor
with any questions, concerns, or suggestions you may have along the way.

In the meantime, please continue to follow all existing procedures and to look out for
one another on the floor. Our track record speaks for itself, and it is a direct
reflection of the care this team brings to work every single day.

Thank you for everything you do, day in and day out. Together, we'll continue building a
workplace we can all be proud of.
```

**After. Slop Score: 1/10.**

```
Subject: Forklift right-of-way changes, starting Monday the 14th

Team,

Three near-misses in the north aisle last quarter, all of them between a forklift and
someone on foot coming out of the pick line. Nobody was hurt. The third one was close
enough that both people went home early.

Three changes, starting Monday the 14th:

Pedestrians do not cross the north aisle between racks 12 and 24. Use the end caps. It
adds roughly 40 seconds to a pick run, which I know is not nothing when you are on a
rate.

Forklifts come to a full stop at every aisle mouth. Not a roll.

Incident reports go to the two-question form on the tablet at the charging station. The
paper form is gone. It took eleven minutes, so we were seeing maybe a quarter of what
actually happened.

Rate expectations are not changing this quarter. If the crossing rule puts you behind,
tell your supervisor and we will look at the numbers in [month]. Do not solve it by
cutting the corner.

Questions to me, not the group thread.

[Name]
```

`271 words down to 180. 34 percent shorter.`

**What drove the original score:** the memo announces that changes are coming and never says what any of them are. No date, no rule, no acknowledgment that new rules cost the people following them anything. Two triad stacks and a closing paragraph of gratitude doing the job that one sentence of information should have done.

**Note on the rewrite:** the line about rate expectations matters more than the safety rules. Every warehouse safety memo gets read as a memo about whether you are about to get written up for being slow, and refusing to answer that question is why safety memos get ignored on the floor.

---

## 4. Email newsletter intro
### Field: a community land trust nonprofit

**Before. Slop Score: 9/10.**

```
Friends,

In an era where housing affordability continues to be one of the most pressing
challenges facing communities across the country, the work of community land trusts has
never been more vital.

This month, we're excited to share a number of updates from our ongoing efforts on the
ground. Thanks to the incredible generosity of supporters like you, we've been able to
make meaningful progress on several fronts — from expanding our portfolio of permanently
affordable homes to deepening our partnerships with local stakeholders and community
organizations.

It hasn't always been easy. The market presents real challenges, and we continue to
navigate a complex and ever-evolving landscape. But we remain more committed than ever
to our mission, and to the families who are counting on us to see it through.

Across the sector, organizations like ours are being asked to do more with less, and we
are no exception. It is a challenge we accept willingly, because the alternative is
unthinkable.

None of this would be possible without you. Your continued support empowers us to foster
stronger, more resilient, more equitable communities for generations to come.

Read on for the full story, and thank you, as always, for being part of this journey.
```

**After. Slop Score: 1/10.**

```
Friends,

We closed on the duplex on Fremont in March. Two families moved in in June. The resale
formula caps their appreciation at 25 percent of market gain, so the next family pays
close to what these two did.

That cap is the model, and it is the hardest conversation we have. We ask people to give
up most of the wealth homeownership is supposed to build. Some hear that and walk. They
are not wrong to.

We closed on one building this year. We looked at nine. Seven went to cash buyers inside
a week, which is the part of this work that never shows up in an annual report.

Below: what the Fremont families pay, where your spring gift went, and the two
properties we want under contract before winter.
```

`203 words down to 132. 35 percent shorter.`

**What drove the original score:** no property, no family, no number, no date. It says progress was made and never says what happened. "In an era where" opener, a triad close, and a full paragraph of donor gratitude standing in where donor information belonged.

**Note on the rewrite:** naming the failure rate, seven of nine lost to cash buyers, is the highest-value line in the piece. Nonprofit copy avoids that number out of a fear that donors read losses as incompetence. Donors read the absence of losses as spin, which costs more.

---

## The pattern across all four

Those four originals came from four unrelated industries and are functionally the same document. Swap the nouns and any one becomes any other. That is the tell underneath every other tell, and it is why the vocabulary pass alone never fixes anything.

Every rewrite here landed shorter, between 32 and 37 percent. None of them lost information, because there was very little information in them to lose. What came out was the opener, the gratitude, the hedges, the restated close, and the sentences that existed only to get from one paragraph to the next.
