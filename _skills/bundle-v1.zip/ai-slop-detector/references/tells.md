# The Tell Catalog

Every tell, with a bad version and a fixed version. Surface tells first because they are easier to see. Structural tells second because they matter more.

Examples labeled **Bad version** are demonstrations of the problem. Em dashes appear there on purpose. They appear nowhere else in this skill.

---

# Part 1: Surface Tells

## 1. Em dashes as an emphasis habit

The most discussed tell, and the most overrated. Plenty of good writers use em dashes. What flags a draft is the frequency: several per page, most of them mid-sentence, usually setting up a phrase that could have been cut.

**Bad version:** `The rollout worked — faster than anyone expected — because the team had already run the migration twice in staging.`

**Fixed:** `The rollout worked faster than anyone expected. The team had already run the migration twice in staging.`

Swaps: a comma for a light aside, a colon for a setup, a period for a real break. If the phrase between the dashes adds nothing, delete it rather than repunctuating it.

## 2. The "not X, it is Y" construction

Sounds like a thesis. Contains no claim. The reader gets a definition of what something is not, which is free, followed by an abstraction.

**Bad version:** `This isn't just a pricing change. It's a fundamental reimagining of how we deliver value to our customers.`

**Fixed:** `We raised the entry tier from $29 to $49 and folded in the analytics add-on. About 8 percent of current customers will pay more. The rest pay the same and get more.`

The cousin form, equally common: "This is not about X. It is about Y." Same fix. Delete the setup and make the claim.

## 3. Rule-of-three everywhere

Three adjectives, three-item lists, three examples per point, three parallel clauses. One triad is rhetoric. A page of them is a machine that learned rhythm without learning content.

**Bad version:** `Our platform is fast, intuitive, and scalable, helping teams work smarter, move faster, and achieve more.`

**Fixed:** `Setup takes about ten minutes. After that, most teams stop thinking about it, which is the only real compliment infrastructure gets.`

Watch for it in your own rewrites. Real reasons come in twos, fours, and sevens.

## 4. Vocabulary flags

None of these words is banned. Any of them appearing three times in a page is a signal, and most of them have a plainer word that is simply better.

| Flag word | Use instead |
|---|---|
| delve into | look at, dig into, examine |
| leverage | use |
| robust | strong, reliable, or name the specific quality |
| testament to | proof of, or cut the sentence |
| tapestry | [cut] |
| landscape | market, field, or name the actual thing |
| realm | [cut] |
| unlock | open up, make possible, or name the result |
| harness | use |
| navigate | handle, get through, deal with |
| foster | build, encourage, cause |
| underscore | show, prove, point to |
| pivotal | important, or name what turns on it |
| crucial | needed, or name the consequence of skipping it |
| seamless | name what does not break |
| holistic | whole, complete, or cut |
| myriad | many, or use the number |
| plethora | too many, or use the number |
| elevate | improve, raise, or name the change |
| empower | let, help, give people the ability to |
| journey | [cut, unless someone is actually traveling] |
| ever-evolving | changing, or cut |
| fast-paced | [cut] |
| game-changer | name what it changed |
| deep dive | look, review, breakdown |
| at the forefront of | early to, leading in, or prove it with a date |
| in the realm of | in |
| when it comes to | for, with, about |

Second tier, less discussed and just as common: **crucial, vital, essential, comprehensive, cutting-edge, state-of-the-art, best-in-class, world-class, transformative, revolutionary, innovative, dynamic, streamline, optimize, curate, meticulously, arguably, undoubtedly, indeed, moreover, furthermore, additionally, that being said, it is worth noting that, it is important to note.**

Two special cases:

- **"Whether you are a X or a Y"** is not a word, it is a whole opener, and it is one of the highest-confidence tells in the set. It exists to avoid choosing a reader.
- **"In today's"** anything. Fast-paced world, digital age, competitive market, evolving landscape. Delete the clause and start at the next word.

## 5. Empty openers

The first paragraph that sets a scene nobody asked for.

**Bad version:** `In today's fast-paced digital landscape, businesses of all sizes are constantly seeking new ways to connect with their audiences. Whether you're a scrappy startup or an established enterprise, the challenge remains the same.`

**Fixed:** `We spent $40,000 on paid social last year and got 11 qualified leads. Here is what we did instead.`

The test: cut paragraph one and read the piece. If nothing was lost, it was warm-up, and warm-up is for the writer, not the reader.

## 6. The summary conclusion

Restates the piece, adds nothing, exists because a model learned that essays have conclusions.

**Bad version:** `In conclusion, building a strong content strategy requires careful planning, consistent execution, and a willingness to adapt. By keeping these principles in mind, you'll be well on your way to success.`

**Fixed:** [Delete it. End on the last real point.]

Openers to search for: "In conclusion," "Ultimately," "At the end of the day," "In summary," "To sum up," "All in all," "The bottom line is." If a genuine last thought exists, it can survive without the label. If the paragraph dies once you cut the label, the paragraph was the label.

## 7. Perfectly symmetrical paragraphs

Four sections, each with a heading, each running four lines, each with an example. Visually tidy, and a strong signal that nobody chose what mattered.

**Fixed:** Give the part you care about most three times the space. Let a section be two sentences if two sentences is all it deserves. Unevenness reads as judgment, because it is judgment.

## 8. Universal hedging

**Bad version:** `This approach can often help teams potentially improve their workflows, though results may vary depending on a number of factors.`

**Fixed:** `This works for teams under about fifteen people. Past that, the coordination cost eats the gain, and you want a real tool instead.`

Honest hedges are fine and sometimes required. What flags a draft is that every claim in it is hedged, which means the writer is not willing to be wrong about anything, which means there is nothing to be right about either.

Hedge stack to watch: can, may, might, could, often, typically, generally, tends to, in many cases, to some extent, relatively, somewhat, arguably, potentially.

## 9. Headings as noun stacks

**Bad version:** `Key Considerations for Content Strategy Implementation`

**Fixed:** `Most content calendars die in week three`

A heading should carry a claim, a number, or a specific. Noun stacks are what you write when you know the topic and have not decided what you think about it.

## 10. Smaller surface habits worth catching

- **"Let's dive in"** and any variant. Cut.
- **Bolded phrases scattered mid-paragraph** for emphasis with no pattern behind them.
- **Every list item starting with the same part of speech,** perfectly parallel, no exceptions.
- **Rhetorical question as a section opener.** "So what does this mean for your business?" Answer it directly instead.
- **"Studies show"** or "research suggests" with no study named. Either name it or cut the claim.
- **Emoji as bullet points** in professional copy where the writer would never use them in speech.
- **"It's important to note that."** Nine words that could be zero.

---

# Part 2: Structural Tells

Fix these and the surface tells often disappear on their own, because specific writing is harder to pad.

## 1. No specifics

Read the draft and hunt for one checkable thing: a number, a name, a date, a place, a proper noun, a price, a version.

**Bad version:** `We've helped numerous clients achieve significant improvements in their marketing performance over the past several years.`

**Fixed:** `We ran this for a 12-person dental group in Tulsa. Their cost per booked appointment went from $84 to $31 over five months, and it took two failed landing pages to get there.`

If the writer does not have the number, bracket it and tell them which one to go get. Never supply it yourself.

## 2. No position

The deepest tell. Every sentence is true and no sentence is contestable.

**Bad version:** `Effective leadership requires strong communication skills and the ability to adapt to changing circumstances.`

**Fixed:** `Most leadership advice about communication is wrong. The problem is almost never clarity. It is that managers say the true thing eight weeks after the moment it would have helped.`

The test: could a reasonable, informed person disagree with any sentence here? If not, the piece is decorative. Nobody needs it, nobody shares it, nobody remembers it.

## 3. No cost

Every recommendation carries only upside. No tradeoff, no wrong-fit case, no admission of what it takes.

**Bad version:** `Moving to a subscription model gives you predictable revenue, stronger customer relationships, and better long-term growth.`

**Fixed:** `Subscription revenue is more predictable, and the switch will hurt for about four quarters. You are trading a big upfront number for a small recurring one, and your cash position gets worse before it gets better. If you cannot fund fourteen months of that, do not start.`

Naming a cost is the cheapest credibility available. It also proves the writer has done the thing, since only people who have done it know what it costs.

## 4. No source of authority

Nothing in the piece could only have been written by someone who was there.

**Bad version:** `Implementing a new CRM requires careful planning and buy-in from all stakeholders.`

**Fixed:** `The CRM migration will not fail on the data. It will fail because two reps keep their real pipeline in a spreadsheet, and you will not find out until quarter close. Ask them directly in week one. They will tell you if you promise not to make it a thing.`

The marker is the detail that comes from the ninth time, not the first. The sequencing that only matters in practice. The thing that surprised the writer.

## 5. Even rhythm

The most reliable machine tell in the set, and the one almost nobody names.

**Bad version:** `Our team has been working on this project for several months now. We wanted to make sure that we got every detail right before launching. The feedback from our early users has been incredibly positive so far. We're excited to share what we've built with a wider audience today.`

Four sentences, 15 to 18 words each, identical shape. Nothing is wrong with any one of them.

**Fixed:** `We have been building this for seven months, mostly because the first version was bad and we did not want to admit it. Forty people used the rebuild. Thirty-one of them came back the next week, which is the only number we cared about. It is open to everyone today.`

Read it out loud. If your breathing does not change, the rhythm is flat. Fix it with one short sentence at the point where the argument turns. Not scattered randomly, and not one per paragraph as a formula, which produces a new pattern just as detectable as the old one.

## 6. Explains the obvious, skips the hard part

**Bad version:** Three paragraphs defining what employee retention is, followed by one sentence saying that competitive compensation and a positive culture help.

**Fixed:** Assume the reader knows what retention is. Spend the piece on the part that is actually hard, which is that the people you most want to keep are the ones with the most options, and that money stops working on them at a level most companies will not reach.

Expertise allocates words to difficulty. Generic writing spreads them evenly because it has no idea which part is hard.

## 7. Symmetry of argument

Every point gets a counterpoint, every benefit gets a caveat, and the piece resolves to "it depends." This looks balanced. It is usually avoidance.

**Fixed:** Come down on a side. You can name the strongest objection and then say why you still think what you think. That is balance. Refusing to conclude is not.

## 8. Nobody is talking to anybody

The copy has no specific reader. It addresses "businesses," "teams," "professionals," or "individuals," which means it addresses nobody.

**Fixed:** Write to one person you can picture. A founder with eleven employees who just lost their second head of sales. The piece gets sharper immediately, and the people outside that description still recognize themselves if the writing is honest.

---

# Part 3: Sentence Patterns to Search For

Fast scan list. Any of these in a draft is worth a look.

| Pattern | What to do |
|---|---|
| "It's not just X, it's Y" | Delete the setup, state the claim |
| "This isn't about X. It's about Y." | Same |
| "In today's [adjective] world/landscape/environment" | Delete the clause |
| "In an era where" | Delete |
| "Whether you're a X or a Y" | Delete, pick one reader |
| "More than ever before" | Delete |
| "Let's dive in" / "Let's explore" | Delete |
| "The truth is" / "Here's the thing" | Usually deletable, occasionally earned |
| "But here's what most people miss" | Only keep if what follows is genuinely uncommon |
| "It's important to note that" | Delete, keep the note |
| "It's worth mentioning" | Delete |
| "That being said" | However, or nothing |
| "Moreover" / "Furthermore" | And, or start a new sentence |
| "In conclusion" / "Ultimately" / "At the end of the day" | Cut the paragraph |
| "By [verb]ing X, you can Y" | Say what happens, in order |
| "Studies show" with no study | Name it or cut it |
| "Countless" / "numerous" / "a variety of" | Use the number |
| "Not only X but also Y" | Two sentences |
| "One of the most important things" | Say which thing |
| "Can help you to" | Helps you, or does |
| "In the world of X" | In X |
| "Serves as a" | Is |
| "Plays a key role in" | Name the role |
| "Is a testament to" | Cut, or state what it proves |

---

# Part 4: The Rewrite Loop

The order to work in, since fixing surface tells first wastes effort you will redo.

1. Read once for position. What does this piece claim? If nothing, that is the whole job, and everything else is cosmetic until it is solved.
2. Find or bracket one specific. Number, name, date.
3. Name one cost or tradeoff.
4. Cut the opener and the conclusion. Check what was lost. Usually nothing.
5. Now do the surface pass: vocabulary, dashes, triads, hedges, headings.
6. Read out loud for rhythm. Break it where the argument turns.
7. Count the words. If you are not down 20 percent, go back to step 4.
