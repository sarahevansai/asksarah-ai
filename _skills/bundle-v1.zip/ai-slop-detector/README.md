# AI Slop Detector

A Claude skill that edits AI-written copy so it stops reading as AI, and hands the whole rewritten piece back rather than a list of things to fix.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Anyone can produce a thousand competent words in nine seconds now. That is the problem. The copy is clean, grammatical, and interchangeable with everyone else's, and readers can feel it even when they cannot name why. They do not comment. They just trust you a little less.

Paste in a draft and Claude will:

1. Hand you the full rewritten piece, copy-ready
2. Score the original from 0 to 10, and name the two or three tells driving the number
3. Give you one coaching note that applies to everything you write after this

**You always get the rewrite.** Ask whether something sounds like AI and you get an answer plus the fixed version. Ask only for a score and you get the score plus the fixed version. A flagged draft is homework, and homework is what you came here to stop doing.

It works on blog posts, LinkedIn posts, newsletters, landing pages, product descriptions, internal memos, bios, sales emails, case studies, and cover letters.

## The two layers

Most advice about this covers the obvious tells and stops. Delete the em dashes, swap out "delve," done. The draft is still hollow.

**Surface tells** are the ones people know: em dashes mid-sentence, "it's not just X, it's Y," triads everywhere, the vocabulary list (leverage, robust, seamless, tapestry, unlock, myriad, ever-evolving), "in today's fast-paced world," and the conclusion that repeats the piece and adds nothing.

**Structural tells** are where the real damage is:

- **No specifics.** Nothing checkable. No number, no name, no date.
- **No position.** Nothing anyone could disagree with. If no reader could argue with it, no reader needs it.
- **No cost.** Every recommendation is upside only, with no tradeoff named.
- **No authority.** Nothing that could only have been written by someone who has actually done the thing.
- **Even rhythm.** Every sentence roughly the same length. The most reliable tell in the set and the least discussed.
- **Explains the obvious, skips the hard part.** Real expertise spends its words where the difficulty is.

The fixes run in priority order: add one specific, take one position someone could argue with, name one cost, add one thing only a practitioner would know, break the rhythm, cut the conclusion, cut the first paragraph and see whether anything was lost.

## What it will not do

**It will never invent a fact.** No made-up statistic, quote, case study, source, or result, ever. Specifics are the fastest fix for generic copy, which makes fabrication the most tempting shortcut in the process. Where a specific is needed and unknown, it comes back in `[BRACKETS]` with a note telling you which one to go get first.

**It is not about beating a detector.** Detection tools are unreliable in both directions: they flag careful human writing and miss lightly edited machine writing. The reason to fix this copy is that the qualities making it sound machine-made are the same ones making it useless. No stake, no specifics, nothing risked. Fixing that makes the writing better. Reading human is the side effect.

**It will not overwrite your voice.** Editing someone else's writing means keeping their patterns, not swapping a generic machine voice for a generic good-writer voice. Both are generic. One is just harder to spot.

## Try it

Once installed, say any of these:

- "Does this sound like AI?" and paste your draft
- "Humanize this"
- "Score this out of 10"
- "Edit this in my voice, do not rewrite it into someone else's"
- "Write this from scratch without the tells"
- "Why does this feel generic?"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `ai-slop-detector.zip` in your skills settings. Claude loads it whenever a draft needs it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/ai-slop-detector/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste any AI-written paragraph, and say "does this sound like AI." You should get the rewritten copy first, then a Slop Score with a before and after number, then one coaching note.

## What is in the package

```
ai-slop-detector/
├── SKILL.md               The framework, the rules, the output format
├── README.md              This file
├── LICENSE
└── references/
    ├── tells.md           The full catalog, surface and structural, each with a
    │                      bad example and its fix, plus the vocabulary flag list
    │                      with plain-word swaps and the sentence patterns to search
    └── examples.md        4 full before-and-after rewrites in 4 formats and 4
                           fields, with scores and word counts shown
```

## Notes

Expect the rewrite to come back 20 to 40 percent shorter. Cutting is usually the single biggest improvement available, and most of what disappears is the opener, the hedges, the restated conclusion, and the sentences that only existed to connect two paragraphs.

One question, maximum, and only after the rewrite is already in front of you. Nothing is held back waiting on an answer.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
