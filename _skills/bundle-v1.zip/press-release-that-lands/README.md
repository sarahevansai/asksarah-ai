# Press Release That Lands

A Claude skill that writes a press release a journalist can actually use, and tells you honestly whether you have news before you write it.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most press releases are internal announcements dressed as news. They lead with the company instead of the change, quote an executive saying something no human would say out loud, and bury or entirely omit the one fact that made it worth writing. Then everyone blames distribution.

Give Claude your announcement, or paste in a draft, and you get:

1. The complete release, copy-ready, headline through contact block
2. An honest verdict on whether it is news, and which of five tests it passes
3. A score across the eight elements of a release
4. One coaching note that generalizes to every release after this one

**You always get a release back.** Ask whether something is newsworthy and you get the answer plus the release. If the answer is no, you still get the release, plus the one specific fact that would turn it into a real story. Missing a number or a contact? It comes back in `[BRACKETS]` naming exactly what goes there. You never have to reply to get a usable document.

It handles funding announcements, product launches, executive hires, partnerships, awards, research and data releases, expansions and new locations, and responses to an event or issue. It also writes the media alert version when the news is an event, and the pitch email that carries the release.

Two things it does that most tools will not:

**It tells you when you do not have news.** In one line, without a lecture. Then it writes the strongest possible version anyway and names the missing fact. Most companies find out their announcement was not news after it goes out and nothing happens.

**It will not fabricate a quote.** Ever, under a real person's name. If no quote exists, it writes a bracketed placeholder naming who should say it, what the quote needs to accomplish, and two or three angles that person could speak to, clearly marked as suggestions for them to approve or replace. Provided quotes are used exactly as given, punctuation included.

## The Newsworthiness Gate

A release needs at least one of these five, and Claude names which one it is running on:

1. A number that is new or surprising
2. A first, a largest, or a genuine change of state
3. A decision with consequences for someone outside the company
4. A conflict, a reversal, or a risk being addressed
5. A human being who is actually affected

None of the five means it is an announcement, not news. You will be told, once.

## The Release Standard

Every release is built and scored across eight elements:

1. **Headline**: under 12 words, active, carries the news and ideally a number
2. **Subhead**: the second most important fact, never a restatement
3. **Dateline and lead**: the whole story in the first sentence
4. **Evidence paragraph**: the number, the scope, the proof
5. **Quote**: something only that person could say, never an adjective about excitement
6. **Supporting paragraphs**: descending importance, so the bottom can be cut
7. **Boilerplate**: what the company is, in plain words, no mission statement language
8. **Contact block**: a real name, email, and phone, not a generic inbox

Plus the rejection checks: no comparative claims about named competitors, no unsubstantiated superlatives, no review or endorsement framing, and a flag on regulated health and finance claims before they reach a wire service.

## Try it

Once installed, say any of these:

- "Write a press release announcing our Series A"
- "Is this newsworthy?"
- "We're launching a new product next month, draft the release"
- "Rewrite this release" and paste your draft
- "Do we even have news here?"
- "Fix the headline and lead on this"
- "Write the media alert for our opening"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `press-release-that-lands.zip` in your skills settings. Claude loads it automatically whenever a release needs writing.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/press-release-that-lands/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and describe something you are announcing. You should get a complete release, a gate verdict naming which of the five elements it runs on, a score out of 8, and one coaching note.

## What is in the package

```
press-release-that-lands/
├── SKILL.md                  The gate, the build, the quote rules, the output format
├── README.md                 This file
├── LICENSE
└── references/
    ├── templates.md          8 full release skeletons with filled headline and lead examples
    └── examples.md           Before-and-after rewrites across industries, including a failed gate
```

## Notes

Claude will never invent a statistic, a customer count, a funding figure, an investor name, or an award to fill a gap. Anything it does not know comes back in `[BRACKETS]` naming the exact fact required. That is deliberate. A confident release built on a made-up number is a correction waiting to happen.

It will never write a quote and attribute it to a real person. A fabricated executive quote is not a drafting shortcut, it is a statement that can be repeated by a reporter as something that person said.

Wire service and newsroom acceptance policies differ by service and change over time. The skill flags the common rejection triggers, but check the current guidelines of whichever service you are using before you distribute.

It will ask at most one question, and only after the release is already in front of you.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
