# Release Templates

Eight skeletons for the most common release types. Each one carries the structure, the gate element it usually runs on, the traps specific to that type, and a filled headline and lead so the shape is visible rather than described.

**These are raw material for you, not output for the user.** Never hand back a skeleton with blank slots. Fill it with the user's actual facts, bracket only what they alone can supply, and deliver a finished release.

All example companies here are fictional and generic. Never write an example release about a real company.

---

## 1. Funding

**Usually runs on:** element 1 (a number nobody had) or element 3 (what the money changes for people outside the company).

**The trap:** the money is not the news. Every company that raises says it raised. The news is what becomes possible, or what the raise says about the market. A funding release that stops at the dollar figure and the investor names is a memo to competitors.

**Filled example**

> **Headline:** Northwind Robotics Raises $34 Million to Put Warehouse Arms in Mid-Size Facilities
>
> **Subhead:** The company will cut its entry price by roughly half, targeting the 40,000 warehouses too small for current systems.
>
> **Lead:** BOISE, Idaho, Sept. 9, 2026: Northwind Robotics raised $34 million to bring automated picking arms to mid-size warehouses, a segment priced out of the technology because existing systems require a minimum floor area most of these facilities do not have.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: amount, and what it buys, under 12 words]
[Subhead: the second fact, usually the use of funds or the market shift]

[CITY, State, Month Day, Year]: [Company] raised $[amount] [round type] to
[what it enables]. [The consequence for someone outside the company.]

[Paragraph 2, evidence: the lead investor, the participating investors, total
raised to date, and the operating number that justified the round. Growth rate,
customer count, or revenue if disclosable.]

[Quote from CEO or founder: why now, why this direction, what was rejected.
Never "excited to partner with." Never a description of the investors.]

[Paragraph 4: what the money is actually spent on. Headcount, geography,
product, manufacturing. Be specific. "Accelerating growth" says nothing.]

[Quote from the lead investor, only if it says something specific about the
market or the thesis. Cut it if it is a compliment.]

[Paragraph 6: context. Market size, the problem, the competitive landscape
without naming competitors.]

[Boilerplate]

[Contact block]

###
```

**Bracket, never invent:** the amount, round type, lead investor, participating investors, valuation, total raised, headcount, customer count, revenue.

**Careful with:** valuation figures, which are often not disclosed and should never be inferred from the round size.

---

## 2. Product launch

**Usually runs on:** element 2 (a change of state) or element 3 (a decision with consequences outside the company).

**The trap:** feature lists. A launch release that catalogs capabilities is a spec sheet. The news is what a person can now do that they could not do before, and what it costs.

**Filled example**

> **Headline:** Alder Software Ships Offline Mode After Three Years of Field Requests
>
> **Subhead:** Inspectors working in basements and rural sites can now file reports without a connection, syncing when they surface.
>
> **Lead:** COLUMBUS, Ohio, Sept. 9, 2026: Alder Software released an offline version of its field inspection tool, letting the roughly 12,000 inspectors on the platform complete and file reports in buildings and remote sites where no network reaches.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: what it now does, active, ideally with a number]
[Subhead: who it changes things for, or the price, or the availability date]

[CITY, State, Month Day, Year]: [Company] released [product], which
[the one thing it does that matters]. [Who is affected and how many of them.]

[Paragraph 2, evidence: how it works in one non-technical paragraph, the
measurable improvement over the prior state, and how that was measured.]

[Quote from the product or company lead: the decision behind it. Why this
problem, why now, what was traded away to build it.]

[Paragraph 4: availability, pricing, platforms, dates. Concrete.]

[Quote from a customer or user who tested it, if one exists and has approved
being named. This is the strongest paragraph in a launch release when it is real.]

[Paragraph 6: context on the problem the product addresses.]

[Boilerplate]

[Contact block]

###
```

**Bracket, never invent:** pricing, availability dates, user counts, performance benchmarks, beta results, customer names.

**Careful with:** "first," "only," and "fastest." Each needs a stated scope and a source in the same sentence.

---

## 3. Executive hire

**Usually runs on:** element 3 (a decision with consequences) or element 4 (a reversal or a risk being addressed).

**The trap:** the resume. Nobody outside the company cares where the new hire went to school. The news is what the hire signals about direction, or what specifically this person has been brought in to change.

**Filled example**

> **Headline:** Cascade Freight Hires First Safety Chief After Two Years of Rising Incident Rates
>
> **Subhead:** Marguerite Ellison will have authority to ground routes, a power previously held only by regional operations managers.
>
> **Lead:** TACOMA, Wash., Sept. 9, 2026: Cascade Freight named Marguerite Ellison as its first chief safety officer, giving her authority to suspend routes and equipment across a network where reportable incidents rose [PERCENTAGE] over the past two years.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: who, into what role, and the change it represents]
[Subhead: the authority, the mandate, or the number behind the hire]

[CITY, State, Month Day, Year]: [Company] named [Name] as [title], where
[the specific mandate]. [Why the role exists now, or what it replaces.]

[Paragraph 2, evidence: what the person will actually own. Reporting line,
scope, team size, budget, the first stated priority.]

[Quote from the person hiring them: what the company needs that it did not
have. Not a welcome. Not a list of the hire's accomplishments.]

[Paragraph 4: the hire's relevant background, two sentences maximum, chosen
for what it predicts about the job rather than for prestige.]

[Quote from the new hire: what they intend to change, and what they are
willing to be measured on. Never "thrilled to join."]

[Paragraph 6: context on the company's position and why this role matters now.]

[Boilerplate]

[Contact block]

###
```

**Bracket, never invent:** start date, prior employers, titles, tenure, team size, reporting line, and any performance figure attributed to the hire's past work.

**Careful with:** implying the predecessor was removed. If a departure is involved, state facts only, or say nothing.

---

## 4. Partnership

**Usually runs on:** element 3 (consequences for someone outside both companies).

**The trap:** the mutual admiration release. Two companies each quoting how pleased they are, with no statement of what a customer can now do. If the release does not name a concrete change for a third party, it fails the gate.

**Filled example**

> **Headline:** Two Rivers Credit Union Adds Same-Day Payroll for 200 Small Employers
>
> **Subhead:** The partnership with Harbor Payments removes the two-day settlement delay that pushed hourly workers to check cashers.
>
> **Lead:** DES MOINES, Iowa, Sept. 9, 2026: Two Rivers Credit Union will offer same-day payroll deposits to about 200 small business clients starting Oct. 1, cutting a two-day settlement delay that left roughly [NUMBER] hourly workers waiting on wages already earned.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: the outcome for the customer, not the fact of the partnership]
[Subhead: the scale, the timing, or what it removes]

[CITY, State, Month Day, Year]: [Company A] and [Company B] will
[the concrete new capability], starting [date]. [Who benefits, how many, how.]

[Paragraph 2, evidence: how it works, the scope, the timeline, the numbers.]

[Quote from whichever company owns the customer relationship: why this
partner, and what was not possible before. One quote, not two, unless the
second is genuinely different in substance.]

[Paragraph 4: the mechanics. Who does what, what changes for existing
customers, whether pricing changes.]

[Quote from a customer or an affected party, if one exists.]

[Paragraph 6: context.]

[Boilerplate for both companies, in separate short paragraphs]

[Contact block for both, or a single lead contact]

###
```

**Bracket, never invent:** contract terms, deal value, exclusivity, customer counts, launch dates.

**Careful with:** describing a reseller agreement, a pilot, or an integration as a "strategic partnership." Say what it actually is.

---

## 5. Award

**Usually runs on:** element 2 (a first or a largest), and often on nothing at all.

**The trap:** most awards are not news. This is the release type most likely to fail the gate, and the honest verdict matters more here than anywhere. An award becomes news when the criteria are meaningful, the field was large and named, or the win reflects a verifiable operating result.

**Filled example**

> **Headline:** Meridian Plastics Cuts Landfill Waste 71 Percent, Wins State Efficiency Award
>
> **Subhead:** The plant diverted 3,400 tons in 2025, the largest single-site reduction in the program's 12-year history.
>
> **Lead:** AKRON, Ohio, Sept. 9, 2026: Meridian Plastics cut landfill waste at its Akron plant by 71 percent last year, diverting 3,400 tons and earning the state's manufacturing efficiency award for the largest single-site reduction the program has recorded.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: the achievement that earned the award, with the award second]
[Subhead: the scope, the field, or the criteria]

[CITY, State, Month Day, Year]: [Company] [did the measurable thing], earning
[award] from [awarding body]. [What the award measures and how big the field was.]

[Paragraph 2, evidence: the operating result behind the win. This is the whole
release. Without a number here, there is no story.]

[Quote from whoever did the work, not the CEO, on what changed operationally.]

[Paragraph 4: what the awarding body is, how the criteria work, how many
entrants or how the field was defined.]

[Paragraph 5: what the company is doing next with the same effort.]

[Boilerplate]

[Contact block]

###
```

**Bracket, never invent:** the award name, the awarding body, the category, the field size, the criteria, the year, and every operating figure.

**If the gate fails here,** say it plainly: an award with no disclosed criteria, no named field, and no operating number behind it is an announcement. Then write the strongest version and name the missing fact, usually the result that earned it.

---

## 6. Research or data release

**Usually runs on:** element 1 (a number nobody had). This is the strongest release type when done well.

**The trap:** burying the finding under methodology, or leading with the fact that a report exists. Nobody covers the existence of a report. They cover the number in it.

**Filled example**

> **Headline:** 61 Percent of Small Contractors Turned Down Work Last Year for Lack of Crew
>
> **Subhead:** A survey of 1,900 firms found the average contractor declined $184,000 in jobs, up from $92,000 in 2023.
>
> **Lead:** RALEIGH, N.C., Sept. 9, 2026: Sixty-one percent of small construction contractors turned down work last year because they could not staff it, according to a survey of 1,900 firms released today by Keystone Trades Institute, with the average firm declining $184,000 in jobs.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: the single most surprising finding, as a number]
[Subhead: the second finding, plus the sample size]

[CITY, State, Month Day, Year]: [The finding, stated as fact], according to
[study name] released today by [organization]. [The second most important number.]

[Paragraph 2, evidence: two or three additional findings, each with its number.
Bullet them only if there are more than three.]

[Quote from the researcher or the organization's lead: what surprised them,
or what the finding means that the number cannot say on its own.]

[Paragraph 4: methodology in plain language. Who was surveyed, how many, when,
how they were selected, margin of error. Short, but never omitted.]

[Quote from someone in the surveyed population, if one exists and consented.]

[Paragraph 6: what changed since the last comparable measurement, and where
the full report can be read.]

[Boilerplate]

[Contact block]

###
```

**Bracket, never invent:** every figure, the sample size, the fielding dates, the margin of error, the methodology, and the report title.

**Careful with:** stating correlation as cause, and generalizing a narrow sample to a whole industry.

---

## 7. Expansion or new location

**Usually runs on:** element 3 (a decision with consequences for a place) or element 1 (jobs, investment, capacity).

**The trap:** writing it for the company instead of the community. Local press covers this type more reliably than any other, and what they want is jobs, timeline, address, and what it replaces.

**Filled example**

> **Headline:** Blue Ridge Foods Opens 90,000-Square-Foot Plant, Adding 140 Jobs in Bristol
>
> **Subhead:** Production starts in March, moving work back from a contract facility three states away.
>
> **Lead:** BRISTOL, Tenn., Sept. 9, 2026: Blue Ridge Foods will open a 90,000-square-foot production plant in Bristol in March, adding 140 jobs and moving packaging work back from a contract facility in [STATE].

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: the location, the size or the jobs number, and the action]
[Subhead: the timeline, or what it replaces or enables]

[CITY, State, Month Day, Year]: [Company] will [open, expand, relocate] at
[location] in [month], [the jobs or investment number]. [What it means locally.]

[Paragraph 2, evidence: square footage, investment figure, job count by type,
hiring timeline, the address, and the opening date.]

[Quote from a company leader: why this location was chosen over others, and
what the company is committing to locally.]

[Paragraph 4: hiring specifics. Roles, wage range if disclosable, how to apply,
when hiring starts. This is the paragraph local outlets reprint verbatim.]

[Quote from a local official or an economic development partner, if provided
and approved. Never write one for them.]

[Paragraph 6: context on the company's footprint and why it is growing.]

[Boilerplate]

[Contact block]

###
```

**Bracket, never invent:** job counts, investment figures, square footage, wages, incentives, addresses, and opening dates.

**Careful with:** tax incentive figures, which are often public record and easy to get wrong, and job numbers, which get checked later.

---

## 8. Response to an event or issue

**Usually runs on:** element 4 (a conflict, a reversal, or a risk being addressed).

**The trap:** the non-statement. A release that acknowledges an issue without saying what is being done, by when, and who is accountable makes the situation worse and reads as evasion. Speed matters more than polish here, and every word is quotable.

**Filled example**

> **Headline:** Lakeside Utilities Will Refund 4,200 Customers Overbilled Since March
>
> **Subhead:** Credits average $118 and appear on October statements. A meter reading error caused the overcharge.
>
> **Lead:** GREEN BAY, Wis., Sept. 9, 2026: Lakeside Utilities will refund 4,200 customers overbilled since March because of a meter reading error, issuing credits averaging $118 on October statements and reverting the affected accounts to their prior rate.

**Structure**

```
FOR IMMEDIATE RELEASE

[Headline: the action being taken, not the acknowledgment of a problem]
[Subhead: the scale, the remedy, and the timing]

[CITY, State, Month Day, Year]: [Company] will [the corrective action],
affecting [number of people]. [What went wrong, in plain factual language.]

[Paragraph 2, evidence: what happened, when it started, when it was found,
how it was found, how many are affected. Facts only, no characterization.]

[Quote from the most senior person willing to be accountable. It must contain
a commitment with a date attached, not a sentiment. This quote gets pulled and
run alone. Write nothing here that cannot stand by itself in a headline.]

[Paragraph 4: what affected people need to do, and what happens automatically.
Include a phone number and a page to check status.]

[Paragraph 5: what is changing so it does not recur, with a date.]

[Paragraph 6: any regulatory or third-party involvement, stated neutrally.]

[Boilerplate]

[Contact block, with a mobile number that will be answered]

###
```

**Bracket, never invent:** the cause, the timeline, the number affected, the remedy amount, and the corrective measures. Getting any of these wrong in a response release is worse than saying less.

**Careful with:** admitting liability, speculating on cause before an investigation closes, and any characterization of intent. Anything touching legal exposure, a regulator, or a health and safety claim goes to counsel before distribution, not after.

**Flag to the user:** if the situation involves injury, a regulator, a data breach, or ongoing litigation, say plainly in one line that this needs legal review before it goes anywhere. Then write it.
