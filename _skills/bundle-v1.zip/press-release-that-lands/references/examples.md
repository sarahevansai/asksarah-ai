# Before and After

Five complete rewrites across different industries, each shown the way the skill delivers: the release first, then the gate verdict and score, then one coaching note.

Example 5 is a gate failure. The release still gets written. That is the point.

All companies, people, and figures here are fictional and generic. Never write an example release about a real company, and never reuse these numbers as if they were real.

---

## Example 1: Manufacturing

### Before

```
FOR IMMEDIATE RELEASE

Halverson Industrial Announces Launch of Innovative New Predictive
Maintenance Platform: Transforming the Future of Factory Uptime

CEDAR RAPIDS, Iowa: Halverson Industrial, a leading provider of
best-in-class industrial solutions, is proud to announce the launch of
HalvSense, a revolutionary new predictive maintenance platform designed
to transform how manufacturers approach equipment reliability.

Leveraging cutting-edge AI and machine learning, HalvSense provides
end-to-end visibility into equipment health, empowering manufacturers to
move from reactive to proactive maintenance strategies.

"We are incredibly excited to bring HalvSense to market," said Ray
Mendel, CEO of Halverson Industrial. "This launch represents a major
milestone in our ongoing commitment to innovation and customer success.
We are passionate about helping our partners achieve operational
excellence, and HalvSense is a true game changer for the industry."

HalvSense features a robust suite of capabilities including real-time
monitoring, customizable dashboards, automated alerting, seamless
integration with existing systems, and comprehensive reporting.

For more information, visit our website.

Media Contact: press@halversonindustrial.example

###
```

What is wrong: the headline is 16 words with a colon stacking two ideas and the company name in front. The lead is a sentence about the company being proud. There is not one number in the entire release. The quote could be pasted into any competitor's release without changing a word. The body is a feature list. The contact is a generic inbox.

The user, asked one question, mentioned that the pilot customers cut unplanned downtime by a third.

That is the release.

### After

```
FOR IMMEDIATE RELEASE

Halverson Cuts Unplanned Downtime 34 Percent Across Six Pilot Plants

Vibration sensors flag bearing failures nine days out, replacing the
monthly inspection routine most mid-size plants still run.

CEDAR RAPIDS, Iowa, Sept. 9, 2026: Halverson Industrial released
HalvSense, a maintenance system that cut unplanned downtime by an
average of 34 percent across six manufacturing plants during an
18-month pilot.

The system uses vibration and temperature sensors on rotating equipment
to identify bearing and motor failures an average of nine days before
they occur. Across the six pilot sites, which run [EQUIPMENT COUNT]
monitored machines combined, the plants recorded [NUMBER] unplanned
stoppages during the pilot period against [NUMBER] in the prior 18
months.

[QUOTE TO BE APPROVED BY RAY MENDEL, CHIEF EXECUTIVE OFFICER]

What this quote needs to do: explain the bet the company made in
building this rather than buying an existing platform, which the facts
above cannot say on their own.

Suggested angles for Ray to approve, revise, or replace:
- Why the company built sensors rather than reselling a software layer
- What the nine-day warning window changes about how a plant staffs
  maintenance
- What he expects the six pilot plants to do differently in year two

HalvSense is available now to manufacturers in North America. Pricing
starts at [PRICE] per monitored machine per month, with installation
handled by Halverson technicians. The system reads from existing
programmable logic controllers and does not require a plant to replace
its control hardware.

Most mid-size manufacturers still run maintenance on a calendar,
inspecting equipment monthly whether or not it shows signs of wear.
That approach misses failures that develop between inspections, which
account for [PERCENTAGE] of unplanned downtime industry-wide according
to [SOURCE].

About Halverson Industrial
Halverson Industrial builds monitoring and control equipment for
manufacturing plants. Founded in 1994 and based in Cedar Rapids, Iowa,
the company serves about [NUMBER] plants across North America and
employs [NUMBER] people.

Media Contact
[NAME], [TITLE]
[DIRECT PHONE] | [EMAIL]

###
```

**Gate:** running on element 1, the 34 percent downtime reduction across six named pilot sites. That number was in the founder's head and not in the draft.

**Release Standard: 2/8 → 8/8 once the brackets are filled.** Brackets carry the equipment counts, pricing, the industry statistic, and the contact block.

- The headline named the company and the product category instead of the result. The result was the only news in the room.
- The quote contained "excited," "passionate," "commitment," and "game changer," and said nothing only Ray could say. It has been replaced with a placeholder and three angles for him to approve.
- The feature list has been cut. A reporter does not write about customizable dashboards.

**Coaching note:** The most interesting fact about your product almost never appears in the first draft, because internally it is old news. Before writing anything, ask the person closest to the work what surprised them. The 34 percent came out of a passing remark, and it was the entire story.

---

## Example 2: Healthcare

### Before

```
FOR IMMEDIATE RELEASE

Pine Hollow Health System Partners With Northgate Medical Group to
Enhance Patient Care Across the Region

PINE HOLLOW, Ore.: Pine Hollow Health System today announced a strategic
partnership with Northgate Medical Group. The collaboration will
leverage the strengths of both organizations to deliver enhanced,
patient-centered care throughout the region.

"We are thrilled to partner with Northgate Medical Group," said Dr.
Alicia Vance, President of Pine Hollow Health System. "Our shared values
and commitment to clinical excellence make them the perfect partner as
we continue our mission of improving lives in the communities we serve."

"We could not be more delighted," said Tom Brackett, CEO of Northgate
Medical Group. "This partnership aligns perfectly with our vision for
the future of healthcare delivery."

The partnership will focus on expanding access, improving outcomes, and
driving innovation across the continuum of care.

###
```

What is wrong: two quotes, both interchangeable, neither containing information. No patient appears anywhere. No number. Nothing a person outside these two organizations could act on. The release is about two companies feeling good about each other.

Asked what actually changes for a patient, the user said Northgate's specialists will hold clinic days at three rural Pine Hollow sites, so patients stop driving to the city.

### After

```
FOR IMMEDIATE RELEASE

Cardiology Comes to Three Rural Clinics, Ending 90-Mile Drives for
2,100 Patients

Northgate specialists will hold weekly clinic days in Pine Hollow,
Dexter and Rowan starting Nov. 3.

PINE HOLLOW, Ore., Sept. 9, 2026: About 2,100 patients in three rural
Oregon counties will see a cardiologist locally starting Nov. 3, ending
a round trip of up to 90 miles that Pine Hollow Health System says
causes roughly [PERCENTAGE] of its specialty referrals to go unfilled.

Under an agreement with Northgate Medical Group, three Northgate
cardiologists will hold weekly clinic days at Pine Hollow's Dexter,
Rowan and Pine Hollow sites. The clinics will handle follow-up visits,
monitoring and pre-surgical consultations. Procedures requiring a
catheterization lab will still be scheduled at Northgate's [CITY]
facility.

[QUOTE TO BE APPROVED BY DR. ALICIA VANCE, PRESIDENT, PINE HOLLOW
HEALTH SYSTEM]

What this quote needs to do: say what the unfilled referral rate has
been costing patients clinically, which is the part of this story the
logistics cannot carry.

Suggested angles for Dr. Vance to approve, revise, or replace:
- What happens medically when a cardiology referral goes unfilled for
  six months
- Why the system chose to bring specialists in rather than expand
  transportation assistance
- What she expects the unfilled referral rate to be a year from now

Patients currently referred to cardiology from the three clinics travel
to [CITY], a drive of 55 to 90 miles each way. Pine Hollow tracked
[NUMBER] referrals from these sites last year.

Existing patients will be contacted by their primary care office to
reschedule. New appointments open Oct. 6 by phone at [NUMBER] or through
the patient portal. Insurance and billing are unchanged: visits are
billed by Northgate under existing coverage.

The agreement runs through [DATE] and covers [NUMBER] clinic days
annually.

About Pine Hollow Health System
Pine Hollow Health System operates [NUMBER] clinics and one hospital
across [NUMBER] counties in eastern Oregon. It was founded in 1961 and
employs about [NUMBER] people.

About Northgate Medical Group
Northgate Medical Group is a physician group of [NUMBER] specialists
based in [CITY], Oregon.

Media Contact
[NAME], [TITLE]
[DIRECT PHONE] | [EMAIL]

###
```

**Gate:** running on element 3, a decision with consequences for people outside both organizations. 2,100 patients stop making a 90-mile drive.

**Release Standard: 1/8 → 8/8 once the brackets are filled.** Brackets carry the referral figures, the facility names, the appointment line, and both boilerplates.

- The original never named a patient, a number, or a change. It described a relationship between two organizations.
- Two executive quotes said the same thing twice. One placeholder replaces both, and the second voice should be a patient or a referring physician if one will speak.
- The paragraph about how to get an appointment is the most reprinted paragraph in a healthcare release, and it was missing entirely.

**Coaching note:** In any partnership release, find the third party. If you cannot name who outside the two companies is better off and by how much, you do not have a release, you have a contract signing. The test is whether a person who has never heard of either organization would care about the first sentence.

---

## Example 3: Financial services

### Before

```
FOR IMMEDIATE RELEASE

Granite Peak Bank Announces Successful Completion of $22 Million
Capital Raise

DENVER: Granite Peak Bank is pleased to announce the successful
completion of a $22 million capital raise led by a group of
institutional investors. The funding will be used to accelerate growth
and support the bank's strategic initiatives.

"This raise is a strong vote of confidence in our team and our
strategy," said Priya Raman, CEO. "We are excited about the road ahead
and remain committed to delivering exceptional value to our customers
and shareholders."

Granite Peak Bank is a leading community bank serving customers
throughout the Mountain West with a full suite of innovative financial
products and services.

###
```

What is wrong: the money is the entire release, and money alone is not news. "Accelerate growth" and "strategic initiatives" say nothing. Nobody outside the bank is mentioned. The boilerplate could describe two hundred banks.

Asked what the money does, the user said the bank is opening branches in three towns that lost their only bank in the last four years.

### After

```
FOR IMMEDIATE RELEASE

Granite Peak Raises $22 Million to Open Branches in Three Towns With
No Bank

Hays, Cordell and Milton lost their last branch between 2022 and 2025,
leaving about 14,000 residents without a local option.

DENVER, Sept. 9, 2026: Granite Peak Bank raised $22 million and will
open full-service branches in Hays, Cordell and Milton, Colorado, three
towns that each lost their only bank between 2022 and 2025 and together
serve about 14,000 residents.

The round was led by [LEAD INVESTOR] with participation from [INVESTORS]
and brings the bank's total capital to [AMOUNT]. Granite Peak will open
the first branch in [MONTH] and all three by [DATE], adding [NUMBER]
employees. The bank holds [AMOUNT] in deposits across [NUMBER] existing
branches.

[QUOTE TO BE APPROVED BY PRIYA RAMAN, CHIEF EXECUTIVE OFFICER]

What this quote needs to do: explain the economics of opening branches
in markets larger banks left, which is the decision at the center of
this story and the thing readers will be skeptical about.

Suggested angles for Priya to approve, revise, or replace:
- Why these three towns are viable when the departing banks concluded
  otherwise
- What the bank gives up by putting capital into branches rather than
  digital
- What she expects deposit growth in these markets to look like by 2028

Residents of the three towns currently drive between 22 and 41 miles to
the nearest branch. Small business lending in the three counties fell
[PERCENTAGE] after the closures, according to [SOURCE].

Each branch will offer consumer deposit accounts, small business
lending, and mortgage origination. Staffing will be local, with hiring
beginning [MONTH]. Branch addresses and opening dates are at [URL].

About Granite Peak Bank
Granite Peak Bank is a community bank founded in 1978 and headquartered
in Denver. It operates [NUMBER] branches in Colorado and Wyoming and
holds [AMOUNT] in assets. Member FDIC. Equal Housing Lender.

Media Contact
[NAME], [TITLE]
[DIRECT PHONE] | [EMAIL]

###
```

**Gate:** running on element 3, a decision with consequences for 14,000 people who currently have no bank in their town. Element 1 is also present in the $22 million, but the money is the weaker of the two.

**Release Standard: 2/8 → 8/8 once the brackets are filled.** Brackets carry the investors, the deposit and asset figures, the opening dates, and the contact block.

- The original made the money the story. The money is never the story. What the money does is the story.
- "Accelerate growth" and "strategic initiatives" were doing the work of three real facts that existed and were left out.
- Regulatory disclosure lines belong in the boilerplate of every bank release. They were missing.

**Note flagged to the user:** anything in a financial services release that could read as a projection of return, a guarantee, or a solicitation needs compliance review before distribution. The deposit growth angle suggested for the quote is the one most likely to need adjusting.

**Coaching note:** Funding is the most over-written and under-reported release type in existence, because most of them stop at the number. The raise is the setup. The spend is the story. Write the release you would write if you were not allowed to mention the dollar amount, then put the amount back in.

---

## Example 4: Education

### Before

```
FOR IMMEDIATE RELEASE

Westfield Technical College Names New Vice President of Student Affairs

WESTFIELD, Mass.: Westfield Technical College is delighted to announce
the appointment of Dr. Marcus Oyelaran as Vice President of Student
Affairs, effective immediately.

Dr. Oyelaran brings over 20 years of experience in higher education
administration. He holds a doctorate in Educational Leadership and has
served in progressively senior roles at several institutions.

"We are honored to welcome Dr. Oyelaran to our leadership team," said
President Karen Doyle. "His extensive experience and proven track record
make him an outstanding addition to Westfield Technical College."

"I am thrilled to join this exceptional institution," said Dr.
Oyelaran. "I look forward to working with the talented faculty and staff
to serve our students."

###
```

What is wrong: this is a resume with two compliments attached. Nothing tells a reader what changes. The quotes are the two most common non-quotes in the genre.

Asked why the role exists, the user said the college has been losing 4 in 10 first-year students and the new VP was hired specifically to change that.

### After

```
FOR IMMEDIATE RELEASE

Westfield Tech Hires Retention Chief After Losing 4 in 10 First-Year
Students

Marcus Oyelaran will control advising, tutoring and emergency aid, three
functions previously split across four departments.

WESTFIELD, Mass., Sept. 9, 2026: Westfield Technical College named
Marcus Oyelaran vice president of student affairs and gave him
consolidated authority over advising, tutoring and emergency student
aid, after 41 percent of the college's first-year students failed to
return for a second year.

Oyelaran will oversee [NUMBER] staff and a budget of [AMOUNT], combining
functions that previously reported to four separate offices. The college
set a target of cutting first-year attrition to [PERCENTAGE] by [YEAR].
The 41 percent figure is drawn from the [YEAR] cohort and compares with
a [PERCENTAGE] average across Massachusetts community and technical
colleges, according to [SOURCE].

[QUOTE TO BE APPROVED BY KAREN DOYLE, PRESIDENT]

What this quote needs to do: state what the college concluded was
causing students to leave, which is the question every reader will have
after the first sentence.

Suggested angles for President Doyle to approve, revise, or replace:
- What the college learned from surveying students who did not return
- Why consolidating four offices was chosen over adding staff to each
- What she will consider a failure of this hire two years from now

Oyelaran previously served as [TITLE] at [INSTITUTION], where [SPECIFIC
RESULT WITH A NUMBER]. He holds a doctorate in educational leadership
from [INSTITUTION].

[QUOTE TO BE APPROVED BY MARCUS OYELARAN]

What this quote needs to do: name the first thing he intends to change
and what he is willing to be measured on.

Suggested angles for Oyelaran to approve, revise, or replace:
- The first change he plans in the first semester
- What he found in the retention data that others missed
- What number he expects to be judged on

Westfield Technical College enrolls about [NUMBER] students across
[NUMBER] programs. First-year attrition has risen from [PERCENTAGE] in
[YEAR], a trend the college attributes in part to [FACTOR].

About Westfield Technical College
Westfield Technical College is a public technical college in Westfield,
Massachusetts, founded in 1966. It enrolls about [NUMBER] students in
trades, health sciences and engineering technology programs.

Media Contact
[NAME], [TITLE]
[DIRECT PHONE] | [EMAIL]

###
```

**Gate:** running on element 4, a risk being addressed. A college losing 41 percent of its first-year class and restructuring to fix it is a story. A hiring announcement is not.

**Release Standard: 1/8 → 8/8 once the brackets are filled.** Brackets carry the attrition target, the budget and staff numbers, the comparison figures, and the hire's prior results.

- The original opened on the appointment. The appointment is the least interesting fact available. The 41 percent is the release.
- Both quotes were interchangeable pleasantries. Both have been replaced with placeholders that name what each person needs to address.
- The hire's background now appears in service of the mandate, not as a credential list.

**Coaching note:** Every executive hire release asks the wrong question. It asks who joined. The question a reporter asks is why this role exists now. If the honest answer is "the last person left," you may not have news. If the honest answer is a number the company is trying to fix, that number is your headline.

---

## Example 5: When the gate fails

This is the one that matters most. The verdict is honest, it is one line, and the release still gets delivered.

### Before

```
FOR IMMEDIATE RELEASE

Fairmount Logistics Named to the 2026 Regional Business Excellence List

FAIRMOUNT, Ky.: Fairmount Logistics is proud to announce that it has
been named to the 2026 Regional Business Excellence List, recognizing
outstanding companies across the region.

"This recognition is a testament to the hard work and dedication of our
entire team," said Owner Dale Kirchner. "We are honored to be included
among such an impressive group of businesses and remain committed to
excellence in everything we do."

Fairmount Logistics has been serving customers since 2009 with a
commitment to quality, integrity, and customer satisfaction.

###
```

The user said the list has no published criteria, does not disclose how many companies were considered, and that companies apply to be considered.

### After

```
FOR IMMEDIATE RELEASE

Fairmount Logistics Named to 2026 Regional Business Excellence List

The Kentucky freight company has operated in Fairmount since 2009 and
runs [NUMBER] trucks across [NUMBER] states.

FAIRMOUNT, Ky., Sept. 9, 2026: Fairmount Logistics was named to the
2026 Regional Business Excellence List, an annual recognition of
businesses in [REGION] selected by [AWARDING ORGANIZATION].

The list recognizes [STATED CRITERIA]. Fairmount Logistics operates
[NUMBER] trucks and employs [NUMBER] people, serving [NUMBER] customers
across [NUMBER] states from its Fairmount terminal.

[QUOTE TO BE APPROVED BY DALE KIRCHNER, OWNER]

What this quote needs to do: give a reader one concrete thing about how
this company operates differently, because the award itself carries no
information.

Suggested angles for Dale to approve, revise, or replace:
- The operating decision he would point to if someone asked why the
  company has lasted 17 years
- What the company does that its customers say larger carriers do not
- What he has turned down business over

The company opened in 2009 with [NUMBER] trucks and has grown to
[NUMBER]. [ONE CONCRETE OPERATING FACT: on-time rate, driver retention,
average customer tenure, or a route or service others do not run.]

About Fairmount Logistics
Fairmount Logistics is a freight carrier based in Fairmount, Kentucky.
Founded in 2009, it operates [NUMBER] trucks serving [NUMBER] states and
employs [NUMBER] people.

Media Contact
[NAME], [TITLE]
[DIRECT PHONE] | [EMAIL]

###
```

**Gate: running on none of the five. This is an announcement, not news.** The list has no published criteria, no disclosed field size, and companies apply to be on it. No outlet will cover it, and the release above is written to be posted on your own site and sent to customers, which is a real and reasonable use.

**The one fact that would turn this into news:** an operating number. Driver retention against the industry average, on-time delivery rate, a route nobody else runs, or the longest customer relationship in years. Give me one of those and the headline stops being about a list.

**Release Standard: 3/8 → 8/8 once the brackets are filled,** measured against what this release can be. The ceiling here is set by the news, not the writing.

- The headline is unchanged, because the award is genuinely all there is. Padding it with "proud" or "excellence" would make it worse, not longer.
- The quote placeholder now asks Dale for something concrete, because the award contributes no information and the quote is the only place information can enter.
- The bracketed operating fact in paragraph four is the most important bracket in the document. Fill that one and the release changes shape.

**Coaching note:** Awards are the most common release type and the least covered. Before writing one, ask three questions: are the criteria published, is the field size disclosed, and did you apply. Three noes means you have a customer newsletter item and a LinkedIn post, which is fine. Save the release for the operating result that earned the award, and lead with that instead.
