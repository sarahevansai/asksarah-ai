---
name: delegation-brief
description: >
  Writes the handoff brief that makes delegated work come back right the first time. Use
  whenever someone is assigning, handing off, or explaining work to another person: a
  direct report, a contractor or agency, a peer, PTO coverage, or a new hire taking over
  a recurring task. Trigger on "how do I delegate this," "write a brief," "hand this
  off," "brief my contractor," "they keep getting it wrong," "I had to redo it myself,"
  "write a handoff doc," "transition plan," or "scope of work." Also trigger in reverse
  when someone received a vague assignment and needs to confirm what was asked: "my boss
  gave me a vague task," "confirm the scope." Trigger unprompted when a described
  handoff has no deadline, no definition of done, or no statement of what the person may
  decide alone. When in doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Delegation Brief

Most rework is not caused by bad workers. It is caused by handoffs that never defined what "done" looks like.

The person doing the work guesses. They guess wrong, in good faith, and they guess wrong for two weeks. The work comes back and it is not what you pictured, so you fix it yourself. Then you conclude that you cannot delegate, that the bench is not strong enough, that it is faster to just do it. So you do it. And you stay stuck at exactly the size of your own calendar.

The bottleneck is almost never capability. It is specification. This skill fixes the specification.

---

## The #1 rule: always deliver the brief

**Every run ends with a written, copy-ready handoff brief. No exceptions.**

Not a checklist of what to think about. Not advice on how to delegate better. Not questions about the task. The brief itself, addressed to the person by name, ready to paste into Slack, Teams, email, or a ticket.

This holds even when:

- The user asked a question about delegating, not for a brief. Answer the question in two lines, then hand them the brief that solves it.
- The user described the task in one vague sentence. Infer the rest and write it. A brief they correct in thirty seconds beats an interview they have to sit through.
- The user is venting that someone keeps getting it wrong. The brief is the fix. Write the one they should have sent, using what actually went wrong as the source of the constraints.
- The user has not decided who it is going for. Write it to `[NAME]` and pick a delegation level based on the task itself.
- The task is small. Small tasks generate most of the rework, because nobody thinks a small task deserves a brief.
- The user only wants one part fixed, like the deadline or the decision rights. Fix that part, then deliver the whole brief with the fix in place.

**Never end a response with a question instead of a brief.** If a missing fact would change the brief, deliver the brief first, then ask the one question, and say what you would change once you have the answer.

**A blank template is not a brief.** Handing back a six-heading skeleton with empty bullets is the most common way this rule gets broken while looking like it was followed. If the user described a situation, the brief is about THEIR situation, in their words, with their details in it. The empty structures live in `references/templates.md` and they are raw material for you, not output for the user.

**Never offer to write the real one later.** "Send me more detail and I will write it up" is a failure. Write it now from what you have.

### Bracket discipline

Brackets are for facts only the user can know: a name, a date, a dollar figure, a link, a client, a tool, a file location.

- Infer aggressively, then state the assumption in one line below the brief. "Wrote this assuming she has done a version of this before and can pick the format herself. If this is her first one, say so and I will drop it to Level 1 with a sample attached."
- Two brackets and one stated assumption beats twelve brackets. Twelve brackets is a form, and a form is homework.
- Never bracket the outcome, the context, the decision rights, or the checkpoint. Inferring those is the entire job.
- Never bracket something the user already told you loosely. If they said "sometime next week," write "Thursday [confirm]," not "[deadline]."
- Never invent a name, a number, a date, a client, or a link.

The brief is the product. Everything else in this file is how to make it good.

---

## The one flip that changes everything

A bad handoff describes **the activity**: "put together a competitive analysis."

A good handoff describes **the finished thing**: "a one-page comparison the sales team can hand a prospect who asks why we cost more than [competitor], with our three strongest differences and their pricing where it is public."

The first one has a thousand right answers, so it has a thousand wrong ones. The second one has a shape. The person can picture the artifact before they start, and so can you, and now you are both aiming at the same object.

Every rule below is downstream of that flip. When a brief feels thin and you cannot say why, check whether the first line names an activity or an artifact.

---

## The Six-Part Handoff

Six parts. Every brief carries all six. Score each one PASS or MISS.

**1. Outcome.**
What "done" looks like, in one sentence, described as a finished thing and not an activity. Name the artifact, its format, its length, and who will hold it. "A written summary" fails. "A one-page memo, five bullets, that the ops lead can read in two minutes and use to pick a vendor" passes. If you cannot name the artifact, you are not ready to delegate this yet. See "What not to delegate."

**2. Context.**
Why this matters, who it is for, and what happens to it after they hand it back. This is the part people skip because it feels like backstory, and it is the part that lets someone make a hundred small judgment calls correctly without asking you. A person who knows the deck goes to a skeptical board will build a different deck than one who thinks it is an internal FYI. Two or three lines. Include what happens if it does not get done, because that sets the real priority better than the word "urgent."

**3. Constraints.**
What cannot change. Budget ceiling, brand rules, legal or compliance limits, required format, required tool, required template, who must be consulted, who must not be contacted, what has already been tried and rejected. State the boundary, not the whole rulebook. The most valuable constraint is usually the one that sounds obvious to you: the thing "everyone knows" is exactly the thing the new person does not.

**4. Examples.**
One thing that is good, and one thing that is wrong. A link to a past example beats any description you can write. "Like the March report" transfers more information in four words than a paragraph of adjectives. If nothing good exists, name the closest thing and say which part of it to copy and which part to ignore. The anti-example matters as much as the example: "not a full research report, we are not trying to be comprehensive here."

**5. Decision rights.**
What they decide alone, and what they bring to you. Use the three levels below. This is the part that separates a brief from an assignment. A task delegated without authority is not delegated, it is queued behind you.

**6. Checkpoint and deadline.**
When you will look at it in progress, and when it is due. Two dates, not one. The checkpoint is what prevents the 90-percent-done surprise, which is the most expensive failure in delegated work, because by then the person is emotionally invested and the calendar is gone.

---

## The three levels of decision rights

Every task, and often every line inside a task, sits at one of three levels. Name the level explicitly. Never make someone infer it.

**Level 1: "Do it exactly this way."**
You have a specific method and a specific output in mind. They execute the spec and check with you before deviating.
Use when: the format is fixed, the stakes are external, compliance or legal is involved, or it is their first time doing this kind of work.
Cost of getting this wrong: you get a stenographer. Nobody grows at Level 1, and if everything is Level 1 you have hired hands, not a team.

**Level 2: "Decide and tell me."**
They choose the approach, make the calls, and report what they decided. You find out after, not before, and you do not overturn it without a real reason.
Use when: they have done something adjacent before, the cost of a wrong call is recoverable, and you want them to build judgment.
This is where most work belongs and where the least work actually sits.

**Level 3: "Decide, no need to tell me."**
They own it end to end. You see the result, or you see nothing, and that is fine.
Use when: they have done this specific thing successfully before, or the decision is genuinely reversible and small.
Cost of getting this wrong: a surprise. Use Level 3 on things where a surprise is survivable.

### How to pick the level

**The level depends on the person's experience with THIS kind of task, not their seniority.**

A twelve-year veteran who has never run a client onboarding is Level 1 on client onboarding and Level 3 on the thing they have done four hundred times. A two-year analyst who has built this exact report six times is Level 3 on the report. Assigning by title is how experienced people get insulted and how new people get drowned.

Four rules:

- **Mixed levels are normal, and they should be written on the line, not on the task.** "Level 3 on the layout and the visuals. Level 2 on the data sources, tell me what you used. Level 1 on the headline numbers, those come from me."
- **Move up one level per successful pass, not three.** The person who did well at Level 1 goes to Level 2 next time. Jumping to Level 3 to prove you trust them is how you manufacture a failure and then blame delegation.
- **Never assign a level you will not honor.** If you say "decide and tell me" and then rewrite their decision, you have taught them that Level 2 is fake and they will come ask you next time. That is not them being needy. That is them being trained.
- **When you are unsure, name the level and name the escape hatch.** "Level 2, but if the number comes in over [X], that becomes a Level 1 conversation with me."

---

## The checkpoint rule

The deadline is when it is due. The checkpoint is when you look at it in progress. Most briefs have only the first, which is why so much work fails on the last day.

- **Set the checkpoint at roughly a quarter to a third of the elapsed time.** On a two-week task, the checkpoint is day 3 or 4. On a one-day task, it is two hours in. On a six-week project, it is end of week 2 at the latest.
- **Name what the checkpoint delivers.** "Check in Wednesday" produces a Slack message that says "going well." "Send me the outline and your three data sources Wednesday by noon" produces something you can actually redirect. The checkpoint is an artifact, not a conversation.
- **Check the direction, not the polish.** At the checkpoint you are asking "is this pointed at the right thing," not "is this good yet." Editing prose at the checkpoint teaches them to hide work from you until it is perfect, which reintroduces the exact surprise you were preventing.
- **The checkpoint is your obligation, not theirs.** Put it on your calendar. A checkpoint the delegator forgets is worse than no checkpoint, because they waited for you.
- **Skip the checkpoint only at Level 3 on work they have already done well.** Everywhere else, it stays.

The 90-percent-done surprise is not caused by bad work. It is caused by the first moment of contact being on the due date.

---

## What not to delegate

Two tests. If a task fails either one, do not hand it over in its current form.

**Test 1: Can you describe it as a finished outcome?**
If you cannot say what done looks like, you do not have a task yet. You have a feeling. Handing over a feeling is how you get three wrong drafts and a demoralized person. Either do the thinking first and then delegate the specified version, or delegate the thinking explicitly: "spend two hours and come back with three options for what this could even be. Level 2, no wrong answers." That is a real, briefable task. "Figure this out" is not.

**Test 2: Will you rewrite it anyway?**
If you already know exactly how you want it worded, structured, and finished, you are not delegating. You are creating a draft you will discard, and you are spending someone else's day to do it. Two honest options:

- Do it yourself. It is thirty minutes and it protects the relationship.
- Or say the truth out loud: "I have a strong version in my head. I am going to write the first draft and I want you to take it from there and own it going forward." That is a legitimate handoff, and it is far better than pretending it was theirs and then rewriting every line.

Also keep, at least for now: anything where you are the only person with the relationship required to do it, and anything where the cost of a wrong first attempt lands on a client or a regulator rather than on you.

Everything else goes. The test is not "could they do it as well as me." It is "could they do it at 80 percent, and is 80 percent enough here." For most work, it is.

---

## The reverse rule: when YOU received a vague handoff

Half of all bad handoffs arrive at your desk rather than leaving it. You get "can you look into the churn thing and put something together," and you have three choices: guess, ask a string of questions that makes you look lost, or write the brief back up.

Write it back up. Always.

**The confirmation brief is the single fastest way for a junior person to look senior.** You take the vague ask, you fill in the six parts with your best interpretation, and you send it back for a yes or a correction. It takes four minutes. It does three things at once:

1. It surfaces the mismatch on day one instead of day nine.
2. It transfers the risk. Once they confirm, the scope is agreed, in writing, and a change later is a change and not a failure.
3. It reads as ownership. The person who says "here is what I understood, confirm or correct" is behaving like the owner of the work. The person who asks six questions in six separate messages is behaving like a ticket.

The shape:

```
Confirming what I heard on [task] before I start.

**Outcome:** [what I am going to hand you, as a finished thing, with format and length]
**Who it is for:** [audience and what happens to it after]
**Approach:** [the two or three things I plan to do, in order]
**Assuming:** [the two or three judgment calls I am making, stated plainly]
**Not doing:** [what I am deliberately leaving out, so scope does not drift]
**Checkpoint:** I will send you [specific artifact] on [date].
**Due:** [date].

If any of that is off, tell me which line and I will adjust. Otherwise I am starting [today / tomorrow morning].
```

Rules:

- **Include "not doing."** It is the highest-value line in the whole message. It is where you discover they wanted something twice the size, on day one, when that is still a cheap discovery.
- **Set your own checkpoint.** Do not wait to be given one. Volunteering a checkpoint is what a senior person does.
- **Commit to starting.** "Otherwise I am starting tomorrow" converts silence into progress instead of into a stall.
- **Never send this as a list of questions.** Questions transfer work back to a busy person and they will answer two of six. A brief they can approve with one word gets answered.
- **Keep it under 150 words.** If your confirmation brief is a page, you are negotiating, not confirming.

---

## Common failure modes

Name these when you see them in a user's situation. Each one has a specific fix.

**Delegating the task but not the authority.**
They own the work and you own every decision inside it, so they stop at every fork and wait. The work moves at the speed of your inbox. Fix: assign a level to each part, and let the Level 2 calls stand even when you would have chosen differently.

**Checkpoint set too late, or not set at all.**
"Let me know when it is done" means the first time you see it, the calendar is spent. Fix: an artifact-bearing checkpoint at a quarter of the elapsed time.

**No example given.**
You have a picture in your head from four years of doing this. They have nothing. Fix: link one past thing that was right. If nothing exists, link the closest thing and say which half to copy.

**"Let me know if you have questions."**
It sounds generous and it does nothing. It puts the burden of knowing what they do not know onto the person who does not know it. It also quietly signals that interrupting you is the escape hatch, which is the opposite of decision rights. Fix: replace it with the actual decision rights, plus one named thing to come back on. "You decide the format. Come to me only if the budget lands over $5K."

**The outcome is an activity.**
"Research competitors," "clean up the process," "look into it." No finish line means no way to be done. Fix: name the artifact.

**The invisible audience.**
You know it is going to the board. They think it is for you. They optimize for a completely different reader. Fix: part 2, every time.

**The deadline with no start.**
Due in three weeks, so it starts in two and a half. Fix: the checkpoint is a start date in disguise, which is a second reason to set one.

**Delegating the piece instead of the outcome.**
Handing over ten disconnected steps keeps all the judgment with you and builds nothing in them. Fix: give the outcome and let them own the steps, at whatever level fits.

**The silent standard.**
"That is not how we do it here" said after the fact, about a rule that was never written down. Fix: constraints. Every time you catch yourself saying "obviously," write that sentence into the brief.

---

## How to run this skill

Determine the mode from what the user gives you. Every mode ends the same way, with a finished brief.

**Mode 1: Write a brief from scratch** (default)
The user describes work they want to hand off. Ask at most two questions, then write it. If they do not answer, write it anyway with brackets and a stated assumption.

**Mode 2: Fix a vague brief**
The user pastes what they sent or plans to send. Deliver the rewritten brief, then the score on the original, then one coaching note. Do not annotate line by line.

**Mode 3: Confirmation brief back up to a manager**
The user received something vague. Write the confirmation brief in their voice, using the reverse-rule shape. Fill the gaps with your best read of what was probably meant, and mark the interpretation clearly so it is easy to correct.

**Mode 4: Rescue a handoff that came back wrong**
The work is already off track. Do not relitigate. Write the redirect brief: what is right and stays, what changes, the new outcome, the new checkpoint. Then one coaching note about which of the six parts was missing the first time, because it is almost always the same one twice.

**Mode 5: Coach**
The user asks a delegation question rather than for a brief. Answer in three lines or fewer, then deliver the brief that puts the answer into practice on their actual situation. Do not offer to draft it. Draft it.

### Before writing, know three things

1. **Who is receiving it,** and how much experience they have with this specific kind of task. This sets the level.
2. **What the finished thing is,** as an object. This sets part 1.
3. **Where it goes after they hand it back.** This sets parts 2 and 3, and it usually sets the real deadline.

Ask a maximum of two questions to close those gaps. If the user is in a hurry or does not answer, write it anyway with brackets. Never stall a brief over missing detail.

---

## Output format

Deliver in this order, every time.

**1. The brief, first.**
In a copy-ready block, addressed to the person by name, complete and sendable. One line above it naming what it is and where to paste it. Never replaced by a description of what the brief should contain.

**2. The score.**
`Handoff Standard: 2/6 → 6/6`, followed by the parts that were missing, named. Three bullets maximum.

Only score a before-number when the user actually pasted a brief or quoted what they said. If they described a situation instead, there is nothing to score, and grading their casual sentence is both wrong and insulting. Write `Handoff Standard: 6/6` alone, or `6/6 once the brackets are filled`, and name which parts the brackets are carrying.

**3. One coaching note.**
The single pattern that would most improve their next handoff, written so it generalizes past this task. One note, not five. Pick the one costing them the most time.

**4. At most one question, and only after the brief.**
Only if the answer would materially change the brief. Say what you would change once you have it. Never above the brief. Never instead of it.

Do not narrate your process. Do not explain each change. Do not summarize after the coaching note.

**Hard formatting constraints on everything you produce.** These override any template or example:

- No em dashes anywhere. Not in the brief, not in the score line, not in the coaching note, not inside bullets. Use a colon, a comma, or a period. This is the most common leak, and it usually happens in your own commentary rather than in the brief.
- No ellipses.
- Bold labels at the start of a line for each of the six parts. Chat has no headings, so bold does that work.
- A blank line between sections. Density is why briefs go unread and then guessed at.
- Arrows (→) for lists in Slack and email. Bullets in documents.
- One clear owner name and one real calendar date. Never "EOD," never "ASAP," never "soon."

**Self-check before responding.** Three questions:

1. Does this contain a complete brief the user could paste right now?
2. Does it name a finished artifact, a level, and two dates?
3. Are there any em dashes in it?

If any answer is wrong, the response is not finished.

---

## Length discipline

A brief is not documentation. It is the smallest thing that removes the guessing.

| Situation | Ceiling | Rule |
|---|---|---|
| One-off task, someone experienced | 6 lines | Outcome, level, date. The other three parts only if they are not obvious. |
| First-time task for that person | 12 lines | All six parts, with a linked example. Non-negotiable. |
| Client-facing deliverable | 15 lines | Constraints and approval path get their own lines. |
| Recurring task handoff | 1 page | Written once, reused forever. This is the one worth over-investing in. |
| Urgent, hours not days | 5 lines | Outcome, the one constraint that matters, decision rights, the hour it is due. |
| PTO or coverage handoff | 1 page | Organized by trigger, not by project. See templates. |
| Confirmation back up to a manager | 150 words | Approvable with one word. |

If the brief is longer than the task, you are writing a manual. Link the manual, keep the brief short.

---

## Language rules

**Cut on sight:**
- "Let me know if you have questions." Replace with the decision rights.
- "Whenever you get a chance." Give a date or admit it is not real.
- "Just a quick thing." It never is, and it teaches people to underscope.
- "Make it good," "make it pop," "you know what I mean." None of these are specifications.
- "ASAP," "EOD," "end of week." Use a day and a time.
- "Basically just" anything. The word "just" hides the hard part.
- "Run it by me" without saying what for. Approval, awareness, or a sanity check are three different requests.

**Keep:**
- Concrete nouns. "A one-page memo," "a five-slide deck," "a spreadsheet with these four columns."
- Real numbers, real dates, real names, real links.
- The word "because." Every constraint lands better with one clause of reason attached, and a person who knows the reason can handle the case you did not anticipate.
- Plain verbs at the front: Write. Send. Confirm. Decide. Choose. Book.

**Never:**
- Em dashes. Use a period, a comma, or a colon.
- Sarcasm or a jab about a past mistake. A brief that scolds gets read as a warning, not as instructions.
- A deadline you invented to create urgency. Fake deadlines are discovered exactly once, and after that none of your deadlines work.
- A constraint you are not willing to state as a rule. If it is a preference, call it a preference and mark it Level 2.

---

## Tone

Warm and specific, not cold and specific. The brief should read like someone handing over something valuable, not like a work order.

- **Say why they are the one getting it.** One line. "You saw the last two rounds of this, so you already have the context nobody else has." It costs nothing and it changes how the work gets done.
- **Precision is respect, not distrust.** Detail is what lets someone succeed without you. Frame it that way, out loud, when handing something to an experienced person: "Being specific here so you are not guessing at what I have in my head."
- **Name the freedom before the constraints.** Lead with what they own. It changes a list of rules into a scope of authority.
- **Never pre-apologize for the ask.** "Sorry to dump this on you" invites them to treat it as a dump.

---

## Reference files

Load these when the situation calls for it. Do not load all of them by default.

- `references/templates.md`: Fill-in briefs for the twelve most common handoffs, including recurring reports, first-time tasks, client deliverables, research, transferring a decision, urgent work, PTO coverage, contractors, the re-brief, the redirect, and the confirmation brief back up to a manager.
- `references/examples.md`: Full before-and-after handoffs from five industries, with scoring shown, including a vague Slack message turned into a real brief. Use these to calibrate the standard, or to show a user what the difference actually looks like.

---

## The final gate

Before the brief is sent, five questions. Any no means it is not ready.

1. Could they start this in the next ten minutes without asking me anything?
2. Would they be able to tell me, in one sentence, what the finished thing is?
3. Do they know which decisions are theirs?
4. Is there a date on my desk, not just theirs?
5. If they do exactly what this says and I still do not like the result, was that my fault?

Question five is the honest one. If the answer is yes, you found the missing part. Add it and send.
