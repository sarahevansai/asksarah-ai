# Delegation Brief

A Claude skill that turns any handoff into a written brief the other person can act on immediately, so the work comes back right the first time.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most rework is not caused by bad workers. It is caused by handoffs that never defined what "done" looks like. The person guesses, guesses wrong for two weeks, and you fix it yourself. Then you decide you cannot delegate, and you stay stuck at the size of your own calendar.

Describe the work you want to hand off, and Claude will:

1. Hand you the finished brief, addressed to the person, ready to paste into Slack or email
2. Score it against six checks, so you see exactly what your original was missing
3. Give you one coaching note that generalizes to every handoff after this one

**You always get a brief back.** Ask a delegation question and you get the answer plus the brief that puts it into practice. Describe the task in one vague sentence and Claude infers the rest, marks only what it genuinely cannot know in `[BRACKETS]`, and tells you the assumption it made. You never have to answer questions to get something you can send.

It works for direct reports, peers, contractors and agencies, new hires, PTO coverage, and transferring a decision you should not still be making.

Two things it handles that most delegation advice does not:

**Decision rights, stated on the line.** Every brief says what the person decides alone and what they bring to you, using three levels: "do it exactly this way," "decide and tell me," and "decide, no need to tell me." Most tasks are mixed, so the level goes on the individual item, not the whole assignment. A task delegated without authority is not delegated, it is queued behind your inbox.

**The reverse case.** If YOU are the one who received a vague assignment, Claude writes the confirmation brief back up to your manager: here is what I understood, here is what I am assuming, here is what I am deliberately not doing, confirm or correct. It takes four minutes and it is the single fastest way for a junior person to look senior.

## The Six-Part Handoff

Every brief carries all six parts:

1. **Outcome**: what done looks like, as a finished thing and not an activity
2. **Context**: who it is for and what happens to it after they hand it back
3. **Constraints**: what cannot change, including the rule that seems obvious to you
4. **Examples**: one thing that is good and one thing that is wrong
5. **Decision rights**: what they decide alone, what comes to you
6. **Checkpoint and deadline**: two dates, not one

The checkpoint is the part people skip, and it is the one that prevents the 90-percent-done surprise. Set it at a quarter of the elapsed time, and make it deliver an artifact, not a status update.

## Try it

Once installed, say any of these:

- "Help me hand this off to [name]" and describe the work
- "Write a brief for this" and paste what you were about to send
- "My boss gave me a vague task, help me confirm what they want"
- "They keep getting this wrong and I keep redoing it"
- "I am out next week, write my coverage handoff"
- "Scope this for a contractor"
- "Score this handoff"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `delegation-brief.zip` in your skills settings. Claude loads it automatically whenever a handoff needs it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/delegation-brief/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "help me hand off the monthly report to someone on my team." You should get a complete brief, a score out of 6, and one coaching note.

## What is in the package

```
delegation-brief/
├── SKILL.md                  The framework, the levels, and the output format
├── README.md                 This file
├── LICENSE
└── references/
    ├── templates.md          12 fill-in briefs for the most common handoffs
    └── examples.md           6 before-and-after handoffs with scoring, across 6 industries
```

## Notes

Claude will never invent a name, a number, a date, or a link to fill a gap. Anything it cannot know comes back in `[BRACKETS]`. It prefers two brackets and a stated assumption over twelve brackets, because twelve brackets is a form and a form is homework.

It will ask at most one question, and only after the brief is already in front of you.

It will also tell you when not to delegate something. If you cannot describe the work as a finished outcome, or you already know exactly how you want it done and will rewrite it anyway, the honest answer is to do it yourself or say so out loud. The skill says that plainly rather than helping you write a brief that was going to fail.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
