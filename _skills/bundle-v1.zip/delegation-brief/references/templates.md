# Handoff Templates

Twelve structures for the handoffs that decide whether work comes back right. Each one already passes the Six-Part Handoff. Fill the brackets, cut what does not apply, and never add a paragraph of preamble above the first line.

These are raw material for you, not output for the user. The user gets a brief about their actual situation, with their details in it.

---

## 1. Recurring report or recurring task

The highest-return brief you will ever write. You write it once and it runs every month without you. Over-invest here.

```
[Name], handing you the [report name] starting with the [month] edition.

**Outcome:** A [format, e.g. 2-page PDF] with [the 4 sections], delivered to [audience] by [day of month]. Same structure every time.
**Context:** [Audience] uses this to [decision they make with it]. If it is late, [what stalls].
**Constraints:** Pull from [source]. Use the [template name]. [Numbers get checked against X before it goes out.] Do not change the format without telling me, because [downstream person] built a process on it.
**Example:** Last month's is here: [link]. Copy the structure exactly. The commentary section is the part that varies.
**Decision rights:** Level 3 on the commentary and what you flag. Level 2 on adding or removing a section, tell me what you changed. Level 1 on the headline numbers, those come from [source] unchanged.
**Checkpoint:** First two months only, send me the draft on the [Nth] so I can look before it goes out. After that it is yours.
**Due:** [Day] of every month, by [time].
```

Rules: name the fade-out of the checkpoint explicitly, because "I will review it for a while" turns into forever. Say what breaks downstream if the format changes, or someone will improve it into something nobody can use.

---

## 2. First-time task

They have never done this kind of work. Level 1 is not an insult here, it is a runway. Say that out loud.

```
[Name], this one is new for you, so I am being specific on purpose. Not because I am worried, because I do not want you guessing at what is in my head.

**Outcome:** [The finished artifact, format, length, and who holds it at the end.]
**Context:** [Who it is for, what they do with it, what happens if it is wrong.]
**Constraints:** [The 2 or 3 hard boundaries.] [Anything that sounds obvious to me and is not obvious to you.]
**Good example:** [link]. **Not this:** [link or description of the over-built version].
**Decision rights:** Level 1 on [the format and the structure], follow the example. Level 2 on [the content choices], make the call and tell me what you picked.
**Checkpoint:** Send me [the outline / the first section / your source list] by [date]. I am checking direction, not polish, so send it rough.
**Due:** [date and time].

If you hit something the example does not cover, [make the call that seems right and flag it / ping me, that specific thing is worth an interruption].
```

Rules: the "send it rough" line is what stops them from hiding until it is perfect. The anti-example is what stops a first-timer from building three times too much.

---

## 3. Client-facing deliverable

The stakes sit outside the building, so the approval path is part of the brief and not an afterthought.

```
[Name], taking [deliverable] for [client] and I want you to own it end to end.

**Outcome:** [Deliverable], [format and length], in [client's] hands by [date].
**Context:** [Client] is [state of the relationship: new, renewing, unhappy about X]. They will use this to [their decision]. [Stakeholder name] is the one who actually reads it.
**Constraints:** [Brand or template requirement]. [What we cannot promise or claim]. Nothing goes to the client without [approver] seeing it first. Do not [contact / cc] [person] directly, that goes through [name].
**Example:** The [other client] version is the closest: [link]. Copy the structure. Their tone was more formal than [client] needs.
**Decision rights:** Level 3 on how you build it. Level 2 on scope, if you want to add or drop a section, decide and tell me. Level 1 on anything that touches [pricing / timeline commitments / legal language], that comes to me first.
**Checkpoint:** [Date], send me the skeleton and the one slide you are least sure about.
**Due:** Internal review [date], client [date]. The internal date has [N] days of margin on purpose.
```

Rules: build the internal date with real margin and say that you did, or the margin gets spent. Name the single person who actually reads it, because "the client" is not an audience.

---

## 4. Research or "look into this"

The most commonly botched handoff, because research has no natural finish line. You have to install one.

```
[Name], want you to take the [question] question.

**Outcome:** [A one-page memo / a 5-row comparison table] that answers one question: [the actual question, phrased as a question]. Not a full report. If it is longer than [one page], it is the wrong shape.
**Context:** We are deciding [the decision this feeds] on [date]. Whatever you find changes [what].
**Constraints:** Timebox this to [N hours]. If you are past that and still not sure, stop and bring me what you have, that is a legitimate outcome. [Only look at X, we already ruled out Y and here is why: link.]
**Example:** The [past] memo is the shape I want: [link]. Bottom line at the top, evidence under it.
**Decision rights:** Level 3 on sources and method. Level 2 on the recommendation, I want your call and your reasoning, not a menu of options with no opinion.
**Checkpoint:** [Date], one Slack message with your working answer so far, even if it is half formed.
**Due:** [date and time].

Come back with a recommendation, not a summary. "I could not find a clear answer, here is why" is a valid recommendation.
```

Rules: timebox it or it expands to fill everything. Ask for a recommendation explicitly, or you will get a neutral summary and still have to do the thinking yourself.

---

## 5. Transferring a decision someone else should own

You are not handing over a task. You are handing over the authority. This brief exists to make that unambiguous.

```
[Name], [decision] is yours now. Not a recommendation to me, the actual call.

**Outcome:** A decision made and communicated to [who needs to know] by [date], with one paragraph on why.
**Context:** [Why it is moving to you: proximity to the work, or it is slowing down sitting with me.] Whatever you pick, I will back it publicly.
**Constraints:** The real boundaries are [budget ceiling], [the thing that cannot break], and [who has to be consulted first, not asked for permission]. Everything inside those lines is yours.
**Example:** [How a similar call went, and what mattered in it: link.]
**Decision rights:** Level 3. Genuinely. If you want to talk it through I am happy to, but I am not approving it and I am not going to overturn it.
**Checkpoint:** [Optional. If used, make it a conversation, not an approval: "grab me [date] if you want a sounding board."]
**Due:** Decided and announced by [date], because [what is waiting on it].
```

Rules: say "I will back it publicly" only if it is true, and then make it true. One overturned Level 3 decision costs you every future Level 3.

---

## 6. Urgent, hours not days

Under pressure, the instinct is to cut the brief. Cut the length, not the parts. Five lines, all six parts compressed.

```
[Name], need this today, here is everything in one message.

**Outcome:** [The finished thing, one sentence, with the format.] In [person's] hands by [time].
**Context:** [Why today. One line.]
**The one thing that matters:** [The single constraint that would make it wrong.]
**Decision rights:** Level 3 on everything except [the one thing]. Do not wait on me for anything else, make the call.
**Checkpoint:** Send me what you have at [time], even if it is half done.

If you have to drop something to make the time, drop [X], not [Y].
```

Rules: the "if you have to drop something" line is the most useful sentence in an urgent brief, and it is almost always missing. Under time pressure someone will cut something. Tell them which thing.

---

## 7. PTO or coverage handoff

Organize by trigger, not by project. The person covering does not need your whole world, they need to know what to do when something happens.

```
[Name], covering my desk [start date] to [end date]. Everything is here, nothing needs a call unless it is on the escalation line.

**Outcome:** Nothing catches fire and nothing waits on me that did not have to. You are not moving my projects forward, you are keeping them from stalling.

**If this happens → do this:**
→ [Client / stakeholder] emails about [topic] → [the answer, or: reply "[name] is back [date], I will have an answer by [date]"]
→ [Recurring thing] on [day] → [what to do, link to the doc]
→ [System / process] does [failure] → [the fix, or the person who owns it]
→ Anything about [topic] → [name], that is theirs, not mine

**Decision rights:** Level 3 on anything under [$ amount] and anything reversible. Level 2 on [category], make the call and leave me a note for when I am back. Level 1 on [the 1 or 2 things that genuinely need me]: those wait, and tell the person they are waiting and why.

**Escalation:** Only reach me for [the specific list]. For everything else, [backup name] is the second call.

**In flight while I am out:** [Item], [status], [next date]. [Item], [status], [next date].

**When I am back:** Leave me a running list. I do not need a report, just the list.
```

Rules: "you are not moving my projects forward" is the line that stops a covering person from either doing nothing or doing too much. Give a genuine dollar threshold for Level 3 or everything becomes an escalation.

---

## 8. Confirmation brief back up to a manager

You received something vague. This is the fastest way to look senior in any organization. Send it the same day.

```
Confirming what I heard on [task] before I start.

**Outcome:** I am going to hand you [the finished thing, format, length] by [date].
**Who it is for:** [audience], who will use it to [decision]. After that it goes to [where].
**Approach:** [Step one]. [Step two]. [Step three]. Nothing fancier than that.
**Assuming:** [Judgment call 1]. [Judgment call 2]. [Judgment call 3].
**Not doing:** [The adjacent thing you are deliberately leaving out.] [The other one.]
**Checkpoint:** I will send you [specific artifact] on [date] so you can redirect me early if I am off.
**Due:** [date].

If any line is wrong, tell me which one and I will adjust. Otherwise I am starting [today / tomorrow morning].
```

Rules: "Not doing" is the highest-value line here, and it is the one people cut. Set your own checkpoint rather than waiting to be given one. Keep it under 150 words. If they do not reply, you start, and you have it in writing.

---

## 9. Contractor, freelancer, or agency

They have no institutional context, no shared vocabulary, and a contract. Constraints and acceptance criteria carry more weight than usual.

```
[Name], scoping [project] for you. Everything you need is below.

**Outcome:** [Deliverable], [format, quantity, specification], delivered by [date]. Done means: [3 acceptance criteria stated as things I can check, not things I have to feel].
**Context:** This is for [audience]. It will be used [where and how]. [What has been tried already, so you do not repeat it.]
**Constraints:** Budget: [$ amount] for [scope]. Format: [spec]. Tools: [required tool or file type]. Anything outside [scope] is a change order, talk to me first. [Confidentiality or brand rules.]
**Examples:** Do: [link]. Do not: [link or description]. If you can only look at one thing, look at [the first one].
**Decision rights:** Level 3 on method and process, you are the expert and I do not need to see how the work happens. Level 2 on [choices within the spec], tell me what you picked. Level 1 on scope and budget, both come to me before they change.
**Revisions:** [N] rounds included, in [format]. Feedback comes from [one named person] only.
**Checkpoint:** [Date], [artifact].
**Due:** [date and time]. Invoice [terms].
```

Rules: acceptance criteria must be checkable by a third party, or the final round becomes an argument about taste. One feedback channel and one named reviewer prevents the most common contractor failure, which is contradictory notes from three people.

---

## 10. Re-briefing something you already sent badly

You gave a vague handoff, you caught it before it went wrong, and you want to fix it without undermining them.

```
[Name], reissuing this one. My first version was too vague and that is on me, not you.

**Outcome:** [The specific artifact, now named properly.]
**What changes from what I told you:** [The one or two things that are actually different.]
**What stays:** [Everything they already started, named, so the work so far is not wasted.]
**Constraints I should have said up front:** [The ones you left out.]
**Example:** [link]
**Decision rights:** [levels]
**Checkpoint:** [date and artifact]
**Due:** [date, adjusted if the change costs them time, and say so if it does not.]
```

Rules: own the vagueness in one sentence and move on. Name what stays before what changes, because the first thing they want to know is whether their work survived. If the change costs them hours, move the deadline and say you moved it.

---

## 11. The redirect, when it came back wrong

The work is off. Do not relitigate and do not take it back. Redirect it with the part that was missing the first time.

```
[Name], this is close on [what is genuinely right], and it is pointed at a different target than I meant. My brief did not say that, so let me fix it.

**What is right and stays:** [Specifically, so it is not vague reassurance.]
**The outcome I actually need:** [The artifact, named properly this time.]
**Why:** [The context that was missing. This is almost always part 2.]
**What to change:** [The 2 or 3 concrete changes. Not a rewrite request.]
**Example of the target:** [link]
**Decision rights:** Level 3 on how you get there.
**Checkpoint:** Send me [the smallest possible proof it is pointed right, e.g. the new outline] by [date] before you build the rest.
**Due:** [new date].
```

Rules: never redirect without naming what stays, or the whole thing reads as rejection. The checkpoint here should be tiny and immediate, because the trust to rebuild is directional trust. Never say "I thought I was clear."

---

## 12. Onboarding someone onto work you have always done yourself

A transfer, not an assignment. Plan it in three passes and say so up front, because "shadow me for a bit" with no end state never finishes.

```
[Name], moving [the work] to you over the next [N weeks]. Three passes, then it is yours.

**Outcome:** By [date], you run [the work] end to end and I am not in the loop.
**Context:** [Why it is moving, and why you.] [What breaks if it goes badly, honestly.]
**Pass 1 [dates]:** I do it, you watch and write the steps down. Your deliverable is the doc, not the work.
**Pass 2 [dates]:** You do it, I review before it goes out. Level 1.
**Pass 3 [dates]:** You do it, you send it, you tell me after. Level 2.
**From [date]:** Level 3. I see the result like everyone else.
**Constraints:** [The rules that are real.] [The two mistakes I have made in this job that you now do not have to make.]
**Examples:** [link], [link].
**Checkpoint:** End of each pass, 15 minutes, what surprised you.
```

Rules: name the date you exit. A transfer with no exit date is supervision with extra steps. "What surprised you" is a better checkpoint question than "any questions," because it surfaces the silent standards you never wrote down.

---

## Universal closers

Pick one. Never close a handoff with "let me know if you have questions."

- "You own [X] and [Y]. Come to me only on [Z]."
- "If you have to drop something to hit the date, drop [X]."
- "Send it rough on [date]. I am checking direction, not polish."
- "Make the call. I will back it."
- "If I do not hear from you by [date], I will assume it is on track."
- "One thing worth interrupting me for: [that thing]. Everything else can wait for [checkpoint]."
