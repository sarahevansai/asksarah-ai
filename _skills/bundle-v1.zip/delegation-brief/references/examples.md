# Before and After

Six real handoffs, rewritten, with the scoring shown. Different industries on purpose: the failure is identical everywhere. Use these to calibrate the standard, or to show a user what the difference actually looks like rather than describing it.

---

## Example 1: The vague Slack handoff

Regional retail chain, 40 stores. Operations director to a store manager being groomed for a district role.

**Before (1/6)**

> hey can you put together something on the Q3 store numbers for the leadership meeting? nothing crazy. let me know if you have questions!

Missing: outcome is an activity, no context, no constraints, no example, no decision rights, no checkpoint. The only thing present is a vague deadline implied by "the leadership meeting."

What she actually built: a 22-slide deck with every metric the POS system exports, four days of work.

What was wanted: three numbers and a recommendation.

**After (6/6)**

> Priya, want you to take the Q3 store performance read for the leadership meeting.
>
> **Outcome:** Five slides. Three charts, one slide of what changed and why, one slide with your recommendation on the two underperforming stores. If it is more than five slides, it is the wrong shape.
>
> **Context:** This goes to the exec team on Oct 14, and it is the input for whether we renew the Riverside and Oak Park leases. Both decisions get made in that room. Dana will push on the labor numbers, she always does, so have that one ready to defend.
>
> **Constraints:** Use the Q2 deck template, it is in the shared drive here: [link]. Comp-store sales only, not total, because total makes the two new stores look like growth and they are not. Do not pull anything from the old dashboard, the categories changed in August.
>
> **Example:** Q2 deck is here: [link]. Copy the structure exactly. Skip the appendix, nobody opened it.
>
> **Decision rights:** Level 3 on which charts and how you cut the data, that is your read to make. Level 2 on the recommendation, I want your actual opinion on those two stores and you do not need my approval to write it, just tell me what you landed on. Level 1 on the labor cost figures, those come from Finance unchanged.
>
> **Checkpoint:** Send me the five slide titles and your recommendation in one line by Thursday Oct 3. That is it, no slides built. I am checking direction, not polish.
>
> **Due:** Final deck Friday Oct 11 by noon, so it is in the pre-read.

**Coaching note:** "Nothing crazy" is not a scope. It is a feeling, and a conscientious person hearing it will build too much, because too much feels safer than too little. Four days were lost to one missing sentence: how many slides. Every time you are tempted to say "nothing crazy" or "keep it simple," say the number instead. Length is the cheapest constraint you will ever give someone and it prevents the most waste.

---

## Example 2: The activity with no finish line

Community health clinic, 60 staff. Practice administrator to a newly promoted operations coordinator.

**Before (2/6)**

> Can you clean up the patient intake process? It is a mess and it is causing complaints. Take a look at it and let me know what you think. Sometime in the next few weeks would be great.

Missing: outcome is an activity, no constraints, no example, no decision rights, no real checkpoint. Context is half present, "complaints," but it never says whose complaints or what happens next.

Six weeks later there was a 14-page process document and nothing had changed.

**After (6/6)**

> Marcus, giving you the patient intake wait problem.
>
> **Outcome:** Intake time from arrival to being roomed drops from an average of 23 minutes to under 12, measured over two full weeks. What you hand me is the new process running, plus one page saying what you changed. Not a report on the current state, I know what the current state is.
>
> **Context:** Intake wait is the number one theme in our patient survey comments, 31 of 88 negative comments last quarter. The board sees the next survey in January. If this does not move, we are looking at adding front desk headcount, which I would rather not do.
>
> **Constraints:** Cannot change the EHR system or add anyone. Anything touching what we collect at check-in goes through Sandra in compliance before it ships, no exceptions, because half of those fields are required and not optional. You can change forms, sequence, staffing pattern, and room flow. Budget for anything you need to buy is $2,000.
>
> **Example:** The Thursday morning shift already runs close to this. Sit with Alma for a morning and watch what she does differently. That is your starting point, not a blank page.
>
> **Decision rights:** Level 3 on process changes inside the clinic. Level 2 on anything that changes what a staff member does daily, make the call and tell me so I am not surprised when someone comes to me about it. Level 1 on the compliance fields, and on anything that changes the schedule template.
>
> **Checkpoint:** Friday Nov 8, tell me the two changes you are making first and what you expect them to save. Two sentences, not a document.
>
> **Due:** New process live by Dec 2. Two weeks of measurement, results to me Dec 20.

**Coaching note:** "Clean up" is the single most expensive phrase in delegation, because it names an activity with no finish line. The person cannot be done, so they build documentation instead, which feels like progress and changes nothing. Replace every "clean up," "look into," "improve," and "figure out" with a number and a date. The number is what turns a chore into a target.

---

## Example 3: Delegating the task but not the authority

Commercial construction firm, 200 employees. Project executive to a project manager.

**Before (3/6)**

> Tom, you are running the Westfield build. Anything comes up, run it by me first. I want to see the subcontractor selections, the schedule before it goes out, and any change orders. Just keep me looped in on everything.

Has outcome, has context implicitly, has constraints. Missing entirely: decision rights are inverted, no example, no checkpoint distinct from the constant approvals.

Result: eleven weeks in, three separate two-day delays waiting on approvals that had never been declined.

**After (6/6)**

> Tom, Westfield is yours. Setting the guardrails so you are not waiting on me for things that do not need me.
>
> **Outcome:** Westfield delivered by the Aug 22 substantial completion date, at or under the $8.4M budget, with the punch list under 40 items at turnover.
>
> **Context:** The client is a repeat and they are deciding on the Northgate project in the fall. Their facilities director walks the site most Thursdays. How this one feels to him is worth more than the margin on it.
>
> **Constraints:** $8.4M hard ceiling. Any single change order over $25K, and any schedule change that moves substantial completion, comes to me. Bonded subs only. Safety incidents get reported to me same day, no matter how small.
>
> **Example:** Run it the way Delgado ran Fairview. Weekly owner update, photos in it, problems named before the client finds them. His update format is here: [link].
>
> **Decision rights:** Level 3 on subcontractor selection from the approved list, sequencing, and daily site calls. Level 2 on change orders under $25K, approve them and put them in the weekly update, I do not need a call. Level 1 on the two things above: the $25K line and the completion date.
>
> **Checkpoint:** Friday 4pm, one page: schedule position, budget position, top risk. Fifteen minutes on my calendar only if the top risk needs me.
>
> **Due:** Substantial completion Aug 22. Owner walkthrough Aug 15.

**Coaching note:** "Run it by me first" and "keep me looped in on everything" sound like engagement and function as a bottleneck. You are not delegating the project, you are delegating the paperwork and keeping the decisions, and the work now moves at the speed of your inbox. The fix is a threshold, not a feeling. Pick a dollar figure and a date impact, and let everything under those lines go without you. A threshold you can name is a decision you have already made once, instead of forty times.

---

## Example 4: The invisible audience

B2B software company, 300 employees. Head of product to a product analyst.

**Before (2/6)**

> Need a summary of the churn data from the last two quarters. Whatever you can pull together. Probably by end of week?

Missing: outcome is vague, no context at all, no constraints, no example, no decision rights. "Probably by end of week" is a deadline in the way a shrug is a decision.

What came back: a thorough 9-tab spreadsheet. What was needed: one slide for the board that answered whether churn was a pricing problem.

**After (6/6)**

> Nadia, need the churn read for the board deck.
>
> **Outcome:** One slide plus a short paragraph, answering one question: is our churn a pricing problem or a product problem? Your answer, with the two or three numbers that support it. Not a data dump, and not both-sides. Pick one.
>
> **Context:** This goes in the board deck for Nov 20. The board asked about pricing at the last meeting and we did not have a real answer, which is why this exists. If the answer is pricing, it changes what we do in Q1. Sameer will ask how many accounts the finding is based on, so know that number.
>
> **Constraints:** Accounts over $10K ARR only, that is what the board cares about and the SMB churn story is completely different. Use the Salesforce export, not the product analytics, the definitions do not match and mixing them is how we got burned in May. Timebox it to two days. If two days is not enough for a confident answer, that is a finding and I want to hear it.
>
> **Example:** The retention memo Priya wrote in June is exactly the shape: [link]. Answer in the first line, evidence under it, one chart maximum.
>
> **Decision rights:** Level 3 on method and which cuts of the data you use. Level 2 on the conclusion, it is your call, I want your read and not a menu of possibilities. Level 1 on nothing here.
>
> **Checkpoint:** Wednesday Nov 6, one Slack message with your working answer, even if you are only 60 percent sure. I would rather redirect you Wednesday than read something excellent on Monday that answers a different question.
>
> **Due:** Friday Nov 8, so it can go in the deck draft.

**Coaching note:** Nine tabs of correct work were useless because the audience was never named. Analysts optimize for whoever they think is reading, and absent information they assume it is you, so they show their work. Naming the audience and the decision does more to shape output than any instruction about format. Two sentences of context are worth more than a page of specification.

---

## Example 5: The confirmation brief back up

Nonprofit, 25 staff. Executive director to a development associate, at 4:40pm on a Friday.

**What she received**

> Can you get the grant stuff together for the Hartwell thing? They want it soon I think. Thanks!!

**What most people do:** guess, or send four questions across four messages on Monday and get two of them answered.

**What she sent instead, at 4:52pm the same day (a 6/6 confirmation)**

> Confirming what I heard on the Hartwell submission before I start Monday.
>
> **Outcome:** A complete Hartwell renewal application package: the narrative, the updated budget, and the two required attachments, in your inbox for review by Thursday Nov 14.
>
> **Who it is for:** Hartwell's program officer, Elaine Voss. Their portal deadline is Nov 21, so Thursday gives us a week for your edits and the board chair's signature.
>
> **Approach:** Start from last year's approved narrative, update the program numbers with the FY25 outcomes, rewrite the impact section around the new after-school expansion. Rebuild the budget in their template.
>
> **Assuming:** We are asking for the same $75,000 and not more. The after-school expansion is the lead story, not the food program. You want the same board chair signature as last year.
>
> **Not doing:** I am not re-running the outcome evaluation, I am using the numbers already in the FY25 report. I am also not touching the Hartwell relationship, no outreach to Elaine from me.
>
> **Checkpoint:** I will send you the narrative section alone on Tuesday Nov 12 so you can redirect me before I build the rest around it.
>
> **Due:** Thursday Nov 14 to you, Nov 21 to the portal.
>
> If any of that is off, tell me which line. Otherwise I am starting Monday morning.

The reply came back in nine minutes: "Ask for $90K. Everything else is right."

**Coaching note:** That one line was worth about eleven hours. A questions list would not have produced it, because questions get skimmed and answered partially, while a brief gets read as a thing to approve or correct, and people correct what is in front of them. The "Assuming" section is where the money was: nobody would have thought to ask "are we asking for the same amount," because it did not look like an open question. State your assumptions and the wrong one identifies itself.

---

## Example 6: The urgent handoff that dropped the wrong thing

Logistics company, 500 employees. VP of operations to a regional coordinator, 9:15 on a Tuesday morning.

**Before (2/6)**

> Emergency: the Dallas DC is down, need a customer impact list and a comms plan by end of day. Drop everything. Go.

Has urgency and half an outcome. Missing: what the artifact is, who it is for, constraints, decision rights, and any guidance on what to sacrifice, which is the one thing an urgent brief cannot skip.

What came back at 5pm: a comprehensive impact list covering all 340 affected accounts, and no comms plan. The comms plan was the part that mattered.

**After (6/6)**

> Ray, Dallas DC is down and I need two things from you today.
>
> **Outcome:** One, a list of the accounts with a delivery promised in the next 72 hours, ranked by contract penalty exposure. Two, a draft customer notice we can send tonight. Both in my inbox by 3pm, not 5pm, because Legal needs an hour with the notice.
>
> **Context:** We do not yet know if this is 2 days or 8. The notice buys us goodwill only if it goes out before customers notice on their own, which for the top accounts is tomorrow morning.
>
> **The one thing that matters:** The top 20 accounts by penalty exposure, done properly, beats all 340 done partially. If you can only do one of the two things, do the notice.
>
> **Decision rights:** Level 3 on everything except the notice wording, which comes to me and then to Legal. Do not wait on me for anything else. Pull Dana and Chris off their queues if you need them, tell them I said so.
>
> **Checkpoint:** Text me at noon with the top 20 list, even if it is rough. I will start calling.
>
> **If you have to drop something:** Drop the full account list. Keep the notice and the top 20.

**Coaching note:** Under time pressure someone will cut something, and if you do not say what, they will cut the hard part and keep the thorough part, because thorough feels defensible and judgment feels risky. "If you have to drop something, drop X" is five words and it is the single most valuable line in an urgent brief. Speed is not a reason to skip the brief. It is a reason to compress it: same six parts, five lines.

---

## What the six examples have in common

Every "before" here came from a competent person handing work to a competent person. Not one of these failures was about skill or effort.

Five of the six failed on the same part: the outcome was named as an activity instead of an artifact. That is the part to check first, every time, in your own briefs and in anyone else's.
