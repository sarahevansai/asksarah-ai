# Company Boilerplate

A Claude skill that writes the standing "About [Company]" paragraph a journalist can paste without editing, in both lengths, ready for sign-off.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

The boilerplate is the most reused piece of writing a company owns. It sits at the bottom of every press release, in the media kit, in the conference program, in the award submission, and in the first paragraph of the article a reporter writes about you. Almost nobody writes it on purpose, and most companies end up with four versions in circulation that disagree with each other.

Give Claude a company name and one line about what it does, and you get back:

1. The standard version, roughly 100 words, finished
2. The extended version, roughly 300 words, finished
3. A short list of what is bracketed and where to go get it
4. One coaching note that applies to everything else the company writes about itself

**You always get both paragraphs back.** No questions first. No outline. No "tell me more about your company and I will write it." If you give it a name and a sentence, it writes from that, infers conservatively, and brackets only the facts that would be wrong to guess.

It also handles the short forms: the one-liner for a byline or speaker bio, and the two-sentence version for a pitch email.

## The honesty rule

Claude will never invent a founding date, a headcount, a customer or revenue figure, an award, a certification, a client name, or a claim of market leadership.

That is not caution for its own sake. Those are the exact facts that end up in a press release, a wire distribution, a regulatory filing, or a pitch deck, and an invented one stops being a writing problem and becomes a real one. Anything Claude does not know comes back in `[BRACKETS]` with a line telling you where to find it.

## The competitor test

The core diagnostic, applied to every paragraph it writes and every paragraph you paste in:

**Swap in your closest competitor's name. If it is still true, the paragraph says nothing.**

Run clause by clause, most boilerplates have one or two real clauses buried in four generic ones. "A leading provider of innovative solutions dedicated to helping clients achieve their goals" passes for every company in every industry, which is why it is worthless. "An actuarial consulting firm that works exclusively with self-insured municipal pension funds" becomes false the moment you swap the name, and that falseness is the proof it is doing work.

## What gets cut, and why

- Mission and vision language. A reporter cannot print a belief.
- "Leading provider" and every unsubstantiated superlative. Editors strip them, regulators do not.
- "Passionate." Nobody has ever hired a vendor for being passionate.
- "Innovative" and "cutting edge." Neither survives a follow-up question.
- "Solutions" as a noun. It is the word companies use when they will not say what they sell.
- Founder philosophy. Founding facts belong in the extended version. Founding beliefs do not.
- Adjective stacks. Three in a row is a confession that no single one is true enough to stand alone.

## Four modes

- **Write from scratch.** Name plus one line about the business is enough.
- **Rewrite.** Paste what you have, get both versions back plus what was cut and why.
- **Shorten.** One-liner or two-sentence version for a bio, byline, or pitch email.
- **Audit.** The competitor test applied clause by clause, then the rewrite anyway.

## Version control

The skill covers what to do after the paragraph is written: one canonical file, one named owner, a date on it, all four lengths updated together, and a review triggered by funding, acquisition, a name change, an HQ move, or a product sunset. This is the part companies skip, and it is why the version on the website and the version in the press release describe two different companies.

## Regulated industries

Financial services, healthcare, insurance, legal, cannabis, pharma, and education often require a disclosure line, a registration statement, or specific mandated language. Claude writes the paragraph, marks the spot where the disclosure goes, and tells you to route it to counsel. It never drafts the legal language itself.

## Try it

Once installed, say any of these:

- "Write our boilerplate. We are [company], we make [thing] for [audience]."
- "Here is our current about paragraph, is it any good?"
- "I need the blurb that goes at the bottom of a press release."
- "Shorten this to one line for my byline."
- "Rewrite our about section, it sounds like everyone else."
- "Audit this against the competitor test."

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `company-boilerplate.zip` in your skills settings. Claude loads it automatically whenever a company description needs writing.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/company-boilerplate/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "write our boilerplate" with a company name and one sentence about what it does. You should get two finished paragraphs with word counts, a short list of what to fill in, and one coaching note.

## What is in the package

```
company-boilerplate/
├── SKILL.md                  The framework, the honesty rule, the structure, the output format
├── README.md                 This file
├── LICENSE
└── references/
    ├── patterns.md           Structural patterns and worked openings for 10 company types
    └── examples.md           5 full before-and-after rewrites with the competitor test applied
```

## Notes

Every example company in this skill is fictional. Claude will not write a boilerplate for a real company as a demonstration.

It will ask at most one question, and only after both paragraphs are already in front of you. Nothing is held back waiting on an answer.

## Support

Questions, or want this adapted for your company: [asksarah.ai](https://asksarah.ai)
