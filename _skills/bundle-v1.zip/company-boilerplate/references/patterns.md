# Boilerplate Patterns

Structural patterns and worked openings by company type. This file is raw material for writing. Never hand a pattern to the user as output. The user gets finished paragraphs.

---

## The base pattern

Five moves. In the standard version, roughly one sentence each. Two of the five are optional.

```
1. [Company] is a [plain category noun] [company / firm / group / practice] ...
2. ... that [concrete verb] [the actual thing] for [specifically named audience].
3. [The checkable differentiator, stated as a fact.]                      (optional)
4. [Scale, years, footprint, certification, or dated award. One or two.]   (optional)
5. [Company] is [headquartered in / based in] [City, State]. [URL sentence.]
```

Moves 3 and 4 are the ones that carry proof, and they are the two that get faked. Cut either one before inventing it.

---

## Sentence-level moves that work

**The exclusion clause.** Naming who you are not for makes the audience clause real.
"works exclusively with independent grocers," "serves contractors with fewer than 50 crews," "represents plaintiffs only."

**The mechanism clause.** Say how it works, in one clause, in plain words.
"routes calls through a single dispatcher instead of a phone tree," "manufactures on the same floor where it designs."

**The dated fact.** A number with a year attached does not go stale as fast.
"has completed more than 900 residential projects since 2004."

**The named credential.** Only when real, only when named, only when current.
"holds an ISO 9001:2015 certification," "is a certified B Corporation," "is accredited by [named body]."

**The footprint line.** Geography is proof and it is almost always true and checkable.
"operates six facilities across the Southeast," "licensed in 14 states."

---

## Sentence-level moves that fail

| Move | Why it fails | Replace with |
|---|---|---|
| "is a leading provider of" | Unbacked claim, editors cut it | The category noun, plainly |
| "is dedicated to helping" | Cannot be printed or checked | A verb describing what it does |
| "offers a full suite of solutions" | Says nothing about what is sold | The actual product or service |
| "serves clients of all sizes" | Defines no audience at all | The one audience you actually serve |
| "leverages cutting-edge technology" | Two dead words in one clause | What the technology does |
| "founded on the belief that" | Founder philosophy, not a fact | Founded in [year] |
| "a dynamic, forward-thinking team" | Adjective stack, zero content | A headcount or a credential |
| "transforming the industry" | Fails the competitor test instantly | What it changed, specifically |

---

## Worked openings by company type

Each entry gives the trap for that category, a failing opening, and a working one. All companies here are fictional.

### 1. Manufacturer

**Trap:** describing the process instead of the product, or hiding behind "advanced manufacturing."

Fails: "Corvid Industrial is a leading provider of advanced manufacturing solutions serving a diverse range of industries nationwide."

Works: "Corvid Industrial is a metal fabrication company that produces precision sheet metal parts for medical device and aerospace manufacturers. The company operates two plants in [City, State] with [N] employees and holds AS9100 certification for its aerospace work."

Notes: name the material, name the part, name who buys it. Certifications are unusually valuable here because buyers screen on them. Facility count and square footage are checkable proof that costs nothing to include.

### 2. Professional services firm (accounting, law, consulting, engineering)

**Trap:** listing every service line, which makes the firm sound like it has no focus.

Fails: "Ashford Partners is a full-service professional services firm offering audit, tax, advisory, consulting, and a comprehensive range of client-focused solutions."

Works: "Ashford Partners is an accounting firm that works with privately held manufacturing and distribution companies in the Midwest. Founded in [year], the firm has [N] partners and serves clients across [N] states from offices in [City] and [City]."

Notes: pick the two service lines that matter and let the rest live on the website. Partner count and office count are the standard proof points in this category and everyone in the industry reads them. Years in business matter more here than almost anywhere else.

### 3. Nonprofit

**Trap:** the mission statement eats the whole paragraph. This is the single most common failure of the type.

Fails: "The Halloway Fund believes every child deserves a safe place to learn and is committed to building a brighter future for communities everywhere."

Works: "The Halloway Fund is a nonprofit organization that provides after-school tutoring and meals to students in [City] public schools. Founded in [year], the organization serves [N] students across [N] school sites and is funded through individual giving, corporate partnerships, and [named] grants."

Notes: the mission belongs in one clause of sentence one, expressed as an activity, not a belief. Nonprofits have unusually good proof points available: people served, sites, years, 501(c)(3) status, funding mix. Use them. State the tax status explicitly in the extended version, because press and grantmakers look for it.

### 4. Healthcare provider

**Trap:** compliance-flavored vagueness, and claims that cross into medical advertising rules.

Fails: "Brightwater Health delivers world-class, patient-centered care through an innovative approach to modern medicine."

Works: "Brightwater Health is a multi-specialty medical group with [N] clinics across [region]. The practice provides primary care, cardiology, and endocrinology services to approximately [N] patients annually and is accredited by [named accrediting body]."

Notes: never write an outcome claim, a cure claim, a safety claim, or a comparative quality claim. Those are regulated. Accreditation, clinic count, specialty list, and patient volume are the safe and useful proof points. Flag that a disclosure or licensure line may be required and route it to counsel.

### 5. Software company

**Trap:** describing the technology instead of the job it does, and stacking category buzzwords.

Fails: "Tessellate is an AI-powered, cloud-native platform that empowers organizations to unlock the full potential of their data."

Works: "Tessellate is a software company that builds scheduling and payroll tools for restaurant operators. The platform is used by [N] locations across [N] states, and the company has been operating since [year]."

Notes: say who uses it and for what task before saying anything about the technology. "AI-powered" is only worth including when the AI is the product, not the plumbing. Location count, seat count, and named integrations are the credible scale numbers. Funding raised belongs in the extended version if it is public.

### 6. Restaurant group / hospitality

**Trap:** writing the menu copy instead of the company description. Sensory language does not belong here.

Fails: "Copperfield Hospitality creates unforgettable dining experiences rooted in a passion for hand-crafted seasonal cuisine."

Works: "Copperfield Hospitality is a restaurant group that operates [N] full-service restaurants in [City] and [City]. Founded in [year], the group employs approximately [N] people and includes [named concept], [named concept], and [named concept]."

Notes: name the concepts. They are the assets and they are what a reporter needs. Location count, headcount, and years operating are the proof. Save the cuisine description for the individual restaurant's own page, not the group boilerplate.

### 7. Construction firm

**Trap:** "quality, integrity, on time and on budget," which every construction company in the country says.

Fails: "Kestrel Builders is committed to quality craftsmanship, integrity, and delivering every project on time and on budget."

Works: "Kestrel Builders is a general contractor that builds commercial warehouse and light industrial facilities in [region]. The company has completed more than [N] projects since [year] and is licensed in [N] states."

Notes: project type and project size range are the two facts a reader actually wants. Licensing, bonding capacity, and safety record (EMR) are strong industry proof points when the numbers are good and current. Never claim a safety record without the number.

### 8. Solo consultancy or independent practice

**Trap:** using "we" and plural language to sound bigger, which reads as insecurity and breaks the moment anyone visits the site.

Fails: "Vane Strategy is a boutique firm delivering world-class strategic counsel to a select portfolio of forward-thinking clients."

Works: "Vane Strategy is an independent consulting practice founded by [Name] that advises hospital systems on facilities planning. [Name] has worked in healthcare capital planning since [year] and has advised on more than [N] projects."

Notes: solo is a feature, not something to hide. Name the person, because the person is the product. Years of experience replaces headcount as the proof point. "Independent" and "practice" are honest words that do not sound small.

### 9. Retail or consumer brand

**Trap:** brand voice bleeding into the boilerplate. The playful tone that works on packaging reads as unserious in a press release.

Fails: "Marlow Goods makes stuff we actually love, for people who care about the little things."

Works: "Marlow Goods is a consumer products company that designs and sells kitchen textiles. Founded in [year], the company sells through its website and approximately [N] independent retail stores in [N] states."

Notes: distribution is the proof point in retail: store count, channel mix, retail partners if publicly disclosed. Say what the product actually is, in the words a customer would use. Keep the brand voice for the brand and use plain third person here.

### 10. Financial services or insurance

**Trap:** performance implications and unregistered advice language, both of which are compliance problems.

Fails: "Pallas Wealth helps clients grow and protect their wealth through a proven, best-in-class investment approach."

Works: "Pallas Wealth is a registered investment advisor that manages assets for individuals and families in [region]. Founded in [year], the firm advises on approximately $[N] in client assets and is [registration status] with [regulator]."

Notes: never imply a return, a performance record, a guarantee, or superiority of approach. Registration status, AUM as of a stated date, and years in business are the accepted proof points. This category almost always requires a disclosure line. Write the paragraph, mark the disclosure spot, and send it to compliance counsel before publication.

---

## Extended version: where the extra 200 words go

The extended version is not the standard version with adjectives added. It is the standard version plus four specific additions, in this order:

1. **One or two sentences of founding fact.** Year, founders by name and title, and what they did before if it is relevant and public. Facts only. No origin mythology.
2. **Named offerings.** Products, service lines, brands, or locations, named. This is the most useful thing the extended version adds, because it gives a reporter something to look up.
3. **Markets and footprint.** Segments served, regions, states, countries, channel mix. Specific.
4. **Disclosed relationships and recognition.** Named customers, partners, or investors, only if publicly and currently disclosed. Awards with the awarding body and the year attached.

Keep it to two or three short paragraphs. A single 300-word block does not get read.

---

## Word count discipline

| Version | Target | Ceiling | Sentences |
|---|---|---|---|
| One line | 15 to 25 words | 30 | 1 |
| Two sentences | 40 to 50 words | 60 | 2 |
| Standard | 95 to 110 words | 120 | 2 to 4 |
| Extended | 270 to 320 words | 340 | 4 to 7 |

Count the words. Report the count under each version. Over the ceiling, cut a whole clause rather than trimming words out of several sentences, which produces prose that reads squeezed.
