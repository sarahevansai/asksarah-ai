# Boilerplate Examples

Five full before-and-after rewrites with the competitor test applied clause by clause. Every company here is fictional. Never write a boilerplate for a real company as an example.

Read these to calibrate the standard. Do not paste them as output.

---

## Example 1: The superlative pile

**Industry:** warehouse robotics
**What arrived:** the version marketing wrote for the website and PR reused for four years.

### Before (94 words)

> About Corvid Robotics
>
> Corvid Robotics is a leading provider of innovative warehouse automation solutions, revolutionizing the future of logistics with its cutting-edge platform. Founded by a team of industry veterans, Corvid is committed to helping organizations around the world transform their supply chains through best-in-class technology and a customer-first approach. With a growing roster of enterprise customers across multiple industries, Corvid is redefining what is possible in fulfillment. The company's world-class team is passionate about building the future of automation. Learn more at corvidrobotics.com.

### Competitor test, clause by clause

| Clause | Swap in a competitor | Verdict |
|---|---|---|
| "a leading provider of innovative warehouse automation solutions" | Still true | FAIL |
| "revolutionizing the future of logistics" | Still true | FAIL |
| "founded by a team of industry veterans" | Still true | FAIL |
| "committed to helping organizations around the world" | Still true | FAIL |
| "best-in-class technology and a customer-first approach" | Still true | FAIL |
| "a growing roster of enterprise customers across multiple industries" | Still true | FAIL |
| "world-class team is passionate about" | Still true | FAIL |
| "corvidrobotics.com" | False | PASS |

Eight clauses. One survives, and it is the URL. Ninety-four words that a competitor could publish unchanged tomorrow.

### After, standard (99 words)

> About Corvid Robotics
>
> Corvid Robotics is a warehouse robotics company that builds autonomous picking systems for fulfillment centers. Its customers are retail, consumer goods, and third-party logistics operators running high-volume distribution facilities. Founded in [year], Corvid has systems deployed in [N] facilities across the United States and holds ISO 9001:2015 certification for its manufacturing operations. The company was named to the [year] [named list] in the logistics category. Corvid Robotics is headquartered in [City, State]. Learn more at corvidrobotics.com.

### After, extended (294 words)

> About Corvid Robotics
>
> Corvid Robotics is a warehouse robotics company that builds autonomous picking systems for fulfillment centers. The company's products include the [named platform] picking system and the [named product] integration layer, which connects to existing warehouse management software without replacing it. Its customers are retail, consumer goods, and third-party logistics operators running high-volume distribution facilities.
>
> Corvid was founded in [year] by [Name], who serves as chief executive officer, and [Name], chief technology officer. The company raised $[N] in [round] funding in [month year], led by [named investor] with participation from [named investor]. Corvid has [N] employees and manufactures its systems at a [N] square foot facility in [City, State].
>
> Corvid systems are deployed in [N] facilities across the United States, primarily in the Midwest and Northeast, with expansion into the Southeast planned for [year]. The company holds ISO 9001:2015 certification for its manufacturing operations and was named to the [year] [named list] in the logistics category.
>
> Corvid Robotics is headquartered in [City, State]. Learn more at corvidrobotics.com.

### What changed and why

- Cut six superlatives. Every one of them was a claim nobody had checked.
- "Warehouse automation solutions" became "warehouse robotics" and "autonomous picking systems." A reporter can picture the second one.
- "Enterprise customers across multiple industries" became three named customer types. Now the audience clause excludes someone, which is what makes it real.
- "Founded by a team of industry veterans" was cut from the standard version and replaced in the extended version with founder names and titles, which are facts.
- Every number is bracketed, because none were supplied. Not one was invented.

---

## Example 2: The mission statement wearing a boilerplate

**Industry:** nonprofit
**What arrived:** the paragraph from the annual report, reused as the press boilerplate.

### Before (77 words)

> About The Halloway Fund
>
> At The Halloway Fund, we believe every child deserves a safe place to learn and grow. Our passionate team works tirelessly to create a brighter tomorrow for the communities we serve. Through the power of partnership and an unwavering commitment to equity, we are transforming outcomes for young people everywhere. Together, we can build a world where every child thrives. Join us at hallowayfund.org.

### Competitor test

Swap in the name of any children's nonprofit in the country. Every clause survives. Then swap in an environmental nonprofit and change one noun, and most of it still survives.

The deeper problem: after 77 words, a reporter still does not know what this organization does. Not tutoring, not housing, not legal advocacy, not scholarships. Nothing in the paragraph names an activity.

It also fails a second test. It is written in first person plural, which means a journalist cannot paste it into an article at all without rewriting every sentence.

### After, standard (96 words)

> About The Halloway Fund
>
> The Halloway Fund is a nonprofit organization that provides after-school tutoring and daily meals to students in [City] public schools. The organization operates programs at [N] school sites, serving approximately [N] students each year in grades three through eight. Founded in [year], The Halloway Fund is a registered 501(c)(3) organization funded through individual donations, corporate partnerships, and [named] grants. The Halloway Fund is based in [City, State]. More information is available at hallowayfund.org.

### After, extended (281 words)

> About The Halloway Fund
>
> The Halloway Fund is a nonprofit organization that provides after-school tutoring and daily meals to students in [City] public schools. The organization operates programs at [N] school sites, serving approximately [N] students each year in grades three through eight. Programs run four afternoons a week during the school year and include small-group reading and math instruction, a hot evening meal, and transportation home.
>
> The Halloway Fund was founded in [year] by [Name], a former [City] public school teacher, and is governed by a [N]-member board of directors. The organization employs [N] full-time staff and works with approximately [N] trained volunteer tutors each year.
>
> The Halloway Fund is a registered 501(c)(3) organization. It is funded through individual donations, corporate partnerships, and grants from [named funder] and [named funder]. In [year], the organization reported [N] percent of expenses directed to program services.
>
> The Halloway Fund is based in [City, State]. More information is available at hallowayfund.org.

### What changed and why

- First person became third person. This alone made it usable by press.
- The belief statement became an activity: tutoring and meals, at school sites, four afternoons a week.
- "Communities we serve" became named grade levels in named schools.
- Added the proof points nonprofits already have and rarely use: 501(c)(3) status, site count, students served, board size, funding mix, program expense ratio.
- Cut "passionate," "tirelessly," "unwavering," "transforming," "thrives," and "together."

---

## Example 3: The software company hiding behind its stack

**Industry:** restaurant scheduling and payroll software
**What arrived:** the version written to impress investors, then reused for press.

### Before (88 words)

> About Tessellate
>
> Tessellate is an AI-powered, cloud-native platform that empowers organizations to unlock the full potential of their workforce data. Built by a team of veteran operators and engineers, Tessellate leverages machine learning to deliver seamless, end-to-end workforce solutions at scale. The company is on a mission to reimagine the future of work for businesses everywhere. Tessellate is backed by leading investors and trusted by a rapidly growing customer base. Learn more at tessellate.io.

### Competitor test

Every clause passes to any workforce software company. Several pass to companies in entirely different categories, because "unlock the full potential of their data" describes roughly forty thousand businesses.

Two specific failures worth naming:

- "Backed by leading investors" and "trusted by a rapidly growing customer base" are claims with no facts behind them. Either name the investors and the number, or cut both.
- The paragraph never says who uses this or what task it performs. A reporter cannot tell whether the customer is a hospital, a factory, or a coffee shop.

### After, standard (97 words)

> About Tessellate
>
> Tessellate is a software company that builds scheduling and payroll tools for restaurant operators. Its products handle shift scheduling, tip distribution, and payroll processing for single locations and multi-unit groups, and connect to the point-of-sale systems restaurants already use. Founded in [year], Tessellate is used by approximately [N] restaurant locations across [N] states. The company is headquartered in [City, State]. Learn more at tessellate.io.

### After, extended (276 words)

> About Tessellate
>
> Tessellate is a software company that builds scheduling and payroll tools for restaurant operators. Its products handle shift scheduling, tip distribution, and payroll processing for single locations and multi-unit groups. The software connects to [named POS system] and [named POS system], so operators do not replace their existing point-of-sale setup to use it.
>
> Tessellate was founded in [year] by [Name] and [Name]. The company has [N] employees and raised $[N] in [round] funding in [month year] from [named investor] and [named investor].
>
> Tessellate is used by approximately [N] restaurant locations across [N] states, ranging from independent single-location operators to regional groups of [N] or more units. The company's scheduling product processes approximately [N] shifts per month.
>
> Tessellate is headquartered in [City, State]. Learn more at tessellate.io.

### What changed and why

- "AI-powered, cloud-native platform" became "software company." The AI was in the plumbing, not the product, so it did not earn a mention.
- "Organizations" became "restaurant operators." One word change, and the paragraph suddenly describes a real business.
- "Workforce solutions" became the three actual jobs: scheduling, tips, payroll.
- "Backed by leading investors" became a bracket for named investors and a dollar figure. If they will not name them, the clause comes out entirely.
- Named integrations went into the extended version because they are the most checkable proof a software company has.

---

## Example 4: The construction firm that said what everyone says

**Industry:** commercial general contracting
**What arrived:** the paragraph from the bottom of the company's proposal template.

### Before (81 words)

> About Kestrel Builders
>
> For over two decades, Kestrel Builders has been committed to quality craftsmanship, integrity, and delivering every project on time and on budget. Our experienced team takes a hands-on approach to every job, treating each client like family. From concept to completion, Kestrel is your trusted partner in building excellence. We pride ourselves on our reputation and look forward to earning your business. Visit kestrelbuilders.com.

### Competitor test

This is the purest version of the failure. Every phrase in it appears verbatim on hundreds of contractor websites. "Quality, integrity, on time and on budget" is not a differentiator, it is the price of admission, and saying it out loud signals that there is nothing else to say.

Two additional problems:

- "Your trusted partner" and "earning your business" are sales language. This is a boilerplate, which means it will appear at the bottom of a press release about a completed project, where sales language reads as desperate.
- "Over two decades" is vaguer than the founding year and no easier to write.

### After, standard (95 words)

> About Kestrel Builders
>
> Kestrel Builders is a general contractor that builds commercial warehouse, distribution, and light industrial facilities. The company works with developers and owner-occupiers on projects ranging from [N] to [N] square feet, and self-performs concrete and steel erection rather than subcontracting them. Founded in [year], Kestrel has completed more than [N] projects and is licensed in [N] states. Kestrel Builders is headquartered in [City, State]. More information is available at kestrelbuilders.com.

### After, extended (271 words)

> About Kestrel Builders
>
> Kestrel Builders is a general contractor that builds commercial warehouse, distribution, and light industrial facilities. The company works with developers and owner-occupiers on projects ranging from [N] to [N] square feet. Kestrel self-performs concrete work and steel erection rather than subcontracting them, which the company uses to control schedule on fast-track industrial builds.
>
> Kestrel was founded in [year] by [Name] and is [ownership structure, for example employee-owned or family-owned]. The company employs approximately [N] people, including [N] field crew members, and maintains bonding capacity of $[N].
>
> Kestrel has completed more than [N] projects since [year] and is licensed in [N] states across [region]. The company reported an experience modification rate of [N] for [year]. Recent projects include [named project or project type] in [City, State] and [named project or project type] in [City, State].
>
> Kestrel Builders is headquartered in [City, State]. More information is available at kestrelbuilders.com.

### What changed and why

- "Quality, integrity, on time and on budget" was cut entirely and replaced with what Kestrel actually does that its competitors do not: self-performing concrete and steel. That is the one clause in the whole paragraph a competitor could not copy.
- "Over two decades" became a bracketed founding year.
- Sales language came out. The boilerplate is not selling, it is describing.
- Added the four proof points every contractor has and most leave out: project count, licensing footprint, bonding capacity, and safety record. Every one is bracketed, because the numbers were not supplied and a safety record is exactly the kind of number that must never be guessed.

---

## Example 5: Audit mode, no rewrite requested

**What arrived:** "Is this any good?" with the paragraph pasted in.

### The paragraph (68 words)

> Vane Strategy is a boutique consultancy delivering world-class strategic counsel to a select portfolio of forward-thinking clients. Drawing on decades of combined experience, we partner with leadership teams to unlock growth and navigate complexity in an ever-changing landscape. Vane is where strategy meets execution. Learn more at vanestrategy.com.

### The audit as delivered

| Clause | Verdict | Why |
|---|---|---|
| "a boutique consultancy" | Pass, barely | Category is real but "boutique" is doing no work |
| "delivering world-class strategic counsel" | Fail | Unbacked superlative, no information |
| "a select portfolio of forward-thinking clients" | Fail | Defines no audience. Every consultancy says this |
| "decades of combined experience" | Fail | "Combined" is how one person's experience gets inflated |
| "we partner with leadership teams" | Fail | First person, and every consultancy partners with leadership |
| "unlock growth and navigate complexity" | Fail | Two dead phrases in one clause |
| "in an ever-changing landscape" | Fail | True of every industry since the invention of industry |
| "where strategy meets execution" | Fail | A tagline, and a common one |
| "vanestrategy.com" | Pass | The only checkable fact in the paragraph |

Nine clauses, one and a half survive. The whole thing reads to a reporter as a company that will not say what it does.

The hidden fact this paragraph is hiding: Vane is one person, and that person spent fifteen years in hospital facilities planning. That is the most interesting thing about the company and the boilerplate buries it under "decades of combined experience."

### After, standard (94 words)

> Vane Strategy is an independent consulting practice that advises hospital systems and health networks on facilities planning and capital projects. Founded by [Name] in [year], the practice works directly with executive teams on decisions about new construction, renovation sequencing, and service line relocation. [Name] has worked in healthcare capital planning since [year] and has advised on more than [N] projects. Vane Strategy is based in [City, State]. Learn more at vanestrategy.com.

### The coaching note that shipped with it

"Boutique" and "select portfolio" are what firms say when they think being small is a weakness. It is the opposite. "Independent consulting practice" run by a named person with fifteen years in one specialty is a stronger sentence than anything a fifty-person generalist firm can write about itself. Lead with the specialty and the person. That is the asset.

---

## Reading these

The common thread across all five: the fix was never adding better adjectives. It was removing every adjective and replacing it with a noun, a number, or a named thing.

If a rewrite came out longer than the original, check it again. Almost every good boilerplate rewrite ends within ten words of where it started and says four times as much.
