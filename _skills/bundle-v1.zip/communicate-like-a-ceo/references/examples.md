# Before and After

Six full rewrites with the scoring shown. Use these to calibrate the standard, and to show a user what "executive-ready" actually looks like rather than describing it.

---

## Example 1: The buried ask

**Before (2/7)**

> Hi Dana,
>
> I hope you had a good weekend! I wanted to touch base about the vendor situation. So as you know we have been evaluating a few different options for the analytics platform and I have been doing a lot of research on this over the past few weeks, talking to different teams and looking at pricing. There are some tradeoffs with each one and honestly they all have pros and cons. Tools A and B are pretty similar but B is more expensive, and C is cheaper but might not scale. Anyway, I was wondering if you had any thoughts on which direction we should go? Let me know when you get a chance!

Missing: answer first, impact, structure, receipts, explicit ask, date.

**After (7/7)**

> Dana, need your call on the analytics vendor by Thursday so we can start onboarding before the Q4 freeze.
>
> Evaluated three over four weeks against cost, scale ceiling, and integration lift. [Link to the comparison]
>
> → **Option A**: $18K/yr, handles 3x our current volume, 2 week integration
> → **Option B**: $31K/yr, same capability as A plus reporting we do not need yet
> → **Option C**: $9K/yr, caps out at 1.5x current volume, we would be re-evaluating inside 12 months
>
> Recommend A. It is the only one that clears the volume we hit in March without a second migration.
>
> Need a yes or no by Thursday. If I do not hear back, I will move on A to protect the Q4 start.

**Coaching note:** The original made Dana do the analysis that had already been done. Four weeks of work was invisible because it was described instead of concluded. When you have done the work, deliver the conclusion. Show the options as evidence for your recommendation, not as a menu for someone else to pick from.

---

## Example 2: The invisible win

**Before (1/7)**

> Hey! Just wanted to let you know I finally finished up the onboarding docs I have been working on. It took a while because there was a lot to cover but they are done now. Let me know if you want me to change anything!

Missing: everything except a friendly tone.

**After (7/7)**

> Onboarding docs are live. [Link]
>
> Covers the 9 steps that generated the most support tickets last quarter. Two new hires ran through them this week and hit day-one setup without help, down from an average of 3 days and roughly 4 hours of a senior engineer's time per hire.
>
> At our current hiring pace that is about 40 senior hours back this year.
>
> No action needed. Flag anything you want changed by Friday, otherwise this becomes the standard.

**Coaching note:** "It took a while" tells the reader the work was hard. The number tells them it was valuable. Nobody promotes effort they have to take your word for. Before you send a completion message, ask what changed because of it, and lead with that.

---

## Example 3: Bad news, delivered late and soft

**Before (1/7)**

> Hi Marcus, so I wanted to give you a heads up that we might be running a little behind on the client report. There were some issues with the data pull and then a couple of the stakeholder interviews got rescheduled which threw things off. I am doing everything I can to catch up and hopefully we can still hit Friday but it might be tight. Sorry about this, I know it is important.

Missing: answer first, impact, structure, ask, real date. And "might" is doing damage.

**After (7/7)**

> Marcus, the client report will land Tuesday the 14th, not Friday the 10th.
>
> What happened: two stakeholder interviews moved to this week and I did not build buffer for that when I scoped it.
>
> Impact: the client's board meeting is the 18th, so Tuesday still clears it with three days of margin. Nothing else on our side slips.
>
> Already done: interviews are rescheduled and locked for Monday, and the data section is finished and in review. [Link to the draft]
>
> Need from you: nothing unless you want me to call the client. I will send them the revised date today with the reason. Next update Monday.

**Coaching note:** "Might be running a little behind" forces the reader to figure out how bad it is, and they will assume worse than the truth. Name the new date in the first line. A firm date you own reads as control. A soft maybe reads as a problem that is still growing.

---

## Example 4: The Slack message that starts a thread of questions

**Before (2/7)**

> hey quick q: do we have budget for the conference thing? need to know soonish

**After (7/7)**

> Need a yes or no on $4,200 for the [Conference] booth by Wednesday, that is the early-rate deadline.
>
> $4,200 covers booth, materials, and travel for two. Last year the same event produced 34 qualified leads and 2 closed accounts at $61K combined. [Link to last year's numbers]
>
> After Wednesday the same package is $6,800.
>
> If I do not hear back by Wednesday noon I will hold the spot with the refundable deposit so we do not lose the rate.

**Coaching note:** "Soonish" costs you the decision. Every ask that touches money needs the amount, the deadline, the return, and the cost of waiting. All four fit in six lines. The default action at the end is what turns a message a busy person might sit on into progress either way.

---

## Example 5: Pushback that reads as complaining

**Before (2/7)**

> I really do not think there is any way we can get all of this done by the end of the month. The team is already stretched really thin and this is a lot to add on top of everything else. It feels like we keep taking on more without any additional resources.

**After (7/7)**

> Cannot deliver the [new project] and the [existing commitment] both by the 31st. Here is the tradeoff so you can pick.
>
> Committed now: [Project A] due the 24th, [Project B] due the 31st. Both are fully allocated across the three of us. [Link to the plan]
>
> If we add [new project]:
> 1. [New project] lands the 31st, [Project B] moves to Feb 7
> 2. [New project] moves to Feb 14, everything else holds
> 3. We add a contractor for 3 weeks at roughly $9K and all three land on time
>
> Recommend 2. [Project B] has a client commitment attached and [new project] has no external date yet.
>
> Your call. Need to know by Friday so I can plan the week.

**Coaching note:** "Stretched thin" is a feeling and it invites a debate about how thin. The allocation and the three options are facts and they invite a decision. You are not saying no. You are showing the cost of yes and handing the prioritization to the person whose job it is. That is how pushback reads as ownership instead of resistance.

---

## Example 6: The status update nobody reads

**Before (3/7)**

> Weekly update:
>
> This week I worked on the website redesign project. I met with the design team on Monday and we went through the wireframes. I also had a call with the developer to talk about timing. I started drafting the copy for the homepage and about page. Next week I am going to continue working on the copy and hopefully get the wireframes finalized. There is a bit of a question about the photography budget that we should probably talk about at some point.

**After (7/7)**

> **Website redesign: week of [date]**
> **Status: At risk** (photography budget unresolved)
>
> **DONE**
> → Wireframes approved for all 6 templates. [Link] Locks the dev estimate at 4 weeks.
> → Homepage and About copy drafted, in review with [name]. [Link]
>
> **IN FLIGHT**
> → Dev build kicks off [date] once photography is resolved
> → Remaining 4 pages of copy: me, due [date]
>
> **RISK**
> → Photography quote came in at $8K against a $5K line. Shooting on the current budget means stock imagery on 3 of 6 templates. I am getting two more quotes by [date].
>
> **NEED FROM YOU**
> → Approve the extra $3K, or confirm stock is acceptable, by [date]. Without a call by then the dev start slips a week.

**Coaching note:** The original mentioned the budget problem last and called it something to discuss "at some point." That is the only thing in the update that needed a human decision, and it was buried under a list of meetings attended. Meetings attended are not progress. Sort every update by what the reader has to act on, and put the status label at the top so they can triage in one second.

---

## How to score

Run the seven checks in order and mark PASS or MISS on each.

1. Answer first
2. Context set
3. Impact stated
4. Scannable structure
5. Receipts attached
6. Ask is explicit
7. Next step and date owned

Report as `Executive Standard: X/7 → 7/7`, then name the three biggest misses. Do not list all seven back to the user. Name what cost them the most and move on.
