# Phrase Swaps

The junior-to-executive translation table. Use it during rewrites. The pattern underneath every swap is the same: replace the feeling with the fact, and replace the open question with the specific ask.

---

## Openings

| Junior | Executive |
|---|---|
| I hope this email finds you well | [Delete. Start with the headline.] |
| Just checking in | Update on [X]: |
| Circling back on this | Following up on [X]. Still need [Y] by [date]. |
| Touching base | [Delete. State the ask.] |
| Sorry to bother you | [Delete.] |
| I know you are really busy, but | [Delete.] |
| Quick question | Need a decision on [X]. |
| I wanted to reach out because | [Delete. Lead with the reason.] |

---

## Stating a position

| Junior | Executive |
|---|---|
| I think maybe we could | Recommend we |
| I feel like this might be | The data shows |
| It seems like there could be an issue | Flagging a risk to [the specific thing] |
| I was wondering if it would be possible to | Asking for [X] |
| This is probably not a big deal, but | [Delete the hedge. State it or cut it.] |
| Correct me if I am wrong | [Delete. If you are wrong they will say so.] |
| In my opinion | [Delete. They know it is your opinion.] |
| I could be off base here | [Delete.] |
| Kind of / sort of / a little bit | [Delete or use the number.] |

---

## Asks and closes

| Junior | Executive |
|---|---|
| Let me know your thoughts | Need a yes or no on Option B by Thursday. |
| Whenever you get a chance | By [date and time] |
| ASAP | By [date and time] |
| At your earliest convenience | By [date and time] |
| Does that make sense? | Confirm and I will proceed. |
| Any feedback would be appreciated | Flag anything you want changed by Friday, otherwise I will publish. |
| Hope that works | Confirming [X]. Tell me if that is wrong. |
| Please advise | Recommend [X]. Need your call by [date]. |
| Let me know if you need anything else | Next update [date]. |

---

## Reporting work

| Junior | Executive |
|---|---|
| I have been working on the migration | Migration is done. Cuts hosting spend $4,200 a month and closes the outage risk from July. |
| I finished the deck | Deck is final and approved by legal. [Link] Ready for Tuesday. |
| I did a lot of research | Reviewed 40 accounts. 12 show the same churn signal. Here is the pattern. [Link] |
| We made good progress | 6 of 9 workstreams complete. The 3 open ones land by [date]. |
| Things are going well | On track for [date]. No blockers. |
| I helped with the launch | Owned launch QA. Caught 3 blocking bugs before release. |
| I just wanted to share | Sharing for visibility, no action needed: |
| I was able to close the deal | Closed [client] at [$X]. Starts [date]. |

---

## Problems and bad news

| Junior | Executive |
|---|---|
| There is a bit of an issue | The [date] launch is at risk. |
| Something went wrong | [What broke], which affects [who]. Here is the fix in progress. |
| Sorry for the delay | Here is the update. New date is [X], and here is what changed. |
| It is not my fault, [person] did not | I under-scoped [X]. Here is the recovery plan. |
| Mistakes were made | I missed [X]. |
| We might miss the deadline | We will miss [date]. New date is [date]. Here is what I have already done. |
| I am blocked | Blocked on [specific thing] from [name]. Need it by [date] or [consequence]. |
| This is impossible with the current timeline | This timeline puts [outcome] at risk. Here is what I would cut to protect it. |

---

## Responding to a leader

| Junior | Executive |
|---|---|
| [Silence while you find the answer] | Do not have the number yet. You will have it by 3pm tomorrow. |
| Sure, no problem! | Confirmed. Landing [date]. |
| I will try | I will have it by [date]. |
| Hopefully by Friday | Friday by noon. |
| I am not sure | Do not know yet. Finding out from [name] and will confirm by [date]. |
| Whatever you prefer | Recommend A. Happy to go B if you prefer. |
| Per my last email | Restating the ask: [one line]. |
| I disagree [said elsewhere, later] | Seeing it differently. Here is why, and here is what I would do instead. |

---

## Words to delete on sight

**just, actually, basically, really, very, quite, somewhat, literally, honestly, obviously, simply, hopefully, potentially**

Each one either weakens a claim or adds nothing. Read the sentence without it. If the meaning survives, the word was decoration.

## Corporate words to plainer words

utilize → use
leverage → use
initiate → start
facilitate → run
sync up → meet
touch base → talk
circle back → follow up
bandwidth → time
low-hanging fruit → the easy wins
at the end of the day → [delete]
moving forward → [delete, or give the date]
going forward → [delete]

## Punctuation

- No em dashes. Use a period, a comma, or a colon.
- One exclamation point per message maximum, and none in escalations, bad news, or client problem threads.
- No ellipses. They read as hesitation.
- Arrows (→) for scannable lists in Slack and email. Bullets in documents.
