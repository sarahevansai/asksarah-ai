# Scenario Templates

Twelve structures for the messages that decide how you are perceived. Each one already passes the Executive Standard. Fill the brackets. Cut anything that does not apply. Never add a paragraph of context above the first line.

---

## 1. Weekly status update

Send it the same day and time every week. Consistency is the point. A leader who knows an update is coming stops asking for one.

```
[Project or client name]: Week of [date]
Status: [On track / At risk / Blocked]

DONE
→ [Result]. [Impact or number]. [Link]
→ [Result]. [Impact or number]. [Link]

IN FLIGHT
→ [Item]: [owner], due [date]
→ [Item]: [owner], due [date]

RISKS
→ [Risk]. [What it threatens]. [What I am doing about it]

NEED FROM YOU
→ [Specific ask] by [date]. If I do not hear back, I will [default action].
```

Rules: status label at the top so it can be triaged in one second. If nothing is blocked, write "Nothing blocked." Never leave the section off, because a missing section reads as an oversight.

---

## 2. Escalation

```
[Subject: Risk to [what], need a call by [date]]

[The problem in one line, with the date or number at stake.]

Impact: [What breaks, who it affects, what it costs.]

Options:
1. [Option]: [tradeoff]
2. [Option]: [tradeoff]
3. [Option]: [tradeoff]

Recommend: [Option number and why, in one sentence.]

Need from you: [Decision] by [date and time]. Default if I do not hear back: [option].
```

Rules: under 100 words. No history of how it happened unless asked. Never send an escalation without options.

---

## 3. Decision request

```
Need a decision on [topic] by [date].

Context: [One or two lines. What changed, why it is on your desk now.]

The choice:
→ Option A: [what happens, cost, timeline]
→ Option B: [what happens, cost, timeline]

Recommend A because [one reason grounded in a number or a risk].

[Link to the supporting doc]

If I do not hear back by [date], I will move on A to protect [the deadline or outcome].
```

Rules: two options beat five. If you truly have three, give three, never more. Always recommend. A decision request without a recommendation transfers your job to them.

---

## 4. Budget, headcount, or resource ask

```
Asking for [specific amount or role] to [outcome it produces].

The gap: [What is not happening today, with the number.]
The cost of not doing it: [Quantified, in revenue, risk, or time.]
The return: [What we get, by when, and how we will measure it.]
What I have already tried: [One line, so it is clear this is not the first move.]

Total: [$X] over [timeframe]. [Link to the breakdown.]

Need: [approval / a 15 minute conversation] by [date].
```

Rules: lead with the outcome, not the amount. Show the cheaper thing you tried first. Name the measurement, because an ask with no measurement gets deferred.

---

## 5. Bad news or a missed deadline

```
[Deliverable] will land [new date], not [original date]. Here is where we are.

What happened: [One sentence. Own your part plainly.]
Impact: [What this affects downstream, and what it does not affect.]
What I have already done: [The mitigation, in progress now.]
New commitment: [Date and time, with margin built in.]

Need from you: [Nothing, or the specific thing.] Next update: [date].
```

Rules: send it the day you know, not the day it is due. One sentence of ownership, no spiral. End with the new date and a commitment to update, because that is what restores confidence.

---

## 6. Meeting recap

```
[Meeting name]: [date]

DECISIONS
→ [Decision]. Owner: [name].
→ [Decision]. Owner: [name].

ACTIONS
→ [Action]: [name], due [date]
→ [Action]: [name], due [date]

OPEN
→ [Question still unresolved]. Needs [name] by [date].

[Link to notes or recording]
```

Rules: send within two hours while people still remember. Decisions before actions. Every line has a name and a date. If you write the recap, you control the record of what was agreed, which is quiet leverage worth having.

---

## 7. Client or external update

```
Hi [name],

[Headline: what is done or what is coming, with the date.]

→ [Deliverable]. [Status]. [Link]
→ [Deliverable]. [Status]. [Link]

[One line on anything that shifted, with the new date and no internal blame.]

Next: [What happens next and when.] I will follow up [date].

[Your name]
```

Rules: never end without a next date. Never expose an internal blocker by name. Never let a client be the one to follow up first.

---

## 8. Self-review or performance summary

```
[Period] summary

[Theme line: the one thing that best describes the period.]

RESULTS
→ [Result]. [Number or impact.] [Proof link.]
→ [Result]. [Number or impact.] [Proof link.]
→ [Result]. [Number or impact.] [Proof link.]

WHAT IT UNLOCKED
→ [What the team or business can now do that it could not before.]

WHERE I GREW
→ [Specific skill], shown by [specific instance].

FOCUS NEXT
→ [Where you are pointing next and why it matters to the business.]
```

Rules: results before effort. Three strong results beat nine tasks. Every result carries a number or it is not a result. Name the skill you grew with the evidence attached, because "I improved my communication" without an example is a claim, and a claim is not a case.

---

## 9. Promotion or scope case

```
Asking to be considered for [role or scope], and here is the case.

Already operating at that level:
→ [Example]. [Scope you carried.] [Outcome.]
→ [Example]. [Scope you carried.] [Outcome.]
→ [Example]. [Scope you carried.] [Outcome.]

Business impact: [The number across those examples.]
What changes if I hold the title: [What you could do that you cannot do today.]
The gap I am closing: [Honest one, with your plan.]

Asking for: [a conversation / consideration in the [cycle] cycle] by [date].
```

Rules: the case is that you already do the job, not that you want it or deserve it. Name one real gap, because a case with no gap reads as unaware, and naming it first takes it away as an objection.

---

## 10. Saying no, or pushing back

```
Cannot take [request] and hold [existing commitment]. Here is the tradeoff.

Current load: [What is committed, with dates.]
If I take this on: [What slips, and by how long.]

Options:
1. [New thing] moves to [date] and everything holds
2. [Existing thing] slips to [date] and the new thing lands on time
3. [Resource or reassignment] and both land

Recommend: [option]. Your call. Need to know by [date] so I can plan the week.
```

Rules: never say a flat no and never say a hollow yes. Show the tradeoff and hand the prioritization back. This reads as ownership, not resistance, and it protects you when something does slip.

---

## 11. Following up on silence

```
Following up on [ask] from [date]. [Link to the original.]

Still need: [the one thing], by [date].
Why it is time-sensitive: [what it holds up].

If it is easier: [reply "A" or "B" / 10 minutes on your calendar / here is my recommendation and I will proceed unless you say otherwise].
```

Rules: never "per my last email," never "just bumping this." Restate the ask so they do not have to scroll. Make replying easier than ignoring. Third follow-up converts to a decision you make and announce.

---

## 12. Introducing yourself to a senior stakeholder

```
[Name]: [your name], [role]. I own [the specific thing that matters to them].

Where we are: [One line of current state with a number.]
What you can expect from me: [Cadence and format of updates.]
What I need from you: [One thing, or "nothing right now."]

[Link to the current status doc.]
```

Rules: four lines, not a biography. Lead with what you own, not where you came from. Setting the update cadence yourself is what a senior person does.

---

## 13. Team update: how we are moving

For when you are the one telling a team what changes and what to do about it. Slack, Teams, or email to a group.

```
**[Project or decision]: [what changed, in one line]**

**What's happening:** [The decision and why now. One or two lines.]

**What this means for you:**
→ @[name]: [specific action] by [date]
→ @[name]: [specific action] by [date]
→ @[name]: [specific action] by [date]

**No change for:** [everyone else, named by team or role]

**Why:** [One line, or a link to the fuller context.]

Questions in this thread, not DMs, so everyone gets the same answer.
```

Rules: every action carries a name and a date. Name who is NOT affected, because it stops six people from privately wondering. One line of why, not three paragraphs of defense. Point questions to the thread or you will answer the same question five times and only five people will hear it.

---

## 14. Issue brief in chat

The Issue Brief compressed for Slack or Teams. Same five parts, six lines.

```
**[The issue in one line, with what it threatens.]**

**Impact:** [Number, date, or consequence.]

**Options:**
→ [Option 1]: [tradeoff]
→ [Option 2]: [tradeoff]
→ [Option 3]: [tradeoff]

**Recommend [option]** because [one reason].

**@[name]: need [decision] by [date].** If I do not hear back I will [default].
```

Put the reasoning, the data, and the background in the first threaded reply, not in the message. The channel gets the decision. The thread gets the homework.

---

## Universal closers

Pick one. Never end on "let me know your thoughts."

- "Need a yes or no by [date]."
- "If I do not hear back by [date], I will proceed with [option]."
- "No action needed, sharing for visibility."
- "Confirming and I will move."
- "Reply with A or B and I will take it from there."
- "Next update [date]."
