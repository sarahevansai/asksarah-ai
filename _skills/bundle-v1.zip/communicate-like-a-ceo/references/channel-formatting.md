# Channel Formatting

Junior communication is rarely wrong about the facts. It is wrong about the shape. A message that is correct but unreadable gets skimmed, misread, or ignored, and the sender concludes that nobody listens to them.

This file covers how a message should physically look in each channel. Apply it to every message this skill produces.

---

## Slack and Teams: the ten rules

**1. One message, never a burst.**
"hey" then "quick q" then "so the thing is" fires three notifications and delivers zero information. Everyone on the channel gets pinged three times to learn nothing. Compose the whole thought, then send once.

**2. Bold labels instead of headers.**
Chat has no heading levels. Bold text at the start of a line is the header. Use it to break the message into scannable sections:

```
**What changed:**
**What it means for you:**
**Need from you:**
```

**3. Blank line between every section.**
The single biggest readability upgrade available in chat, and the most skipped. A message with no whitespace reads as a wall and gets postponed. Two sections with a blank line between them get read.

**4. Arrows or bullets for anything with more than one item.**
Never comma-separate a list of actions inside a paragraph. One item per line:

```
→ Jamie: update the pricing page by Thursday
→ Priya: send the revised deck to the client by Friday noon
```

**5. Name the owner at the start of the line, not buried at the end.**
People scan for their own name. If it is at the end of a sentence they miss it. `@jamie: ship the fix by Thursday` beats "the fix needs to ship by Thursday and Jamie can you take that."

**6. Bold the ask.**
One bolded phrase per message, on the thing you need. If everything is bold, nothing is.

**7. Six lines in the main message. Detail goes in the thread.**
Post the decision, the owners, and the dates in the channel. Post the reasoning, the background, and the long explanation as the first reply in the thread. People who need it will open it. People who do not are not punished for scrolling past.

**8. Hyperlink the words, never paste a raw URL.**
A bare link is 90 characters of visual noise that says nothing about where it goes. `[the revised deck](url)` or Slack's link formatting. Every link gets a label.

**9. Reply in thread by default.**
Use "also send to channel" only when the whole channel genuinely needs the answer. Threads keep the channel readable, and a readable channel is why people keep reading yours.

**10. Never send a hard message at 11pm.**
Schedule it for the morning. Sending an escalation at midnight makes the reader anxious and makes you look like you have no boundaries. Both cost you.

---

## What junior chat looks like, and the fix

**Before**

> hey so i was looking at the numbers for the campaign and it seems like the conversion rate dropped a bit last week, not sure exactly why yet but i think it might be related to the checkout change we pushed on tuesday? anyway i wanted to flag it and see what you think we should do, also the reporting dashboard is showing some weird stuff but that might be a separate issue. let me know!

Six problems: no headline, no numbers, two unrelated issues braided together, hedges on every claim, no options, no ask, no date.

**After**

> **Conversion is down 18% since Tuesday. Recommend we roll back the checkout change today.**
>
> **What happened:** conversion dropped from 4.2% to 3.4% starting Tuesday afternoon, which lines up with the checkout release. About $12K in lost revenue so far.
>
> **Options:**
> → Roll back today: we lose the new checkout for a week, revenue recovers immediately
> → Leave it and investigate: we keep the feature, cost is roughly $4K a day while we look
> → Ship a partial fix Thursday: needs two engineering days we have not scoped
>
> **Recommend rolling back today** and re-releasing once we know the cause. The feature is not time-sensitive and the revenue loss is.
>
> **@dana: need a yes on the rollback by 2pm.** If I do not hear back I will roll back and we can discuss re-release tomorrow.
>
> Separate and lower priority: the reporting dashboard is showing duplicate rows. Opening that in its own thread so it does not compete with this.

Same information. One is a person thinking out loud, the other is a person who can be given more responsibility.

---

## Team updates: telling people how to move

When you are the one telling a team what to do next, the message answers three questions in this order. Anything else belongs in a doc.

```
**[Project or decision]: [what changed, in one line]**

**What's happening:** [One or two lines. The decision and why now.]

**What this means for you:**
→ @[name]: [specific action] by [date]
→ @[name]: [specific action] by [date]
→ @[name]: [specific action] by [date]

**No change for:** [everyone else, named by team or role]

**Why:** [One line, or a link to the fuller context.]

Questions in this thread, not DMs, so everyone gets the same answer.
```

Rules:

- **Every action has a name and a date.** An action with no owner does not happen. An action with no date happens last.
- **Tell people who is NOT affected.** This is the most skipped line and the most appreciated one. It stops six people from privately wondering whether this is about them.
- **One reason, not a defense.** A single "why" line earns compliance. Three paragraphs of justification invites debate you did not want.
- **Point questions to the thread.** Otherwise you answer the same question in five DMs and only five people get the answer.

---

## Email

- **Subject line carries the ask and the date.** "Budget approval needed by Friday: $4,200 for the conference booth." Leaders triage by subject before they open anything. "Quick question" and "Update" are how a message gets buried.
- **First line repeats the ask.** Do not make them scroll to confirm what the subject promised.
- **150 words above the fold.** Supporting detail goes below a horizontal break or in the attachment.
- **Bold the ask and the date.** Two bolded elements maximum.
- **One topic per email.** Two topics means one gets answered and the other gets lost, and the lost one is your fault for braiding them.
- **Signature has the next date.** "Next update Friday" closes the loop before they ask.

---

## Documents and decks

- **Title says the conclusion, not the topic.** "Recommend Dallas for the new warehouse" beats "Warehouse Location Analysis."
- **Summary on page one, and it must survive alone.** Assume half the readers stop there. Write it so stopping there is fine.
- **One idea per slide, one sentence per bullet.** If a bullet wraps to three lines it is a paragraph wearing a bullet.
- **Number the pages.** People reference them in meetings, and "the one with the chart" wastes everyone's time.

---

## Spacing, universally

The most common formatting failure across every channel is density. Fix it with three habits:

1. **Blank line between sections.** Always.
2. **Nothing longer than three lines without a break.** If it runs longer, it is two thoughts.
3. **The bold text alone should tell the story.** Read only the bold in your draft. If that reads as a coherent summary, the formatting is done. If it reads as fragments, the labels are wrong.
