# Communicate Like a CEO

A Claude skill that rewrites any workplace message into the version a senior leader can act on in twenty seconds, and teaches you why, so your next draft is better without help.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most people are not held back by the quality of their work. They are held back by how they hand it over. This skill closes that gap.

Paste in a draft, or describe the situation, and Claude will:

1. Hand you the finished message, copy-ready
2. Score the original against seven checks, so you see exactly what was missing
3. Give you one coaching note that generalizes to every message after this one

**You always get a message back.** Ask for a review and you get a review plus the better version. Ask how to handle a situation and you get the framing plus the draft that executes it. Missing a number or a link? It comes back with `[BRACKETS]` to fill, not a question to answer. You never have to reply to get something you can send.

It works on Slack and Teams messages, emails, status updates, escalations, bad news, budget asks, self-reviews, promotion cases, client updates, meeting recaps, and pushback.

Two things it handles that most writing tools do not:

**Raising an issue.** Any problem comes back as an Issue Brief: the issue, the impact with a number attached, two or three real options with their tradeoffs, your recommendation, and the ask with a date. Three problems means three recommendations, not three complaints.

**Making it look right in chat.** Slack and Teams have their own rules, and junior formatting is where good thinking goes to die. Bold labels as headers, a blank line between sections, one item per line, the owner's name at the front, six lines in the channel with detail in the thread. Team updates come back with a named owner and a date on every action, plus a line naming who is not affected.

## The Executive Standard

Every message passes seven checks before it sends:

1. **Answer first**: the conclusion or ask is in line one
2. **Context set**: assume zero recall
3. **Impact stated**: a number, a date, a risk, a consequence
4. **Scannable structure**: the bold text alone tells the story
5. **Receipts attached**: every claim and doc linked inline
6. **Ask is explicit**: one clear ask, named person, real options
7. **Next step and date owned**: including what happens by default if nobody replies

Plus the Problem Rule: never bring a problem without options and a recommendation.

## Try it

Once installed, say any of these:

- "Rewrite this for my VP" and paste your draft
- "Is this ready to send?"
- "How do I tell my manager the deadline is slipping?"
- "Help me ask for headcount"
- "Turn this into a status update my director will actually read"
- "Score this email"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `communicate-like-a-ceo.zip` in your skills settings. Claude loads it automatically whenever a message needs it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/communicate-like-a-ceo/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and paste any rough draft with "make this executive-ready." You should get a rewrite, a score out of 7, and one coaching note.

## What is in the package

```
communicate-like-a-ceo/
├── SKILL.md                      The framework, rules, and output format
├── README.md                     This file
├── LICENSE
└── references/
    ├── templates.md              14 fill-in structures for the highest-stakes messages
    ├── channel-formatting.md     How it should look in Slack, Teams, email, docs, decks
    ├── phrase-swaps.md           The junior-to-executive translation table
    └── examples.md               6 full before-and-after rewrites with scoring
```

## Notes

Claude will never invent a number, a date, a name, or a link to fill a gap. Anything it does not know comes back in `[BRACKETS]` for you to fill. That is deliberate. A confident message built on a made-up number is worse than no message.

It will ask at most one question, and only after the draft is already in front of you. Nothing is ever held back waiting on an answer.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
