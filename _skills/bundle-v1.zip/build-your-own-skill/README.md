# Build Your Own Skill

A Claude skill that turns a workflow you repeat into a working Claude skill, without writing a line of code.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

There is a task you do every week. You know how to do it well. And every time you ask an AI for help with it, you re-explain the whole thing from scratch and get a slightly different result.

A skill freezes the good version. It is a plain text file holding your steps, your standards, and your rules. Once it exists, the good version happens every time.

Describe your workflow in a sentence or two, and Claude will:

1. Hand you the complete SKILL.md file, written out in full, ready to save
2. Give you three test prompts so you can see whether it works before you trust it
3. Give you one coaching note that makes the next skill you build better

**You always get a finished file.** Not an outline. Not a list of sections you should write. Not "here is what your skill would contain." If you describe a workflow in two sentences, it writes the whole file from those two sentences, infers the rest, and marks only the things it genuinely cannot know in `[BRACKETS]`.

There is no code in a skill. There is no terminal. If you can write down how you do your job, you can build one.

## The five steps

It walks you through all five in one pass, conversationally. No questionnaire to fill out first.

1. **Pick the right workflow.** Good candidates repeat, have a right answer you can recognize, and produce inconsistent results today. It will tell you plainly when your idea is not one, and point you at the version nearby that is.
2. **Interview the expert.** The expert is you. It pulls out the trigger, the inputs, the steps, and the unwritten rules you never thought to say out loud. Two or three questions at a time, never a form. Go quiet and it writes the skill anyway.
3. **Write the file.** Frontmatter, the hard rule about what gets delivered, the framework, the output format, the never-do list, worked examples, and reference files if the material earns them.
4. **Make it trigger.** The description field is the only part read before the skill loads, and it is where most skills die. It gets written as the phrases a real person actually types, not a formal summary.
5. **Test and tighten.** Three prompts: a clean case, a vague case with almost no context, and an awkward case designed to tempt the model into doing the wrong thing. Plus a table for reading the results and knowing exactly what to change.

## What it fixes

**Skills that never fire.** Roughly nine times out of ten the description is written as a formal summary instead of a list of casual phrases. Paste in a skill that is not triggering and you get a rewritten description plus test prompts.

**Skills that talk instead of doing.** A skill that hands back feedback on the work rather than the work. Fixed with a hard number one rule that names exactly what must be delivered on every run, and lists every situation where it still applies.

**Skills that are too polite to be useful.** "Write professionally" does nothing. "Never open with a greeting, lead with the decision, cap it at 150 words" produces a different result every time. Every instruction should be something a reasonable person could argue with.

## Try it

Once installed, say any of these:

- "I do this every Monday and I want to make it a skill" and describe it
- "Turn this into a skill" and paste a process
- "Write me a Claude skill for reviewing contracts"
- "Why isn't my skill triggering?" and paste the file
- "Improve my skill"
- "Write test prompts for this"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `build-your-own-skill.zip` in your skills settings. Claude loads it automatically whenever it recognizes the situation.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/build-your-own-skill/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "I do the same report every month and I keep re-explaining it. Can you make it a skill?" You should get a complete SKILL.md in a code block, three test prompts, and one coaching note.

## What is in the package

```
build-your-own-skill/
├── SKILL.md                The five steps, the rules, and the output format
├── README.md               This file
├── LICENSE
└── references/
    ├── anatomy.md          Every section of a skill file, with a weak and a strong
    │                       version of each, plus a 20-point review checklist
    └── examples.md         Three complete builds from three professions, showing the
                            messy thing the user said and the finished skill from it
```

## Notes

Claude will not invent your numbers, your tools, your approval chain, or your thresholds. Anything it cannot know comes back in `[BRACKETS]` for you to fill. Everything else it infers and writes, then tells you in one line what it assumed so you can correct it.

It will ask at most one question, and only after the finished file is already in front of you. Nothing is held back waiting on an answer.

It will also tell you when you should not build a skill: when a saved prompt would do, when the task changes every time, when the real bottleneck is data rather than instructions. In those cases you still leave with something usable.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
