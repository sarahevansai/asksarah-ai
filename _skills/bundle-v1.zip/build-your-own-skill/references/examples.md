# Three Worked Builds

Three complete skills, built from three professions, each one starting from what the user actually said. The messy input is real in shape: short, incomplete, and full of assumed knowledge. The finished file is what gets handed back.

Read these when a workflow sounds too thin to build from. In all three cases, most of the finished file was inferred, not extracted.

---

# Build 1: A bookkeeper's month-end close review

## What the user said

> "Every month I close the books for like eight small business clients and then I go through the P&L and balance sheet looking for stuff that's off before I send it. It's the same stuff every time honestly. Accruals that didn't reverse, someone coded an owner draw as an expense, prepaid insurance nobody amortized. Takes me maybe 40 minutes a client and I always find something. I'd love to not have to remember all of it."

That is four sentences. Everything else below was inferred from what a month-end close review is, plus the three specific errors she named, which told us the level she works at.

## What was asked back

Two questions, not eight: "What is the thing that has actually made it out the door wrong before?" and "When you send it, who reads it, the owner or their CPA?"

She said a misclassified loan payment went out once and the client's CPA caught it, and that it is usually the owner, who does not read financial statements well.

Those two answers produced the entire "what goes out" section and the plain-language rule.

## The finished skill

```
---
name: month-end-close-review
description: >
  Reviews a closed month for a small business client before the financials go out, and
  produces a written review with every issue found, ranked. Use whenever books are closed
  and someone needs a second set of eyes before the statements are sent: P&L review,
  balance sheet review, accrual and prepaid checks, coding errors, unusual entries,
  month over month swings. Trigger on "close is done," "review the month end," "does this
  look right," "check my numbers," "before I send this," "the P&L looks weird," "something
  is off in this balance sheet," "run the close review," "here is the trial balance," or
  any pasted financial statement, trial balance, or account comparison. Also trigger when
  the user names a month and a client in the same sentence as a set of numbers. When in
  doubt, use this skill. A review nobody needed costs two minutes. A misclassified entry
  reaching the client's CPA costs the relationship.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Month-End Close Review

The books balance and something still feels wrong. Nine times out of ten it is the same handful of things, and they are the same things every month across every client.

This skill runs that review in a fixed order, writes up everything it finds, and produces the client-facing note that goes out with the statements.

## The #1 rule: always deliver the written review

**Every run ends with a completed review document plus the client note. No exceptions.**

Not a list of what you would check. Not questions about the accounts. The finished review, with every issue found, ranked, and a plain-language note the owner can actually read.

This holds even when:

- Only one statement was provided. Review what is there, and list what you could not check.
- The numbers look clean. Say so, and still deliver the review and the note.
- The user asked about one account. Answer that, then run the full review anyway.
- Prior month comparatives are missing. Note it, run everything that does not require them.

Never end a response with a question instead of the review. Ask afterward, and only if the answer changes a finding.

## The review, in order

Run all six passes. Do not skip a pass because the last one was clean.

**1. The reversal check.**
Every accrual booked last month either reversed this month or has a reason it did not. List any that did not reverse, with the amount and the month it originated.

**2. The prepaid and deferred check.**
Every prepaid on the balance sheet should have moved this month. A prepaid balance that is identical to last month means nobody amortized it. Same logic for deferred revenue.

**3. The owner check.**
Owner draws, personal expenses, and shareholder loans are the most commonly miscoded items in a small business. Scan every expense account for anything that looks personal: travel with no client attached, meals on a weekend, a subscription that matches a hobby. Flag, do not assume.

**4. The debt service check.**
Every loan payment splits between principal and interest. A full payment sitting in an expense account is an error and it is the one that gets caught downstream. Check every recurring payment against a loan on the balance sheet.

**5. The swing check.**
Every account that moved more than 25 percent or more than [dollar threshold] against the prior month gets a named explanation. "Higher this month" is not an explanation. "Annual insurance premium paid in full, will amortize over 12 months" is.

**6. The suspense check.**
Anything sitting in ask-my-accountant, undeposited funds, or a clearing account at month end. These accounts should be empty. If they are not, that is a finding, not a rounding issue.

## Ranking what you find

Every issue is one of three:

- **Must fix before sending.** The statements are wrong. Misclassification, a missing reversal, a real balance error.
- **Should fix this month.** Not wrong, but it will become wrong. An unamortized prepaid, a growing clearing balance.
- **Worth a conversation.** Not an error, but the owner should know. A trend, a vendor that doubled, a margin slipping.

Never bury a must-fix inside a list of minor items. Must-fix items go first, always.

## Output format

1. **The review**, in a code block. Client and month at the top, then Must Fix, Should Fix, and Worth a Conversation, each item one line with the account, the amount, and what to do about it. If a section is empty, say "None found," never omit the heading.
2. **The client note**, in a separate code block, written for the owner, not the accountant. Three sentences maximum on how the month went, plus anything they need to act on. No account numbers, no jargon.
3. **What you could not check**, one line, naming what was missing.
4. **At most one question**, only if the answer changes a finding.

Never explain the process. Never summarize at the end.

## Rules

- **Write the client note in plain words.** The owner does not know what an accrual is and does not want to. "The insurance payment was for the full year, so it will spread out over the next twelve months" beats anything with the word amortization in it.
- **Never state a cause you cannot see.** "Meals up $1,400, no detail available" is honest. Guessing why is how bad information travels.
- **Every finding gets a dollar amount.** An issue without a number cannot be prioritized.
- **Never say the books look good without naming what you checked.** A clean review lists the six passes and says clean.
- **Never round in the review.** Round in the client note only, and only to the nearest dollar.
- **Never send a client note that mentions the client's own error.** Report the fix, not the blame.
```

## What made this one work

The three errors she named in passing became passes 1, 2 and 3. The one thing that had gone wrong before became pass 4. The audience answer became the entire client note section and the plain-words rule. Four sentences and two answers produced a file she uses on eight clients a month.

---

# Build 2: A recruiter's candidate summary for hiring managers

## What the user said

> "I send hiring managers a write-up after every screen and they never read them. Or they read them and still ask me the same three questions. I think mine are too long? I do maybe 15 screens a week so this is the thing I spend the most time on."

No process described at all. This is a complaint, not a workflow. That is normal, and it is enough.

## What was asked back

"What are the three questions they always come back with?"

She said: can they actually do the job, why are they leaving, and what do they want to get paid.

That answer became the framework. The skill was written around the three questions the managers ask instead of around the write-up she was already doing, which is why it works.

## The finished skill

```
---
name: candidate-summary
description: >
  Turns screen notes, a resume, or a scorecard into a one-page candidate summary a hiring
  manager reads in ninety seconds and can decide from. Use after any screen or interview,
  before a debrief, when a manager asks who is in the pipeline, or when two or more people
  need comparing for the same role. Trigger on "write up this candidate," "summarize this
  interview," "send this to the hiring manager," "what did you think of her," "who should
  I be seeing," "here are my notes from the screen," "is this one worth a debrief," "put
  together a brief on him," "compare these two," or any pasted resume, screen note, or
  scorecard. Also trigger when the user mentions a candidate name and a role in the same
  sentence. When in doubt, use this skill. A summary the manager skims costs nothing. A
  strong candidate lost to a slow write-up costs the search.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Candidate Summary

Hiring managers do not read long write-ups. They read the first two lines, then they ask the same three questions anyway: can this person do the job, why are they leaving, and what will they cost.

This skill answers those three questions first, in that order, and gets everything else out of the way.

## The #1 rule: always deliver the finished summary

**Every run ends with a complete, sendable candidate summary. No exceptions.**

Not an assessment of the notes. Not questions about the candidate. The finished one-pager, with a verdict on it, even when the notes are thin.

This holds even when:

- The notes are three bullets. Write the summary from three bullets and mark what is unknown.
- Only a resume was provided and no interview happened. Write the resume-only version, and label it as such in the first line.
- The user asked a narrow question about one candidate. Answer it, then deliver the summary.
- The candidate is a clear pass. Write the summary anyway. A pass still needs a record.

Never end a response with a question instead of the summary. Never invent a fact the notes do not contain. Missing facts go in brackets.

## The four sections, always in this order

**1. The verdict, one line.**
Advance, pass, or hold, with the single strongest reason. Half of all readers stop after this line, so it has to stand alone.

**2. Can they do the job.**
The three things that actually matter for this specific role, named for this role, not generic competencies. Each gets a rating of strong, adequate, or gap, plus one piece of evidence from the conversation, quoted where possible. A quote is evidence. A paraphrase is an opinion.

**3. Why they are leaving, and what they want.**
Their stated reason, in their words, plus your read on whether it holds up. Then compensation: their number, the range for the role, and whether those two meet. If the number was not discussed, say so plainly. Do not estimate it.

**4. The risk, and what to probe.**
The one thing that would make this hire go badly, stated plainly. Every candidate has one, and a summary without one reads as a sales pitch. Then two questions written out for whoever interviews next.

## Output format

1. **The summary**, in a code block, one page maximum, ready to paste into an email or a tracking system.
2. **One line** naming anything you assumed or could not verify.
3. **At most one question**, only if the answer would change the verdict.

Never write an introduction. Never restate the request. Never add a closing summary.

## Rules

- **One page, always.** A manager who has to scroll stops reading.
- **Lead with the verdict, never with the background.** Where they worked is context, not a conclusion.
- **Quote the candidate at least twice.** Their words are more persuasive than your assessment of their words.
- **Never soften a gap into a strength.** "Would need ramp-up support" usually means "does not have the skill." Say which one you mean.
- **Banned phrases:** great communicator, team player, self-starter, culture fit, rock star, passionate. Each one hides the thing you were supposed to say. Describe what they did instead.
- **Never include anything outside job performance.** Not age, family status, appearance, accent, health, where they live, or how they sounded on a bad connection.
- **Never write a summary with no risk section.** If you cannot name a risk, the screen was not deep enough, and that is itself the finding.
- **When comparing candidates,** use one shared table with the same three criteria for everyone, then one line per person on the tradeoff. Never a separate write-up for each and no comparison.
```

## What made this one work

She never described her process, and it did not matter. The framework came from the three questions her audience kept asking. When a user cannot describe their workflow, ask what the reader always comes back with, and build the skill around that instead.

---

# Build 3: A teacher's parent update

## What the user said

> "I have to send updates home about kids and it takes forever because I'm trying to say something isn't working without the parent getting defensive. And then some parents want way more detail than others. Middle school, 130 students, I do maybe 20 of these a month."

## What was asked back

"When a parent does get defensive, what set them off?"

She said it is almost always when the message is only about the problem, or when it feels like it came out of nowhere.

That one answer produced the two hardest rules in the file: something specific and true first, and the pattern before the incident.

## The finished skill

```
---
name: parent-update
description: >
  Writes a message home to a parent or guardian about a student: progress, a concern, a
  behavior pattern, a missing-work problem, or good news. Use whenever a family needs to
  hear something and the wording matters. Trigger on "I need to email his mom," "write a
  message home," "how do I tell these parents," "parent email," "I have to tell them about
  the grade," "she is not turning anything in," "flag this to the family," "write a note
  home about," "progress update for," "this parent is going to be upset," or any time the
  user describes a student situation and a family in the same breath. Also trigger when
  the user is drafting anything to a family and hesitating over the wording. When in
  doubt, use this skill. A message nobody needed takes a minute to discard. A message
  worded badly takes a semester to recover from.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Parent Update

Parents get defensive for two reasons: the message is only about the problem, or it arrives with no warning. Both are fixable in the first two sentences.

This skill writes the message home, in a shape that gets a reply instead of a fight.

## The #1 rule: always deliver the message

**Every run ends with a complete, sendable message. No exceptions.**

Not advice on how to approach the conversation. Not questions about the student. The finished message, ready to paste into email or the school portal.

This holds even when:

- The user described the situation in one sentence. Write it from one sentence.
- The user asked how to handle it, not how to word it. Give the approach in two lines, then write the message.
- Details are missing. Use brackets for the specifics only the teacher knows, like a date, an assignment name, or a score.
- The user is frustrated with the student or the family. Write the calm version. That is the whole job.

Never end with a question instead of the message.

## The shape

Five parts, in this order. Do not reorder them, because the order is what keeps the reader open.

**1. Something specific and true about the student, first.**
Not a compliment sandwich, and not flattery. One real observation: something they said in class, a moment they showed up, an assignment where the effort was visible. It must be specific enough that it could only be about this child. Generic praise reads as a setup and makes everything after it suspect.

**2. The pattern, not the incident.**
"Three of the last five assignments have come in late" lands. "He did not turn in the essay" invites an argument about the essay. Give the timeframe and the count.

**3. What it means, plainly.**
The consequence in the language a parent cares about: the grade, the readiness for what is next, the habit forming. One sentence. No education jargon, no acronyms.

**4. What you are already doing.**
Name the support already in place. This is the line that stops a parent from feeling the problem is being handed to them.

**5. One specific ask, and one door open.**
One thing you want from home, small and concrete. Then an invitation to reply or meet, with a real window of time.

## Output format

1. **The message**, in a code block, with a subject line, ready to send.
2. **One line** on the tone you aimed for and what you would change if this family is already frustrated.
3. **At most one question**, only if it would change the message.

Never explain the approach before the message. The message comes first.

## Rules

- **Length: 150 words maximum for a concern, 75 for good news.** Long messages read as a case being built.
- **Send good news on its own, at least once, before you ever need to send a concern.** If the user has never sent this family anything positive, say so in the note under the message and offer to write that one first.
- **Never use school jargon.** No tiered intervention, no scaffolding, no formative, no acronyms of any kind. If a phrase would not appear in a text message, cut it.
- **Never describe the child with a label.** Not lazy, not unmotivated, not disrespectful, not defiant. Describe what happened and when.
- **Never compare the student to classmates or to a sibling.**
- **Never ask a parent to fix the behavior.** Ask for one specific, doable thing: check the portal on Sundays, ask about the reading log at dinner.
- **Never put anything in writing you would not want read aloud at a conference,** because it may be.
- **Match the family's detail preference when it is known.** Some parents want the full picture, some want three lines. If the user says which, follow it. If not, write the short version and offer to expand.
- **When the news is serious,** the message asks for a call instead of delivering the news in writing. Some things should not be read alone at a kitchen table.
```

## What made this one work

The last rule, about serious news going to a phone call, was not in anything she said. It was inferred from the domain. Good skill-building includes the rules an expert would agree with instantly but never thought to say, and marking them clearly enough that the user can strike them if they disagree.

---

# The pattern across all three

- **The user gave four sentences or fewer.** None of the three could describe their own process on demand. All three could react to a draft instantly.
- **One good question produced the framework.** What has gone wrong before. What do they always ask you. What set them off. Pick the question that reveals the failure mode, not the question that asks them to outline their process.
- **The specifics they mentioned in passing became the structure.** The three errors, the three questions, the two triggers for defensiveness. When someone names a specific thing without being asked, it is load-bearing.
- **Most of the file was inferred.** That is not a shortcut, it is the job. The user's role is to correct a draft, not to author one.
