# Anatomy of a Skill File

Every part of a SKILL.md, in order, with a weak version and a strong version of each. Use this when writing a skill from scratch, improving one, or diagnosing why one does not fire.

At the end there is a review checklist for auditing any skill in about five minutes.

---

## Part 1: The frontmatter

The block at the very top, wrapped in three dashes above and below. It holds the name, the description, and the metadata. It is the only part of the file read before the skill loads.

```
---
name: skill-name-here
description: >
  What it does, when to use it, and the phrases that trigger it.
metadata:
  version: "1.0.0"
  author: "Your Name"
  license: "Single-user commercial license. See LICENSE."
---
```

Rules:

- The three dashes must be the very first line of the file, with nothing above them.
- `name` is lowercase, words separated by hyphens, and it matches the folder name exactly.
- `description:` uses `>` when it runs longer than one line, which it always should. The `>` means "the indented text below is all one value."
- Everything under the `>` is indented by two spaces. Keep the indentation consistent or the file will not load.

### The name

**Weak:** `helper`, `my-skill`, `assistant-v2`, `reports`

Too generic to distinguish from anything else, and it gives no signal about when to use it.

**Strong:** `month-end-close-review`, `candidate-summary-for-hiring-managers`, `parent-update-writer`

Name it after the work, not the tool. Two to five words. If someone read only the name, they should know what it produces.

---

## Part 2: The description

The highest-leverage forty lines in the whole file. It is the only thing that decides whether the skill ever runs. Most broken skills are broken here.

### The weak version

```
description: A skill for helping with candidate summaries.
```

Three problems. It uses formal words nobody types. It names no situations. It contains no quoted phrases. In practice this fires almost never.

### The strong version

```
description: >
  Turns interview notes, a resume, or a scorecard into a one-page candidate summary a
  hiring manager can read in ninety seconds and make a decision from. Use whenever a
  candidate needs to be written up, compared, or passed along: after a screen, before a
  debrief, when a manager asks who is in the pipeline, or when a resume needs a verdict
  attached. Trigger on "write up this candidate," "summarize this interview," "who should
  I see," "send this to the hiring manager," "what did you think of her," "put together a
  candidate brief," "is this person worth a debrief," "here are my notes," or any pasted
  resume, interview note, or scorecard. Also trigger when the user is comparing two or
  more people for the same role. When in doubt, use this skill. A summary the manager
  skims costs nothing. A candidate lost to a slow write-up costs the search.
```

### The five ingredients

1. **What it does,** one sentence, starting with a verb, naming the output.
2. **When to use it,** one sentence naming the real situations, not categories.
3. **Trigger phrases,** quoted, in casual language, at least six, including sloppy and incomplete ones.
4. **An unprompted trigger,** the situation where it should fire although the user did not ask.
5. **"When in doubt, use this skill,"** plus one clause on why over-triggering is the cheaper mistake.

### How to generate trigger phrases

Ask: what would this person actually type at 4:45 on a Thursday? Not what a job description would call the task.

For every formal phrase, write the casual twin:

| Formal, low value | Casual, high value |
|---|---|
| Conduct a variance analysis | "these numbers look off" |
| Prepare a stakeholder communication | "what do I tell them" |
| Generate a candidate evaluation | "what did you think of her" |
| Draft parent correspondence | "I need to email his mom" |
| Perform a reconciliation review | "does this tie out" |

Include both columns. Include a phrase with no keywords at all, like "can you look at this," if the skill is one the user runs constantly.

### The width rule

Over-triggering costs a few seconds of a user's attention. Under-triggering costs the entire skill, plus the user's belief that skills work at all. When you cannot decide whether a phrase belongs, include it.

---

## Part 3: The opening

Two to four sentences under the title, before any rules. Not a summary of the file. A statement of the problem the skill exists to solve, written so the reader nods.

**Weak:**

> This skill helps users create month-end close reviews. It provides a structured framework for reviewing financial close packages and identifying issues.

Restates the title. Says nothing true or specific. Teaches nothing.

**Strong:**

> The close is done, the numbers balance, and everything still feels slightly wrong. Nine times out of ten it is the same handful of things: an accrual that did not reverse, a prepaid nobody amortized, a deposit sitting in the wrong month. This skill runs the same review a senior accountant runs on instinct, in the same order, every month.

Names the moment, the pattern, and the promise.

---

## Part 4: The #1 rule

A hard statement of what must come back on every run. Put it near the top, right after the opening.

**Weak:**

> This skill should provide helpful, well-structured output.

Nothing here can be violated, so nothing here does anything.

**Strong:**

> **Every run ends with a complete written summary, ready to send. No exceptions.**
>
> Not a list of what is missing. Not questions about the candidate. The finished write-up with a recommendation attached, even when the notes are thin. If a fact is missing, mark it in brackets and deliver anyway. Never end a response with a question instead of the summary.

Then list the situations where it still applies, because the model will look for the exception. Three to six bullets. "Even when the user only asked a narrow question." "Even when the input is incomplete." "Even when the user seems unsure."

This one section prevents the two most common skill failures: producing commentary instead of work, and stalling on missing information.

---

## Part 5: The framework

The body. The actual steps, checks, or standard. Numbered, named, and ordered.

**Weak:**

> Consider the candidate's experience, skills, and cultural fit. Evaluate against the role requirements and provide an assessment.

Three abstract nouns and a verb. Two people following this produce two unrelated documents.

**Strong:**

> Four sections, always in this order:
>
> **1. The verdict, in one line.** Advance, pass, or hold, with the single reason. This goes first because half the readers stop here.
> **2. The three things that matter for this role.** Named for this specific role, not generic competencies. Each one gets a rating and one piece of evidence from the interview, quoted where possible.
> **3. The risk.** The one thing that would make this hire go badly, stated plainly. Every candidate has one. If you cannot name it, you did not interview hard enough.
> **4. What to probe next.** Two questions for the next interviewer, written out.

Specific, ordered, and impossible to follow two different ways.

**How much detail.** Enough that someone who has never done the work could produce an acceptable result. If a step contains a judgment call, say how to make it. "Rate each as strong, adequate, or gap" beats "assess each area."

---

## Part 6: The output format

Short and blunt. Models default to preamble, so if you do not say what comes first, you get an introduction.

**Weak:**

> Present the information in a clear and organized manner.

**Strong:**

> ## Output format
>
> 1. The summary itself, in a code block, complete and ready to paste into email.
> 2. One line naming anything you assumed.
> 3. One question, only if the answer would change the verdict.
>
> Never write an introduction. Never restate the request. Never summarize at the end.

Always state: what comes first, what order the rest goes in, and what never appears.

---

## Part 7: The rules and the never-do list

Short, blunt, specific, and arguable. Group them if there are more than eight.

**Weak:**

> - Be professional
> - Be accurate
> - Consider the audience

Nobody disagrees with any of these, so none of them change the output.

**Strong:**

> - Never write more than one page. A hiring manager who scrolls does not read.
> - Never soften a concern into a strength. "Might need support ramping up" hides "does not have the skill."
> - Never use the words "great communicator," "team player," or "self-starter." Say what they did instead.
> - Always quote the candidate directly at least twice. Paraphrase reads as opinion, quotes read as evidence.
> - Never mention anything outside job performance: age, family, appearance, accent, where they live.

The last one is the kind of rule that only comes from an expert who has seen it go wrong. Those are the rules worth the most.

**The contradiction check.** Read every rule against every other rule and confirm they can all be satisfied at once. "Be comprehensive" and "keep it under 200 words" cannot. This is the second most common reason a skill misbehaves.

---

## Part 8: Examples

At least one, ideally two, in the main file. Complete, never truncated.

**Weak:**

> Example: A summary might include the candidate's background, their strengths, and a recommendation.

That is a description of an example, not an example.

**Strong:** the messy real input, then the full finished output, then one line on what the example is demonstrating. See `references/examples.md` for three complete builds in this shape.

If you have more than two good examples, move them to a reference file and keep the two best in the main file.

---

## Part 9: Reference files

Anything over a page that is only needed sometimes. They live in a `references` folder next to SKILL.md, and the main file names each one with a line saying when to load it.

Good candidates: long example sets, lookup tables, templates, style guides, edge case handling, checklists used only occasionally.

**Weak:** naming a reference file with no instruction about when to open it. It either gets ignored or gets loaded every time, and both are waste.

**Strong:**

> - `references/examples.md`: Six full write-ups across engineering, sales, and support roles. Load when the role is unusual or when the user asks to see the standard applied.

Do not create reference files for a short skill. A tight two-page skill with no references beats a thin one with four.

---

## The review checklist

Run this against any skill, yours or someone else's, in five minutes. Score each item pass or fail.

**Will it fire**

1. Does the description contain at least six quoted phrases in casual language?
2. Does it name at least one unprompted trigger?
3. Does it include "when in doubt, use this skill"?
4. Would it fire on a single casual sentence with none of the obvious keywords?
5. Does the name match the folder, and does it describe the work?

**Will it deliver**

6. Is there a hard #1 rule naming exactly what comes back every time?
7. Does that rule list the situations where it still applies?
8. Does the skill produce something, rather than reviewing or planning something?
9. Is there an explicit instruction on what to do when information is missing?
10. Is there an explicit instruction not to end with a question?

**Will it be good**

11. Is there at least one instruction a reasonable person could disagree with?
12. Are the vague adjectives replaced by numbers, prohibitions, or named examples?
13. Is the output format stated, including what comes first?
14. Is there at least one complete worked example?
15. Do any two rules contradict each other?
16. Would a new person on the team be able to do the work from this file alone?

**Housekeeping**

17. Does the frontmatter start on line one, with correct indentation under the `>`?
18. Is every reference file named in the main file with a line on when to load it?
19. Is it one skill, not two?
20. Is anything in the file specific to a single client, month, or project that will expire?

Fewer than sixteen passes means the skill needs another round. A failure anywhere in "Will it fire" means the rest of the score does not matter yet, because nothing else ever runs.
