# Drills

The drill is the unit of this skill. Everything else is scaffolding around it.

A drill is not a topic with a verb attached. It is a task on real material, inside a time box, with a pass condition the learner can read without you, and a named likely failure. If any of those five parts is missing, it is not a drill and it will not produce ability.

This file holds the patterns. They are subject agnostic on purpose. Pick the pattern that fits the move being taught, then fill it with the learner's real material.

---

## The five parts, restated

| Part | The test | Failure if missing |
|---|---|---|
| Task | Starts with a verb, one sentence | They negotiate with the task instead of doing it |
| Material | Real, specific, already in front of them | They go looking, and looking becomes the session |
| Time box | An actual number of minutes | The drill expands until it fails |
| Pass condition | They can grade it alone | They ask you if it was right, which teaches dependence |
| Likely failure | Named before they hit it | They conclude they are bad at this and stop |

Write all five. Every time. Even in a one line mid session reply.

---

## The twenty drill patterns

### Production patterns
These produce a result. Use them early, because a result in the first fifteen minutes is what keeps a person in the session.

**1. The smallest complete thing.**
Have them produce the entire artifact at the smallest possible scale. Not a piece of a budget: a whole budget with four lines. Not a section of a talk: a complete ninety second talk with an open, a point, and a close. A whole small thing teaches the shape. A large piece of a thing teaches nothing about the shape.
Time box: 10 to 15 minutes. Pass: it is complete, however crude.

**2. The copy and swap.**
Give them a correct finished example. They rebuild it exactly, then swap in their own data or content, one element at a time. The rebuild teaches the mechanics with no decisions. The swap forces every decision, one at a time, on a scaffold that already works.
Time box: 8 minutes rebuild, 8 minutes swap. Pass: their version does what the example did.

**3. The blank page start.**
Same output as a previous drill, from nothing. No example visible, no notes. This is the drill that reveals whether the earlier drill produced ability or just compliance.
Time box: same as the original drill. Pass: they finish without opening anything.

**4. The real stakes rep.**
The drill is a thing they actually have to do anyway, done now under supervision instead of later alone. The email they owe. The chart they have to file. The number their boss asked for. Motivation is free and the artifact is not thrown away.
Pass: it is good enough to actually send, file, or use.

**5. The volume set.**
Ten small reps of one move, fast, back to back. Not one careful rep. Automaticity comes from count, and the move you want automatic is usually small enough that ten reps takes six minutes.
Time box: 6 to 10 minutes. Pass: the last three were faster than the first three.

### Diagnostic patterns
These find the gap. Use them mid session and before the proof of function.

**6. The broken version.**
Hand them something that is wrong and let them find it. Do not say how many errors. Debugging teaches structure faster than building does, because a person cannot find a break in a system they do not understand.
Time box: 5 minutes. Pass: they found it and can say why it broke.

**7. The closed book test.**
Everything closed. Notes away, tabs closed, example gone. Do the move. The gap between how it feels and what comes out is the most useful thing you will show them all session.
Time box: short, 3 to 5 minutes. Pass: they produced it without opening anything. Run this any time they say "I have got it."

**8. The explain it back.**
They explain the move to an imagined person who has never seen it, in four sentences, without jargon. Muddled explanation means muddled understanding, reliably. This is the one form of talking that is worth session time.
Time box: 2 minutes. Pass: no jargon, four sentences or fewer, and it would actually work as instructions.

**9. The predict then check.**
Before they run it, they say out loud what the result will be. Then they run it. A wrong prediction is worth more than a correct result, because it locates the exact false belief.
Time box: 30 seconds plus the run. Pass: prediction matched, or they can name why it did not.

**10. The novel case.**
A case they have not seen, slightly outside the drilled examples. Transfer is the whole point of learning, and a person who can only do the practiced version is not functional.
Time box: 8 minutes. Pass: they got there, even slowly, without asking what to do.

### Pressure patterns
These convert a thing they can do into a thing they can do when it counts. Use them in the second half.

**11. The half clock.**
The same drill they just passed, in half the time. Speed pressure strips out the parts they were doing by careful reasoning and forces the parts they have actually internalized.
Pass: finished, even if messier.

**12. The interruption.**
Start the drill, interrupt them with an unrelated question thirty seconds in, then have them resume. Real work is interrupted work. A skill that only survives uninterrupted focus is not usable in a job.
Pass: they resumed at the right place.

**13. The messy input.**
The same task with bad material: inconsistent data, a rambling source, a bad recording, a difficult person. Clean practice material is the biggest lie in training.
Pass: they handled the mess without starting over.

**14. The no tools rep.**
Remove the crutch: the template, the cheat sheet, the autocomplete, the notes, the script. Whatever they lean on hardest, remove exactly that.
Pass: they finished without it, or they can name precisely what the crutch was doing for them.

**15. The audience rep.**
Do it in front of someone, or recorded. Performance pressure changes what a person can access. Anything that has to happen in front of humans must be practiced in front of humans, or at least a camera.
Pass: they got through it without stopping to restart.

### Consolidation patterns
These make it stick past the session. Use them at the end and in multi day plans.

**16. The one line log.**
After each drill, one line: what broke, and the fix. Not notes. Not a summary. One line. This is the only note taking allowed in this skill, and it is worth more than pages.
Time box: 30 seconds.

**17. The next day cold start.**
Day two opens by doing yesterday's proof of function again, cold, before any review. Whatever fell out overnight is the real gap, and the review afterward lands on evidence instead of guessing.
Pass: within reach of yesterday's result.

**18. The teach the sequence.**
They write the five steps of the core move from memory, in order, as instructions for someone else. Then they follow their own instructions on a new case. Gaps in the instructions are gaps in the skill, and this drill exposes them without you having to.
Time box: 5 minutes.

**19. The failure inventory.**
They list the three ways this move goes wrong and what each one looks like when it happens. Knowing the failure signature is most of what separates a functional person from a trained one.
Time box: 4 minutes.

**20. The escalating constraint chain.**
The same drill on consecutive days, one new constraint each day. Day one: do it. Day two: do it in half the time. Day three: do it with messy input. Day four: do it in front of someone. The move gets harder while the material stays the same, which is the opposite of how courses do it and the reason this works.

---

## Escalation ladders

Never run the same drill twice at the same difficulty. Escalate along one axis at a time. Changing two axes at once produces a failure you cannot diagnose.

**The five axes:**

1. **Support.** Full example visible, then a partial hint, then nothing.
2. **Time.** Generous, then tight, then uncomfortable.
3. **Material quality.** Clean, then realistic, then deliberately bad.
4. **Scope.** One element, then a few, then the whole real thing.
5. **Stakes.** Practice, then a thing that gets used, then a thing another person sees.

A standard three rep ladder for one move:

- **Rep 1:** example visible, generous time, clean material, small scope. Goal: understand the shape.
- **Rep 2:** example gone, normal time, realistic material, fuller scope. Goal: do it alone.
- **Rep 3:** nothing visible, tight time, messy material, real stakes. Goal: prove it holds up.

If rep 2 fails, do not go to rep 3. Repeat rep 2 with the one specific error corrected. Moving on after a failure is how a session produces a person who believes they learned something.

---

## Reading the learner mid session

| What they do | What it means | What you do |
|---|---|---|
| Asks for another example | About to hit the hard part, avoiding it | Refuse once. "Try it wrong first, then I will show you." |
| Says "that makes sense" | Recognition, not ability | Closed book test, immediately |
| Produces it perfectly and fast | The drill was too easy | Escalate two axes at once, just this time |
| Freezes, stares, does not start | The drill has too many unlearned moves in it | Cut it into a smaller one. It is your fault, not theirs. |
| Gets it wrong in the same way twice | A false belief, not a missing fact | Find the belief. Predict then check will surface it. |
| Wants to take notes | Substituting transcription for practice | One line log only, and only after the drill |
| Asks an interesting off topic question | Usually avoidance | One sentence answer, then back to the drill |
| Says "I am not good at this" | Almost always at the exact point where learning happens | Name it plainly, shrink the drill, get a win in five minutes |

---

## Building the proof of function

The proof is one drill, at the end, that tests the functional sentence directly.

**Build it in this order:**

1. Read the functional sentence back. The proof is that sentence, performed.
2. Check that it requires every LEARN FIRST move at least once. If a move is not needed, either the move does not belong in the core or the proof is too small.
3. Shrink it until it fits one sitting. A proof they will not attempt is worth nothing. Smaller and completed beats bigger and abandoned, every time.
4. Write the pass criterion as something they can observe with no expert present. A number that reconciles. A person who understood. A system that accepted the entry. A recording they can watch.
5. Name the most likely failure point and the fix, in one line, before they start.

**What disqualifies a proof:**

- It could appear in a textbook. It has to come from their material and their job.
- It requires something they do not have access to today.
- It has no observable pass condition, so they finish and still do not know.
- It takes more than one sitting, so it becomes a project and projects get abandoned.
- It only tests one of the core moves.

**Three examples of the shape:**

| Functional sentence | Proof of function | Pass criterion |
|---|---|---|
| Read her division P&L and name what moved | Do it on the actual current month, write the three lines and one sentence each on why | The three she names match the three largest variances, and a finance person would not correct the sentences |
| Chart a full encounter in the new system | Chart the next real patient encounter end to end | It saves and closes with no supervisor override and no missing required fields |
| Run a hiring interview | Run a full forty minute interview with a real candidate | A written hire or no hire call with two pieces of evidence for it, made within ten minutes of the interview ending |

---

## Time boxes that work

These are tested defaults. Adjust for the subject, not for the learner's comfort.

| Drill type | Box |
|---|---|
| Volume set of one small move | 6 to 10 minutes |
| Build the smallest complete thing | 10 to 15 minutes |
| Closed book test | 3 to 5 minutes |
| Explain it back | 2 minutes |
| Find the break | 5 minutes |
| Novel case | 8 minutes |
| Proof of function | 20 to 40 minutes |
| One line log | 30 seconds |

A drill over twenty minutes is usually two drills. Split it. Long drills hide which part failed.
