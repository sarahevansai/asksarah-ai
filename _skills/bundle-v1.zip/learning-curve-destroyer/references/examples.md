# Worked Examples

Six runs, shown in full output format. Four are complete plans in different fields. Two show the shorter modes: diagnosing a stall and compressing a course.

Read these for the standard, not for the content. The content is always rebuilt from the learner's actual job and material.

---

## Example 1: A manager who has to read a P&L before a board meeting

**What they said:** "I got promoted into a role where I present to the board in nine days and I have never read a P&L in my life. I have maybe three hours total between now and then."

**What was assumed:** nothing. Budget and deadline were both given.

---

# Functional in reading a P&L: your division, in front of a board

**Budget:** 3 hours across three sittings · **By the end you will be able to:** open your division's P&L, name the three lines that moved most this quarter, say in one sentence why each moved, and answer a follow up question without saying you will get back to them.

**Assuming:** you are presenting your own division's numbers, not the whole company's, and finance produces the statement for you.

## Learn first

1. **The three block read.** Revenue, cost of revenue, operating expense. Every P&L is those three blocks and a subtraction. Once you see the blocks you stop reading it as a wall of numbers.
2. **The variance reflex.** Never read a number alone. Read it against the prior period and against plan. A number by itself has no meaning and cannot be discussed.
3. **The three sentence why.** For any line that moved, one sentence: what moved, how much, and the operational cause. This is the entire skill of presenting financials.
4. **The one question defense.** Know the two follow up questions your biggest variance invites, and have the answer ready. Boards ask about the biggest number that changed. Every time.

## Ignore completely

- **The balance sheet and the cash flow statement.** You are not presenting them. They are a trap because they are conceptually harder and they will eat your three hours. If someone asks, "that sits with finance" is a complete answer from a division head.
- **Accrual versus cash accounting theory.** It feels foundational. It changes nothing about what you say next week. It only matters when you are the one deciding how something gets booked, and you are not.
- **Ratio analysis, EBITDA multiples, and anything with the word margin stacked in front of it.** These are analyst tools. A division head who names their variances and their causes outperforms one who quotes a ratio and cannot explain the operations behind it.
- **Learning to build a P&L.** You are reading, not producing. Building is a different skill and it is not on the clock.

## Defer until

- **Budget versus forecast versus actual, as three separate concepts.** Come back once you have presented twice and someone asks you to reforecast.
- **Reading other divisions' statements.** Once your own is automatic, this takes twenty minutes.
- **Cost allocation and how overhead lands on you.** Learn this the first time a number appears on your statement that you did not spend.

## The plan

**Sitting 1: 60 minutes. Learn the shape.**
Open your last full quarter's statement and your prior quarter's. Do drills 1 through 3 below. Artifact: a marked up printout with the three blocks circled and the five biggest variances highlighted.

**Sitting 2: 60 minutes. Build the story.**
Write the three sentence why for each of your top five variances. Send two of them to your finance contact and ask only "is my cause right." Artifact: five written explanations, two of them verified.

**Sitting 3: 60 minutes. Proof of function.**
Present your current quarter out loud, recorded, to a stopwatch. Then answer the three hardest follow ups you can invent. Artifact: a recording you have watched.

---

## Drill 1: the three block cut

**Task:** print your last full quarter P&L and draw a line across the page at exactly two places: where revenue ends and where cost of revenue ends.

**Material:** your division's most recent full quarter statement, printed.

**Time box:** 6 minutes.

**Pass:** every line item on the page falls into one of three blocks, and you can say what block the bottom line is derived from.

**Likely failure:** you will find lines that seem to belong to two blocks, usually anything with the word "other" in it. Put them in operating expense and move on. Getting this exactly right is an accounting question, not a reading question, and it does not change the story you tell.

---

## Proof of function

Present your current quarter, out loud, in four minutes, recorded on your phone, with the statement in front of you. Cover: total revenue and its direction, the three lines that moved most with one sentence of cause each, and one thing you are watching next quarter.

**Pass criterion:** watch it back. You never say "I think," you never say "I would have to check" more than once, and every number you say is on the page in front of you.

**Most likely failure:** you will describe what the number is instead of why it moved. If a sentence has no operational cause in it, it is a reading, not an explanation. Rerecord that section.

---

**Coaching note:** you will be tempted to read about financial statements to feel prepared. That will not work here, because your problem is not knowledge, it is that you have never had your own numbers in front of you with a reason to care. Every minute in this plan is on your actual statement. Keep it that way, including if you get nervous and go looking for a course.

**One question:** does the board see the statement itself, or only your slides? If they see the statement, I would add a fifteen minute drill on the two lines you cannot explain but they can see.

---

## Example 2: A nurse learning a new charting system in one shift

**What they said:** "We switched charting systems and I am on the floor tomorrow. I get about forty minutes with it before my shift starts."

---

# Functional in the new charting system: one shift, no supervisor overrides

**Budget:** 40 minutes before shift · **By the end you will be able to:** complete a full encounter entry, from open to signed, without a supervisor unlocking anything for you.

**Assuming:** you already know what belongs in a chart. This is a system problem, not a clinical one, and the plan treats it that way.

## Learn first

1. **The spine path.** The exact click sequence from patient open to signed and closed, for the single most common encounter type you handle. One path, memorized cold.
2. **The required field map.** Which fields block a save. Every system has five or six and they are the entire reason people get stuck at the end of a shift with fourteen open charts.
3. **The undo route.** How to correct an entry after saving, and what it looks like when you cannot. Knowing this in advance is the difference between one slow chart and a supervisor call.
4. **The find move.** How to pull up a prior encounter and a prior result. You will need this within the first hour and you will not have time to hunt.

## Ignore completely

- **Every module you do not touch.** Scheduling, billing codes, reporting, the admin views. The training deck covers them because it was built for the whole hospital. You are one role for one shift.
- **Customization: layouts, favorites, saved templates, shortcut keys.** These are how you get fast, and you are not trying to get fast today. You are trying to not get blocked. Customizing before you know the spine path means customizing the wrong things.
- **The full documentation and any recorded webinar over ten minutes.** You have forty minutes. A thirty minute video leaves you ten minutes of practice, which is the wrong ratio by a factor of four.
- **Learning the terminology differences between the old and new system.** You will absorb these by contact in the first two hours. Studying them costs time and teaches nothing your hands will not learn faster.

## Defer until

- **Templates and favorites.** After two shifts, when you know which four things you type constantly.
- **The second and third encounter types.** Learn each one the first time you hit it, live, using the spine path as the map.
- **Corrections workflow beyond the simple undo.** The first time you need a real amendment, ask someone. It is rare and it is worth doing right.

## The plan

**0 to 10 min:** Drill 1, the spine path, three times.
**10 to 20 min:** the required field map. Deliberately try to save an incomplete chart and write down every field it stops you on.
**20 to 30 min:** the find move and the undo route, twice each.
**30 to 40 min:** proof of function, cold, on a test patient.

---

## Drill 1: the spine path, three reps

**Task:** open a test patient, complete a routine encounter, sign it, and close it. Then do it twice more. On the third rep, do it without looking at any menu label before you click.

**Material:** the training environment with a test patient. If there is no training environment, use the shortest real encounter you have and slow down.

**Time box:** 10 minutes for all three reps.

**Pass:** the third rep took less than half the time of the first, and you did not hover to read a menu.

**Likely failure:** you will get stopped at signing by a field you did not fill at the top. That is not an error, that is the required field map introducing itself. Write the field down and start rep two.

---

## Proof of function

Cold, with nothing open, no notes, no one watching: complete one full encounter end to end and sign it.

**Pass criterion:** it saves and closes with no override, no missing field warning, and no one else touching your screen.

**Most likely failure:** a required field buried in a section you scroll past. If it stops you, the fix is not to study the system, it is to add that field to the top of your spine path and rerun the whole path once.

---

**Coaching note:** the instinct with a new system is to explore it, so you feel oriented. Exploring is the slowest possible way to learn software you have to use tomorrow. One path, memorized cold, then branch out from it as real cases force you to. Orientation follows use, it does not precede it.

---

## Example 3: Enough Spanish for a two week job assignment

**What they said:** "Two weeks in Mexico City for work starting in three weeks. Work is in English. I know almost nothing. I can give it maybe thirty minutes a day."

---

# Functional in Spanish: two weeks in Mexico City, work in English

**Budget:** 30 minutes a day for 21 days, about 10 hours · **By the end you will be able to:** handle a taxi, a restaurant, a shop, a hotel front desk, and a "sorry, do you speak English" moment without switching to English first and without freezing.

**Assuming:** you want to function socially and get around, not to conduct business in Spanish. If the work itself is in Spanish, this plan is wrong and I would rebuild it entirely.

## Learn first

1. **The survival hundred.** About one hundred words and twelve phrases that cover ordering, directions, transactions, and politeness. Not the first hundred words in a course, the hundred you will actually use in those five situations.
2. **Present tense only, three verb forms.** I want, I need, is there. Yo quiero, yo necesito, hay. These three carry an astonishing share of everything a visitor says.
3. **The rescue phrases.** How to say slower please, I do not understand, how do you say, and what is that. These are the phrases that keep a conversation alive when it goes wrong, which it will, constantly. Most beginners learn how to start a conversation and nothing about how to survive one.
4. **Ear training on numbers.** Prices, addresses, times. You will understand almost nothing else on day one and you will need numbers within an hour of landing.

## Ignore completely

- **All past and future tense.** They are most of any beginner course and they are worth close to nothing for a two week trip. You can say "yesterday" and use present tense and every human will understand you.
- **Grammatical gender as a study subject.** You will get it wrong. Nobody will misunderstand you. It is graded heavily in classes because it is easy to grade, which is exactly why courses front-load it.
- **Vocabulary outside your five situations.** Animals, weather, family members, colors, the classroom words. Course units are built around themes because themes are easy to organize, not because you need them.
- **Perfecting pronunciation before speaking.** An accent is not a barrier. Silence is. People who wait until they sound good never start.
- **Reading and writing.** You are not writing anything in Spanish for two weeks. Every minute spent on spelling is a minute not spent on the ear, which is where your real bottleneck is.

## Defer until

- **Past tense.** Once you have had ten real conversations, it starts to be the thing you are actually missing.
- **Formal versus informal address.** Use the formal form with everyone for two weeks. It is never wrong. Learn the distinction after the trip.
- **Listening to native speed media.** Comes alive once your survival hundred is automatic, not before, when it is just noise.

## The plan

**Days 1 to 5:** survival hundred, twenty words a day, drilled by speaking, never by reading a list. Plus the three verb forms from day one.
**Days 6 to 12:** the rescue phrases, plus daily two minute out loud monologues on one of the five situations. Numbers drill every day, five minutes.
**Days 13 to 18:** live reps. One real interaction per day with a real Spanish speaker, in person or on a language exchange app. This is the block that matters most and the one you will want to skip.
**Days 19 to 21:** proof of function, plus two repeats of it under harder conditions.

---

## Drill 1: the taxi, out loud, five times

**Task:** say out loud, standing up, the complete arc of getting into a taxi and arriving: greet, give the destination, ask roughly how long, ask the price, thank and leave. Then say it four more times, changing the destination each time.

**Material:** none. This is the point. If a drill needs material, you will do it later and later means never.

**Time box:** 6 minutes.

**Pass:** the fifth run has no English in it and no pauses longer than two seconds.

**Likely failure:** you will stall on the destination sentence because you are trying to build a grammatically complete request. Do not. "A este dirección, por favor" plus showing your phone is a complete and correct interaction. Learners lose more time to unnecessary sentence construction than to any missing vocabulary.

---

## Proof of function

Twenty minutes on a language exchange app, or with any Spanish speaker who will sit with you, where you do not switch to English once. Cover three of your five situations, roleplayed.

**Pass criterion:** they understood you every time without you repeating in English, and you used at least two rescue phrases rather than freezing.

**Most likely failure:** the first time you do not understand a reply, you will apologize in English and the whole thing collapses. That moment is exactly what the rescue phrases exist for. Practice "más despacio, por favor" until it comes out before the panic does.

---

**Coaching note:** the deepest habit to break here is silent study. Reading Spanish, or tapping through an app, produces recognition, and recognition feels like learning right up until someone speaks to you. Every drill in this plan is out loud, including the ones done alone in your kitchen. If a day passes with no speaking in it, that day produced almost nothing.

---

## Example 4: A founder learning to run a hiring interview

**What they said:** "I have to interview five people for our first real hire this week. I have never interviewed anyone. I have tonight."

---

# Functional in hiring interviews: your first five candidates, this week

**Budget:** one evening, about 2 hours · **By the end you will be able to:** run a forty minute interview that produces a hire or no hire decision you can defend in one paragraph, with evidence, not a feeling.

**Assuming:** you are hiring for a role where you understand the work, and you are the final decision maker.

## Learn first

1. **The one question standard.** Decide, before any interview, the single thing this hire must be able to do. Write it as a sentence. Every question in the interview exists to gather evidence on that sentence. Interviews fail because nobody wrote the sentence.
2. **The past behavior move.** Ask what they actually did, not what they would do. "Tell me about the last time you" beats "how would you handle" every time, because hypotheticals measure imagination and articulacy, which are not the job.
3. **The follow the thread move.** Never accept the first answer. Three follow ups on one real story tells you more than twelve questions. What was your specific part, what went wrong, what would you do differently. This is the whole skill and it is the one thing beginners never do.
4. **The evidence note.** During the interview, write only what they said and did, never your impression. Impressions are how five interviews blur into one preference for whoever was most likeable.

## Ignore completely

- **Brain teasers, puzzles, and clever questions.** They measure composure under a weird social situation. They have no relationship to the work and they cost you goodwill with the candidates you most want.
- **Culture fit as a judgment category.** As commonly used, it means "did I enjoy talking to them," which is the single largest source of bad hires. If there is a real behavioral requirement, name it as a specific behavior and ask about it directly.
- **Structured scorecard systems with weighted rubrics.** Real, useful at scale, and completely wrong for tonight. You have two hours and five candidates. Weighting a rubric is a distraction from the one thing that will change your outcome, which is asking a real follow up.
- **Selling the company for the first twenty minutes.** Do it at the end, for the candidates you want. Selling first anchors you to liking them and burns the time you need for evidence.

## Defer until

- **A consistent interview loop with multiple interviewers.** Once you are hiring a third person.
- **Work sample tests and take home exercises.** These are stronger than interviews and worth building next, not tonight.
- **Reference checks done properly.** Do them, but the technique is a separate skill. Tonight is the room.

## The plan

**0 to 20 min:** write your one question standard and the four pieces of evidence that would satisfy it. Drill 1.
**20 to 50 min:** write six past behavior questions against that standard, then cut to four. Fewer questions with follow ups beats more questions.
**50 to 80 min:** practice the follow the thread move out loud, three rounds, against a story you invent for a fictional candidate.
**80 to 120 min:** proof of function.

---

## Drill 1: the one question standard

**Task:** write, in one sentence, the thing this person must be able to do for this hire to be a success in six months. Then write four specific pieces of evidence that would convince you they can.

**Material:** the role you are hiring for. Not a job description. If a job description exists, close it, because it was written to attract, not to evaluate.

**Time box:** 12 minutes.

**Pass:** the sentence names an action and a context, and none of your four evidence items is a personality trait. "Is a self starter" fails. "Has shipped something end to end with no manager checking in" passes.

**Likely failure:** you will write three things instead of one, because everything feels necessary. Pick the one that would make the hire a failure if it were missing. The other two become nice to have and you stop weighting them equally with the one that matters.

---

## Proof of function

Run a full forty minute interview with a real candidate, or with a friend playing a candidate if the first real one is not until tomorrow. Use your four questions. Follow at least two answers with three follow ups each. Take evidence notes only.

Within ten minutes of finishing, write your hire or no hire call in one paragraph, citing two specific things they said.

**Pass criterion:** your paragraph contains two direct pieces of evidence and zero sentences about how the conversation felt. If you cannot write it without using the word "seemed," you did not gather evidence, you gathered impressions.

**Most likely failure:** you will accept a good sounding first answer and move to the next question, because following up feels rude. It is not rude, and it is the entire difference between an interview and a conversation. If you notice you have finished all four questions in twenty minutes, that is the symptom.

---

**Coaching note:** the trap in this skill is that interviewing feels natural, because talking to people is natural. That familiarity is exactly why most people never get better at it. Assume none of your instincts here transfer, and follow the four questions and the follow ups even when the conversation is going well. Especially then.

---

## Example 5: Mode 3, diagnosing a stall

**What they said:** "I have been trying to learn to play guitar for eight months. I practice most days. I still cannot play a single song all the way through."

**Response, in full:**

Eight months of practice with no complete song means you are practicing pieces, not songs. Almost certainly you have been running through chord changes, scales, and the first sixteen bars of several songs, and you have never once played anything start to finish. That is not a practice volume problem, it is a scope problem, and more months of the same will not fix it.

Two of the five anti-patterns are running here: starting at the beginning, because every song starts at the beginning and that is where all your reps have gone, and mistaking familiarity for ability, because you can play any of those openings and cannot finish anything.

**Drill, right now, twelve minutes:** pick the easiest song you already half know. Play it all the way through, badly, without stopping, including the parts you cannot play. Where you cannot play the chord, mute the strings and keep the rhythm. Do not restart for any reason. Do this three times.

**Pass:** three complete run throughs, no restarts, however bad they were.

**Likely failure:** you will restart at the first mistake. That instinct is the entire cause of your eight months. Restarting on error is why your first sixteen bars are excellent and your song count is zero.

**Coaching note:** for the next two weeks, every practice session ends with one complete unbroken run of something. Broken practice makes broken players. The unbroken run is the only rep that teaches you to recover, and recovering is most of what playing a song actually is.

---

## Example 6: Mode 4, compressing a course

**What they said:** "My company bought me a forty hour project management certification course. I have eight hours and I run projects starting next month."

**Response, abbreviated to the structure:**

Forty hours to eight is a ninety percent cut and it is the right call. The certification is optimized for an exam. You are optimizing for running a project in four weeks. Those are different goals and the course does not know that.

**Carries the ability, do these:** the module on scoping and requirements, the module on dependency mapping, and the section on status reporting. Roughly six of the forty hours. These three are what you will actually do every week.

**Skip entirely:** the history of project management methodologies, the comparison chapters between frameworks, the vocabulary and acronym units, the earned value calculation module, and every practice exam. Combined, about twenty two hours. The exam material is heavy on definitions because definitions are what a multiple choice test can measure. None of it changes what you do on a Monday.

**Keep for reference, never read front to back:** the risk register templates and the stakeholder analysis chapter. Look at them the week you need them, which will be weeks two and three.

**Now the part the course cannot do.** Reading those six hours still leaves you with knowledge and no ability. Here is the eight hour plan that converts it, with the reading cut to three hours and five hours in drills on your actual upcoming project.

[Plan and Drill 1 follow in standard format.]

**Coaching note:** you skipped thirty two hours of content and you will feel underprepared for about a week. That feeling is caused by the missing certificate, not by missing ability. The person who ran one real project badly and fixed it is more useful in month two than the person who scored well on the exam, and both of you will be in the same meeting.
