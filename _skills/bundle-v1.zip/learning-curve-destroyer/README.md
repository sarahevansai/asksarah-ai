# Learning Curve Destroyer

A Claude skill that turns any "I need to learn this fast" into a time-boxed plan you can start in the next sixty seconds, with a drill written out and a test at the end that proves you can actually do the thing.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most learning advice optimizes for coverage. This one optimizes for capability by a deadline.

Tell Claude what you need to learn and how long you have, and it will:

1. Define what functional means for your specific situation, as a testable sentence
2. Cut the subject to the small core that produces most of the working ability, and tell you exactly what to skip
3. Hand you the block by block plan against your actual clock
4. Write out the first drill, ready to start, on your real material
5. Set the proof of function at the end: the thing you will do, once, that tests whether it worked

**You always get a plan and a drill back.** No curriculum overviews. No reading lists. No "here are some resources to explore." If you did not say how much time you have, it assumes a sensible default, tells you what it assumed in one line, and starts anyway.

It works on anything: spreadsheets, a new software system at work, a language, public speaking, reading financials, interviewing, negotiation, a machine, a certification, a role you just got handed with no warning.

Three things it does that a course never will:

**It tells you what to skip.** Every plan includes a specific ignore list with reasons. Not "skip the advanced stuff," but "skip past tense entirely, it is most of any beginner course and it is worth nothing for a two week trip." This is the part no curriculum can give you, because a curriculum is paid to cover everything.

**It is honest about the clock.** If two hours cannot make you able to do what you asked, it says so plainly, names the narrower thing that does fit, and builds to that instead. It will not pad a plan to flatter a budget, and it will not add topics just because you have a whole weekend. More time means more reps, not more material.

**It tests you.** Every plan ends with a proof of function: a complete real thing you do once, with a pass criterion you can read without an expert present. Because feeling ready and being able are different, and only one of them shows up on Monday.

## The Function Five

Every plan passes five gates before you see it, and the score comes back with the plan.

1. **Function defined**: a specific, observable thing you will be able to DO, written before any content is picked
2. **Cut to the core**: three to five moves, each justified against your actual job, everything else named and cut
3. **Sequenced by unblock**: ordered by what lets you produce something next, never by how a textbook would build it
4. **Taught by drill**: every block is a task on real material with a time box, not an explanation
5. **Proof of function**: a demonstrable test at the end, with a pass criterion you can grade yourself

## The five habits it kills

Named on sight, with the fix attached:

- **Tutorial hopping**: watching a second explanation of something you have never attempted
- **Note taking instead of doing**: transcription is not learning
- **Theory before use**: the why lands fifteen minutes after the first thing breaks, not before
- **Starting at the beginning**: chapter one is almost never the fastest route to a first result
- **Mistaking familiarity for ability**: the feeling of "I could do that" is recognition, and recognition is not retrieval

## Five modes

- **Build the plan**: you name a skill and a deadline, you get the full time-boxed plan
- **Run the next drill**: you report what happened, it corrects the specific error and escalates
- **Diagnose the stall**: you have been at this for months with nothing to show, it finds the cause and hands you a win in under ten minutes
- **Compress a course**: you have a forty hour course and eight hours, it tells you what carries the ability and what to skip, then converts the rest into drills
- **Test whether you are functional**: closed book, under constraint, on a case you have not seen, with a plain verdict

## Try it

Once installed, say any of these:

- "I have two hours to learn enough Excel to build a budget"
- "Teach me to read a P&L before Thursday"
- "I keep watching tutorials and I still cannot do anything"
- "Crash course in running a hiring interview, I have tonight"
- "Cut this forty hour course down to what actually matters"
- "Am I any good at this yet? Test me."
- "I start Monday and I have no idea what I am doing"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `learning-curve-destroyer.zip` in your skills settings. Claude loads it automatically whenever a request needs it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/learning-curve-destroyer/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "I have ninety minutes to get functional at [anything]." You should get a plan with a time-boxed block structure, an ignore list with reasons, Drill 1 written out, and a proof of function at the end.

## What is in the package

```
learning-curve-destroyer/
├── SKILL.md                The Function Five, the modes, the anti-patterns, output format
├── README.md               This file
├── LICENSE
└── references/
    ├── drills.md           20 drill patterns, escalation ladders, how to build a proof of function
    └── examples.md         6 full worked runs across different fields
```

## Notes

It will not hand you a topic list dressed up as a plan. Every block says what you open, what you do, and what you produce. If a block has no verb and no artifact in it, it is not finished, and the skill is built to catch that.

It will ask at most one question, and only after the plan is already in front of you. Nothing is ever held back waiting on an answer.

For subjects that change quarterly, it checks what is current before telling you what to skip. An authoritative ignore list built on stale knowledge is worse than no list, because you would act on it.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
