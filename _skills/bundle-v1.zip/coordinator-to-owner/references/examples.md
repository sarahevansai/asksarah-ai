# Before and After

Six full transformations, each from a different industry and role, with the shift named. Use these to calibrate what a rewrite should look like, and to show a user the standard applied rather than described.

Notice what does not change in any of them: the facts, the effort, the person. Only the organizing principle changes, from the task to the result.

---

## Example 1: Operations lead at a distribution warehouse

**Shift 1: from reporting activity to reporting outcomes**

**Before**

> Hi Marcus, wanted to give you an update on this week. I have been working on the inbound backlog and spent most of Tuesday and Wednesday going through the aging pallets. I also reached out to the carrier about the missed pickups and had a call with them Thursday. I got the new receiving checklist printed and posted at both docks and walked the second shift through it. Still trying to sort out the label printer issue, IT has not gotten back to me. Let me know if you need anything else from me.

Everything in that message is real work. None of it tells Marcus the state of anything.

**After**

> Inbound backlog is clear as of Thursday. We were at 340 aging pallets Monday, we are at zero.
>
> **Carrier:** the missed pickups were a routing error on their side. They have corrected it and we have had four on-time pickups since Thursday. I am watching it through next week before I call it fixed.
>
> **Receiving:** new checklist is live at both docks and second shift is trained on it. First full week of data next Friday.
>
> **Open:** the dock 2 label printer is still down. IT has had the ticket eight days. It costs us about twenty minutes a shift in manual labeling. If it is not resolved by Wednesday I am going to buy a replacement out of the ops budget rather than keep waiting. Flagging so that is not a surprise.

**Coaching note:** The before version made Marcus do the arithmetic. He had to read six activities and work out for himself whether the week was good. The after version tells him in the first line and then gives him only the one thing that needs him. Every update should be forwardable by your manager without a single word of interpretation added. If they would have to write "so basically we are fine," you have not finished the update.

---

## Example 2: Laboratory coordinator at a research institute

**Shift 2: from asking questions to bringing decisions**

**Before**

> Hi Dr. Okafor, quick question. The reagent order for the [assay] work has not arrived and the supplier is now saying it will be another two weeks because of a manufacturing delay on their end. I know we have the sample runs scheduled for the 14th. What do you want me to do?

**After**

> Dr. Okafor, the reagent order slipped two weeks: supplier manufacturing delay, new ETA is the 27th. The sample runs are scheduled for the 14th. Two ways to handle it.
>
> **Option A:** run on the 14th with the alternate reagent from [second supplier]. In stock, arrives Thursday, costs $340 more for the batch. It is the same grade but a different lot, so we would need a validation run first. I have the bench time for that on Monday.
>
> **Option B:** push the runs to the 28th. No extra cost, but it puts the analysis inside the week you are traveling, and it moves the interim report past the [funder] check-in on the 30th.
>
> **I recommend A.** The $340 is small against missing the check-in date, and the validation run gives us the comparison data anyway.
>
> Unless you tell me otherwise by end of day tomorrow, I will place the order with [second supplier] Thursday and book the validation for Monday. Nothing there is irreversible until Thursday afternoon.

**Coaching note:** The before version was a well-written, polite request for someone else to do the thinking. The after version does not ask for more of Dr. Okafor's attention, it asks for less: she can approve by saying nothing. This is the single change that most reliably moves a person from being managed to being trusted, and it does not require anyone's permission to start. The default line at the end is the piece people leave off, and it is what turns a busy person's silence into progress instead of into your delay.

---

## Example 3: Assistant manager at a retail store

**Shift 3: from owning your slice to owning the whole result**

**Before**

> Hey, just so you know, I sent the seasonal display plan over to the regional visual team like you asked. That is with them now. I also submitted the extra staffing request for the weekend through the portal. Should be all set on my end.

"On my end" is the tell. Two things left the building and nobody is watching either one.

**After**

> Seasonal display and weekend staffing are both moving. Here is where each one actually stands.
>
> **Display:** plan went to regional visual Tuesday. They confirmed receipt and said they will come back with fixture availability by Friday. If I do not have it Friday I will call [contact] directly, because we need eight working days to build and the set date is the 22nd. That gives us until the 12th before it is a real problem.
>
> **Staffing:** request is in the portal for two extra associates Saturday and Sunday. Portal requests have taken between three and nine days lately, so I have also asked [name] and [name] directly whether they can pick up the shifts if the approval is slow. Both said yes. Worst case we cover it and I sort the paperwork after.
>
> I will confirm both on Friday.

**Coaching note:** The gap between the two versions is not effort, it is where the work is considered finished. A coordinator's work ends when the thing leaves their hands. An owner's work ends when the result exists. The handoff is where almost everything goes wrong in every organization, and almost nobody watches it, which is exactly why watching it makes you visible so fast. Every handoff needs a return date and a plan for the date being missed. A handoff without one is a donation.

---

## Example 4: Junior analyst at a financial services firm

**Shift 1 and the visibility problem**

**Before**

> Hi Elena, I finished the reconciliation model rebuild we talked about. It took a bit longer than I expected because the source data had a lot of inconsistencies I had to clean up first, but it is done now. Let me know if you want me to walk you through it or if anything needs changing!

**After**

> The reconciliation model is rebuilt and live. [Link]
>
> Month-end close on this book goes from six days to two. That is roughly thirty analyst hours a month back, and it removes the manual mapping step that caused three of the four restatements we had last year.
>
> The rebuild also surfaced 214 mismatched entries in the legacy source that nobody had caught. They are documented on tab 3. Most are immaterial, eleven are not, and those eleven total about $47K in misallocated cost. I have flagged those for [name] separately.
>
> No action needed from you. If nothing comes back by Friday I will run August's close on the new model and keep the old one as a parallel check for one cycle.

**Coaching note:** "It took a bit longer than I expected" is the most expensive sentence in that first message. It asks the reader to credit difficulty, and nobody promotes difficulty they have to take on faith. The rebuilt model was worth thirty hours a month and caught $47K, and the original message contained neither number, which means the work was effectively invisible. Making work visible is not self-promotion when you do it with numbers. "It cut close from six days to two" is not a boast, it is a fact, and facts are what survive being repeated by someone else in a room you are not in.

---

## Example 5: Program coordinator at a community nonprofit

**Shift 4: from waiting to be asked to managing up on a cadence**

**Before, three separate messages across two weeks, each sent after being asked**

> Yes sorry, the intake numbers are 62 for last month.

> Hi, following up on your question, the volunteer training is scheduled for the 18th.

> The grant report is mostly done, I should have it to you this week I think.

**After, one message, sent every Monday at 9, without being asked**

> **Week of [date]. Program status.**
>
> **Intake:** 62 last month, up from 48. The increase is entirely from the [referral partner] channel that started in June. If it holds we will be over capacity for [service] by October, and I want to raise that now rather than in September.
>
> **Volunteer training:** scheduled for the 18th, 14 confirmed, room and materials booked. On track.
>
> **Grant report:** narrative sections are done. I am waiting on the final expense figures from [name in finance], asked last Tuesday, following up today. Due to the funder the 30th, and I need the figures by the 24th to make that comfortably.
>
> **Need from you:** nothing this week. Heads up that I will want thirty minutes before the end of the month on the capacity question.

**Coaching note:** Three of those before messages exist because someone had to come looking. Every time your manager has to ask where something stands, you have cost them a small amount of attention and confirmed that you are a thing that needs checking. The cadence solves that, and it does something else people do not expect: it forces you to notice patterns, because sitting down every Monday to write what changed is when you spot the capacity problem in October rather than in October. Pick a slot, keep it even in the weeks when nothing happened, and escalate emergencies off the cadence rather than saving them for it.

---

## Example 6: Executive assistant at a mid-sized engineering firm

**Shift 5: from following the process to creating the process, plus claiming an unowned gap**

**Before**

> I have been handling the visitor and contractor site access requests for a while now since nobody else really knows how, so it usually comes to me. It takes up a lot of my week and it gets hectic when there are a lot of them, especially because everyone asks in a different way, some by email, some just stopping by my desk.

That is a description of a trap. She is the only one who can do it, which means she can never be moved.

**After, sent to her manager**

> I want to fix something that has quietly become a third of my week: site access requests.
>
> Right now they come to me by email, chat, and in person, in no standard format, and there is no written process. I am the only person who knows the full sequence, which is a risk when I am out and a ceiling on what else I can take on.
>
> **What I have done:** written the whole thing up. [Link] One page: the trigger, the seven steps with the actual system names, the two approval decision points, the four exceptions that come up, and who to escalate to. Anyone on the admin team could run it from that doc tomorrow.
>
> **What I would like to do next:** put a single intake form in front of it so requests stop arriving three different ways, and train [name] to run the standard cases with me handling only the exceptions. Two weeks to have that in place.
>
> **Why it is worth it:** it takes about eight hours a week off my plate, it removes the single point of failure, and it gets requests turned around faster because they arrive complete instead of needing three follow-up questions.
>
> **The gap underneath this:** nobody actually owns site access as a process, which is how it ended up informal. I am going to own it unless you want it somewhere else. That means I keep the doc current, I handle the exceptions, and I flag it when the policy needs to change.
>
> I would put the eight hours into [the higher value work], which I think is the better use of it.

**Coaching note:** Being the only person who can do something feels like security and it is a ceiling. Nobody gets promoted out of a job that would break the moment they left it, and the fix is entirely in your hands: first time, do it; second time, document it; third time, hand it off or automate it. Notice the last two paragraphs, because they are doing separate jobs. Documenting the process proves she can be moved. Claiming the unowned gap grows her scope. Those are two different moves and both are available in the same message. Also notice the phrasing on the claim: it states what she is doing, it names the gap as a fact rather than as a criticism of anyone, and it gives her manager a four word escape hatch, which is what makes saying yes cheap.
