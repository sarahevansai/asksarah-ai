# Scripts

Word for word language for the moments where people freeze. Every script here is adaptable to any industry, any company size, any country. Adapt the specifics to the user's situation before you deliver one. Never paste a generic version into a user's hands: swap in their project, their manager, their numbers.

Each script includes what to expect back, because the freeze usually happens on the second sentence, not the first.

---

## 1. Asking for more scope

Use when you already do the work informally and want it made official, or when there is a named area you want to own.

**In writing, before the conversation:**

> Hi [Name], I would like fifteen minutes this week to talk about scope. Short version so you can think about it first: I would like to own [specific named area] end to end. I have been carrying most of it informally for [time period] and I think making it official saves you the review cycle. Happy to talk through it whenever works.

**In the conversation:**

> I want to talk about taking on [specific named area].
>
> Here is where I am already doing it. [Thing one]: I have run that end to end since [month], and [result with a number]. [Thing two]: I took that over when [context], and it now [result].
>
> What I am asking for is to own [named area] outright, including [the decision you currently escalate].
>
> What that changes for you: you stop [the specific thing they currently do, for example reviewing every one of these before they go out, or being the one who gets pulled in when it breaks].
>
> I would suggest we check in at [date, six to eight weeks out] and you tell me honestly whether it is going well. If it is not, we put it back.

**If they say yes:** get the boundary immediately. "One thing before we finish: what decisions in this area do you still want to see before they happen?" This prevents the overstep that would undo it.

**If they say no or not yet:**

> That is fair. What would need to be true for it to be a yes in six months?

Then write down the answer and send it back to them in the follow-up so it exists in writing. A no with a condition attached is a roadmap. A no without one is a wall.

**If they say "let's revisit later":**

> Works for me. Can we put a date on it now so it does not get lost? [Month] work?

---

## 2. Telling your manager you disagree

The mistake is either saying nothing and grumbling later, or disagreeing about the person instead of the work.

> I want to flag that I see this differently, and then I will get behind whatever you decide.
>
> My concern is [the specific risk, with the consequence attached]. What I think happens is [outcome], and the cost of that is [number, date, or named impact].
>
> What I would do instead is [alternative], because [one reason].
>
> If you have context I do not have, tell me and I am done. Otherwise I wanted it said before we commit rather than after.

Rules that make this safe:

- Disagree once, in private, before the decision. Not after, and never in front of their boss.
- Attach a consequence, not a feeling. "I do not love this approach" is not a position.
- End with the commitment. "I will get behind whatever you decide" is what makes disagreement affordable for both of you.
- If you were overruled and turn out to be right, say nothing. Zero. The record is enough, and being gracious about it is worth more than the point.

**If they push back hard:**

> Understood. I have said my piece, I am on board. What do you need from me first?

---

## 3. Claiming work nobody owns

> Nobody owns [X] right now, so I am going to take it unless you want it somewhere else.
>
> The reason I am raising it: [the specific evidence that it is unowned and costing something. Two examples beat an assertion. "It came up twice this month and both times we answered it from scratch."]
>
> What I would do: [two or three concrete things, with a date on the first one].
>
> If it belongs to someone else, tell me and I will drop it.

Variants:

**A gap between two teams:**

> The handoff between [team A] and [team B] has dropped [number] things this quarter. The middle of it does not have a name on it. I am going to own the handoff, which means [specific action], unless you want it elsewhere.

**A recurring question with no standing answer:**

> [Question] comes in about [frequency] and gets answered from scratch every time. I am going to build the standing answer and keep it current. It will live [where], and I will own updating it.

**Something a peer half owns.** Do not claim this one. Offer.

> I have some room this month and I know [the thing] keeps slipping. Want me to take [the specific piece] so you can hold the rest? Genuinely fine either way.

---

## 4. Admitting a mistake

Five lines maximum. Sent the same day. In private, before anyone else can tell them.

> [Name], I [the mistake, in one sentence, active voice, your name on it].
>
> Impact: [what it cost, who it affects, how bad. Accurate, not softened, not inflated.]
>
> Already done: [the fix that is in motion right now, with a time on it].
>
> Preventing it: [one specific change].
>
> I will update you [when].

Worked example:

> Priya, I sent the [client] report with last month's figures in the summary table. Caught it an hour after it went out.
>
> Impact: they have a wrong revenue number in a document their board sees Thursday. Nothing else in the report is affected.
>
> Already done: corrected version is out with a short note flagging the change, and I called [contact] directly so they heard it from me before they read it.
>
> Preventing it: I am adding a figures check against the source file as the last step before anything client facing goes out.
>
> I will confirm once [contact] comes back.

What not to do, and it is worth naming these to a user because they will do them by instinct:

- Do not open with the explanation. Context before ownership reads as an excuse.
- Do not apologize more than once. The second apology moves the conversation from the problem to your feelings.
- Do not promise it will never happen again. Promise the specific change.
- Do not wait until you have fully fixed it. Speed matters more than completeness.

---

## 5. Asking what "good" looks like

Most people never ask this and then spend a year guessing. Ask in the first month of any role, and again whenever the work changes.

> I want to make sure I am aiming at the right thing. If you look back at the end of [the quarter, the year] and think I did an excellent job, what is true that is not true now?
>
> And the other side: what would make you think this is not going well?

The second question is the one that matters. People will tell you the ceiling happily and the floor only if asked directly.

**If the answer is vague** ("just keep doing what you are doing," "be more strategic"):

> Let me try to make that concrete and you tell me if I have it right. I think that means [your specific interpretation, with an example]. Is that the right read?

**If they still cannot answer,** write your own version and send it:

> Here is what I am treating as the bar for this quarter: [three specific things with measures on them]. Tell me if any of that is wrong or missing.

Silence on that is agreement, and that is a fair trade for a manager who will not define it themselves.

---

## 6. Pushing back on an unrealistic deadline

Never say it cannot be done. Show the tradeoff and hand them the choice.

> [The date] is not achievable with what is currently committed. Here is the tradeoff so you can pick.
>
> Committed now: [A] due [date], [B] due [date]. Both are fully allocated.
>
> If [new thing] takes priority, [B] moves to [realistic date] and I will tell [stakeholder] today.
>
> If [B] holds, the earliest realistic date for [new thing] is [date].
>
> Third option if the date is fixed: [reduced scope version] by [date], with [what gets cut] following after.
>
> My recommendation is [one of them], because [one reason]. Tell me which way to go and I will move today.

Why this works: you have not refused anything. You have moved the decision to the person whose decision it actually is, with the information they need to make it. That is ownership, not resistance.

**Never say:** "we are stretched really thin," "there is no way," "this is a lot." All three describe your experience. None of them describe the tradeoff.

---

## 7. Asking for a promotion timeline

Do this in a scheduled conversation. Never in passing, never at the end of a meeting about something else.

> I want to talk about the path to [the level or title], not today but as a plan.
>
> My read is that I am doing a lot of that job already: [two specific things you own end to end, with results]. I might be wrong about that, and I would rather know.
>
> Two questions. First, what is the gap between where I am and that level? Second, is there a realistic timeline, or is the constraint structural right now?

That second question matters more than people realize. Sometimes there is genuinely no seat, and knowing that is worth more than a vague yes. If the constraint is structural, you can plan around it. If nobody tells you, you spend two years waiting.

**Follow up in writing the same day:**

> Thanks for the conversation. Capturing what I heard so I am working on the right things: the gap is [X and Y], and we are looking at [timeframe] assuming [condition]. I will come back to you in [interval] with where I am on those two. Correct me if I have any of that wrong.

That message turns a friendly chat into a shared record. Do it every time.

**If the answer is a soft yes with no specifics,** push once, politely:

> That helps. Can we put one thing on it: what would you need to see from me by [date] for this to be a real conversation then?

---

## 8. Saying you are at capacity

The goal is never to refuse. It is to make the cost visible and hand back the priority call.

> I can take this on. Here is what it displaces so you can decide.
>
> Right now I am carrying [A], [B], and [C]. [A] is due [date] and is the one with an external commitment on it.
>
> If [new thing] goes to me, [C] slips to [date] or someone else picks it up.
>
> My recommendation: [specific]. Tell me which and I will move.

**If you are genuinely underwater and it is not one request but a pattern:**

> I want to flag something bigger than this one request. Over the last [period] my committed work has grown by roughly [amount or list] with nothing coming off. I have been absorbing it and the quality is going to start showing.
>
> Here is what I think the right list is: [the three things you should own]. Here is what I think should move or stop: [the rest, with a suggestion for each].
>
> I am not asking to do less. I am asking to be pointed at the right things.

That last line is the difference between a capacity conversation and a complaint.

---

## 9. Taking over a stalled project

The delicate one, because there is usually a person attached to the stall.

**To your manager first, always:**

> [Project] has not moved since [date]. [Consequence of it staying stalled, with a number or a date on it.]
>
> I would like to take it and get it to [specific end state] by [date]. What I would do first: [the one concrete unblocking action].
>
> [Current owner] has [context, said generously: is buried in the launch, has had it deprioritized, is covering two roles]. I would want to talk to them directly before anything moves.
>
> Want me to?

**Then to the current owner, and never before:**

> Hey, [manager] and I were talking about [project] and I offered to pick it up so it stops sitting on your list. Completely fine if you would rather keep it, genuinely. If you are happy to hand it over, can I get thirty minutes for what you know that is not written down?

Rules:

- Manager first, then the owner. Reversing that order looks like a takeover.
- Say nothing about why it stalled. Ever. Not to your manager, not to anyone. Just move it.
- Give them the exit. "Fine if you would rather keep it" costs nothing and preserves the relationship you will still need.
- When it lands, credit their work publicly and specifically. This is not politeness, it is the thing that makes the next person willing to hand you something.

---

## 10. Asking for feedback that is actually useful

"Do you have any feedback for me" gets you "you are doing great" every time, because it is a big vague question and the honest answer is expensive to give.

Make it small, specific, and easy to answer:

> One thing I would like your read on: in [specific situation, for example the client call on Tuesday, or the update I have been sending on Fridays], what would you have done differently?

Or narrow it to a choice, which is the easiest form to answer honestly:

> If you had to pick one thing for me to be better at over the next quarter, is it [option A] or [option B]?

Or ask about the ceiling, which surfaces what nobody volunteers:

> What is the thing that would stop me from being ready for [the next level]? I would rather hear it now than in a review.

**When you get real feedback, and this is the part that determines whether you ever get it again:**

> That is useful, thank you. Let me make sure I have it: you are saying [restate it in your own words, accurately, without softening it]. Is that right?

Then say nothing else. Do not explain, do not give context, do not defend. Explaining is the single most common reason a manager decides not to give someone feedback again. Come back in two weeks with what you changed.

---

## 11. Setting the cadence with a new manager

Do this in week one. It costs one message and it removes months of ambiguity.

> Want to set up how I keep you posted so you never have to chase me for a status.
>
> My default is a short written update every [day], covering what is done, what is moving, what is stuck, and anything I need from you. Anything urgent comes to you the moment it happens, not in the update.
>
> Two questions: is [day] the right slot for how your week runs, and do you prefer that in chat, in email, or in the one-on-one?

Then hold it. The value is entirely in never missing one.

---

## 12. Handing off a process you have documented

The moment that proves you can be promoted. Make it clean.

> I have written up [process] and I would like [name] to take it from here.
>
> The doc is [where]. It covers the steps, the three exceptions that come up, and who to escalate to. [Name] and I will run it together once on [date], then it is theirs.
>
> I will stay on as backup through [date] and then step out completely.
>
> This frees up roughly [time estimate] a month on my side, which I would put into [the higher value thing].

That last line is the one people leave off, and it is the whole point. A handoff without a stated redirect looks like offloading. A handoff with one looks like leverage.

---

## 13. Following up on silence

Nothing is more common and almost nobody does it well. The trick is that the follow-up carries a decision, not a reminder.

> Following up on [thing] from [date]. Still need [the specific decision] to hold [the date].
>
> If I do not hear back by [date and time], I will [default action], which is reversible until [date].

Never say "just bumping this." Never say "per my last email." Restate the ask in one line, attach the default, and move on. The default is what makes silence productive instead of expensive.
