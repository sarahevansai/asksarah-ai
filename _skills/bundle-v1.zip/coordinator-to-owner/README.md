# Coordinator to Owner

A Claude skill that makes the jump from doing tasks to owning outcomes. It finds the specific behavior that is keeping you at your current level, then writes the exact thing you need to send, say, or publish to change it.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

There is a line in every organization that almost nobody explains out loud. On one side, people are handed tasks. On the other, people are handed outcomes and left alone.

The people stuck below that line are usually the ones working hardest. The gap is not effort and it is not talent. It is a set of specific, learnable behaviors that signal "this person can be given a result and trusted with it." Most people are never told what those behaviors are.

Paste in your recent updates, or just describe the situation, and Claude will:

1. Hand you the finished artifact, ready to use
2. Name which of the five shifts is currently costing you the most, with the evidence from your own writing
3. Give you one coaching note that changes every message after this one

**You always get a thing, not a pep talk.** Ask how to handle a situation and you get the framing plus the message that executes it. Ask which shift to work on and you get the diagnosis plus a rewrite of your own material that demonstrates it. Missing a number? It comes back in `[BRACKETS]` for you to fill, not as a question you have to answer first. It never ends on "want me to draft that."

## The Five Shifts

Each one is a before and after behavior pair, and each one is visible in how you already write.

1. **From reporting activity to reporting outcomes.** Nobody is tracking what you did. They are tracking what changed.
2. **From asking questions to bringing decisions.** Replace "what should I do about X" with "here is X, here are two options, I recommend A, tell me if you disagree." This is the fastest promotion signal that exists and you can start it this afternoon.
3. **From owning your slice to owning the whole result.** If the thing you touched fails downstream, it still failed. Owners chase the handoff. Coordinators mark their part complete.
4. **From waiting to be asked to managing up on a cadence.** Set the update rhythm yourself. Being asked for a status is a small failure.
5. **From following the process to creating the process.** First time, do it. Second time, document it. Third time, hand it off or automate it.

## What else is in it

**Ownership without overstepping.** The clean line between claiming authority you were not given, which is a land grab, and closing a gap nobody owns, which is free scope. Plus the exact sentence that makes the second one land: "Nobody owns X right now, so I am going to take it unless you want it somewhere else."

**Asking for scope.** Built on evidence that you already operate at that level, not on the fact that you want it. Including what to say when the answer is no, so a rejection becomes a checklist instead of a wall.

**The visibility problem.** Doing invisible work well is how good people stall. How to make work visible without the version that reads as bragging, and what specifically separates the two.

**When your manager is the problem.** Ownership behaviors that work when your manager is a bottleneck, disorganized, absent, or takes credit. Upward, never political, with the line you do not cross named explicitly.

**Handling a mistake like an owner.** One sentence of ownership, the impact stated plainly, the fix already in motion, one line of prevention. No spiral. Five lines total.

## Try it

Once installed, say any of these:

- "Here are my last three updates to my manager. What am I doing wrong?"
- "How do I get promoted?"
- "I want to own [area]. Help me ask for it."
- "My manager micromanages everything. What do I do?"
- "How do I sound more senior in writing?"
- "I made a mistake and I have to tell my boss."
- "Nobody notices the work I do."
- "There is a project that has been stalled for a month. Can I take it over?"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `coordinator-to-owner.zip` in your skills settings. Claude loads it automatically whenever the conversation calls for it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/coordinator-to-owner/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste a recent update you sent your manager, and say "what shift am I missing." You should get a rewrite, one named shift with the evidence for it, and one coaching note.

## What is in the package

```
coordinator-to-owner/
├── SKILL.md                 The five shifts, the diagnostic, the rules, the output format
├── README.md                This file
├── LICENSE
└── references/
    ├── scripts.md           13 word-for-word scripts for the hard conversations
    └── examples.md          6 full before and after transformations, with the shift named
```

The scripts cover asking for more scope, disagreeing with your manager, claiming unowned work, admitting a mistake, asking what good looks like, pushing back on a deadline, asking for a promotion timeline, saying you are at capacity, taking over a stalled project, asking for feedback that is actually useful, setting a cadence with a new manager, handing off a process, and following up on silence.

The examples run across a warehouse operations lead, a laboratory coordinator, a retail assistant manager, a junior financial analyst, a nonprofit program coordinator, and an executive assistant at an engineering firm. Every rule in this skill works in any industry, any company size, any country.

## Notes

Claude will never invent a number, a date, a name, or a result to fill a gap. Anything it does not know comes back in `[BRACKETS]`. A confident update built on a made-up figure is worse than no update.

It names exactly one shift at a time, on purpose. Naming three halves the impact of each.

It will not tell you that a real structural problem is a mindset problem. If your manager is not going to change, it says so.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
