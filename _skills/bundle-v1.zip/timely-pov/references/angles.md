# Angles, Channel Shapes, and the POV Bank

Load this when choosing an angle, fitting a piece to a channel, or building a POV bank entry.

All events below are hypothetical and described generically. Use them as shape references, never as facts.

---

## Part One: The Seven Angles, Worked

One piece, one angle. If a draft contains two, one of them is padding.

---

### 1. The mechanism

**What it is:** explain how the thing actually works, for readers who only saw the headline.

**Works when:** the story is technical, financial, regulatory, or operational, and the coverage stopped at the announcement. Most coverage stops at the announcement.

**Requires:** you genuinely understand the machinery. Not that you can describe it. That you have operated it.

**Fails when:** you are paraphrasing an explainer someone else wrote this morning. Readers can tell, because the paraphrase has no rough edges in it.

**Worked example.** Hypothetical event: a large payments processor announces it will settle merchant transactions in one day instead of three.

> One-day settlement sounds like a speed upgrade. It is a cash flow change, and it will hit small merchants hardest in the first quarter.
>
> Here is why. Under three-day settlement, most small merchants are running a rolling float of roughly three days of revenue sitting in transit. It is invisible money, but their working capital math is built on it. When settlement compresses, that float pays out once and then stops existing. You get one good week, then a permanently smaller buffer between a slow Tuesday and payroll.
>
> The merchants who will feel this are the ones with thin margins and weekly payroll. The ones who will not notice are the ones already sitting on sixty days of cash.
>
> If you run finance for a business under twenty staff, the number to check this week is your minimum daily cash balance over the last twelve months. If it dipped under three days of revenue more than twice, this changes your planning.

Note what is doing the work: the float, the one good week, the specific number to check. None of that was in the announcement.

---

### 2. The second-order effect

**What it is:** what happens next that nobody is tracing yet. The news is the first domino. You name the third.

**Works when:** the direct story is fully covered within hours and the follow-on is not covered at all.

**Requires:** you are right about a chain. State it as a projection, not a fact, and say what would prove you wrong.

**Fails when:** the chain is three vague steps and the last one is "and this changes everything for everyone."

**Worked example.** Hypothetical event: a major job board removes salary range requirements from its listings.

> The salary range rollback will not stay a job board story. It will land on recruiting teams in about a quarter, and it will land as a volume problem.
>
> The ranges were doing filtering work nobody credited them for. When candidates could see the number, the wrong-fit applications self-selected out before anyone read a resume. Take the number away and every listing collects a wider funnel, which lands on the same recruiter who is already the bottleneck.
>
> Watch for the second effect after that: teams will start putting the range back in the job description body voluntarily, not for fairness reasons but because their recruiters will demand it. I would expect that to show up first at companies hiring in volume for mid-level roles.
>
> I would be wrong about this if application volume does not move in the first sixty days. That is the signal to watch.

---

### 3. The practitioner's view

**What it is:** what this changes for people who do the work, concretely, starting Monday.

**Works when:** you are one of those people. This is the angle most available to most people and the one most often skipped, because analyst voice feels more impressive than practitioner voice. It is not.

**Requires:** specificity about the work. The tool, the step, the meeting, the handoff.

**Fails when:** written as "for professionals in this space" instead of "for anyone who does this exact task."

**Worked example.** Hypothetical event: a widely used design tool changes its file versioning model.

> The versioning change is going to break the way most teams do design handoff, and the fix takes about an hour if you do it before the migration rather than after.
>
> The specific breakage: if your team links to a specific file version in tickets, those links are pointers into the old model. After migration they will resolve to the current state instead of the state you specified. Every ticket older than the migration date will silently point at the wrong thing. Nothing errors. It just quietly stops being true.
>
> What I would do this week, in order: export a static reference for any ticket currently in flight, add the version identifier as text in the ticket body rather than relying on the link, and tell QA that anything they verify against a link from before the cutoff needs a second look.
>
> This is a one hour job now and a two week archaeology project later.

---

### 4. The contrarian data point

**What it is:** a fact that complicates the consensus.

**Works when:** you hold a number or a repeatable observation that cuts against the story everyone is telling.

**Requires:** the fact is real, is yours to share, and is stated with its source and its limits. Contrarian without a fact is just contrarian, and it reads as a bid for attention.

**Fails when:** the fact is a vibe. "In my experience it is the opposite" is not a data point.

**Worked example.** Hypothetical event: an industry survey reports that most firms in a sector plan to cut a particular category of spend next year.

> Everyone is reading the survey as a spending collapse. Our own numbers say something narrower is happening, and the distinction matters if you sell into this category.
>
> Across [number] accounts we renewed in the last two quarters, total spend in this category was down about [percent]. But the count of accounts spending anything was flat. What moved was concentration: the same buyers, buying less, from fewer vendors. Nobody exited the category. They consolidated inside it.
>
> That is a different problem than a collapse. A collapse means finding a new category. Consolidation means being one of the two vendors left, which is a positioning fight, not a market exit.
>
> Caveat worth stating: our sample skews toward mid-market, and I would not extend this read to enterprise buyers.

The caveat is not weakness. It is the thing that makes the rest believable.

---

### 5. The pattern

**What it is:** this is the fourth time this has happened, and here is what the first three taught us.

**Works when:** you have the history and the audience does not, or has forgotten it. Newer audiences almost always have not.

**Requires:** the earlier cases are real and named, and the pattern is genuinely a pattern rather than three loosely similar events.

**Fails when:** the prior cases are so vague they cannot be checked. "We have seen this before, many times."

**Worked example.** Hypothetical event: a large platform announces it will begin charging for API access that was previously free.

> This is the third time in about a decade that a platform in this category has moved a free interface behind a fee. Both prior rounds went the same way, and the timeline was consistent enough to plan against.
>
> What happened both times: an immediate wave of public complaint that changed nothing, a six to nine month period where a handful of small integrators quietly went out of business, and then a stable market at the new price with roughly a third fewer builders on the platform. The tooling ecosystem got smaller and the surviving tools got more expensive. Nobody reversed anything.
>
> The teams that came out fine did one thing early: they wrote down exactly which of their workflows depended on that interface and what each one would cost to replace. Not migrating. Just knowing. That inventory took a week and turned a panic into a budget line.
>
> If you depend on this interface, that inventory is this week's work. The pricing details will move. The dependency will not.

---

### 6. The translation

**What it is:** what this means specifically for one named audience.

**Works when:** the coverage is written for a general reader and your audience has a particular exposure nobody addressed.

**Requires:** naming the audience narrowly. "For businesses" is not an audience. "For independent bookkeepers with fewer than five staff" is.

**Fails when:** the translation is generic advice with an audience label glued to the front.

**Worked example.** Hypothetical event: a new data retention rule is announced with an eighteen month compliance window.

> If you run a small clinic with fewer than fifteen staff and no dedicated compliance person, here is the version of this rule that applies to you. Most of the coverage is written for organizations with a legal department. You do not have one, so the practical shape is different.
>
> Three things actually change for you. Your intake forms will need a retention notice, which is a text change and takes an afternoon. Your backup vendor becomes a compliance dependency, which means you need their attestation in writing and most of them will not volunteer it. And your staff offboarding checklist needs a data access step, which is the one that gets missed and the one that shows up in an audit.
>
> The eighteen month window sounds generous. The backup vendor attestation is the long pole, because you are in a queue behind their larger customers. I would start that request in the next two weeks and let the rest wait.
>
> What I am not certain about: whether the rule reaches paper records held offsite. If you hold those, that is the question to put to your own counsel rather than to a post like this one.

---

### 7. The honest uncertainty

**What it is:** what nobody knows yet, which signals would resolve it, and what you would change your mind about.

**Works when:** the story is genuinely undetermined and everyone else is performing confidence.

**Requires:** real analytical work. Uncertainty is not the absence of a position. It is a position about what is knowable and when.

**Fails when:** it is used as cover for having no view. "Only time will tell" is not this angle. It is the opposite of it.

**Why it is underrated:** it ages better than a confident wrong call, and it is the only angle that gets stronger as the story develops. When the signal you named lands, you get to write the follow-up, and everyone remembers you called the signal.

**Worked example.** Hypothetical event: two large firms in a sector announce a merger.

> I do not know whether this merger is good or bad for buyers in this category, and neither does anyone posting confidently about it today. What I do know is which signal decides it, and it will show up within about two quarters.
>
> The signal is what happens to the smaller of the two product lines. In every consolidation I have watched in this space, the acquiring side says both products continue. Sometimes that is true. The tell is not the announcement, it is the hiring: if the smaller product's team is still posting roles ninety days in, it continues. If those postings quietly close, it is in maintenance, whatever the press release says.
>
> So the thing I would watch is job postings, not press releases. Two quarters, one signal.
>
> If both product lines are still hiring in six months, I will have been too cynical about this, and I will say so.

---

## Part Two: Channel Shapes

The four parts of the shape do not change. Their proportions do.

---

### Short social post

60 to 120 words. One claim, one specific, one consequence. The open is optional and only earns a line if it is a real signal or a real question.

```
[The claim. One line. A position, not a summary.]

[The specific. The number, the mechanism, the thing only you could say.]

[The consequence. What changes for the reader.]

[Optional: the one signal to watch.]
```

Rules:
- Line breaks after almost every sentence. Density kills reach and kills comprehension.
- The first line has to work alone, because on most feeds it is the only line shown before the fold.
- No hashtag stack. If you use tags at all, two, and only ones a real person follows.
- No "thoughts?" No "curious what others think." No rhetorical opener.

---

### Long social post

200 to 350 words. All four parts, with the specific carrying the most weight.

```
[The claim. One or two lines.]

[Context in one clause if truly needed. Never a paragraph.]

[The specific. This is the body. The mechanism, the number, the case, the year.]

[The consequence, broken out for whoever it lands on hardest.]

[The open. What to watch, what you are unsure about, or one real question.]
```

Rules:
- The specific section should be roughly half the piece. If it is not, the piece is padding.
- One angle. If two angles appear, cut the weaker one and save it.
- Name who this does not apply to. It is the most credible sentence available to you and almost nobody writes it.

---

### Client or customer email

150 to 250 words. Lead with what changes for them, not with what happened.

```
Subject: [What changes for them, plus a timeframe]

[One line: what this means for you specifically.]

[What actually changed, in two or three lines, only the part that touches them.]

[What we are doing about it, with an owner and a date.]

[What we need from you, or explicitly: nothing right now.]

[Who to reach with questions, by name.]
```

Rules:
- Never sell inside a news note. If the piece ends with a service mention, it was marketing wearing a notice as a costume.
- Say "no action needed" out loud if none is. It is the most valuable sentence in the email.
- If you do not know something yet, say what you do not know and when you will know it. Do not wait for certainty to send.

---

### Reporter comment

Three to five sentences. Written to be quoted in isolation, because one sentence is what survives.

```
[Sentence 1: the claim, stated so it stands alone with your name attached.]
[Sentence 2 to 3: the specific. The number, the mechanism, the direct observation.]
[Sentence 4: the consequence, or the limit of what you can say.]
```

Rules:
- Every sentence must survive being lifted out of context, because one of them will be.
- No jargon a general reader would need explained. It will be cut for that alone.
- Do not reference the question. The quote appears without it.
- Say plainly what you cannot speak to. Reporters trust sources who name their limits, and they come back to them.

The outreach message that carries it, three lines:

```
[Who you are and why you would know. One line, specific relevance, not a bio.]

[The useful thing, stated outright. Give it away here. Do not tease it.]

[When you can talk today, and your phone number.]
```

Send it to the byline on this story. If you have nothing for this story, send nothing.

---

### Internal note to a team

100 to 200 words. What we know, what we do not, what we are doing, who owns it.

```
**What happened:** [one or two lines, facts only]

**What we know for sure:** [verified items]

**What we do not know yet:** [the open questions, named]

**What we are doing:** [action, owner, date]

**If someone asks you about this:** [the one line anyone can say, or: send them to a named person]

**What not to do:** [usually: do not post about this publicly yet]
```

Rules:
- The holding line matters more than the rest. Give the team one sentence they can say without checking.
- Name the person who decides what goes public. Ambiguity is how a team member posts something the company has to walk back.
- Send it before people ask. An internal note that arrives after the group chat is already going is a cleanup job.

---

## Part Three: The POV Bank

A running file of positions you already hold, with the proof attached. It is what makes a ten minute turnaround possible without manufacturing a belief under deadline.

### Entry format

```
## [The position, stated as a claim in one sentence]

**Why I hold it:** [the experience, the data, the pattern watched]

**The specific:** [the number, the case, the year, the mechanism. Without this it is an opinion.]

**What would change my mind:** [the condition or signal]

**Who this matters to:** [the narrow audience]

**News that would activate this:** [the kinds of stories where this becomes relevant]

**Last reviewed:** [date]
```

### A filled entry

```
## Most teams do not have a tooling problem, they have an ownership problem, and buying a tool makes it worse.

**Why I hold it:** Watched this in eleven onboardings over four years. Every time
a workflow broke, the diagnosis was "we need better software," and every time the
actual failure was that two people each believed the other one owned a step.

**The specific:** In the last six engagements, we mapped ownership before touching
tools. In four of the six, the mapping alone fixed the reported problem and no new
software was purchased. The two that still needed a tool needed a much smaller one
than they were about to buy.

**What would change my mind:** A team with genuinely clean ownership mapping that
still cannot execute the workflow. I have not seen one. If I saw three, I would drop
this position.

**Who this matters to:** Operations leads at 20 to 200 person companies, and anyone
about to sign a platform contract to solve a process complaint.

**News that would activate this:** Any major tooling launch aimed at team
coordination, any large company announcing a consolidation of its internal tools,
any funding round in the workflow software category.

**Last reviewed:** [date]
```

### Building it

- **Start with five, not fifty.** The five things you already argue about in client meetings, at dinner, or in your own head at 2am.
- **Add one whenever you catch yourself saying "everyone gets this wrong."** That sentence is a position announcing itself.
- **Add one after every project that surprised you.** The surprise is the evidence.
- **Attach the receipt the day you have it.** The number is easy to grab now and impossible to reconstruct in eighteen months.
- **Review quarterly.** Delete what you no longer believe. Positions rot, and a stale one is worse than none because you will defend it out of habit.
- **Keep it in one file.** Searchable, one place, boring format. A bank spread across five tools is a bank you will not open when the clock is running.

### Using it when news breaks

1. Scan the bank first, before reading a second article.
2. If the story touches a banked position, you have standing, evidence, and a claim already. Ten minutes to a piece.
3. If it touches nothing in the bank, treat that as information rather than a gap to fill. You probably do not have standing on this one, and the bank just told you so before you embarrassed yourself.
4. Whatever happens, write a new entry afterward. Every news cycle you sit out should still leave you better armed for the next one.
