# Worked Examples

Six full runs, across different industries, showing the standing test, the angle choice, the finished piece, and the coaching note.

Every event below is hypothetical and described generically. None of these are real companies, real people, or real news. Use them for shape and standard, never as facts to cite.

---

## Example 1: Standing passes, the mechanism angle

**Industry:** logistics and freight

**Hypothetical event:** a national carrier announces it will stop offering guaranteed delivery windows on residential deliveries, replacing them with a same-day notification model.

**What the user said:** "Everyone in my feed is posting about the carrier thing. I run a 3PL. Should I say something?"

### Standing test

1. **Do you know something the reader does not?** Yes. They operate a third party logistics business and see the downstream effect of window guarantees on their own dispatch planning.
2. **Would you have said this a week ago?** Yes. They have held the view that window guarantees were being priced below cost for years.
3. **Can you be specific without pretending?** Yes, on their own operation. Not on the carrier's internal economics.

**Verdict: 3/3.** Write it, staying inside their own operation.

### The piece

Channel: long social post.

> Dropping guaranteed delivery windows is not a service cut. It is a carrier admitting the guarantee was never priced correctly, and the cost is about to move onto everyone downstream of it.
>
> Here is the mechanism that matters to anyone running fulfillment. A guaranteed window is not a promise about a truck. It is a promise about the last fifteen minutes of a route, which is the least controllable part of the day. Carriers have been absorbing the reattempt cost when that window is missed, and the reattempt is the expensive part: a second trip to the same address costs more than the original delivery did.
>
> When the guarantee goes away, that cost does not disappear. It becomes a customer service ticket in your inbox instead of a reattempt on their route. You will feel this as call volume before you feel it as anything else.
>
> If you run fulfillment, the number to pull this month is your ticket rate on delivery timing questions. Get the baseline now, while the old model is still in place. In ninety days you will want to know what it was, and you will not be able to reconstruct it.
>
> What I am watching: whether the notification model actually lands the same day or drifts to a morning-of message. Same day is workable. Morning-of moves the whole problem to you.

### Verdict, angle, coaching note

**Standing: 3/3.** Angle: the mechanism, because the coverage stopped at the announcement and the reattempt economics are the part nobody explained.

**Coaching note:** the strongest line here is the one telling people to pull a baseline number now. Useful commentary usually contains one instruction the reader can act on today, before the consequence arrives. When you are deciding what to cut, keep the instruction and cut the analysis.

---

## Example 2: Standing fails, the narrower honest piece gets written

**Industry:** independent accounting practice

**Hypothetical event:** a large tax software vendor announces an AI-driven filing feature. The professional community is loudly split.

**What the user said:** "Everybody is posting about whether this kills our profession. I want to weigh in. Draft me a take on what this means for the industry."

### Standing test

1. **Do you know something the reader does not?** No, not about the feature. They have not used it, have not seen the accuracy data, and have no view into how it handles edge cases. They know what the announcement said.
2. **Would you have said this a week ago?** No. The position is entirely produced by the news.
3. **Can you be specific without pretending?** Not about the industry-wide question. They can be specific about one thing: what their own clients actually call them about, which is not filing.

**Verdict: 1/3.** The broad take fails. Do not write "what this means for the profession."

### What gets written instead

The narrower honest piece, about the part they genuinely know: the composition of their own client requests.

Channel: short social post.

> I have no idea whether the new filing feature is good. I have not used it. But I can tell you what my clients called me about last year, and almost none of it was filing.
>
> I went back through twelve months of client requests. The single largest category was not preparing a return. It was a question about a decision that had already been made: should I have bought that, can I still fix this, what does this letter mean. Filing was the smallest slice and the least of anyone's anxiety.
>
> So the question I would actually want answered is not whether software can file. It has been able to file for a long time. It is whether it can tell someone what to do in March about something they did in September.
>
> If someone has used the feature on a genuinely messy return, I want to hear about it. That is the only test I would trust.

### Verdict, angle, coaching note

**Standing: 1/3, narrowed to their own client request data.** Angle: the contrarian data point, using a number that is genuinely theirs.

Wrote the narrow version because the broad take failed all three questions. The industry-wide piece would have been a reaction to a press release, and there were already four thousand of those by lunch. This one contains something no other post that day contained: a real breakdown of what one practice actually gets asked.

**Coaching note:** the impulse when a big story breaks is to comment on the biggest version of it. The biggest version is where you have the least standing and the most competition. The reliable move is to go one level down, to the part of the story where your own data lives. A small true thing outperforms a large general one every single time.

---

## Example 3: The correct answer is public silence plus an internal note

**Industry:** regional healthcare staffing

**Hypothetical event:** a serious workplace incident at another company in the same sector, with injuries. It is dominating coverage, and several competitors have posted statements about safety culture.

**What the user said:** "Two of our competitors have posted about this. Our marketing lead thinks we look absent. Do we need to say something?"

### Standing test

Not reached. This stops at the Do Not Touch list first.

The event involves injury to identified people, is under active investigation, and the user's organization is not operationally involved. A public statement here converts someone else's harm into visibility. That the competitors did it is not an argument, it is a description of what competitors did.

**Verdict: do not post.** Not a close call.

### The distinction being applied

This organization is a spectator, not a participant. Its systems, staff, and customers are not touched by the event. It holds no information the response needs. Its community is not in the path. The only reason to post is that others did.

A response would have been legitimate if their own staff were placed at that site, if a client asked what their protocols are, or if they held safety data that materially helped. None of those are true today. Two of them could become true this week, which is why the internal note matters.

### What gets written instead

An internal note to the team, plus a holding line for anyone asked directly.

> **What happened:** A serious incident occurred at another organization in our sector. It is under investigation and coverage is heavy. We have no operational connection to it.
>
> **What we know for sure:** None of our placed staff were at that site. No client of ours is directly involved.
>
> **What we do not know yet:** Whether the investigation produces sector-wide guidance. That would take weeks, not days.
>
> **What we are doing:** [Name] is reviewing our own site protocols this week, not because of any finding, but because it is the right week to do it. Nothing about that review is public.
>
> **If a client or candidate asks you about this:** "We are following it closely. We are not involved and I do not want to speculate about someone else's investigation. If you want to talk about our own protocols, I can set that up with [name]."
>
> **What not to do:** Do not post about this publicly, and do not comment on other companies' posts about it. If a reporter contacts you, forward to [name] without responding.

### Verdict, angle, coaching note

**Standing: not assessed.** The Do Not Touch list resolves this before the standing test runs. Wrote the internal note and the holding line instead, because the real need was a team that knows what to say when asked, not a public statement.

**Coaching note:** "our competitors posted" is the single worst reason to post, and it is the most common one. The right comparison is not what competitors did during the news cycle. It is how each of you looks in six months, when someone scrolls back through the week this happened. Absence reads as restraint far more often than people fear.

---

## Example 4: Standing passes, the honest uncertainty angle

**Industry:** commercial real estate brokerage

**Hypothetical event:** a large employer in a mid-size metro announces a return to full in-office work. Local commentary immediately declares the remote work era over.

**What the user said:** "Everyone here is saying this is the turning point. I do not think it is that simple. Can I say that without sounding like I am hedging?"

### Standing test

1. **Do you know something the reader does not?** Yes. They have lease renewal data across their own portfolio and can see what companies do rather than what they announce.
2. **Would you have said this a week ago?** Yes. They have been saying the announcement and the square footage do not match for two years.
3. **Can you be specific without pretending?** Yes, on their own renewals. Not on national trends.

**Verdict: 3/3.**

### The piece

Channel: long social post.

> I do not know whether this announcement marks a turn, and I would not trust anyone who says they do today. What I do know is which number settles it, and it will not be visible for about three quarters.
>
> The number is square footage per employee at renewal. Not the announcement, not the badge data, not the number of days in the policy. The renewal.
>
> Here is why that one and not the others. In our own portfolio over the last two years, we have seen a consistent gap between what companies announced about office attendance and what they signed for. Announcements said full return. Renewals came in smaller, sometimes meaningfully smaller, in the same quarter. Both things were true at once, because the policy is a management decision and the lease is a finance decision, and those are different people with different incentives.
>
> So a full return announcement is not evidence about space. It is evidence about management preference. The evidence about space arrives when that company's lease comes up, and that is the thing to watch and the thing to put in your calendar.
>
> If their next renewal comes in flat or larger, I will have been wrong and I will say so directly. If it comes in smaller while the policy stays in place, then the announcement was never the story.

### Verdict, angle, coaching note

**Standing: 3/3.** Angle: honest uncertainty, because the story is genuinely undetermined, the crowd is performing confidence, and the user holds the data that names the resolving signal.

**Coaching note:** honest uncertainty only works when you name the signal and the timeline. "It is complicated" is not this angle, it is the absence of one. The move that makes it land is committing to something falsifiable: this specific number, in this window, and here is what I will say if it goes the other way. That commitment is what separates a considered position from a hedge, and readers hear the difference immediately.

---

## Example 5: Standing passes, the reporter comment

**Industry:** food manufacturing and co-packing

**Hypothetical event:** a new labeling requirement is announced for a common ingredient category, with a twelve month compliance window. A trade reporter emails asking for comment on whether small producers can meet the deadline.

**What the user said:** "A reporter asked me about the labeling rule. I have twenty minutes before her deadline. What do I send?"

### Standing test

1. **Do you know something the reader does not?** Yes. They run a co-packing operation and know the actual lead time on label plate production, which is the constraint nobody outside the industry knows exists.
2. **Would you have said this a week ago?** Yes. Label lead time is a thing they complain about constantly.
3. **Can you be specific without pretending?** Yes, on lead times and their own order book. Not on whether the rule is good policy.

**Verdict: 3/3.**

### The piece

The comment, written to be quoted in isolation.

> "Twelve months sounds generous until you know that label plate lead times in our category run [number] weeks in a normal quarter, and this rule will put every producer in the queue at once. The constraint is not whether a small producer understands the rule, it is whether they can get physical labels printed before the deadline, and printing capacity does not expand on announcement. My honest read is that the compliance date will hold and a meaningful number of small producers will be non-compliant for reasons that have nothing to do with intent. I can speak to production timelines. I would not speculate on how enforcement will actually be handled."

### If she still needs the outreach message

Three lines:

> I run a co-packing operation that produces for [number] small food brands, so I see the label supply chain from the production side.
>
> The binding constraint on this rule is not comprehension, it is label plate lead time, which runs [number] weeks normally and will spike when every producer in the category orders at once. Twelve months is not twelve months if the printing queue is the bottleneck.
>
> I can talk any time before 4pm today at [phone].

### Verdict, angle, coaching note

**Standing: 3/3.** Angle: the mechanism, applied to a constraint that is invisible from outside the industry.

**Coaching note:** the last sentence of that quote, naming what you will not speculate about, is the one that gets you called again. Reporters are managing risk on every quote they run, and a source who marks their own limits is a source who is safe to use. Most people do the opposite under deadline pressure and try to be useful on everything. Being useful on one thing and explicitly silent on the rest is worth more.

---

## Example 6: Standing partially passes, the client note instead of the post

**Industry:** boutique insurance brokerage

**Hypothetical event:** a major insurer announces it is exiting a specific coverage line in several regions, effective at next renewal.

**What the user said:** "This is big for our clients. Should I post about it or email them? Marketing wants a LinkedIn post."

### Standing test

1. **Do you know something the reader does not?** Yes, but only for their own book. They know which of their clients hold that coverage and what the alternatives cost.
2. **Would you have said this a week ago?** Partly. They have held the view that this line was underpriced. They have no prior position on this specific exit.
3. **Can you be specific without pretending?** Yes, and this is the deciding one. Their specificity is entirely client-specific, and it stops being specific the moment it is generalized for a public audience.

**Verdict: 2/3, and the useful version is not public.**

### The judgment

The public post would be the generic version of what they know, which is the weakest version of it. The client email is the strong version, and it goes to the people it actually affects, on the day it affects them. Post later if a real pattern emerges. Serve the book today.

### The piece

Channel: client email.

> **Subject: Your [coverage line] renewal, and what changes before [month]**
>
> If you carry [coverage line] with us, your renewal is going to look different this year and I want you to hear it from me before you see it on a quote.
>
> One of the larger carriers in this line is exiting several regions at next renewal, including ours. That removes a meaningful share of capacity from the market. It does not affect your current policy, which runs to its stated end date.
>
> What we are doing: I am pulling every affected policy in our book this week and running alternatives on each one, starting with the renewals closest to their dates. You will get a specific note about your own policy from me by [date], with options and pricing, whether or not the news is good.
>
> What we need from you right now: nothing. If someone contacts you about switching before you hear from me, forward it to me rather than responding.
>
> Any questions before then, call me directly at [phone].

### Verdict, angle, coaching note

**Standing: 2/3, and the strongest version is private.** Angle: the translation, aimed at one named audience, delivered to that audience rather than performed in front of a general one.

**Coaching note:** when the useful thing you know is client-specific, publishing it forces you to generalize it, and generalizing is what strips out the value. Ask where the knowledge is strongest before asking which channel is bigger. A note that reaches forty people who need it beats a post that reaches four thousand who do not, and the forty are the ones who pay you.
