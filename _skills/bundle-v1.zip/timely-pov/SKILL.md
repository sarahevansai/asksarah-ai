---
name: timely-pov
description: >
  Turns a breaking story into a credible point of view, fast, and refuses to help you
  post a hollow one. Use whenever news lands in someone's industry and they are deciding
  whether to say something, what to say, and where: a LinkedIn post, an X thread, a
  comment for a reporter, a client note, an internal message, or a founder statement.
  Trigger on "should we post about this," "everyone is talking about," "write a take
  on," "hot take," "a reporter asked me about," "do we need to say something," "what is
  our angle on this," "can we newsjack this," "clients are asking about this," or any
  pasted headline or link with a question about commenting. Also trigger unprompted when
  the user is about to publish commentary that restates the news, adds a platitude, or
  ties their business to an unrelated event. When in doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Timely POV

Something big happens in an industry. Within four hours, a thousand people post about it. Almost all of it is worthless.

It is worthless for one reason: it summarizes news the reader already read, then adds a sentiment. "Big news today. This changes everything. Curious what others think." That is not a point of view. That is a person announcing they have seen the internet.

The posts that land do one thing the others do not: they add information or judgment the reader could not get from the news itself. A mechanism. A number. A consequence nobody traced. A view from inside the work.

Speed matters. Standing matters more. Most people have neither and post anyway.

This skill fixes both, in that order.

---

## The #1 rule: always deliver the finished piece

**Every run ends with something written and ready to publish or send.** The post, the comment for the reporter, the client note, the internal message. Whatever the situation calls for, finished.

Never a list of possible angles with nothing written. Never "here are three directions, which do you want." A menu is homework, and the user came here because the window is closing.

This holds even when:

- The user asked only "should we post about this." Answer in one line, then hand them the piece, or the honest alternative.
- The standing test fails. Say so in one line and write the narrower honest piece anyway, which is usually about the part they genuinely do know.
- The correct answer is public silence. Then write the internal note, the client note, or the holding line for anyone who asks. Silence in public still needs words somewhere.
- Facts are missing. Draft it with `[BRACKETS]` for the things only the user can supply, and never for the argument, the structure, or the position.
- The story is still developing. Write the version that survives being wrong, and say which line to change if the facts move.

**Never end a response with a question instead of a piece.** If one fact would sharpen it, deliver the piece first, then ask.

The user always leaves with something publishable. That is the product.

---

## The Standing Test

Run this before writing a word. Three questions. Answer each one honestly, out loud, in the response.

**1. Do you know something about this that the reader does not?**

Direct experience with the thing. Data you hold. A mechanism you understand because you have operated it. A consequence you can trace that others have not. If the answer is "I read the article carefully," that is not knowledge, that is reading.

**2. Would you have said this a week ago?**

If the position is new because the news is new, it is a reaction, not a point of view. Real positions predate the headline. The news is the occasion to say the thing, not the reason you believe it. A take that could not have existed on Monday usually should not exist on Tuesday.

**3. Can you be specific without pretending?**

Name the number, the mechanism, the example, the year you watched this happen. If everything you can honestly say is general, you have no standing on this one. Posting anyway spends credibility that took years to build, on a post that will be scrolled past in nine seconds.

### Scoring it

- **Three yes:** write the piece. You have standing.
- **Two yes:** write it, narrowed to the part you actually know. Cut the rest without apology.
- **One or zero yes:** do not post the take. Say so plainly, and offer the alternatives below.

### When the test fails

Not commenting is a legitimate choice and it is frequently the correct one. Nobody has ever lost a client because they stayed quiet during a news cycle. People lose clients because they said something thin and someone senior noticed.

The cost of a hollow take is real and it compounds. Every empty post trains your audience that your posts are empty, so the one time you have something worth reading, fewer people stop for it. Standing is a balance you spend down.

When the test fails, the honest alternatives, in order of preference:

1. **Write the narrower piece.** Almost always the right move. You do not have a view on the whole story, but you have a real one on one part of it. Write that part, and only that part. A specific small piece beats a general big one every time.
2. **Ask a real question in public.** Only if it is a question you genuinely want answered and cannot answer yourself. Not a rhetorical prompt for engagement. Readers can tell the difference instantly.
3. **Send it internally instead.** The team, the clients, the customers who will ask. Useful, no public exposure, and often where the value actually was.
4. **Say nothing, and bank the position.** Add what you learned to the POV bank so that next time this happens, and it will, you are ready in ten minutes with something real.

Say which one you picked and why, in one line. Then write it.

---

## The Angle Types

Seven angles. Pick one. One piece, one angle. A post that tries two does neither.

**The mechanism.** Explain how the thing actually works, for readers who only saw the headline. Works when the story is technical, financial, regulatory, or operational and the coverage skipped the plumbing. Requires that you genuinely understand the machinery. Highest value, most underused.

**The second-order effect.** What happens next that nobody is tracing yet. The news is the first domino. You name the third. Works when the direct story is already fully covered and the follow-on is not. Requires you to be right about a chain, so state it as a projection, not a fact.

**The practitioner's view.** What this changes for people who do the work, concretely, starting Monday. Works when you are one of those people. This is the angle most available to most people and most often skipped in favor of pretending to be an analyst.

**The contrarian data point.** A fact that complicates the consensus. Works when you hold a number or an observation that cuts against the story everyone is telling. The fact must be real, sourced, and yours to share. Contrarian without a fact is just contrarian, and it reads as a bid for attention.

**The pattern.** This is the fourth time this has happened. Here is what the first three taught us. Works when you have the history and the audience does not, or has forgotten it. Requires that the earlier cases are real and that you name them.

**The translation.** What this means specifically for one named audience. Not "for businesses." For independent bookkeepers with fewer than five staff. For hospital procurement teams. The narrower the audience, the more useful the piece and the more it gets forwarded.

**The honest uncertainty.** What nobody knows yet, which signals would resolve it, and what you will change your mind about if they land a certain way. Underrated and undersupplied. It ages better than a confident wrong call, and it is the only angle that gets stronger when the story develops.

Full worked examples of each in `references/angles.md`.

---

## The Shape

Four parts, in this order, in every piece regardless of channel or length.

**1. The claim.** First line. Your position, not a summary of the news. The reader learns where you stand before they learn anything else.

**2. The specific.** The number, the mechanism, the example, the experience. This is the part that could only have come from you. If this section is thin, the piece is thin, and no amount of good writing elsewhere fixes it.

**3. The consequence.** What this means for the reader, concretely. Not what it means in general. What changes for the person reading.

**4. The open.** What to watch, what you are unsure about, or one real question. Not "thoughts?" A signal, a date, a condition, or something you actually want to know.

### The hard rule on the first paragraph

**Never restate the news in the opening.** The reader already knows or they would not be reading this. Summarizing the headline back to them is the single clearest marker of a post with nothing in it.

If context is genuinely needed, it goes in one clause inside your claim, not in a paragraph before it. "The new rule caps disclosure at ninety days, which is going to break more compliance workflows than anyone is saying" carries the fact and the position in one line. A paragraph of setup followed by "here is my take" wastes the only three seconds you were given.

### Length by channel

| Channel | Length | Rule |
|---|---|---|
| Short social post | 60 to 120 words | One claim, one specific, one consequence. Cut the open if it does not earn its line. |
| Long social post | 200 to 350 words | All four parts. Line breaks every one or two sentences. |
| Client or customer note | 150 to 250 words | Lead with what changes for them, not what happened. |
| Reporter comment | 3 to 5 sentences | Quotable in isolation. Assume one sentence survives. |
| Internal note to a team | 100 to 200 words | What we know, what we do not, what we are doing, who owns it. |
| Newsletter section | 300 to 500 words | Room for the mechanism. Still no news summary at the top. |

Full channel shapes in `references/angles.md`.

---

## The Do Not Touch list

Some events are not commentary opportunities. Attaching your business to them costs more than any reach it could ever generate, and the damage does not fade with the news cycle.

**Do not comment on:**

**Tragedy, death, violence, and disaster.** There is no version of a brand insight about a body count. The reflex to be present in a big moment is exactly the reflex to distrust here.

**An active crisis where people are still at risk.** During the event, the only useful public speech is information from people running the response. Anything else takes attention from it. Wait.

**Anything where your comment converts someone's harm into your marketing.** This is the test that catches the cases the other rules miss. If the post works because someone got hurt, do not post it. This includes a competitor's public failure, a customer's breach, and a layoff at another company.

**Ongoing legal matters involving named people.** You do not have the facts. You have the coverage, which is a filtered subset of the facts. Commenting exposes you legally and makes you look certain about something under active dispute.

**Political flashpoints where you have no standing and no stake.** Not a rule about courage. A rule about relevance. If the issue does not touch your work, your customers, or your obligations, your comment is a costume.

### The plainest version of the rule

**If the connection between the event and your business needs to be explained, there is no connection.**

When a draft contains a sentence beginning "which got me thinking about," that sentence is the confession. Cut it and the post collapses, because that sentence was the only thing holding the event and the pitch together.

### Telling an inappropriate moment from a legitimately relevant one

Some hard events genuinely do call for a response from certain organizations. The difference is not the severity of the event. It is whether you are a participant or a spectator.

**A response is legitimate when:**

- You are operationally involved. Your systems, staff, customers, or supply chain are directly touched, and people need to know what you are doing.
- You have an obligation to inform. Customers are affected, or a regulator, contract, or duty of care requires you to speak.
- You hold information the response needs. You have data, capacity, or expertise that materially helps, and you are offering it rather than describing it.
- Your community expects to hear from you. You lead a group directly in the path of the event, and silence would read as absence.

**A response is spectating when:**

- Your connection is that you work in the same broad industry.
- The piece ends with your product, your service, or your availability.
- It exists because everyone else is posting.
- You are describing your feelings about something happening to other people.

The legitimate versions are almost never posts. They are notices, updates, and offers. Write them plainly, put the useful information first, and leave your positioning entirely out of it.

---

## Speed versus accuracy

Fast is worth a lot. Wrong is worth less than nothing.

**Verify before commenting.** The event must be real and reported by more than one credible source. One outlet, one screenshot, one confident account with a large following, or one aggregator repeating another aggregator is not verification. If you cannot find a second independent source, you are not late yet, you are early and unprotected.

**Early reports of any developing story are routinely wrong.** Numbers move. Names get corrected. The first cause named is often not the cause. The most common way a smart person embarrasses themselves publicly is by building a sharp take on a fact that was retracted six hours later. The first version of a story is a draft that a newsroom published under time pressure.

**Being late is survivable. Being wrong is expensive.** A good piece on day three outperforms a wrong piece on day one, permanently, because the wrong one stays searchable and screenshot-able. The people you want to impress are not scoring you on speed.

**If you commented and the facts changed:**

1. Correct it visibly and fast, in the same place, at the same size. Not a quiet edit. Not a reply buried in the thread.
2. Say what you got wrong in plain words. "I said the cap was ninety days. It is thirty. That changes my read."
3. Say what it changes about your position, including if it changes nothing and why.
4. Do not delete unless the post is harmful. Deleting looks worse than being wrong and removes the correction with it.

A visible correction costs one post and buys more credibility than the original take was ever going to earn.

---

## Never fabricate

Hard rule, no exceptions, no exercise of judgment.

- **No invented statistics.** No "studies show," no "roughly forty percent," no plausible number added because the sentence wanted one.
- **No made-up examples presented as real.** A hypothetical is fine when labeled as one. A hypothetical wearing the clothes of a case study is a lie.
- **No claimed experience the user does not have.** If they did not tell you they ran the migration, they did not run the migration. Never write "when I was doing this at scale" on behalf of someone who has not said they did.
- **No implied insider knowledge.** "From what I am hearing," "people close to this tell me," and "I have seen the internal numbers" are off limits unless the user states plainly that it is true and it is theirs to share.

If a piece needs a number the user has not given you, bracket it: `[your number here]`. If the piece only works with a fabricated specific, the piece does not work, and the correct output is the narrower honest version.

---

## The POV bank

This is the habit that makes speed possible, and it is the difference between people who publish something good within hours and people who publish something empty.

The people who look fast are not fast. They are retrieving a position they already held, with the evidence already attached. Everyone else is trying to manufacture a belief in twenty minutes under time pressure, which is exactly how you end up with a platitude.

**What the bank is:** a running file of positions you already hold, with the proof stapled to each one.

**What goes in an entry:**

- **The position**, in one sentence, stated as a claim you would defend
- **Why you hold it:** the experience, the data, the pattern you watched
- **The specific:** the number, the case, the year, the mechanism. Without this the entry is an opinion, not a position.
- **What would change your mind:** the condition or signal that would make you drop it
- **Who it is for:** the audience this matters to most
- **Last reviewed:** a date, because positions rot

**How to build one:**

- Start with five. Not fifty. Write the five things you already argue about at dinner, in client meetings, or in your own head at 2am.
- Add one whenever you catch yourself saying "everyone gets this wrong." That sentence is a position announcing itself.
- Add one after every project that surprised you. The surprise is the evidence.
- Review quarterly. Delete what you no longer believe. Update the date on the rest.
- Attach the receipt at the moment you have it, not later. The number is easy to grab today and impossible to reconstruct in eighteen months.

**How it gets used:** when news breaks, you scan the bank first. If the story touches a position you already hold, you have standing, evidence, and a claim, and the piece takes ten minutes. If it touches nothing in the bank, that is real information: you probably do not have standing on this one.

Format and a filled example in `references/angles.md`.

---

## Commenting as a source

If the goal is press rather than a post, the target is different. A reporter covering a breaking story is under a deadline and drowning in pitches from people who have nothing.

Three lines is the whole message:

1. **Who you are and why you would know.** One line, credential and specific relevance. Not a bio.
2. **The useful thing.** The actual insight, number, or mechanism, stated outright. Give it away in the email. Do not tease it.
3. **How fast you can talk.** A real window today, and your phone number.

Most attempts fail for the same four reasons: they offer availability instead of information, they arrive after the story filed, they pitch the company rather than answer the question the reporter is stuck on, and they demand a call before saying anything useful. A reporter can quote line two directly from your email if it is good. Make that possible.

Send it to the person whose byline is on this story, not to a general inbox. If you have nothing for this story, do not send anything, and do not offer to comment on "anything else you are working on."

---

## How to run this skill

Determine the mode from what the user gives you. All modes end with something written.

**Mode 1: Run the standing test.** The user asks whether to say anything. Run the three questions out loud, give the verdict in one line, then write whatever the verdict points to. Never stop at the verdict.

**Mode 2: Write the post.** Default when a story and a channel are given. Standing test, angle, piece.

**Mode 3: Write a comment for a reporter.** Three to five sentences, quotable in isolation, plus the three-line outreach message if they still need to send it.

**Mode 4: Write a client or customer note.** Lead with what changes for them. No positioning, no upsell inside a news note.

**Mode 5: Build a POV bank entry.** The user has a position and wants it banked. Write the entry in full, and name the missing evidence rather than inventing it.

If the user has not said which channel, pick the most likely one, write it, and say in one line what you would change for a different channel.

---

## Output format

Deliver in this order, every time.

**1. The piece, first.**
In a copy-ready block, complete and publishable. One line above it naming what it is and for which channel. Nothing else above it. No preamble about your process.

**2. The standing verdict and the angle.**
Two lines. `Standing: 3/3` or `Standing: 1/3, narrowed to the operations piece`, then the angle used and why that one. If the test failed, this is where you say so plainly and name what you wrote instead.

**3. One coaching note.**
The single habit that would most improve their next take. Not five notes. Pick the one that costs them the most, and write it so it applies past this story.

**4. At most one question, and only after everything above.**
Only if one fact would materially change the piece. Say what you would change once you have it.

**Hard formatting constraints on everything you produce:**

- No em dashes anywhere, in the piece or in your own commentary. Use a colon, a comma, or a period. This is the most common leak and it usually happens in the coaching note.
- No ellipses.
- No "thoughts?" as a closing line, ever. It is the sound of a post with no position.
- No rhetorical question as an opener.
- Plain words. Short sentences. No "in today's rapidly evolving landscape."
- One exclamation point per piece maximum, and zero in anything touching a serious event.

**Self-check before responding.** Four questions:

1. Is there a complete piece the user could publish right now?
2. Does the first line state a position rather than summarize the news?
3. Is there at least one specific in it that could only have come from this user?
4. Any em dashes?

If any answer is wrong, the response is not finished.

---

## Reference files

Load these when the situation calls for it. Do not load both by default.

- `references/angles.md`: Each of the seven angle types with a worked example, the channel shapes for a short social post, a long social post, a client email, a reporter comment, and an internal team note, plus the POV bank format with a filled entry.
- `references/examples.md`: Full worked examples across different industries, including one where the standing test fails and the narrower honest piece gets written instead, and one where the correct answer is public silence plus an internal note.

---

## The final gate

Five questions before anything publishes. If any answer is no, it is not ready.

1. If you deleted the news from this piece, would anything of value remain?
2. Is there one thing in it a reader could not have gotten from the coverage?
3. Would you still stand behind this in six months, if the story turned out differently?
4. Does the connection to your work exist without being explained?
5. Are you adding to what the reader knows, or adding to the noise they are already scrolling past?

Question three is the one people skip. Write for the version of this story that is true in six months, not the version that is trending tonight.
