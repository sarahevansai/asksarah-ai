# Timely POV

A Claude skill that turns a breaking story into a credible point of view, fast, without embarrassing yourself.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Something big happens in an industry. Within four hours, a thousand people post about it, and almost all of it is worthless, because it summarizes news the reader already read and adds a platitude.

The posts that land do one thing the others do not: they add information or judgment the reader could not get from the news itself. Speed matters. Standing matters more. Most people have neither and post anyway.

Paste in the story, or just describe it, and Claude will:

1. Run the standing test and tell you plainly whether you have anything to say
2. Pick the angle and write the finished piece, ready to publish or send
3. Give you one coaching note that applies to every news cycle after this one

**You always get something publishable.** If the standing test passes, you get the piece. If it fails, you get one line saying so and the honest alternative, which is usually a narrower piece about the part you genuinely do know. If the right answer is public silence, you get the internal note and the holding line for anyone who asks instead. You never get a list of possible angles with nothing written.

It works for LinkedIn and X posts, comments for reporters, client and customer notes, internal team messages, newsletters, and founder statements.

Three things it does that a general writing tool will not:

**It tells you not to post.** Not commenting is a legitimate choice and often the correct one. The cost of a hollow take is real: every empty post trains your audience that your posts are empty, so the one time you have something worth reading, fewer people stop.

**It knows which events are off limits.** Tragedy, active crises, anything that converts someone's harm into your marketing, ongoing legal matters involving named people, and political flashpoints where you have no stake. It also knows the difference between an inappropriate moment and one that genuinely calls for a response, because some hard events do.

**It will not make anything up.** No invented statistics, no hypotheticals dressed as case studies, no claimed experience you did not describe, no implied insider knowledge. Anything it does not know comes back in `[BRACKETS]`.

## The Standing Test

Three questions, run before a word gets written:

1. **Do you know something about this that the reader does not?** Direct experience, data, a mechanism you understand, a consequence others have not traced.
2. **Would you have said this a week ago?** If the position is new because the news is new, it is a reaction, not a point of view.
3. **Can you be specific without pretending?** If everything you can honestly say is general, posting anyway spends credibility that took years to build.

Three yes means write it. Two means write the narrower version. One or zero means do not post the take, and here is what to do instead.

## The seven angles

The mechanism. The second-order effect. The practitioner's view. The contrarian data point. The pattern. The translation. The honest uncertainty.

One piece, one angle, each with a worked example and a note on when it works and when it fails.

## The shape

Every piece, every channel, four parts in order:

1. **The claim** in the first line, your position and not a summary of the news
2. **The specific**, the number, the mechanism, the example, the experience
3. **The consequence**, what this means for the reader, concretely
4. **The open**, what to watch, what you are unsure about, or one real question

Plus a hard rule against restating the news in the first paragraph. The reader already knows, or they would not be reading.

## The POV bank

The durable habit that makes speed possible. People who look fast are not fast, they are retrieving a position they already held with the evidence attached, while everyone else manufactures a belief in twenty minutes under deadline. The skill will build bank entries with you and tell you what evidence is missing rather than inventing it.

## Try it

Once installed, say any of these:

- "Should we post about this?" and paste the headline
- "Everyone is talking about this and I want to weigh in"
- "Write a take on this for LinkedIn"
- "A reporter asked me about this and I have twenty minutes"
- "Do our clients need to hear from us about this?"
- "Help me build a POV bank entry on this"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `timely-pov.zip` in your skills settings. Claude loads it automatically whenever a news reaction is on the table.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/timely-pov/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste any headline from your industry, and ask "should we post about this?" You should get a standing verdict, a finished piece, and one coaching note.

## What is in the package

```
timely-pov/
├── SKILL.md              The standing test, the angles, the shape, the rules
├── README.md             This file
├── LICENSE
└── references/
    ├── angles.md         The seven angles worked in full, the channel shapes, the POV bank format
    └── examples.md       6 full runs across different industries, including two where the answer is not a post
```

## Notes

Claude will verify before it commits. Early reports of any developing story are routinely wrong, and the skill will say so rather than sharpening a take on a fact that gets retracted six hours later. Being late is survivable. Being wrong is searchable.

It will ask at most one question, and only after the piece is already in front of you.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
