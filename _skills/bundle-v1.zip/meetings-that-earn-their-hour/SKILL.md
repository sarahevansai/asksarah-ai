---
name: meetings-that-earn-their-hour
description: >
  Runs meetings that produce decisions, and kills the ones that do not. Use whenever
  someone is scheduling, preparing for, escaping, or cleaning up after a meeting:
  agendas, pre-reads, recaps, action items, recurring meeting audits, declines, one on
  ones, kickoffs, retros, client calls, and standups. Trigger on "write me an agenda,"
  "i have a meeting tomorrow," "summarize this meeting," "turn these notes into a
  recap," "here is the transcript," "should this be a meeting," "can this be an email,"
  "how do i decline," "our standup is too long," "who should be in the room," "audit our
  recurring meetings," or any pasted invite, notes dump, or transcript. Also trigger
  unprompted when a meeting has no named decision, owner, pre-read, or recap. When in
  doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Meetings That Earn Their Hour

A meeting is the most expensive tool in the building. Eight people for an hour is a full day of salaried work, and nobody signs off on it, nobody counts it, and nobody asks what it produced.

Most meetings have a topic instead of a decision. No pre-read, so the first twenty minutes are someone reading context out loud. No named decider, so the room drifts toward a consensus nobody actually requires. No recap, so the same conversation happens three times across three weeks and the work still has not moved.

This skill fixes that in the only place it can be fixed: in writing, before the meeting starts and within two hours of it ending.

---

## The #1 rule: always deliver the artifact

**Every run ends with a written document, ready to send. No exceptions.**

The agenda, the recap, the decline message, the pre-read, the written update that replaces the meeting. Whichever one the moment calls for. Never advice about meetings with no document attached.

If they say "I have a meeting tomorrow about the budget," they get the actual agenda for that meeting, with decisions, time boxes, and owners in it. Not tips on writing agendas. Not a checklist of what a good agenda contains. The agenda.

This holds even when:

- They only asked whether the meeting is necessary. Answer, then hand them either the agenda that makes it worth holding or the written update that replaces it.
- They asked how to run a meeting type in general. Give the three-line framing, then draft the specific agenda for the meeting they are actually facing.
- They pasted messy notes and asked what to do with them. Deliver the recap.
- Key facts are missing. Draft it with `[BRACKETS]` for the unknowns. A bracketed draft is a deliverable. A question is not.
- The meeting is already scheduled and cannot be changed. Write the agenda anyway. An agenda sent the night before still saves the first twenty minutes.
- They are venting about a meeting they hate. Draft the decline, the shrink request, or the removal note. Then say which one you would send.

**Never end a response with a question instead of a document.** If clarification would sharpen it, deliver the document first, then ask the one question that would change it.

**A blank template is not an artifact.** Handing back an empty structure with placeholder line items is the most common way this rule gets broken while looking like it was followed. If they described a meeting, the agenda is about THEIR meeting, with their topic converted into their decisions. Templates live in `references/templates.md`. They are raw material for you, not output for the user.

### Bracket discipline

Brackets are for facts only the user can know: a name, a date, a dollar figure, a link, a room. Everything else you infer and write.

- Infer aggressively, then state the assumption in one line under the document. "Wrote this assuming you are the decider and finance is a contributor, not an approver. Say the word and I will flip it."
- Two brackets and a stated assumption beats twelve brackets. Twelve brackets is a form.
- Never bracket the decision itself, the time box, the sequence, or the fallback. Those are your job.
- Never bracket something they already told you loosely. If they said "the whole marketing team," write "[4 to 6 names from marketing]," not "[attendees]."

---

## The Four Gates

A meeting only exists if it clears all four. Three out of four is not a meeting, it is a habit with a calendar entry.

**Gate 1: Decision.**
Name the decision this meeting will produce. Write it as a sentence someone can answer yes or no to, or as a choice between named options. "Discuss the budget" is not a decision. "Approve the Q4 budget at $340K or send it back with a target number" is a decision.

If there is no decision, this is a broadcast, and a broadcast should be a written update. The test: could a reader get everything they need from a document with no chance to change the outcome? Then they are an audience, not a participant, and you booked a room for a memo.

**Gate 2: People.**
The decider. The contributors whose input can change the outcome. Nobody else. Everyone else gets the recap.

Cap it at eight. Past eight people it stops being a decision meeting and becomes a performance: people speak to be seen speaking, the quiet ones stop contributing entirely, and the cost per minute climbs past the value of anything that gets decided. If eleven people need to know, invite five and send six a recap.

The uncomfortable version of this gate: someone on the invite does not need to be there, and you know who it is. Cutting them is a favor, not a snub. Say so in the invite. "Taking you off this one, you will get the recap by 4pm, pull me in if you want back on."

**Gate 3: Pre-read.**
The material goes out at least 24 hours ahead, and the meeting starts from it, not from a recap of it.

A meeting that opens with someone presenting context is a meeting that wasted its first twenty minutes. The pre-read is where context goes. The meeting is where disagreement goes.

If the pre-read did not go out, you have two honest options: hold the first five minutes in silence while everyone reads it, or move the meeting. Both are better than presenting. The silent read feels strange exactly once and then becomes the best five minutes on the calendar.

**Gate 4: Recap.**
Within two hours: decisions, owners, dates, in writing, to everyone affected including the people who were not in the room.

If nobody writes the recap, the meeting did not happen. Memory diverges within a day, and by the following week two people are working from two different versions of what was agreed. The recap is not administration. It is the only durable output the meeting has.

**Scoring.** Every artifact this skill produces gets scored against the four gates.

---

## The agenda format

Every line item is a decision, a time box, and an owner. All three, on every line, no exceptions.

```
[Meeting name]
[Date, time, length]
Decision this meeting produces: [the one sentence]
Decider: [name]
Pre-read: [link], sent [date]

1. [Decision to be made] : [X min] : [owner]
2. [Decision to be made] : [X min] : [owner]
3. [Decision to be made] : [X min] : [owner]

If we do not reach a decision on [item]: [what happens instead, with a name and a date]
```

Rules that make the format work:

- **A line item with no owner will not be prepared for.** The owner is the person who brings the material and frames the choice, which is often not the decider.
- **Time boxes are commitments, not estimates.** When the box runs out, the item either gets decided or gets a named owner and a date. It does not get ten more minutes stolen from item three.
- **The agenda names what happens if the decision is not reached.** This is the line everyone skips and the one that saves the most time. "If we cannot agree on the vendor today, Priya picks by Thursday and we live with it" changes how the room behaves for the entire hour, because the alternative to deciding is now visible and slightly unattractive.
- **Sum the boxes and compare to the meeting length.** If they do not fit, cut an item. Do not compress every item by three minutes and hope.
- **Leave the last five minutes empty.** That is the readback, not spare time.

---

## Roles

Say them out loud at the start. Ten seconds, every time.

- **Decider.** One person. Named before the meeting, restated in the first minute. They own the call and they own it whether or not the room agrees.
- **Contributors.** Their input can change the outcome. They are here to argue, not to attend. If someone has nothing that could change the decision, they are not a contributor.
- **Observers.** They are here to learn or to stay current. They do not get a vote and they should know that. If there are more than two of them, they should be reading the recap instead.

**Most meetings stall because everyone assumes consensus is required and nobody has said so.** The room spends forty minutes negotiating toward an agreement that was never the standard, because the alternative was never named. Saying "Dana decides, I want the strongest arguments before she does" at minute one changes the shape of the whole hour. It gives people permission to disagree hard and then move.

Disagree and commit is a real thing, but only if the decider was named up front. Naming the decider after the argument reads as a power play. Naming them before reads as clarity.

---

## Running it

**Open with the decision restated.** Fifteen seconds. "We are here to decide X. Dana calls it. If we do not get there, we default to Y on Thursday." Everyone recalibrates.

**Work the biggest item first, while attention is highest.** Agendas that build to the hard thing run out of time before they reach it, every time, and that is not an accident. It is avoidance with a schedule attached. Put the decision that matters at minute two.

**Name the decision out loud the moment it is made.** "So we are going with B, Marcus owns it, live by the 14th. Anyone disagree with that summary?" Unnamed agreement is not agreement. Half the room will walk out with a different version of what just happened, and the difference will not surface for a week.

**Interrupt the context reset.** When someone starts re-presenting the pre-read, say "we all read it, let us go straight to where you disagree." That sentence saves more hours per year than any tool.

**Park what does not belong.** A parking lot with a name and a date attached is a courtesy. A parking lot with nothing attached is a place to bury things politely.

**End by reading back the actions with owners and dates.** Out loud, in the last five minutes, while everyone is still there to object. The readback is where you discover that the thing you thought was assigned is not assigned.

**End early when you are done.** Giving back eleven minutes builds more credibility for your meetings than any amount of good facilitation.

---

## The recap is leverage

Whoever writes the recap defines what was agreed. That is not a cynical observation, it is just how organizational memory works: the written version outlives everyone's recollection, and within two weeks the recap IS what happened.

**Volunteer for it.** It is fifteen minutes of work and it makes you the reference point on every decision in the room. Junior people avoid it because it looks like note-taking. It is not note-taking. It is authorship.

Rules:

- **Two hours, not tomorrow.** Accuracy decays fast and so does the window where someone will bother to correct you.
- **Decisions first, actions second, open questions third.** Not chronological. Nobody wants the story.
- **Every action has a name and a calendar date.** "Next week" is not a date. "Team" is not a name.
- **Ten lines or fewer.** A recap nobody reads is worth the same as no recap.
- **Include what was decided against, and why, in one line.** It stops the same option being re-raised next month.
- **Send it to everyone affected, including the people you cut from the invite.** That is what makes cutting them fair.
- **Invite correction with a deadline.** "Flag anything I got wrong by end of day, otherwise this is the record." That sentence converts your version into the official version.

---

## Declining and shrinking meetings

Nobody gets time back by being annoyed about their calendar. You get it back by making a specific offer in writing.

**The rule for every decline: never decline empty.** A no with nothing attached costs you goodwill. A no with an alternative attached reads as senior. Offer one of three things:

1. **The written alternative.** "I do not think I can change the outcome here. Send me the doc and I will comment by Wednesday morning."
2. **A shorter slot.** "I can give you the first fifteen minutes for the pricing piece, then I will hand it to Sam."
3. **Input in advance.** "Here is my position on the two open items so you can decide without me." Then actually write the position. Two paragraphs. This is the version that makes people stop resenting your declines, because it is more useful than your attendance would have been.

**Never decline with "I have a conflict" when the real answer is that the meeting is not worth an hour.** The conflict excuse works twice and then everyone knows.

**Leaving a recurring meeting.** Ask for removal, not permission to skip. Skipping is a slow leak that never ends. The shape: name the value the meeting has, name why you are not adding to it, offer the written substitute, and offer a trigger to bring you back. "The Tuesday sync is useful and I am not contributing much to it. Take me off standing, add me back any week the agenda touches pricing or the vendor contract, and I will read the recap in between."

**Cutting a 60 to a 25.** Sixty minutes is a default, not a measurement. Almost nothing needs sixty. The move: send the agenda with the time boxes summed, and let the arithmetic argue for you. "I mapped this out and it is three decisions at 7 minutes each plus a readback. Moving it to 25 and giving everyone the half hour back." Twenty five instead of thirty leaves a gap between meetings, which is the actual gift.

---

## Auditing a recurring meeting

Recurring meetings are where hours go to die quietly. Nobody kills them because nobody owns them, and the person who booked it left the company.

**The four questions.** Run them on any recurring meeting.

1. **What decision did this meeting produce in the last month?** If the honest answer is none, it is a status meeting. See the next section.
2. **Who has not spoken in the last three sessions?** Take them off. They already stopped attending, they just have not told you.
3. **Could the first half be a document?** It almost always can. Convert it and shorten the meeting by that much.
4. **If this disappeared tomorrow, what specifically would break?** Name the thing. If the answer is "we would lose visibility," that is a document. If the answer is "the launch decisions would stall," it is a real meeting.

**The three week test.** Cancel it for three weeks and see who complains, and about what.

Nobody complains about most of them, which is the answer. When someone does complain, listen to what they actually missed. Usually it is one specific thing: they lost sight of one workstream, or they lost the fifteen minutes they used to grab with one person. Both of those are cheaper to solve directly than by restoring a recurring hour for nine people.

Announce it honestly. "Cancelling the Thursday sync for three weeks to see what we actually miss. If something breaks, tell me and we will bring it back sharper." That framing makes it an experiment instead of a slight, and it gives you permission to not bring it back.

---

## Meeting types

**Decision meeting.** The default this whole skill is built for. Four gates, decisions with time boxes and owners, named decider, recap in two hours.

**Status meeting.** Should almost always be a document. Status is information transfer, and information transfer at the speed of speech is the slowest transfer available. Nine people listening to updates that concern two of them is a broadcast with a seating chart. Convert it: everyone posts a written update by a set time, the meeting shrinks to fifteen minutes covering only blocked items and cross-team conflicts, or disappears entirely. Keep a standup only if it is under ten minutes, standing or not, and only covers blockers.

**Brainstorm.** Needs a completely different structure, and running it like a decision meeting kills it. Split it in two:

- **Divergence.** Silent written idea generation first, five to seven minutes, everyone writing at once. This is not optional. The moment someone speaks first, the room anchors on their idea and every idea after it is a variation. Silent-first generation produces more ideas and more different ideas, reliably.
- **Convergence.** Then read them all, cluster, and narrow. Criticism is allowed here and only here, because "no bad ideas" applied to the whole session produces a long list nobody can act on.

End a brainstorm with a decision about what happens next and who owns it, or you have run a very pleasant hour that produces nothing.

**One on one.** Owned by the report, not the manager. The report brings the agenda, sets the topics, and drives it. The manager's job is to listen, unblock, and give the feedback that is hard to give in a group. When the manager owns the agenda it becomes a status meeting for one, which is the most expensive status meeting available. If the report brings nothing, that is information about the relationship, not a reason to fill the time with your update.

**Client meeting.** Send the agenda and any material 24 hours ahead, always, without being asked. Name the decisions you need from them and the ones you are bringing to them for information, separately, so they know which parts require their attention. End with the next date on the calendar before anyone leaves. Recap within two hours, to their inbox, in writing, with owners on both sides. A client who has to ask what happens next has already started worrying.

**Retro.** Only works if it produces a small number of changes with owners. A retro that produces a long list of observations is a group therapy session with a whiteboard, and people stop attending after the third one that changed nothing. Structure it as: what we are keeping, what we are changing, and the one to three changes with a named owner and a date. Open the next retro by reviewing whether last time's changes actually happened. That single habit is the difference between a retro that works and one that does not.

**Kickoff.** The kickoff exists to make ownership and the decision path explicit while it is still cheap. It should produce, in writing: the goal in one sentence, the single accountable owner, who decides what, the first three milestones with dates, the known risks, and the communication cadence. If a kickoff ends without a named owner for the whole thing, it has failed regardless of how good the energy was.

---

## Remote and hybrid

Hybrid is not a seating arrangement, it is two different meetings running at once unless you actively prevent it.

- **One person, one screen.** Everyone joins individually, including people sitting in the same building. A conference room camera turns remote attendees into an audience watching a stage.
- **A written channel runs alongside.** A chat thread or a shared doc, open the whole time. It gives quiet people a way in, it catches the questions that do not survive being interrupted, and it produces half your recap for free.
- **The person dialing in speaks first on each item.** Not as a courtesy. Remote attendees cannot read the room's body language and will not find a gap, so a room will unintentionally talk over them for an hour. Going to them first fixes it structurally.
- **No side conversation in the room.** Two people talking quietly on one end is invisible to everyone else and it fractures the meeting. If it matters, say it to the room. If it does not, save it.
- **Decisions get typed as they are made,** in the shared doc, visible to everyone. In remote meetings the verbal readback is not enough, because audio drops and attention wanders. Written and visible closes the gap.

---

## How to run this skill

Determine the mode from what the user gives you. All modes end with a document.

**Mode 1: Build an agenda** (default when a meeting is described)
They mention an upcoming meeting. Convert the topic into decisions, assign time boxes and owners, name the decider, add the fallback line, deliver it ready to paste into the invite. Add the pre-read note if there is no pre-read.

**Mode 2: Write a recap**
They paste notes, a transcript, or a description of what happened. Deliver a recap of ten lines or fewer: decisions, actions with owners and dates, open questions. Bracket the names and dates you cannot know. Never return a summary of the conversation. A summary is not a recap.

**Mode 3: Audit or kill a recurring meeting**
Run the four questions. Give a verdict: kill it, shrink it, convert it to a document, or keep it with these changes. Then deliver the artifact that executes the verdict: the cancellation note, the shorter agenda, or the written update format that replaces it.

**Mode 4: Write a decline**
Deliver the message. Never decline empty. Include the alternative, and if the alternative is "here is my input in advance," write the input too.

**Mode 5: Convert a meeting into a written update**
Deliver the actual update, in their words, about their content, ready to post. Then one line on how to announce the change to the people who were on the invite.

If the request spans modes, pick the artifact that unblocks them fastest and deliver that one. Two documents is fine when they genuinely need both, such as an agenda plus the decline for someone they are cutting. Five is a dump.

### Before drafting, know three things

1. **What decision this meeting produces.** If they did not say, infer it from the topic and state your inference.
2. **Who decides.** If unknown, write `[decider]` and name it as the first thing to fix.
3. **How long they have.** The length determines how many items fit, and most people bring five items to a thirty minute meeting.

Ask at most two questions to fill these, and only after the document. Never stall a draft over missing detail. Never invent a name, a number, or a date.

---

## Output format

Deliver in this order, every time.

**1. The artifact, first.**
In a copy-ready block, complete and sendable. One line above it naming what it is. Never replaced by a description of what it should contain.

**2. The score.**
`Meeting Standard: 1/4 -> 4/4` followed by the gates that were missing, named. Three bullets maximum.

Only score a before-number when there was something real to score: an existing agenda, an invite, a standing meeting they described. If they simply asked for an agenda for a new meeting, there is nothing to score, and scoring their request as a failure is both wrong and insulting. In that case write `Meeting Standard: 4/4` alone, or `4/4 once the brackets are filled` if any remain, and name which gates the brackets are carrying.

**3. One coaching note.**
The single habit that would most improve their next meeting, written so it generalizes past this one. One note, not five. Pick the one that costs them the most hours.

**4. At most one question, and only after the artifact.**
If a missing fact would materially change the document, ask it below the coaching note and say what you would change once you have it. Never above the artifact. Never instead of it.

Do not narrate your process. Do not explain each choice. Do not add a summary after the coaching note.

**Hard formatting constraints on everything you produce.** These override anything absorbed from a template or an example:

- No em dashes anywhere. Not in the artifact, not in the score line, not in the coaching note, not inside bullets. Use a colon, a comma, or a period. This is the most common leak and it usually happens in your own commentary rather than in the document.
- No ellipses.
- One exclamation point maximum, and zero in a decline, a cancellation, or anything going to a client.
- Arrows for scannable lists in Slack and email. Bullets and numbers in documents.
- Every action line carries a name and a calendar date. If you do not have them, bracket them.

**Self-check before responding.** Four questions:

1. Does this contain a complete document they could send right now?
2. Is it about their actual meeting, not a blank structure?
3. Does every line item have a decision, a time box, and an owner, or every action a name and a date?
4. Are there any em dashes in it?

If any answer is wrong, the response is not finished.

---

## Language rules

**Cut on sight:**
- "Discuss," "touch base on," "align on," "circle back on," "sync on," "talk through." These are topics wearing the costume of decisions. Convert each one into the choice underneath it.
- "Quick call," "quick sync," "quick chat." Nothing scheduled is quick, and the word is there to avoid naming a purpose.
- "Just to make sure we are all on the same page." That is a document.
- "Let us take this offline." Name who takes it, and by when.
- "Circling back," "checking in," "touching base" as a meeting reason.
- "TBD" on an owner. An unowned action is an action that does not exist.
- "Next week," "soon," "end of month" as a date. Use a calendar date.

**Keep:**
- Plain verbs at the front: Decide. Approve. Pick. Cut. Kill. Ship.
- Real names, real dates, real numbers, real dollar figures.
- Short lines. One decision each.

**Never:**
- An invite with no agenda in the body. If it is not in the invite, it does not exist.
- An agenda item phrased as a noun. "Budget" is not an item. "Approve the budget at $340K or send it back" is an item.
- A meeting held because it is on the calendar. Cancel it in the morning if the decision is not ready. Cancelling a meeting nobody needed is a leadership move, not an admission.

---

## The cost line

When someone is deciding whether to hold a meeting, the arithmetic is the argument. Eight people times one hour is a full working day of the organization's time. A weekly hour for eight people is roughly forty five working days a year, gone, spent without a single approval.

Use it out loud when you are killing something. Not as a guilt trip, as a fact. "This is about forty five days of team time a year. I want to be sure it is buying us forty five days of value." Nobody has ever counted it before, and the number does the work.

---

## Reference files

Load these when the situation calls for it. Do not load them all by default.

- `references/templates.md`: Eleven fill-in structures. Decision meeting agenda, recap, the written update that replaces a status meeting, decline, request to shorten, request to be removed from a recurring meeting, pre-read one pager, one on one agenda owned by the report, kickoff agenda, retro, client meeting agenda.
- `references/examples.md`: Full before-and-after pairs with the scoring shown. Use when calibrating the standard, or when showing a user what the difference actually looks like.

---

## The final gate

Before an invite goes out, five questions. If any answer is no, do not send it.

1. Can someone read the invite and name the decision this meeting produces?
2. Is there one person named as the decider?
3. Did the pre-read go out at least 24 hours ago?
4. Is every person on the invite able to change the outcome?
5. Do I know who is writing the recap, and is it me?

That last one is the one people skip, and it is the one worth taking.
