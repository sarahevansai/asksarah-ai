# Meetings That Earn Their Hour

A Claude skill that runs meetings which produce decisions, and kills the ones that do not. You always get the document: the agenda, the recap, the decline, the pre-read, the written update that replaces the meeting entirely.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most meetings have a topic instead of a decision. No pre-read, so the first twenty minutes are someone reading context out loud. No named decider, so the room drifts toward a consensus nobody actually required. No recap, so the same conversation happens three times across three weeks and the work still has not moved.

The cost is measured in salaried hours and nobody counts it. Eight people for an hour is a full working day of the organization's time. A weekly hour for eight people is roughly forty five working days a year.

Describe a meeting, paste an invite, dump your notes, or complain about a recurring call, and Claude will:

1. Hand you the finished document, ready to send
2. Score it against four gates, so you see exactly what was missing
3. Give you one coaching note that applies to every meeting after this one

**You always get a document back.** Say "I have a meeting tomorrow about the budget" and you get the actual agenda for that meeting, with decisions, time boxes and owners in it. Not tips on writing agendas. Missing a name or a date? It comes back in `[BRACKETS]` to fill, not as a question you have to answer first.

## The Four Gates

A meeting only exists if it clears all four. Three out of four is not a meeting, it is a habit with a calendar entry.

1. **Decision.** Name the decision this meeting will produce. "Discuss X" is not a decision. If there is no decision, it is a broadcast and it should be a written update.
2. **People.** The decider, the contributors whose input can change the outcome, and nobody else. Everyone else gets the recap. Cap it at eight. Past eight it stops being a decision meeting and becomes a performance.
3. **Pre-read.** Material goes out at least 24 hours ahead and the meeting starts from it. A meeting that opens with someone presenting context wasted its first twenty minutes.
4. **Recap.** Within two hours: decisions, owners, dates, in writing. If nobody writes the recap, the meeting did not happen.

Plus the agenda format that makes the gates hold: every line item is a decision, a time box, and an owner, and the agenda names what happens if the decision is not reached.

## What it covers

**Building the agenda.** Your topic converted into decisions, sequenced biggest first, time boxed, owned, with the fallback line that changes how the room behaves for the whole hour.

**Writing the recap.** Paste your notes or a transcript and get ten lines back: decided, not doing and why, actions with names and calendar dates, still open. Plus the correction deadline that turns your version into the official record. Whoever writes the recap defines what was agreed, which is why you should volunteer for it.

**Killing or fixing a recurring meeting.** Four questions that produce a verdict, the three week cancellation test, and the document that replaces the meeting when the verdict is "this is a status meeting."

**Getting out of meetings without damage.** Declines that come with an alternative attached, requests to cut a 60 to a 25 with the arithmetic doing the arguing, and the note that gets you off a standing invite permanently instead of skipping it forever.

**Meeting types that need different rules.** Decision meetings, status meetings that should be documents, brainstorms with a divergence and convergence split, one on ones owned by the report rather than the manager, client meetings, retros, and kickoffs.

**Remote and hybrid.** One person one screen, a written channel running alongside, the person dialing in speaks first on every item, no side conversation in the room.

## Try it

Once installed, say any of these:

- "I have a meeting tomorrow about the budget, write me the agenda"
- "Turn these notes into a recap" and paste your notes
- "Do we still need our Monday sync?"
- "How do I get out of this recurring call?"
- "Cut this 60 minute meeting down"
- "Should this be a meeting or an email?"
- "Write the agenda for our kickoff"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `meetings-that-earn-their-hour.zip` in your skills settings. Claude loads it automatically whenever a meeting comes up.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/meetings-that-earn-their-hour/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "I have a meeting Thursday about our vendor decision." You should get a full agenda with decisions, time boxes and owners, a score out of 4, and one coaching note.

## What is in the package

```
meetings-that-earn-their-hour/
├── SKILL.md                  The Four Gates, the agenda format, the running rules, output format
├── README.md                 This file
├── LICENSE
└── references/
    ├── templates.md          11 fill-in structures: agendas, recaps, declines, pre-reads, retros
    └── examples.md           5 before-and-after pairs with the scoring shown
```

## Notes

Claude will never invent a name, a date, a number, or a decision to fill a gap. Anything it does not know comes back in `[BRACKETS]`. A confident agenda built on a made-up owner is worse than no agenda.

It will ask at most one question, and only after the document is already in front of you. Nothing is held back waiting on an answer.

It is opinionated on purpose. It will tell you a meeting should not exist. That is the part that gives you the hours back.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
