# Meeting Templates

Eleven structures for the meetings and the messages around them. Each one already clears the Four Gates. Fill the brackets. Cut what does not apply. Never add a paragraph of context above the first line.

These are raw material for you, not output for the user. Everything you hand back is filled in with their situation.

---

## 1. Decision meeting agenda

Goes in the body of the invite, not in an attachment. If it is not in the invite, it does not exist.

```
[Meeting name]
[Day, date, start time, length]

Decision this meeting produces: [The one sentence, answerable yes or no, or a choice between named options.]
Decider: [name]
Pre-read: [link]. Sent [date]. Please read before we start.

1. [Decision to be made] : [X min] : [owner]
2. [Decision to be made] : [X min] : [owner]
3. [Decision to be made] : [X min] : [owner]
4. Readback of actions and owners : 5 min : [facilitator]

If we do not reach a decision on [item 1]: [name] decides by [date] and we proceed.

In the room: [name, role] x [n]
Getting the recap instead: [names]
```

Rules: biggest decision first. Time boxes sum to the meeting length with five minutes left for the readback. Every item has all three parts. If an item has no owner, it will not be prepared for and it will eat the meeting.

---

## 2. Meeting recap

Send within two hours. Ten lines or fewer.

```
[Meeting name]: [date]

DECIDED
1. [Decision]. [One line of why, if it will be asked again.]
2. [Decision].

NOT DOING
→ [The option we ruled out] because [one line]. Reopening this needs [new information].

ACTIONS
→ [Name]: [action], by [calendar date]
→ [Name]: [action], by [calendar date]

STILL OPEN
→ [Question]. [Name] brings an answer by [date].

Flag anything I got wrong by [end of day / time]. Otherwise this is the record.
```

Rules: decisions before actions, never chronological. Every action has a name and a calendar date. The "not doing" section is what stops the same option coming back next month. The correction deadline is what converts your version into the official version.

---

## 3. Written update that replaces a status meeting

The document that lets you cancel the recurring hour. Posted on a fixed day and time, every week, in a channel where everyone can see everyone else's.

```
[Workstream or name]: week of [date]
Status: [On track / At risk / Blocked]

SHIPPED
→ [Result]. [Number or impact]. [Link]

IN FLIGHT
→ [Item]: on track for [date]
→ [Item]: on track for [date]

BLOCKED
→ [Item]. Blocked on [specific thing] from [name]. Need it by [date] to hold the date.

DECISIONS I NEED
→ [Decision] from [name] by [date]. If I do not hear back I will [default].

Nothing else needs a meeting.
```

Rules: same day, same time, every week, or it decays in three weeks. "Blocked: nothing" is a required line, because a missing section reads as an oversight. The only thing that earns a live conversation is a blocker or a cross-team conflict, and those get fifteen minutes, not sixty.

---

## 4. Declining a meeting

```
Hi [name],

I do not think I can change the outcome on [topic], so I am going to skip this one.

[Pick one:]
→ Send me the doc and I will comment by [date and time].
→ I can take the first [X] minutes for [the piece where you matter], then hand it to [name].
→ Here is my position on the open items so you can decide without me:
   [Item 1]: [your actual position, one or two lines]
   [Item 2]: [your actual position, one or two lines]

Pull me back in if [the specific condition that would make you necessary].
```

Rules: never decline empty. Never use "I have a conflict" when the real reason is that the meeting is not worth an hour. If you offer input in advance, actually write the input. That version is more useful than your attendance and it is why nobody resents your declines.

---

## 5. Request to shorten a meeting

Let the arithmetic do the arguing.

```
[Name], I mapped [meeting] against what we actually decide in it.

It is [n] decisions:
→ [Decision]: [X] min
→ [Decision]: [X] min
→ Readback: 5 min

That is [total] minutes. Moving it to [25 / 40] and sending the pre-read [the day before] so we start from it instead of presenting it.

Same decisions, [X] minutes back for everyone. Say the word if you want the full hour held.
```

Rules: 25 instead of 30 and 50 instead of 60. The gap between meetings is the actual gift. Never propose a shorter meeting without the summed agenda attached, because without it you are asking for a favor rather than presenting a finding.

---

## 6. Request to be removed from a recurring meeting

Ask for removal, not permission to skip. Skipping is a slow leak that never closes.

```
[Name], a request on the [meeting name].

It is a useful meeting and I am not adding much to it. I have not had an item in [n] weeks.

Asking to come off the standing invite. Two things so nothing drops:
→ I will read the recap every week.
→ Add me back any week the agenda touches [the specific topic where you matter]. I will make it a priority.

Happy to keep going if you want me there. Just did not want to hold a seat I am not using.
```

Rules: name the value first. Name why you are not adding to it, honestly. Offer the substitute and the trigger that brings you back. The trigger is what makes it a reallocation rather than an exit.

---

## 7. Pre-read one pager

Goes out 24 hours ahead. One page. If it is longer than a page, the meeting is going to be longer than it needs to be.

```
Pre-read: [meeting name], [date]

THE DECISION
[One sentence. What we are choosing between, and by when.]

WHY NOW
[Two lines. What changed, what it costs to wait.]

THE OPTIONS
Option A: [what it is]
  Cost: [$X / X weeks]. Upside: [one line]. Risk: [one line].
Option B: [what it is]
  Cost: [$X / X weeks]. Upside: [one line]. Risk: [one line].

RECOMMENDATION
[Option] because [one reason tied to a number or a risk].

WHAT I NEED FROM YOU IN THE ROOM
[The specific disagreement or input you want. Name the thing you are least sure about.]

[Link to the supporting detail, for anyone who wants it.]
```

Rules: the recommendation goes in the pre-read, not saved for the meeting. Holding it back to reveal it live wastes the room's preparation and turns a decision meeting into a presentation. Naming what you are least sure about is what gets you real input instead of polite agreement.

---

## 8. One on one agenda, owned by the report

The report brings this. The manager does not write it.

```
[Name] / [Manager]: [date]

MY AGENDA
1. [Topic the report wants to cover]
2. [Topic the report wants to cover]

WHERE I AM STUCK
→ [The thing]. What I have tried: [one line]. What I need: [decision / intro / cover / nothing, just visibility].

WHAT I WANT YOU TO KNOW
→ [The win, with the number, so it is on the record.]
→ [The risk you are watching, so it is not a surprise later.]

FOR YOU
→ [Anything you want to raise with me.]

DECISIONS I NEED FROM YOU
→ [Decision] by [date].
```

Rules: the report drives it. When the manager owns the agenda it becomes a status meeting for one, which is the most expensive status meeting available. "For you" goes near the end and stays small, or it takes over. If the report brings nothing three times running, that is information about the relationship, not a reason for the manager to fill the time.

---

## 9. Kickoff agenda

The kickoff exists to make ownership and the decision path explicit while it is still cheap to argue about.

```
[Project] kickoff
[Date, 45 min]

Decision this meeting produces: Confirm the owner, the first three milestones, and who decides what.
Pre-read: [the one page brief], sent [date]

1. Goal in one sentence, and what "done" looks like : 5 min : [owner]
2. Confirm the single accountable owner : 5 min : [decider]
3. Who decides what: scope, budget, launch date : 10 min : [owner]
4. First three milestones with dates : 10 min : [owner]
5. Known risks and who is watching each : 8 min : [owner]
6. Cadence: what gets written, how often, where : 2 min : [owner]
7. Readback : 5 min : [facilitator]

If we cannot agree the owner today: [name] assigns by [date].

Output, in writing, within 2 hours: goal, owner, decision rights, three milestones, risks, cadence.
```

Rules: if a kickoff ends without one named accountable owner for the whole thing, it failed, regardless of how good the energy was. Decision rights is the item everyone wants to skip and the one that prevents the argument in week six.

---

## 10. Retro structure

```
[Team / project] retro: [period]
[45 min]

0. Did last retro's changes actually happen? : 5 min : [facilitator]
   → [Change]: [done / not done]. [If not done: is it dead or is it late?]

1. Silent writing: what to keep, what to change : 7 min : everyone
2. Read out and cluster : 10 min : [facilitator]
3. Pick 1 to 3 changes, no more : 15 min : [decider]
4. Assign owner and date to each : 5 min : [facilitator]
5. Readback : 3 min : [facilitator]

CHANGES WE ARE MAKING
→ [Change]: [name], starting [date]. We will know it worked if [observable thing].
```

Rules: silent writing first, or the room anchors on whoever speaks first. One to three changes, never a list of twelve, because twelve changes is zero changes. Opening with last retro's changes is the single habit that separates a retro that works from a ritual people stop attending. Never run a retro that produces observations without owners.

---

## 11. Client meeting agenda

Send 24 hours ahead, always, without being asked.

```
[Client name] / [your company]: [date, length]

WHAT WE NEED FROM YOU TODAY
1. [Decision]: [X min]. [Why it is on your desk and what it unblocks.]
2. [Decision]: [X min].

WHAT WE ARE BRINGING YOU FOR INFORMATION
→ [Item]. No action needed.
→ [Item]. No action needed.

Pre-read: [link]. [One line on what is in it.]

Next session: [date already on the calendar].

Recap with decisions and owners on both sides comes to your inbox within 2 hours.
```

Rules: separate what needs their decision from what is for information, so they know where to spend attention. Put the next date on the calendar before anyone leaves the call. A client who has to ask what happens next has already started worrying, and that worry costs more than the meeting was worth.
