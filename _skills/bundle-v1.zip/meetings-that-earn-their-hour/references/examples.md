# Before and After

Five worked pairs with the scoring shown. Use these to calibrate the standard, and to show a user what the difference looks like rather than describing it.

---

## Example 1: A calendar invite with a topic instead of a decision

**Before (0/4)**

> **Title:** Q4 Budget Discussion
> **When:** Thursday 2:00 to 3:00pm
> **Attendees:** 11
> **Body:** Hi all, wanted to get everyone together to discuss the Q4 budget and align on next steps. Please come prepared with your numbers. Thanks!

Gates missed: no decision named, eleven people, no pre-read, no recap owner.

**After (4/4)**

> **Title:** Decide: Q4 budget approval or send back
> **When:** Thursday 2:00 to 2:40pm
> **Attendees:** 6
>
> **Decision this meeting produces:** Approve the Q4 budget at $340K, or send it back with a target number and a date.
> **Decider:** Dana
> **Pre-read:** [Budget v3 and the three line variance summary]. Sent Wednesday 9am. Please read before we start.
>
> 1. Approve or cut the $62K contractor line : 12 min : Marcus
> 2. Approve or defer the tooling renewal at $28K : 10 min : Priya
> 3. Approve the total, or set the target we cut to : 13 min : Dana
> 4. Readback of decisions and owners : 5 min : Marcus
>
> If we do not land the total today: Dana sets the target number by Friday noon and we cut to it.
>
> In the room: Dana, Marcus, Priya, Sam, Alex, Jo.
> Getting the recap instead: the other five. Recap by 4pm, written by Marcus.

**Coaching note:** "Discuss" and "align on next steps" is how an hour disappears without producing anything. Every time you write "discuss," ask what someone would have to say yes or no to for the meeting to be over. That sentence is your title. Do that one substitution and your meetings shorten themselves, because a named decision cannot be avoided for sixty minutes the way a topic can.

---

## Example 2: A rambling notes dump

**Before**

> ok so we got on the call and Priya walked through the vendor comparison again, Marcus had questions about the integration timeline for Vendor B and there was some back and forth about whether the 2 week estimate was realistic, Dana said she was worried about the cost of A over three years, we talked about whether we could negotiate, Sam mentioned that legal would need to review either way which nobody had thought about, then we went back to the timeline thing and Marcus said he could get a firmer number from their solutions engineer, Dana seemed to lean toward A by the end but said she wanted the legal timeline first, someone should probably loop in legal, we also briefly talked about the reporting piece but ran out of time, I think next steps are Marcus gets the number and we pick up next week?

**After (4/4)**

> **Vendor decision: Aug 26**
>
> **DECIDED**
> 1. Vendor A is the working choice, pending two inputs below. Cost over three years is the only open concern.
>
> **NOT DOING**
> → Vendor C. Caps out below our March volume. Reopening this needs our volume forecast to drop.
>
> **ACTIONS**
> → Marcus: firm integration estimate from Vendor B's solutions engineer, by Aug 29.
> → Sam: legal review timeline for both vendors, by Aug 29.
> → Priya: three year cost comparison including the negotiated case, by Aug 30.
>
> **STILL OPEN**
> → Reporting requirements. Not covered, ran out of time. Priya brings a one page summary to the Sept 2 session.
>
> **DECISION DATE**
> → Dana calls it Sept 2. If the legal timeline is not back by then, we go with A and absorb the review risk.
>
> Flag anything I got wrong by end of day. Otherwise this is the record.

**Coaching note:** The notes are a transcript of a conversation. A recap is a record of outcomes, and it is a different document with a different shape. Nobody needs to know that you went back to the timeline thing. Write decisions first, actions second, open questions third, and add the one thing the notes were missing entirely: a date on which the decision gets made whether or not the inputs arrive. That last line is what stops this meeting from happening a third time.

---

## Example 3: A recurring status meeting that should be a document

**Before (0/4)**

> **Weekly Team Sync**
> Every Monday, 10:00 to 11:00am, 9 attendees, recurring since March 2024.
> Body: Standing sync. Everyone gives their update.

Gates missed: all four. No decision, nine people, no pre-read, no recap. Roughly 45 working days of team time a year.

**The audit**

1. Decisions produced in the last month: none.
2. Not spoken in three sessions: 4 of 9.
3. Could the first half be a document: all of it could.
4. What breaks if it disappears: "we would lose visibility." That is a document.

**After: the meeting is cancelled and replaced with this**

> **The Monday sync is going away. Here is what replaces it.**
>
> Every Monday by 9am, post your update in #team-updates in this shape:
>
> ```
> [Your workstream]: week of [date]
> Status: On track / At risk / Blocked
>
> SHIPPED
> → [Result]. [Number]. [Link]
>
> IN FLIGHT
> → [Item]: on track for [date]
>
> BLOCKED
> → [Item]. Blocked on [thing] from [name]. Need it by [date].
>
> DECISIONS I NEED
> → [Decision] from [name] by [date].
> ```
>
> Read the channel by 10am. That is the whole ask.
>
> Anything in a BLOCKED or DECISIONS line gets 15 minutes on Monday at 10, with only the people named in it. Some weeks that will be nobody and we all get the hour back.
>
> Trying this for three weeks. If something breaks, tell me what specifically you missed and we will bring back a sharper version of it.
>
> The arithmetic: nine people times one hour times fifty weeks is about 45 working days a year. I want to be sure we are buying 45 days of value.

**Coaching note:** Status is information transfer, and speech is the slowest way to transfer information. Nine people listening to updates that concern two of them is a broadcast with a seating chart. The test that settles it: could someone get everything they need from a document, with no chance to change the outcome? Then they are an audience, and you booked a room for a memo. Cancel for three weeks rather than forever. It makes it an experiment instead of a slight, and it gives you permission to not bring it back.

---

## Example 4: Declining without damage

**Before (0/4)**

> Hey, sorry, I have a conflict Thursday so I will have to miss the pricing meeting. Let me know what I miss!

The conflict excuse works twice. "Let me know what I miss" hands someone else your homework.

**After (4/4)**

> Hi Dana,
>
> Skipping Thursday's pricing meeting. I do not think I change the outcome on the tier structure, and you have Priya, who does.
>
> Here is my position on the two open items so it is in the room without me:
>
> → **Enterprise floor at $40K:** support it. Everything we lost below $40K last year churned inside nine months, so the deals we would give up are not deals worth having.
> → **Grandfathering existing accounts:** support 12 months, not 24. Twenty four months puts the transition into next year's planning and we will be renegotiating it in the middle of the renewal cycle.
>
> Pull me back in if the conversation turns to the partner tier. That one I own and I will make it a priority.

**Coaching note:** A no with nothing attached costs you goodwill every time you send it. A no with your actual position attached is often worth more than your attendance, because a written position can be quoted, forwarded, and read twice, and a comment in a meeting cannot. Two paragraphs of real input buys you the right to decline the next three.

---

## Example 5: The brainstorm that produced nothing

**Before (1/4)**

> **Title:** Campaign Ideation Session
> **When:** Friday 1:00 to 2:30pm, 9 attendees
> **Body:** Bring your ideas for the spring campaign. No bad ideas! Whiteboard session.

Gates missed: no decision, nine people with no roles, no pre-read, no recap. Outcome last time: 40 sticky notes, nothing chosen, nothing owned.

**After (4/4)**

> **Title:** Pick 2 spring campaign directions
> **When:** Friday 1:00 to 2:00pm
> **Attendees:** 6
>
> **Decision this meeting produces:** Two campaign directions move to concepting, with an owner each.
> **Decider:** Priya
> **Pre-read:** [Last spring's numbers and the three audience segments]. Sent Thursday 10am.
>
> 1. Silent writing: every direction you would run, one per line : 7 min : everyone
> 2. Read out, cluster, no criticism yet : 15 min : Sam
> 3. Narrow to five. Criticism allowed and expected here : 15 min : Sam
> 4. Priya picks two, names an owner for each : 18 min : Priya
> 5. Readback : 5 min : Sam
>
> If we do not get to two: Priya picks from the five by Monday noon.
>
> Recap with the two directions and owners goes out by 3pm, written by Sam.

**Coaching note:** Two things kill brainstorms. The first is talking first: the moment someone speaks, the room anchors and every idea after it is a variation on theirs. Silent writing for seven minutes produces more ideas and more genuinely different ideas, every time. The second is "no bad ideas" applied to the entire session, which produces a long list nobody can act on. Divergence and convergence are two different activities with two different rules, and criticism belongs in the second one. Then end with a decision and an owner, or you have run a very pleasant hour that produces nothing.
