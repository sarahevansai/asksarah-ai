# Worked First Hours

Four scenarios, played out minute by minute. All organizations here are fictional and no real incident is described.

Each one shows the same three artifacts: the holding statement, the internal note, and the stakeholder sequence. The fourth example shows a bad statement first, then the damage it caused, then the version that would have worked.

Read one of these before you need it. It takes four minutes now and saves twenty later.

---

## Example 1: Marlowe Analytics, extended outage

**Fictional organization.** A 200-person software company. Their platform is used by client teams for daily reporting.

**The situation.** At 9:14am the platform stops responding. By 9:20 it is clear this is not a brief blip. Support tickets are arriving. Two customers have posted about it publicly. Nobody yet knows the cause, and one engineer has said in a channel that it "might be the database migration."

### 0 to 10 minutes: verify

Confirmed: the platform is unavailable, it started at approximately 9:14am, customers cannot log in.

Not confirmed: the cause, whether data is affected, when it will be back.

The migration comment is a report, not a fact. It does not go in anything.

### 10 to 15 minutes: contain

Engineering is working the technical containment. On the communication side, two actions. Scheduled social posts are paused. And a note goes into the engineering channel: keep working the problem, keep the speculation out of writing, nothing leaves this channel.

### 15 minutes: spokesperson

The VP of Communications is the single voice. Support uses one approved line and nothing else. Sales stops outbound until told otherwise.

### 25 minutes: those directly affected

Customer success calls the eight largest accounts directly, before anything is posted. Ninety seconds each: we are down, we are on it, you will hear from us by 11am, here is my mobile number.

### 35 minutes: employees

**Internal note, 9:49am**

> **What happened:** The platform went down at approximately 9:14am. Engineering is working on restoration now. We do not yet know the cause.
>
> **What it means for you:** Support, expect heavy volume, use the line below and only that line. Sales, hold all outbound until I say otherwise. Everyone else, no change today.
>
> **If a customer asks:** "We are aware of the outage, the team is working on it now, and updates are posted at status.marloweanalytics.example." That is the whole answer.
>
> **Route to:** Dana for anything from a reporter. Priya for customer escalations.
>
> **Please do not:** guess at the cause, give a restoration estimate, or post about this personally. We have a theory internally and theories have been wrong before. Next update by 11am either way.

### 45 minutes: the statement

**Posted at 9:58am, on the status page and natively on social**

> Marlowe Analytics has been unavailable since approximately 9:14am ET. We know this is disrupting your work and we are sorry for it.
>
> Our engineering team is working on restoration now. We have not confirmed the cause and will not speculate on it.
>
> There is no indication at this time that customer data has been affected. We will say so clearly if that changes.
>
> Next update by 11:00am ET, whether or not service is restored.
>
> Status: status.marloweanalytics.example. Questions: support@marloweanalytics.example.

87 words. Five parts. No cause named.

### Ongoing: monitor and log

Every question that arrives goes on a list. By 10:30 the list is dominated by three: is my data safe, when will it be back, will I be credited. Those three become the 11am update, in that order.

### 60 minutes: cadence

11am update goes out on time. It says restoration is in progress, no data impact confirmed, and next update at 12:30. Nothing new, sent anyway, on time.

### Stakeholder sequence used

1. Top eight accounts, by phone, 9:39am
2. All employees, 9:49am
3. All customers, in-app and email, 9:58am
4. Public statement and status page, 9:58am
5. Reseller partners, 10:15am
6. Board, brief email, 10:30am
7. Press, on inbound only, from 10:00am

**What made this work.** The migration theory never appeared in anything. It turned out to be wrong. Because it was never written down, there was nothing to correct, and the 4pm resolution note was the first and only account of the cause.

---

## Example 2: Tidewater Grocery Co., product recall

**Fictional organization.** A regional grocery chain with 60 stores and a house brand.

**The situation.** At 2:40pm, quality assurance confirms that a house-brand packaged salad from three production dates was packed on a line that was not properly sanitized. No illness has been reported. Roughly 9,000 units shipped. Stores are open.

### 0 to 10 minutes: verify

Confirmed: three lot codes, the sanitation failure, roughly 9,000 units, no reported illness as of now.

Not confirmed: whether anyone has been affected. "No reported illness" is not "nobody is sick." The statement has to say the first and not imply the second.

### 10 to 15 minutes: contain

Stop-sale to all 60 stores immediately. Pull from shelves. Hold remaining inventory. Notify the relevant food safety authority, because that is required and the deadline is short.

### 15 minutes: spokesperson

The Director of Food Safety takes technical questions. The VP of Communications takes everything else. Store managers take none, and are told so directly.

### 25 to 35 minutes: affected people, then employees

Loyalty program purchase records identify roughly 4,100 customers who bought an affected lot. Direct email and SMS to all of them, before the public statement.

**Internal note to all store teams, 3:15pm**

> **What happened:** We are recalling Tidewater house-brand garden salad, lot codes TG4471, TG4472, TG4478. The confirmed issue is a sanitation failure on the packing line. No illness has been reported. This goes public at 3:30pm.
>
> **What it means for you:** Pull all three lot codes from shelves now. Do not sell them. Hold them in the back, do not discard them. Accept returns with or without a receipt, full refund, no questions.
>
> **If a customer asks:** "We are recalling three lots of our garden salad because of a packing line issue. Bring it back for a full refund, receipt or not. Details are at tidewater.example/recall."
>
> **Route to:** Marcus for any reporter. Elena for any customer who says they have become ill. Get their name and number and call Elena immediately, that same minute.
>
> **Please do not:** tell a customer the product is probably fine, discuss which line or supplier is involved, or estimate how many units are out there. We are still confirming numbers.

### 45 minutes: the statement

**Posted 3:30pm**

> We are recalling Tidewater garden salad, lot codes TG4471, TG4472 and TG4478, sold between March 4 and March 9.
>
> A packing line was not properly sanitized before these lots were produced. No illness has been reported to us.
>
> Please stop eating this product. Bring it to any store for a full refund, with or without a receipt. We are contacting known purchasers directly and have notified state food safety officials.
>
> We are reviewing how this happened and will report what we find.
>
> Next update by 6:00pm. Questions: 1-800-[number].

93 words.

### Stakeholder sequence used

1. Food safety authority, 2:55pm, because the regulatory clock is shorter than the news clock
2. Store teams, stop-sale, 3:00pm
3. Identified purchasers, direct, 3:10pm
4. All employees, 3:15pm
5. Public statement, 3:30pm
6. Suppliers and distribution partners, 3:45pm
7. Press, 3:30pm, same statement, no separate version
8. Board, end of day summary

**What made this work.** "No illness has been reported to us" is precise and survives a case appearing tomorrow. "No one has been harmed" would not have. Also note what is absent: no "abundance of caution," no "isolated," no number of units in the public statement while the number was still being confirmed.

---

## Example 3: Ridgeway Manufacturing, workplace accident

**Fictional organization.** A 400-person parts manufacturer with one main plant.

**The situation.** At 6:52am, an equipment failure on the floor injures two workers. Emergency services are on site by 7:01. Both workers are transported to hospital. Their conditions are not known. Roughly 90 people were in the building. Phones were out. Photos are already circulating in a group chat.

This is the situation where the temptation to say more is strongest and the cost of doing it is highest.

### 0 to 10 minutes: verify

Confirmed: an incident occurred at approximately 6:52am, emergency services responded, two people were transported to hospital, production is halted.

Not confirmed: everything else. Conditions, cause, sequence, whether equipment or procedure was involved.

The plant manager makes one call to counsel and one to the insurer while the safety lead handles the floor. That is the right use of the first ten minutes.

### 10 to 20 minutes: contain and account for people

Secure the area, preserve the scene, do not touch the equipment. Account for everyone in the building by name, on paper. Send everyone not needed to a designated area, not home, until the count is complete.

### 20 minutes: spokesperson, and the families

The families are the first priority and they are not a communications task. A senior leader who knows the workers, plus HR, contact them personally. No statement of any kind goes out until that is done, and the two are not run in parallel.

The CEO is the single public voice.

### 40 minutes: employees

**Internal note, 7:35am, and read aloud in the assembly area at the same time**

> **What happened:** There was an incident on the floor at approximately 6:52am. Emergency services responded and two of our colleagues were taken to hospital. We do not have information about their condition and we will not share anything about them until their families have been reached and have told us we may.
>
> **What it means for you:** Production is stopped for today. Everyone on shift is paid for the full day. Do not return to Bay 3. If you are on second shift, do not come in, we will contact you by 2pm.
>
> **If anyone asks you, including a reporter:** "There was an incident at our plant this morning, emergency services responded, and I am not able to discuss it." Then send them to Ana.
>
> **Route to:** Ana for every outside question without exception, including from a neighbor or a friend.
>
> **Please do not:** name anyone, share photos or video, describe what you saw, or post anything. Two families are being contacted right now and no one should learn this from a phone screen. If you have photos, do not delete them, send them to Ana, they may be needed.
>
> **If you need support:** Counseling is available now in the front office and by phone at [number]. Please use it. Today was hard for everyone in that building.

### 55 minutes: the statement

**Issued 7:50am, after families were reached**

> An incident occurred at our Ridgeway plant this morning. Emergency services responded and are on site.
>
> Two of our colleagues were taken to hospital. Out of respect for them and their families, we are not going to say more about individuals.
>
> The plant is closed and secured. We are cooperating fully with emergency responders and investigators.
>
> We do not yet know what caused this and we will not speculate.
>
> Next update by 1:00pm. Media: Ana Ruiz, [contact].

79 words.

### Stakeholder sequence used

1. Emergency services, 6:53am
2. Families of the two workers, in person and by phone, by 7:25am
3. Everyone in the building, in the assembly area, 7:35am
4. All employees including other shifts, 7:35am
5. Regulator notification, per requirement, handled by counsel
6. Customers with orders on the affected line, 9:00am, brief and factual
7. Press, 7:50am
8. Public statement, 7:50am

**What made this work.** Three things. The families came before the statement and nothing was published until they had been reached. The photo instruction was specific, both do not post and do not delete. And the statement contained no cause, which mattered a great deal, because the initial assumption on the floor turned out to be wrong.

---

## Example 4: Pinecrest Fitness Studios, viral complaint, done badly and then correctly

**Fictional organization.** A 22-location fitness chain.

**The situation.** A member posts on a Saturday morning that she was refused entry, spoken to rudely, and told her membership was suspended for non-payment, which she says is false. The post includes a photo of her at the door. By 10am it has 40,000 views. By noon, 200,000. Comments include a dozen other members saying similar things happened to them.

### What they actually posted, at 12:40pm

> We take member experience very seriously. Pinecrest has served this community for 14 years and prides itself on world-class service. This appears to be an isolated incident involving a miscommunication about a billing matter. We have policies in place regarding account status and our staff followed them. We are always looking to improve and welcome feedback from our valued members.

### Why it made everything worse

Every clause in that paragraph did damage, and it is worth naming each one.

**"We take member experience very seriously," with nothing after it.** The phrase is so worn that it now reads as a signal that nothing follows. Nothing did.

**"14 years" and "world-class service."** Marketing copy inside a crisis statement. It tells the reader you are thinking about your reputation while they are thinking about a person. It is also an implicit argument that the complaint cannot be true, which reads as calling her a liar.

**"Isolated incident."** Twelve people in the comments had already said otherwise. This was falsified in public within minutes and became the most quoted line. It moved the story from a bad customer experience to a company that does not know what is happening in its own locations.

**"A miscommunication about a billing matter."** Two problems. It minimizes, and it discloses. Characterizing a member's account status in public, when she disputes it, is both a privacy problem and a fight you cannot win publicly.

**"Our staff followed them."** A conclusion published before any review. It closes off the investigation before it starts, tells every employee that the company will defend the process over the person, and leaves nowhere to go if the review finds a problem.

**"We welcome feedback."** After telling her she was wrong.

**What happened next.** The statement itself became the story, and it traveled further than the original post. Local coverage picked it up on Monday, quoting the statement rather than the incident. Two of the twelve commenters were contacted by reporters. On Tuesday the company posted a second statement contradicting the first, which is the walk-back that a rushed statement always produces, and which restarted the clock a third time.

A single-day story became a nine-day story. Nothing in the original incident required that.

### What should have gone out, at 10:20am

**One reply in the thread**

> We have seen this and we are looking into it now. This is not the experience we want anyone to have. We have reached out to Ms. [name] directly and we will follow up here once we know more.

**Then a statement at 12:30pm, since it kept growing**

> A member shared her experience at one of our studios this weekend. We have been in contact with her directly.
>
> We are reviewing what happened, including how our staff handle account status questions at the door. Several other members have raised similar experiences and we are reviewing those as well.
>
> We are not going to discuss any member's account details publicly.
>
> We will share what we are changing by Wednesday.
>
> Contact: care@pinecrestfitness.example.

**Internal note, 10:45am**

> **What happened:** A member's post about being refused entry at our Oakhill studio is circulating widely. We have replied once publicly and reached out to her directly. Rosa is handling this.
>
> **What it means for you:** Front desk teams, do not discuss account status where other members can hear, at any location, starting now. All scheduled social posts are paused.
>
> **If a member asks:** "We are aware of it, we have reached out to her directly, and we are looking into what happened."
>
> **Route to:** Rosa for press and for anything on social. Dev for any member who says something similar happened to them. Take their name and number, do not defend the company, just get it to Dev.
>
> **Please do not:** reply to comments, defend us in the thread, or argue with anyone. It will feel wrong to stay quiet while people are angry. Stay quiet anyway. Every employee reply extends the reach of the post.

**Stakeholder sequence that should have been used**

1. The member herself, by phone, before anything is posted
2. The other members who came forward in comments, individually, that day
3. Front desk and studio staff, with the process change, 10:45am
4. All employees, same note
5. Franchisees and location owners, 11:30am
6. Public reply in thread, 10:20am, then the fuller statement at 12:30pm
7. Press, on inbound only

**The lesson from this one.** The bad statement was not written by a careless person. It was written by someone defending an organization they care about, quickly, alone, under pressure, on a weekend. That is exactly the condition this skill exists for. Every damaging phrase in it is a phrase that felt protective while it was being typed.

---

## The pattern across all four

- Nobody with a direct stake learned it from the press.
- No cause was named before it was verified.
- The internal note went out before the public statement, and told people what not to say.
- Every statement named a next update time, and each one was held.
- The three statements that worked were all under 100 words. The one that failed was 60 words and every one of them was wrong, which is the reminder that short is necessary and not sufficient.
