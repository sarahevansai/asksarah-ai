# Ready Holding Statements

Eleven situations. Each one has a public holding statement and an internal version.

Every public statement here follows the five parts: acknowledge, confirmed and unconfirmed, action in the present tense, next update with a time, where to go. Each is under 100 words. Keep them under 100 words when you fill them in.

Brackets are for facts only the organization can supply. Fill them and send. Do not add paragraphs. The most common way these get worse is by getting longer.

Every internal version follows the four parts: what happened, what it means for you, what to say if asked, who to route to. Every internal version ends with what not to say, because that is the part people assume is obvious and it is not.

A note on the time you put in part four. Pick a time you can hold with no new information. It is better to promise 4pm and update at 3:45 than to promise noon and go quiet.

---

## 1. Service outage

**Public**

> [Service or product name] has been unavailable since approximately [time] [time zone]. We know this is disrupting your work and we are sorry for it.
>
> Our engineering team is working on restoration now. We have not yet confirmed the cause and will not speculate on it.
>
> No indication at this time that customer data has been affected. We will say so clearly if that changes.
>
> Next update by [time], whether or not service has been restored.
>
> Status page: [link]. Questions: [contact].

**Internal**

> **What happened:** [Service] went down at [time]. Engineering is working on it now. We do not yet know the cause.
>
> **What it means for you:** [Support: expect volume, use the statement below. Sales: hold outbound until further notice. Everyone else: no change today.]
>
> **If a customer or anyone else asks:** "We are aware of the outage, the team is working on it now, and updates are posted at [link]." That is the whole answer. Point them to the status page.
>
> **Route to:** [Name] for press. [Name] for customer escalations.
>
> **Please do not:** guess at the cause, give a restoration estimate, post about it personally, or forward internal threads. Our next update goes out by [time].

---

## 2. Data incident

Coordinate with counsel before this one goes out. Notification requirements and deadlines apply, and they vary by jurisdiction. Draft now, send after review.

**Public**

> On [date] we identified [unusual activity in / unauthorized access to] one of our systems. We took the affected system offline immediately.
>
> We are working with outside security specialists to determine what happened and what information was involved. We do not yet know the full scope, and we will not estimate it before we do.
>
> If we determine your information was affected, we will contact you directly.
>
> Next update by [time].
>
> Information and contact: [link or address].

**Internal**

> **What happened:** We identified [unusual activity] on [system] on [date] and took it offline. Outside security specialists and counsel are engaged. We do not yet know what data was involved.
>
> **What it means for you:** [Do not access system X. Change your password at link. Otherwise no change today.]
>
> **If anyone asks:** "We identified an issue, we took the system offline, specialists are investigating, and we will contact anyone affected directly." Nothing beyond that.
>
> **Route to:** [Name] for press. [Name] for customer questions. [Name] for anything a regulator sends.
>
> **Please do not:** describe what data you think was involved, name a number of records, speculate about who or how, or discuss this outside the company. Scope is not confirmed and anything we say now we will have to correct.

---

## 3. Product recall or defect

**Public**

> We are [recalling / issuing a safety notice for] [product], [identifiers, lot numbers, or date range].
>
> We identified [the confirmed issue, in plain words]. [Confirmed harm status, stated plainly and without minimizing.]
>
> Stop using the product. [Return, replace, or refund instruction in one sentence.] We are contacting known purchasers directly and have notified [relevant authority, if applicable].
>
> We are still determining how this occurred and will report what we find.
>
> Next update by [time]. Help: [contact].

**Internal**

> **What happened:** We are recalling [product], [identifiers]. The confirmed issue is [plain description]. This is public as of [time].
>
> **What it means for you:** [Stop shipping affected lots. Support: script and volume expected. Retail partners: [name] is contacting them.]
>
> **If anyone asks:** "We identified [issue], we are recalling [product], and anyone who has one should [action]. Details at [link]."
>
> **Route to:** [Name] for press. [Name] for retail and distribution partners.
>
> **Please do not:** discuss cause, quantities, or which supplier or line is involved. Do not tell a customer the product is probably fine. If someone reports being harmed, take their details and get them to [name] immediately.

---

## 4. Workplace accident

Involve counsel and your insurer before sending. If someone was injured, their family hears from a person, not from a statement.

**Public**

> An incident occurred at our [location] this [morning / afternoon]. Emergency services responded and are on site.
>
> [Confirmed status of people involved, in the plainest possible terms, and only what is confirmed.] We are not going to discuss individuals further out of respect for those involved and their families.
>
> The site is [closed / secured] and we are cooperating fully with [authority].
>
> We do not yet know what caused this. We will not speculate.
>
> Next update by [time]. Media: [contact].

**Internal**

> **What happened:** There was an incident at [location] at approximately [time]. Emergency services responded. [Only confirmed facts. Nothing about individuals beyond what has been confirmed and cleared.]
>
> **What it means for you:** [Site status. Whether to report tomorrow. Support resources and how to reach them, named specifically.]
>
> **If anyone asks:** "There was an incident at our [location], emergency services responded, and we are not able to discuss details right now." Then send them to [name].
>
> **Route to:** [Name] for all press and all outside questions, without exception.
>
> **Please do not:** name anyone involved, describe what you saw or heard, post anything, or speculate about cause. This matters for the families first and for the investigation second. If you need to talk to someone, [name and how to reach them] is available now.

---

## 5. Executive departing under scrutiny

Say less here than anywhere else. Every added sentence creates a question. Have counsel and HR review before sending.

**Public**

> [Name] is no longer with [organization], effective [date]. [Name, title] is [assuming the role / serving in the interim].
>
> We are not going to comment further on the circumstances of an individual's departure.
>
> [One sentence on continuity: the work, the clients, the commitments, and who is accountable now.]
>
> Media questions: [contact].

**Internal**

> **What happened:** [Name] is no longer with the company as of [date]. [Name] is stepping in [permanently / on an interim basis].
>
> **What it means for you:** [Reporting lines. Who to go to for approvals. What does not change.]
>
> **If anyone asks:** "[Name] is no longer with the company and [name] is leading [area] now." That is the complete answer. It is fine to say you do not have more detail, because you do not.
>
> **Route to:** [Name] for press. [Name] for client questions.
>
> **Please do not:** speculate about why, repeat anything you have heard, or comment on social media. Some of what is circulating is wrong, and some of it involves people's privacy and legal rights. We are not able to share more, and that is not the same as there being something hidden from you.

---

## 6. Employee conduct allegation

Counsel first. This one carries privacy and employment law exposure in both directions, toward the person who raised it and the person named.

**Public**

> We are aware of [the allegation, described in general terms and without detail].
>
> We take reports of this kind through a formal process, and that process is underway now. [Where appropriate and confirmed: the individual is not currently working / has been placed on leave pending the review.]
>
> Out of fairness to everyone involved, we are not going to discuss specifics or individuals while the review is active.
>
> We expect to be able to say more by [time or date].
>
> Media: [contact].

**Internal**

> **What happened:** We have received a report regarding [general description]. A formal review is underway. [Interim step taken, if any.]
>
> **What it means for you:** [Coverage or reporting changes, if any. How to raise a concern, with the specific route named.]
>
> **If anyone asks:** "There is a formal review underway and we are not discussing details." Nothing more.
>
> **Route to:** [Name] for press. [Name] in HR for anyone who wants to report something or needs support.
>
> **Please do not:** discuss this in channels, speculate about who or what, or contact anyone involved about it. A review only works if it is not conducted in public, and everyone involved has a right to that. If you have information relevant to the review, bring it to [name] directly.

---

## 7. Viral customer complaint

Move fast and stay small. The goal is to end the exchange, not win it.

**Public reply, posted once, in the thread**

> We have seen this and we are looking into it now. This is not the experience we want anyone to have. We have reached out directly to [customer, by handle or name] and we will follow up here once we have more.

**Public statement, if it keeps growing**

> A customer shared their experience with [our service] on [platform] this week. We have been in contact with them directly.
>
> We are reviewing what happened, including [the specific process involved]. We are not going to share details of an individual customer's situation without their consent.
>
> [What is being done: the review, the pause, the retraining, whatever is actually true and already underway.]
>
> We will share what we change by [date].
>
> Contact: [address].

**Internal**

> **What happened:** A customer post about [issue] is circulating on [platform]. We have replied once and contacted them directly. [Name] is handling it.
>
> **What it means for you:** [Support: expect related questions, here is the line. Social: scheduled posts are paused.]
>
> **If anyone asks:** "We are aware of it, we have reached out to the customer directly, and we are looking into what happened."
>
> **Route to:** [Name] for press. [Name] for anything on social.
>
> **Please do not:** reply to comments, defend us in the thread, argue with anyone, or share the customer's information. Well-meant replies from employees are what turns a bad day into a bad week. Send anything you see to [name] instead.

---

## 8. Negative news story

**Public**

> A story published today by [outlet] reports on [subject, described neutrally].
>
> [Correct any specific factual error, plainly, with the accurate fact. If there is no factual error, do not manufacture one.]
>
> [What is confirmed and what is being done, in the present tense.]
>
> We are reviewing the questions raised and will respond substantively by [date].
>
> Contact: [address].

**Internal**

> **What happened:** [Outlet] published a story today about [subject]. Here is the link, and here is what is accurate and what is not: [short, honest list].
>
> **What it means for you:** [Client outreach plan and who owns it. Whether to raise it proactively.]
>
> **If a client or anyone else asks:** "We are aware of the story, [the one accurate correction if there is one], and we are addressing it directly. [Name] can tell you more."
>
> **Route to:** [Name] for press. Do not respond to a reporter yourself, even to correct something obviously wrong.
>
> **Please do not:** post about it, respond to it publicly, or share internal reactions in writing. Assume anything written today gets seen. If a reporter contacts you, forward it to [name] without replying, including to say no comment.

---

## 9. Regulatory inquiry

Counsel reviews this before it goes anywhere. Assume the regulator reads it.

**Public**

> We received [an inquiry / a request for information] from [authority] regarding [subject, in general terms] on [date].
>
> We are cooperating fully and are providing the information requested.
>
> An inquiry is not a finding, and we are not going to characterize its scope or its outcome while it is active.
>
> [Continuity line: what is unchanged for customers, in one sentence.]
>
> Contact: [address].

**Internal**

> **What happened:** We received [an inquiry] from [authority] on [date] regarding [general subject]. Counsel is leading our response and we are cooperating fully.
>
> **What it means for you:** [Document retention instruction, stated exactly. Any process pause. Who is gathering what.]
>
> **Preserve everything.** Do not delete emails, messages, files, or notes relating to [subject], starting now. This is a legal requirement, and deleting something routine looks worse than anything it contained.
>
> **If anyone asks:** "We received an inquiry, we are cooperating, and we are not discussing it further."
>
> **Route to:** [Name] for press. [Name in legal] for anything that arrives from [authority] or any other agency.
>
> **Please do not:** discuss this in writing internally beyond what is necessary, speculate about the outcome, or respond to any outside request yourself.

---

## 10. Natural disaster affecting operations

**Public**

> [Event] has affected our [location or region]. Our first concern is the safety of our people, and we are accounting for everyone now.
>
> [Confirmed operational status: what is closed, what is running, what is delayed.]
>
> [What is being done in the present tense: rerouting, remote operations, contacting affected customers.]
>
> We do not yet know how long this will last. We will update by [time] and daily after that.
>
> Status and contact: [link].

**Internal**

> **What happened:** [Event] has affected [location]. [Facility status.] We are accounting for everyone. If you have not checked in, reply here or text [number].
>
> **Your safety comes before anything on your list. Do not travel to [location].**
>
> **What it means for you:** [Who works, who does not, from where, and how you get paid. Say this clearly. It is the question everyone has and is least likely to ask.]
>
> **If a customer asks:** "Our [location] is affected by [event]. [Impact on their order or service.] We will update by [time]."
>
> **Route to:** [Name] for press. [Name] for anything urgent about people.
>
> **Support available:** [What the company is providing, how to reach it, and who to call if you need something not on the list.]

---

## 11. Supply chain failure

**Public**

> We are experiencing a disruption affecting [product or service], beginning [date].
>
> [Confirmed impact: what is delayed, by roughly how long, and for whom.] We are contacting affected customers directly with specifics on their orders.
>
> We are [what is actually being done: sourcing alternatives, reallocating, expediting]. We are not going to promise a resolution date we cannot hold.
>
> Next update by [time].
>
> Order questions: [contact].

**Internal**

> **What happened:** [Supplier or input] failure beginning [date]. [Products affected.] [Estimated duration, if we have a real one. If we do not, say we do not.]
>
> **What it means for you:** [Sales: what to stop promising, stated specifically. Support: the script. Ops: allocation rules and who decides.]
>
> **If a customer asks:** "There is a supply disruption affecting [product]. Your order is [status]. We are updating customers directly and the next update is [time]."
>
> **Route to:** [Name] for press. [Name] for account escalations.
>
> **Please do not:** name the supplier, blame them, or give a delivery date that has not come from [name]. A date we miss twice is worse than a date we do not give. If a customer needs a commitment, get [name] on it.

---

## Filling these fast

1. Pick the closest statement. It does not have to be an exact match.
2. Fill the brackets with confirmed facts only. If a fact is not confirmed, cut the sentence rather than guessing.
3. Read it aloud once. If you stumble, the sentence is too long.
4. Check the five parts are all present, especially the update time.
5. Check the word count. Over 100 words means something is in there that does not need to be.
6. Send the internal version a few minutes before the public one.
