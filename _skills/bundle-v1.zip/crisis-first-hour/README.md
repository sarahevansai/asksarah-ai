# Crisis First Hour

A Claude skill that hands you the written holding statement in the first minute, then walks you through the next sixty.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

In the first hour of a bad situation, the instinct is to wait until you know everything. Silence in that hour is read as guilt or incompetence, and it is the window where the story gets defined by whoever speaks first.

The second instinct is worse: saying too much, too fast, which produces statements that have to be walked back. Most organizations have no plan and make both mistakes at once.

Describe what happened, in whatever shape you can manage, and Claude will:

1. Hand you a written holding statement, copy-ready, under 100 words
2. Map your situation to the eight-step first hour sequence, with clock times
3. Give you one coaching note for the hour ahead

**The statement always comes first.** Before advice, before questions, before anything else in the response. If facts are missing, you get the statement that works without them, because a holding statement is built to be sent before the facts are known. That is the whole point of one.

It writes the public statement, the internal message to employees, the customer notice, the stakeholder sequence, the answers to the hardest questions a spokesperson will get, and the follow-up updates.

Two things it handles that most crisis advice does not:

**Employees, in the right position.** The most commonly skipped step in the first hour is telling your own people before they read it somewhere else, and it is the most damaging one to skip. An employee who learns it from the news becomes a source. Every internal message this skill writes includes what to say if someone asks, and what not to say, because assuming people know is how good intentions become quotes.

**The phrases that backfire.** "No comment," "isolated incident," "we take this very seriously" with nothing after it, a cause named before it is verified, "a small number of." Each one is flagged with the specific reason it turns a one-day story into a longer one, so you know what to say instead.

## The framework

**Part one: the holding statement.** Five parts, nothing else, under 100 words.

1. Acknowledge that it happened, in plain words, without minimizing
2. State only what is confirmed, and say what is not yet known
3. State what is being done right now, in the present tense
4. Commit to a next update, with a specific time
5. Name where to go for information and who to contact

**Part two: the first hour sequence.** Verify, contain, name one spokesperson, tell the people directly affected, tell employees, issue the statement, log every question asked, set the update cadence and keep it even when there is nothing new.

**Part three: stakeholder order.** People harmed, employees, customers, partners, investors and board, regulators, press, public. The rule behind it: nobody with a direct stake should learn it from the press.

Plus severity triage, so a complaint does not get treated like a crisis, which is its own kind of damage.

## Where it stops

This skill helps you communicate clearly and quickly. It will not help you conceal facts, mislead people who have been affected, evade a legal or regulatory duty, or shift blame onto someone who is not responsible. If a request heads there, it says so in one line and offers the honest version, which is almost always the better strategy anyway.

Anything involving injury, death, legal exposure, regulatory reporting, or a data breach needs counsel, and often carries mandated notification with specific deadlines. The skill says so plainly and supports that work rather than replacing it.

## Try it

Once installed, say any of these:

- "We have a situation, here is what happened"
- "Draft a holding statement about an outage"
- "A reporter just emailed me and I do not know what to say"
- "What do we tell employees"
- "Is this a crisis or just a complaint"
- "Prepare me for the hardest questions I will get"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `crisis-first-hour.zip` in your skills settings. Claude loads it automatically whenever a situation calls for it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/crisis-first-hour/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "our service has been down for twenty minutes and customers are asking." You should get a finished statement first, then the sequence, then one coaching note.

## What is in the package

```
crisis-first-hour/
├── SKILL.md                  The framework, the rules, and the output format
├── README.md                 This file
├── LICENSE
└── references/
    ├── statements.md         11 ready holding statements with internal versions
    └── examples.md           4 worked first hours, including one done badly
```

`statements.md` covers a service outage, a data incident, a product recall or defect, a workplace accident, an executive departing under scrutiny, an employee conduct allegation, a viral customer complaint, a negative news story, a regulatory inquiry, a natural disaster affecting operations, and a supply chain failure.

## Notes

Claude will never invent a fact, a cause, a number, a name, or a time to fill a gap in a crisis statement. Anything it does not know comes back in `[BRACKETS]` for you to fill. In this skill that rule is not a preference. A confident statement built on an unverified detail is the specific error that turns one bad day into several.

It will ask at most one question, and only after the statement is already in front of you.

Set this up before you need it. The whole value of the first hour is that you are not reading instructions during it.

## Support

Questions, or want this adapted for your organization: [asksarah.ai](https://asksarah.ai)
