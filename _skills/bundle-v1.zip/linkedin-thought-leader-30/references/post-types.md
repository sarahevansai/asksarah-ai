# The eight post types

Pick the type before writing. The type determines the shape, and the shape is most of the work.

Every example below is built the way a real post gets built: from something the person actually said about their own work. Where a specific would be invented, it is bracketed instead.

---

## 1. The position

**Structure**

1. The position, stated flat, in the first line. No warm up.
2. The cost of the common practice, in real terms.
3. The experience that gave them the position. One case, with numbers.
4. The boundary: where the common practice is actually correct.
5. What to do instead, concretely.

**Notes**

Naming the boundary is what separates a position from a rant. A person who can say when they are wrong is easier to believe when they say they are right. Never end on a challenge to the reader.

**Example**

> Stop asking for three bids on work under $20,000.
>
> You will spend six weeks and about $4,000 of your own staff time to save maybe $1,800, and the low bid will be low because somebody missed something.
>
> We bid a mechanical room retrofit last spring against two other shops. Our number was $61,000. The winner came in at $52,400. They found the same problem in week two that we had priced, and the owner paid $14,000 in change orders to fix it.
>
> Three bids is for work where the scope is truly identical and the dollars are big enough to matter. Above about $250,000 I would not skip it.
>
> Below that, call two contractors you already trust and ask each of them what would make this job go wrong. You will learn more from that than from a third number.

---

## 2. The mechanism explained

**Structure**

1. A surprising statement of where the failure or the result actually comes from.
2. The physical or procedural reason, in two or three lines. Plain words.
3. The consequence that follows from it.
4. What they see when they look at a real case.
5. The one thing a reader can now check for themselves.

**Notes**

The reader should finish able to predict something. If the post only categorizes, it is a definition, not a mechanism. Keep the trade vocabulary and explain it in passing rather than avoiding it.

**Example**

> Roofs almost never fail in the field. They fail at the edge.
>
> Wind does not push down on the middle of a roof. It pulls at the perimeter, where the air has to turn the corner and speeds up. Suction at a corner can run three times what it is twenty feet in.
>
> So the cheapest way to lose a roof is to save money on edge metal and fastener spacing in the first six feet.
>
> When I pull a core on a failed system, the membrane in the field is usually fine. What I am looking at is a termination bar with fasteners at 12 inches where the spec called out 6, and a cleat that was never continuous.
>
> If someone hands you a re-roof bid that is $30,000 under everyone else, ask for their fastener pattern in the corner zones. That is where the money went.

---

## 3. The mistake they made and what it cost

**Structure**

1. The cost, in the first line, with the number attached.
2. What happened, briefly, including the part where they were technically right.
3. The real reason it went wrong, which is usually about a person and not a process.
4. What they do now, specifically, with the threshold.
5. Stop. No lesson paragraph.

**Notes**

The cost has to be real: dollars, a client, a person who quit, a year. "It taught me humility" is not a cost. This type fails instantly if the person comes out looking good, so keep the unflattering detail. If they are the hero of their own mistake story, it is the wrong story.

**Example**

> I lost a $310,000 a year customer over a $600 credit.
>
> They had a batch of parts run out of tolerance on a feature they had changed on the print three weeks earlier and never told us. Technically their fault. I had the emails. I made the point twice, in writing.
>
> They paid the invoice and moved the work to a shop in Ohio the following quarter.
>
> What I actually spent that $600 on was proving I was right to a buyer who already knew he had made the mistake and needed a way out that did not require him to say so out loud.
>
> Now when I am certain I am right and the number is under about $2,000, I eat it and mention it once on the phone, lightly, so it does not happen again. Nobody has moved work over it since.

---

## 4. The pattern across many cases

**Structure**

1. The volume, stated as a number, in the first or second line. This is the credential.
2. What people expect the answer to be.
3. The actual pattern, with its frequency and its cost.
4. Why it gets missed.
5. The thing a reader can do about it without hiring anyone.

**Notes**

Vague volume kills this type. "A lot of clients" carries no weight. If they do not know the count, help them estimate it out loud and use the estimate honestly: "roughly 2,400 in eleven years." Giving away the check for free at the end is what makes people call.

**Example**

> I have walked about 2,400 houses in this county in eleven years. The most expensive thing I find is almost never the thing people are worried about.
>
> Buyers ask me about the roof and the foundation. Those are the two scary numbers, so that is where the anxiety goes.
>
> The repair that actually blows up deals here is grading. Dirt sloping toward the house. It shows up in roughly one inspection in five, it runs $4,000 to $18,000 to correct properly, and it is behind about half the wet basements I get called back on.
>
> It gets missed because it does not look like anything. No stain, no crack, no smell in July. You have to stand at the corner of the house and actually watch where water would go.
>
> If you are buying, walk the perimeter yourself before you write the offer. You do not need me for that part.

---

## 5. The counterintuitive observation

**Structure**

1. The reversal, stated as an observation rather than a claim.
2. What they used to believe, and that they believed it for a long time.
3. What they noticed that broke it.
4. Why the common belief exists, taken seriously.
5. What changed in how they work.

**Notes**

Step four is the one people skip and it is the one that makes the post credible. If they cannot explain why sensible people believe the wrong thing, they have not understood it well enough to overturn it. Never label it "unpopular opinion." If it is unpopular, the content will make that obvious.

**Example**

> The clients who argue with me about the estimate are usually the ones who go through with the treatment.
>
> I assumed the opposite for years. Pushback felt like the beginning of a no, so I would get defensive and start justifying line items.
>
> What I finally noticed is that the quiet ones are the ones who never book the follow up. They are not agreeing. They have already decided they cannot afford it and they do not want to say that out loud in a room with other people in it and a sick dog on the table.
>
> Arguing takes energy. Somebody spending energy on the estimate is planning to pay it and wants to understand what they are buying.
>
> Now when an owner goes quiet on a number I stop talking about medicine and ask what they were expecting it to cost. About a third of the time we find a version of the plan that works. Before, I lost all of them.

---

## 6. The specific how

**Structure**

1. What the process produces, with the result stated.
2. The inputs. Actual data, actual sources.
3. The thresholds, as numbers, with the reason for each.
4. The rule for what happens when a threshold trips.
5. The part that took them longest to accept, which is usually about themselves.

**Notes**

Give the real thresholds. A version with the numbers removed is worse than not posting, because it advertises that they are holding back. Nobody is going to steal a business by copying a checklist. This type earns more inbound than any other and it is the one people are most afraid to write.

**Example**

> Here is the whole process I use to decide when a truck leaves the fleet. Twenty minutes a month, and it has cut our unplanned downtime by about half.
>
> Every month I pull three numbers per unit. Cost per mile for the trailing twelve months, days out of service for the trailing twelve, and current auction value from the January and July guides.
>
> Then two thresholds.
>
> If cost per mile is up more than 20 percent year over year and it is not fuel, the truck goes on the list. Rising CPM on a stable route is a truck telling you what is coming.
>
> If days out of service crosses 12 in a rolling year, it goes on the list regardless of the money. A truck that is not there wrecks the schedule for everybody, and that cost never shows up on the maintenance line where you can see it.
>
> Anything on the list sells in the next window where auction value beats the projected 18 month repair spend. Two windows a year, so we are never selling under pressure.
>
> The part that took me longest: the trucks I hated to sell were the ones I kept too long, because I was pricing my own memory of what that unit used to do.

---

## 7. The customer or colleague moment

**Structure**

1. The moment, told plainly, in one or two lines. Present the fact before the meaning.
2. The context that makes it land, kept short.
3. The detail that carries the weight, and only one.
4. What it changed about how they work.
5. End on the person, not the lesson.

**Notes**

The most common failure is turning a person into a device for a business point. Keep them a person. Never write a quote they did not say. If they do not remember the words, describe the action. Ask permission or strip identifying detail before anything about a real named client goes out.

**Example**

> A guy I have been treating for eight weeks came in Monday and told me he mowed his lawn.
>
> He is 71. Left knee replacement, slower recovery than we wanted, a rough patch around week four. We have been working on stairs and getting up off the floor.
>
> Mowing was not on the plan. It was not a goal we wrote down. He just did it, and then he stood in the doorway and told me about it before he took his coat off.
>
> His wife has been doing the lawn since March.
>
> I have started asking people at intake what they stopped doing that somebody else picked up. It gets better answers than asking about goals. Nobody's goal is 110 degrees of flexion. His goal was that his wife should not have to mow.

---

## 8. The honest uncertainty

**Structure**

1. The thing they do not know, named directly, with how long they have been sitting with it.
2. The case for. Numbers.
3. The case against. Numbers, or the honest absence of them.
4. Their current best theory, labeled as a theory.
5. What would change their mind, stated as a specific observable thing with a date.

**Notes**

Step five is what makes this a position rather than hand wringing. Uncertainty without a falsifiable next step reads as someone fishing for reassurance. Only use this type on something genuinely open. Fake uncertainty about a settled question is bait and readers in the field can smell it.

**Example**

> I do not know if our four day week is working, and we are 14 months in.
>
> The case for it is clean. Turnover on the floor went from 41 percent to 19. We are not paying agency rates anymore. Overtime is down.
>
> The case against is harder to see and it keeps nagging at me. Changeover times have crept up about 8 percent. My best theory is that the three crews overlap less now, so the small stuff that used to get handed off in person gets handed off on a whiteboard, badly.
>
> But I hired 30 people this year. That could be all of it.
>
> Here is what would settle it. If changeover times are still climbing in Q1 after this class is fully trained, it is the schedule and I will have to deal with the schedule. If they flatten, it was the ramp.
>
> I am putting this in writing partly so I have to be honest with myself in March about what the numbers actually said.

---

## Choosing between types

When the material could go several ways:

- If it has a number attached to a loss, write the mistake.
- If it has volume behind it, write the pattern.
- If they got heated telling you about it, write the position.
- If they explained something to you and you understood it better afterward, write the mechanism.
- If they described a person, write the moment.
- If they described a repeatable procedure, write the specific how.
- If they said "I am still not sure," write the uncertainty.
- If they said "everyone thinks X but actually," write the counterintuitive observation.

One event usually supports three of these. Note the others at the bottom of the delivery in one line each so tomorrow is already handled.
