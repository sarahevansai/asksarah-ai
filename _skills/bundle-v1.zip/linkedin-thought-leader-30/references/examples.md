# Worked examples

Each example shows the raw thing the person said and the finished post built out of it. Read the raw material closely. Almost every strong line in the finished post is a phrase they already used, moved into a better position.

None of these people work in marketing. That is deliberate. The method does not need an audience of peers or a clever industry.

---

## 1. Construction company owner

**What he said**, recorded into his phone driving between sites:

> This week was a mess. We had four guys sitting on the Fairview job Tuesday and half of Wednesday because the electrician never showed and nobody told me until Wednesday afternoon. That is like $3,800 of payroll for nothing. And the thing that kills me is my super knew Tuesday morning. He just figured it would work itself out. It is not the first time. I think the problem is I have made it so bad news travels up slow because I get hot about it.

**The post**

> Four guys sat on a job for a day and a half last week because an electrician did not show up. About $3,800 in payroll for nothing.
>
> My superintendent knew Tuesday morning. I found out Wednesday afternoon.
>
> He is not a bad super. He is one of the best I have. He waited because he thought it would sort itself out by lunch, and because bringing me a problem has historically been unpleasant.
>
> That second part is mine.
>
> If I get hot every time bad news shows up, I am training everyone around me to sit on it until it is either fixed or undeniable. By the time it is undeniable it has cost me a day and a half of payroll.
>
> So we changed one thing. Every super texts me by 7:15 with anything that is not on site that should be. No commentary, no plan, just the fact. My only job when that text lands is to say thanks.
>
> First week I got four of them. Three were nothing.

**Type and why:** The mistake and what it cost. The $3,800 is what earns the click, so it goes in line one. He owns his part in one sentence and does not spiral, which is what keeps it from reading as performance.

**What the last line came from:** the draft ended on "my only job is to say thanks." After handing it over, one question: what happened the first week? His answer was "four texts, three were nothing, one of them saved a pour." Three of those words became the ending. Nothing was invented to get there.

**Coaching note given:** the line he almost cut was the one about getting hot, because it makes him look bad. That line is why the post works. The unflattering detail is the most credible thing in any post about a mistake.

---

## 2. Pediatric dentist

**What she said**, in a message:

> Parents apologize to me constantly. Like every day. Kid is screaming and mom is saying sorry sorry he is usually so good. And I want to tell them the screaming kid is fine, actually. The one I worry about is the four year old who sits there totally silent and lets me do whatever. That kid has usually learned that nobody is coming. But you cannot say that to a parent in a chair.

**The post**

> Parents apologize to me every single day.
>
> The kid is crying, mom is holding his hand saying sorry, he is usually so good, I do not know what has gotten into him.
>
> He is four. He is fine.
>
> Crying is what a healthy four year old does when a stranger comes at his face with a light and a mirror. It means he understands what is happening to him and he expects somebody to respond when he objects to it.
>
> The one I pay attention to is the four year old who goes completely still. Opens up, lets me do whatever I want, does not make a sound.
>
> Sometimes that is just a calm kid and the visit is uneventful. Often enough that I notice it, it is a kid who has already worked out that objecting does not get you anywhere.
>
> You cannot say that to a parent sitting in the chair next to you. So I am saying it here.
>
> If your kid screamed through a cleaning this week, nothing has gone wrong. You have a child who expects to be listened to.

**Type and why:** The counterintuitive observation. The reversal is real and it comes from volume she did not even mention, which is the thing to ask about next. The common belief is taken seriously rather than mocked, so parents can read it without feeling judged.

**Kept from her raw words:** "sorry sorry he is usually so good," "totally still," "nobody is coming" reworked to "objecting does not get you anywhere," and the entire closing move, which was her last sentence turned around.

**Coaching note given:** she wrote "you cannot say that to a parent in a chair" as an apology for not saying it. Turning it into the reason the post exists is a move she can use again any time she catches herself saying "I could never actually tell them this."

---

## 3. Supply chain director

**What he said**, on a call:

> We got burned on the single source thing again. The Q2 resin shortage. We had one supplier for a component that costs like forty cents and it stopped three lines. I keep telling people that dual sourcing is not about price, it is about, okay, I know how that sounds. Basically every stoppage I have had in 18 years has been a cheap part, never an expensive one. Nobody dual sources the cheap parts because the savings analysis says it is not worth the qualification cost.

**The post**

> Every line stoppage I have had in 18 years was caused by a cheap part.
>
> Never the compressor. Never the controller. A forty cent component with one qualified supplier that nobody thought about until the morning it did not show up.
>
> We did it to ourselves again in Q2. One resin supplier, one part, three lines down for [number] days.
>
> Here is why this keeps happening to teams who are good at their jobs.
>
> Dual sourcing gets evaluated on unit price and qualification cost. On a forty cent part that math never works. The annual savings are a rounding error and qualification runs about [cost] and six weeks. So it goes to the bottom of the list, every quarter, permanently.
>
> The math is measuring the wrong thing. Qualification cost belongs next to a day of downtime on the lines that part feeds, not next to the annual spend on the part.
>
> We reran the whole list on that basis last month. Forty-one components moved from "not worth it" to "do this quarter." Thirty-eight of them cost under a dollar.

**Type and why:** The position, carried by a pattern. The 18 years and the count of 41 are the credential. The post argues with a specific practice, not with people, so a peer can disagree with the analysis without being insulted.

**Note on the voice rule:** he started to say "dual sourcing is not about price, it is about" and caught himself, because he could hear it turning into a slogan. The post does not use that construction anywhere. The argument he was reaching for is made with the qualification math instead, which is more persuasive and sounds like him.

**Coaching note given:** the two brackets are the only things holding this post back. He knows both numbers and could not remember them on the call. Every post gets stronger when the number is exact rather than approximate, and "about six weeks" is a number where "quite a while" is not.

---

## 4. Employment lawyer

**What she said**, over email:

> Honestly, 80 percent of the cases that come to me could have been prevented by a manager writing one email at the time. Not a formal write up. Just an email. "Following up on our conversation today about the missed deadlines, here is what we agreed." Nobody does it. Then eighteen months later they fire someone and there is nothing in the file, and I am standing in front of a jury and this person's entire documented history is glowing reviews, because performance reviews are always glowing.

**The post**

> Most of the wrongful termination cases I defend could have been prevented by one email that nobody sent.
>
> Not a written warning. Not a PIP. An email, that afternoon, that says: following up on our conversation about the three missed deadlines this month, here is what we agreed you would do differently, tell me if I have any of that wrong.
>
> Ninety seconds. No HR involvement. No form.
>
> Here is what happens when it does not get sent.
>
> Eighteen months of conversations, none of them written down anywhere. Then a termination. I open the personnel file and the entire documented history of this employee is performance reviews rated 4 out of 5, because performance reviews are always rated 4 out of 5.
>
> Now I am in front of a jury explaining why the glowing reviews do not mean what they obviously appear to mean. That is not a fun afternoon and it is not cheap for my client.
>
> Managers skip the email because sending it feels like escalation. It feels like starting something.
>
> What it actually starts, most of the time, is the person fixing the problem. Which is the outcome everybody in the conversation said they wanted.
>
> If you had a hard conversation with someone on your team today, send the recap before you leave tonight.

**Type and why:** The specific how, wrapped in a pattern. She gave away the exact sentence to send, which is what makes it useful enough to save. The "80 percent" was softened to "most" because she said "honestly" before it, which is how people flag an estimate rather than a figure.

**Coaching note given:** she has an entire month of posts in the phrase "there was nothing in the file." Every recurring frustration in a professional's practice is a post, because a recurring frustration is a pattern they have seen dozens of times and other people have seen once.

---

## 5. When the material is thin

Not every day produces a story. This is what a post looks like when someone gives you three sentences and says they have nothing.

**What he said:**

> Nothing happened this week. I turned down a job on Tuesday, a big one, because the customer wanted to reuse the existing ductwork and I knew it was not going to work. That is it.

That is enough. It has a decision, a reason, and a cost. Draft it, then ask.

**The post as delivered, brackets and all**

> I turned down a job on Tuesday that I wanted.
>
> [Size of the job, in dollars or in tons.] Full system replacement. Good customer, ready to sign.
>
> They wanted to keep the existing ductwork to save money. I looked at it and the returns are undersized for what they want the new equipment to do. Put a properly sized system on that duct and it will short cycle, the rooms that were already uncomfortable will still be uncomfortable, and in two years that is my problem, not theirs.
>
> I told them what it would cost to fix the duct first. [That number.] They are thinking about it.
>
> I used to take these. Install the equipment, write the duct issue on the invoice, figure I had covered myself.
>
> The note on the invoice protects you legally and it protects you in no other way. The customer does not remember it two summers later. What they remember is that they spent [amount] with you and their bedroom is still hot.

**The one question asked after handing it over:** what did the duct fix cost, and what was the job worth? Two numbers, one reply, three brackets closed. The post went out that afternoon.

**Why this is the important example:** he opened with "nothing happened this week." Nothing had happened, by his standards, because turning down work is Tuesday. Everything a person does routinely is invisible to them and interesting to everyone outside the trade. When someone says they have no material, they mean they have no material that surprises them.

---

## Reading these for voice

Look at what all five have in common.

They start on a fact. They contain at least one number. They use the words the person actually uses at work: pour, short cycle, qualification, PIP, returns. They admit something. Not one of them ends by summarizing itself, and not one of them asks for engagement.

The last thing, and the hardest to keep: every one of them could only have been written by the person who wrote it.
