# LinkedIn Thought Leader 30

A Claude skill that writes your LinkedIn posts out of your own words, one finished post at a time, and builds you a 30 day arc that adds up to something instead of thirty disconnected updates.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most people who want to be known for their work post nothing for months, then post something generic, get eleven likes, and decide LinkedIn does not work for their industry.

The platform is rarely the problem. The problem is trying to sound like a thought leader instead of writing down what you already know.

Tell Claude what happened at work, paste a draft, or hand over a call transcript, and you get:

1. The finished post, written out, ready to publish
2. Which of the eight post types it is and why that type fits
3. One coaching note that makes your next post better without help

**You always get a post back.** Ask for a 30 day plan and you get the plan plus day one written. Ask why your posts are not landing and you get the diagnosis plus a rewrite of your weakest one. Missing a number? It comes back in `[BRACKETS]` for you to fill, not as a question you have to answer before anything gets written.

## The part that matters most

**It will not invent your life.**

No made up client stories. No invented results. No statistics that appeared from nowhere. No anecdote about a conversation you never had. If a post needs a specific you have not given, it comes back bracketed with exactly what goes in the blank.

This is the whole product. A fabricated founder story is the fastest way to destroy the credibility you are posting to build, and the people most likely to catch it are the ones you most want reading. Every post goes out in your words, your vocabulary, your opinions, your numbers.

## The 30 day arc

Thirty posts are not a strategy. Thirty posts in an order are.

- **Week one, establish what you actually do.** The daily reality of the work. This is why anyone should listen to you at all.
- **Week two, take positions.** Now that people know what you do, say what you think about it. A position nobody could disagree with is not a position.
- **Week three, show the work.** Numbers, before and after, the real process. Positions without proof age badly.
- **Week four, turn attention into conversation.** Say plainly what you want and what kind of problem you like being called about.

Credibility before opinion, proof before ask. The reasoning is explained in the skill so you can stretch it to six weeks, start at week two if you already have an audience, or run it again next quarter.

## The eight post types

The position. The mechanism explained. The mistake you made and what it cost. The pattern across many cases. The counterintuitive observation. The specific how. The customer or colleague moment. The honest uncertainty.

Each one comes with the structure, what makes it work, and what makes it fail. Most of them fail the same way, by being about everybody instead of about you.

## If you think you have nothing to say

Almost everyone does, and almost everyone is wrong in the same way. You discount everything you do all week because it is routine to you. The expertise is invisible from the inside.

The skill includes the extraction method: the specific questions that pull real posts out of your actual week, and how to mine a sales call, a customer complaint, or a voice memo from the truck for the three or four posts already sitting in it. People say sharper things out loud than they type.

## Try it

Once installed, say any of these:

- "Build me a 30 day LinkedIn plan"
- "Write my post for today" and describe what happened
- "Turn this into a post" and paste a transcript or a rambling message
- "I don't know what to post about"
- "Rewrite this so it sounds like me"
- "Why is nobody engaging with my posts?"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `linkedin-thought-leader-30.zip` in your skills settings. Claude loads it whenever a post needs writing.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/linkedin-thought-leader-30/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "write my LinkedIn post for today" with two sentences about something that happened at work. You should get a finished post, the type it is, and one coaching note.

## What is in the package

```
linkedin-thought-leader-30/
├── SKILL.md                  The rules, the arc, the post architecture, the modes
├── README.md                 This file
├── LICENSE
└── references/
    ├── post-types.md         All 8 types with structure and a full example each
    └── examples.md           5 worked posts, raw material through finished draft
```

## Notes

Nothing gets held back waiting on an answer. At most one question, and only after the post is already in front of you.

No em dashes, no engagement bait, no "agree?" closers, no hashtag walls, no posts that could have been written by anyone in any industry. If a draft comes back sounding like software wrote it, the fix is more of your actual words, and the skill will ask for the specific one it needs.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
