# Visibility Preflight

A Claude skill that checks a blog post or editorial article before it publishes, scores it on 41 points across search, AI answers, place, trust, and technical metadata, and writes every missing part so you can paste it in and ship.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

An article gets found three ways now. A search engine looks for a page that matches a query. An AI assistant looks for a passage that answers a question and can be lifted out whole. And when the subject has a place attached, both look for proof the page belongs there.

Most articles ship with the writing finished and the rest missing. No title tag written on purpose. No answer in the first hundred words. No byline, no date, no schema, no sources a reader could check. The piece is good and nobody finds it.

Paste a draft and Claude will:

1. Score it on 41 checks across five layers: Search (SEO), Answer (GEO), Place (geolocation), Trust (E-E-A-T), and Machine (schema, metadata, crawlability)
2. Give a verdict: READY, READY WITH FIXES, or NOT READY, with eight gates that block publication on their own
3. Write the Publish Kit: every missing part, ready to paste

**You always get the parts, written.** The title tag with its character count. The meta description. The slug. The 40 to 80 word answer block for the top of the page. The question headings. The FAQ. The author box. The JSON-LD schema as one valid block. The Open Graph tags. The local paragraph when the article has a place. The checklist for your developer covering what cannot be seen from a draft. You will never get "here is what a well-optimized article includes."

## The five layers

| Layer | What it answers | Checks |
|---|---|---|
| Search | Will a search engine match this page to the query it deserves? | 10 |
| Answer | Can an assistant lift a complete answer out of it and attribute it? | 10 |
| Place | If the subject has a geography, does the page prove it belongs there? | 6, or N/A |
| Trust | Would a careful reader believe who wrote this and why? | 7 |
| Machine | Is the page described correctly in code, and can every reader reach it? | 8 |

## The Place decision

Geolocation is the layer people get wrong in both directions. Local businesses publish useful articles with no place in them. National publishers jam a city into a piece that has no geography and read as spam.

The skill decides first whether the article has a place at all. If it does not, the layer is skipped and the count becomes 35. If it does, the test is simple: swap the city for another one. If the article still reads as true, it was never local. The fix is one honest paragraph of things only a local would know, not a city name in every heading.

Multi-country and multi-language articles get the full treatment: one page per locale, hreflang between them, each self-canonical.

## What it will not do

It will not promise a ranking or a citation. No search engine or assistant publishes how it decides, and the skill says so before it says anything else.

It will not invent a statistic about search or AI behavior. If a number would help your case, it tells you to find a current source and cite it yourself.

It will not mark something as passing that it could not see. Canonical tags, robots rules, sitemap inclusion, and whether your content is in the served HTML all come back as VERIFY with the exact test to run, never as a PASS on assumption.

It will not report a score out of 100 or a percentage. You get a count: "24 of 41," because that is honest and a grade is not.

## Try it

Once installed, say any of these:

- "Check this before I publish" and paste the draft
- "Is this post optimized for search and AI?"
- "Run the preflight on this"
- "What is this article missing?"
- "Write the meta description and schema for this"
- "Make this rank locally" or "this is for our Denver office"
- "I have a topic and no draft yet" for the pre-write brief
- "Here is the revised version" for a re-check with before and after counts

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `visibility-preflight.zip` in your skills settings. Claude loads it automatically whenever the question comes up.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/visibility-preflight/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste any blog draft, and say "check this before I publish." You should get a scorecard with a verdict and count, then a Publish Kit that starts with a title tag and its character count.

## What is in the package

```
visibility-preflight/
├── SKILL.md                    The five layers, the eight gates, the kit, the output format
├── README.md                   This file
├── LICENSE
└── references/
    ├── checklist.md            All 41 checks: criterion, how to test, the fix
    ├── kit-templates.md        Paste-ready templates for every kit item, including the
    │                           JSON-LD graph and where each part goes on 7 platforms
    ├── place.md                The geolocation layer in depth: local, regional,
    │                           multi-country, hreflang, listing consistency
    └── examples.md             3 complete worked preflights with scorecards and kits
```

## Notes

Claude will never invent a number, a source, or a credential to fill a gap. Anything only you can know comes back in `[BRACKETS]` naming the exact fact, so you can fill it in one step.

It asks at most one question, and only after the kit is in front of you. Usually it is the one that matters most: what do you know about this topic that nobody else does.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
