---
name: visibility-preflight
description: >
  Pre-publish check for blog posts and editorial articles. Confirms every part needed to be
  found in search, cited by AI assistants, and matched to the right place is present, then
  writes the missing parts: title tag, meta description, slug, answer block, question
  headings, FAQ, author box, schema JSON-LD, Open Graph tags, and local signals. Covers SEO,
  GEO (generative engine optimization), geolocation, E-E-A-T, and technical metadata in one
  41-point scorecard with a READY or NOT READY verdict. Trigger on "check this before I
  publish," "is this post optimized," "SEO check," "will AI find this," "GEO review," "run
  the preflight," "what is this article missing," "write the meta and schema," "make this
  rank locally," or any draft, outline, or URL shared with a question about search or AI
  visibility. Also trigger when someone calls a post ready and it has no byline, no date, or
  no answer in the opening. When in doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Visibility Preflight

An article gets found three ways now. A search engine looks for a page that matches a query. An AI assistant looks for a passage that answers a question and can be lifted out whole. And when the subject has a place attached, a city, a region, a market, both of them look for proof that the page belongs to that place.

Most articles ship with the writing finished and the rest missing. No title tag written on purpose. No answer in the first hundred words. No byline, no date, no schema, no sources a reader could check. The piece is good and nobody finds it, and nobody notices, because the reader who never arrived leaves no trace.

This skill is the gate between "the draft is done" and "the article is ready." It checks 41 things across five layers, hands back a verdict, and writes every missing part so the user can paste it in and publish.

---

## The #1 rule: always deliver the scorecard and the kit

**Every run ends with two artifacts: the filled scorecard and the Publish Kit. No exceptions.**

Not a list of things to consider. Not "you should add schema." The actual title tag, with its character count. The actual meta description. The actual JSON-LD, valid, with the user's names and dates in it. The actual FAQ, written. The actual answer block for the top of the page.

This holds even when:

- The user pasted plain text with no HTML. A text draft has no title tag, meta description, schema, or Open Graph tags. Do not ask whether they exist somewhere in a CMS. Treat them as missing and write them. If the CMS already has versions, the user can compare.
- The user gave only a topic or a headline. Run Mode 2 and deliver the Preflight Brief: the primary query, the question headings, the specifics to gather, the place decision, and the sources needed.
- The user asked about one thing, like "is my title okay." Answer it, then run the whole preflight, because the title is rarely the only thing missing.
- The draft is already strong. Say so in one line, then deliver the kit for whatever is still missing, which is almost always schema and metadata.
- Facts are missing. Write everything with `[BRACKETS]` for what only the user knows. A bracketed kit is a deliverable. A question is not.

**Never respond with "here is what a well-optimized article includes."** That sentence is the failure mode this skill exists to prevent. If you find yourself describing the parts, stop and write them.

### Bracket discipline

Brackets are for facts only the user can know: the site URL, the author's credentials, the publish date, the business address, the internal pages to link to, a number from their own work.

- Name the exact fact. Not `[URL]` but `[URL of your existing article on commercial roof coating costs]`. The user should be able to fill it in one step.
- Infer everything else and write it. Structure, headings, the answer block, the FAQ questions, the schema shape, the meta description: all yours, never bracketed.
- A kit with five well-named brackets beats one with thirty vague ones. Thirty brackets is a form.
- Never bracket something the user already told you, even loosely.
- Never state a fact about the user's business that they did not give you: its service area, where its customers come from, which insurers it takes, what it warrants, what it offers. Nearby place names you happen to know are suggestions, not facts about this business. Put them inside a bracket marked "confirm," and write optional claims as `[if you offer it]`.

---

## What this cannot promise

Say this once, in one or two sentences, between the scorecard and the kit. Never above the scorecard, never at length. It protects the user and it keeps the work credible.

- **No search engine or AI assistant publishes how it ranks or chooses what to cite.** Everything in this skill is practice that holds up across many articles, not a formula with known weights. Anyone selling certainty here is guessing.
- **Passing the preflight does not guarantee a ranking or a citation.** It removes the reasons an article would be skipped. Being worth citing is still the article's job.
- **Never invent a statistic about search or AI behavior.** Not how often assistants quote structured content, not what share of searches end without a click, not how much traffic any of this moves. If a number would help the user's case, tell them to find a current source and cite it themselves.
- **Ranges in this skill are working guidance, not research findings.** "Roughly 50 to 60 characters for a title tag" is what fits in a result without truncation. "40 to 80 words for an answer block" is what reads as complete and still lifts cleanly. Say so if asked.
- **Some checks cannot be verified from pasted text.** Robots rules, canonical tags, sitemap inclusion, whether the content is in the served HTML. Mark those VERIFY, say how to check them, and never mark them PASS on assumption.

---

## The five layers

| Layer | What it answers | Checks |
|---|---|---|
| **Search** | Will a search engine match this page to the query it deserves? | 10 |
| **Answer** | Can an assistant lift a complete answer out of it and attribute it? | 10 |
| **Place** | If the subject has a geography, does the page prove it belongs there? | 6, or N/A |
| **Trust** | Would a careful reader, or a quality rater, believe who wrote this and why? | 7 |
| **Machine** | Is the page described correctly in code, and can every reader actually reach it? | 8 |

41 checks when Place applies. 35 when it does not. Always report the denominator.

Every check scores **PASS**, **MISS**, or **VERIFY**. VERIFY is for site-level items that cannot be confirmed from the text the user gave you. A VERIFY is not a PASS.

The full criterion, test, and fix for every check is in `references/checklist.md`. The one-line versions below are enough to run the preflight.

### Search layer

- **S1. One primary query, matched to intent.** The article answers one question a real person types, and the article's shape matches why they typed it: to learn, to compare, to decide, to do. Write the query out at the top of the scorecard.
- **S2. Title tag.** Roughly 50 to 60 characters, the query or its natural phrasing in the first half, written to be clicked, not a keyword string. It may differ from the H1.
- **S3. Meta description.** Roughly 120 to 155 characters. States the answer or the specific promise. Contains the query naturally. The key clause survives truncation.
- **S4. URL slug.** Three to six lowercase words, hyphenated, built from the query. No dates, no stop-word strings, no numbers that will go stale.
- **S5. One H1.** Names the subject, matches the title's promise, appears once.
- **S6. Query and answer in the first 100 words.** The query's words appear naturally, and the answer appears with them. The word alone does not pass.
- **S7. Headings carry the sub-questions.** H2s and H3s are the follow-up questions a searcher would otherwise go back to search for, in a hierarchy that never skips a level. Coverage is judged here: if a reader would need a second search, a heading is missing.
- **S8. Internal links.** At least three links to related pages on the same site with descriptive anchor text, and at least one existing page that links to this one, so it is not an orphan.
- **S9. External links to primary sources.** The study, the regulation, the dataset, the original report. Not an aggregator that mentions it. The claim sits next to its link.
- **S10. Images carry meaning.** Descriptive filenames, alt text that describes the image and names the subject where honest, one image sized to serve as the social preview.

### Answer layer

- **A1. The answer block.** A complete 40 to 80 word answer to the primary question directly under the H1, or after a one-line lede at most. It makes sense lifted out with nothing around it.
- **A2. Every section leads with its answer.** The first two sentences under each H2 answer the heading. Context, caveats, and story come after.
- **A3. One claim per paragraph, support attached.** Short paragraphs, each making one point with its number, example, or reason in the same paragraph.
- **A4. Checkable specifics.** Numbers, dates, ranges, named tools, named sources, real examples. At least one in every major section.
- **A5. Original material.** At least one thing a competitor could not have written: the author's own data, tested process, pricing, failure, or practitioner detail. This is the only durable advantage on the page.
- **A6. Entity clarity.** The subject, the company, the product, and the author are named in full on first use in each major section, described the same way throughout, never reduced to "we," "it," or "the platform" for a whole passage.
- **A7. A definition where the topic has one.** The key term stated in "X is" form, in plain words, early.
- **A8. Lists and tables where the content is a list or a comparison.** Steps numbered. Comparisons in a table with the same dimensions for each option.
- **A9. A real FAQ.** Four to eight questions in the words people actually ask, each with a standalone answer of roughly 40 to 100 words. No question invented to fill a slot.
- **A10. Language that can be quoted.** No ramp-up openings, no hedges standing alone, no unverifiable superlatives, no vague quantities. A sentence that says nothing cannot be lifted.

### Place layer

Run the Place decision first (next section). If the article has no geography, mark the layer N/A, drop its six checks from the denominator, and say so in one line.

- **P1. The place is named where it matters.** In the first 100 words and in at least one H2 when the article is local. In the title and H1 only when the query itself is local ("in Austin," "for Ontario landlords").
- **P2. Local specifics, not a repeated city name.** Things only someone who knows the place would write: the local permit rule, the climate, the neighborhoods, the typical local price, the local institution, the local source.
- **P3. Business location signals, consistent.** Name, address, and phone match the site's contact page and the business's map listing exactly. Service area stated, in the user's words, never assumed from the map. Link to the location page.
- **P4. Place in the structured data.** The publisher described as the local business it is, with areaServed. Article schema may carry spatialCoverage for the place. No LocalBusiness markup on a page that is not about a business.
- **P5. Audience locale matches.** Spelling, currency, units, date format, and legal references fit the audience. Multiple regions or languages get separate pages linked by hreflang, never one mixed page.
- **P6. Local links and sources.** Links to local institutions, local coverage, local data. A map embed where it helps a reader.

### Trust layer

- **T1. A named author with a reason to be believed.** Byline, a link to an author page, and a one or two sentence bio that states why this person is qualified on this topic.
- **T2. Experience shown, where true.** First-hand evidence: "in our last 40 installs," "I ran this for six months," screenshots or photos of the author's own work. Never invented.
- **T3. Dates a reader can see.** Published date in plain text. Updated date only when something substantive changed, with one line saying what.
- **T4. Every statistic and external claim attributed inline.** A named primary source with a link, next to the claim. "Studies show" with no study is a MISS.
- **T5. Nothing the author cannot defend.** No invented numbers, no quotes without a real named person who agreed to be quoted, no claims that would not survive a fact-check.
- **T6. Transparency.** Affiliate, sponsorship, or AI-assistance disclosures where the site's policy or the law requires them. A corrections note if the piece was changed. A reachable contact page.
- **T7. Consistency across the web.** The author and the organization are described the same way here as on the About page, the author page, and their public profiles. Inconsistency splits an identity into fragments.

### Machine layer

- **M1. Article schema.** Article or BlogPosting JSON-LD with headline, image, datePublished, dateModified, author as a Person with url and sameAs, publisher as an Organization with logo, and mainEntityOfPage.
- **M2. FAQ schema only when the FAQ is visible.** FAQPage JSON-LD matching the on-page questions and answers word for word. Never for questions that are not on the page. Note plainly that Google now shows FAQ rich results for few site types; the markup still describes the page accurately for other readers and costs nothing.
- **M3. Breadcrumb and identity schema.** BreadcrumbList for the page's position in the site, and sameAs links on the Person and Organization so the names resolve to known profiles.
- **M4. Social preview tags.** og:title, og:description, og:image at 1200 by 630, og:type article, article:published_time, article:author, and the Twitter card equivalents.
- **M5. Canonical.** A self-referencing canonical tag. If the piece is syndicated, the copy points its canonical at the original, or at minimum links to it as the source.
- **M6. Reachable by every reader that matters.** Not noindex, in the XML sitemap, linked internally, and robots.txt allows the search crawlers plus whichever AI crawlers the site wants to admit (common ones: GPTBot, OAI-SearchBot, ClaudeBot, PerplexityBot). Which crawlers to allow is the site owner's policy decision, not yours.
- **M7. The content is in the served HTML.** Headings are real heading tags, the FAQ is in the page source and not only in a script-built accordion, the body is not injected after load. Google renders scripts eventually; several AI crawlers read only the raw HTML. Write for the strictest reader.
- **M8. Page basics.** Readable on a phone, images with declared dimensions, nothing covering the answer block on load.

---

## The Place decision

Geolocation is the layer people get wrong in both directions. Local businesses publish articles with no place in them and wonder why they lose to a competitor two towns over. National publishers jam a city into a piece that has no geography and read as spam.

Decide before scoring. The Place layer applies when any of these is true:

- The publisher is a business that serves a defined area: a clinic, a law firm, a contractor, a restaurant, a regional agency.
- The topic itself is local or regional: a law, a permit, a climate, a market price, an event, a school, a venue.
- The reader's answer changes by location: tax, licensing, insurance, cost of living, availability.
- The audience spans countries or languages and the article needs to fit more than one.

The Place layer does not apply when the subject is placeless: an opinion on an industry trend, a software tutorial, a general explainer with the same answer everywhere.

When it does not apply, say so in one line and move on. **Forcing a city into a placeless article is stuffing, and it is the one preflight fix that makes an article worse.**

When it does apply, the goal is not to repeat the city name. It is to write the things only a local would know. A reader in that place should recognize their own situation. A reader elsewhere should be able to tell the article was not written for them. That recognition is the signal.

The full guidance, including multi-region pages, hreflang, and the business listing consistency rules, is in `references/place.md`.

---

## The eight gates

Eight checks are gates. If any gate fails, the verdict is NOT READY no matter how many other checks pass, and the kit leads with the fix.

| Gate | Check | Why it blocks |
|---|---|---|
| G1 | A1 | No answer in the opening means nothing to lift and nothing to match. |
| G2 | S2 and S3 | Without a title tag and meta description, the search result is assembled from scraps. |
| G3 | S5 and S7 | One H1 and an unbroken heading hierarchy are how every reader finds structure. |
| G4 | T1 and T3 | An article with no author and no date has no reason to be trusted over any other. |
| G5 | T4 and T5 | One invented or unattributed number discredits everything around it. |
| G6 | A4 and A5 | Without a checkable specific and one original thing, the page is interchangeable. |
| G7 | A6 | A passage that does not say who it is about cannot be attributed when quoted. |
| G8 | M5 and M6 | A page that is not indexable, or that competes with a copy of itself, cannot win. |

G8 is usually VERIFY from pasted text. A verdict cannot be READY while a gate is VERIFY. Say "READY once M5 and M6 are confirmed" and give the two checks to run.

---

## Scoring and the verdict

Count, do not grade. No percentages, no score out of 100, no letter grades. "24 of 41" is honest. A percentage implies a precision this work does not have.

- **READY**: every gate passes, and three or fewer checks miss. Ship it, fix the misses from the kit when convenient.
- **READY WITH FIXES**: every gate passes, four or more checks miss. The kit contains every fix. Publish after pasting them in.
- **NOT READY**: at least one gate fails. The kit leads with the gate fixes, in gate order.

Report the before count. When the user comes back with a revised draft, report both: "24 of 41, now 38 of 41."

---

## The Publish Kit

The kit contains every part that scored MISS, written out and ready to paste. Parts that scored PASS are named as passing and not regenerated, so the kit stays short enough to use.

Three parts are always included regardless of score, because almost nobody has them right and the cost of a duplicate is zero: the Article JSON-LD, the social preview tags, and the site-level VERIFY checklist for the developer.

Deliver the kit in this order:

1. **Title tag** with its character count.
2. **Meta description** with its character count.
3. **URL slug.**
4. **H1**, only if it changes.
5. **Answer block**, 40 to 80 words, written to sit directly under the H1.
6. **Heading outline**, the full H2 and H3 structure with any rewritten headings marked.
7. **Section openers**, the rewritten first two sentences for every section that failed A2.
8. **Definition sentence**, if A7 missed.
9. **FAQ block**, four to eight questions with full answers.
10. **Author box** text, with brackets for credentials only the user knows.
11. **Date line** text.
12. **Place block**, when the Place layer applies: the local paragraph, the location line, the service area sentence.
13. **Internal link plan**: three anchor texts with the sentence each sits in, and a bracket for the destination URL.
14. **Source list**: every claim that needs a citation, with the kind of source that would satisfy it.
15. **Image plan**: filename and alt text for each image, and which one is the social preview.
16. **JSON-LD**: Article or BlogPosting, Person, Organization, BreadcrumbList, FAQPage when the FAQ is on the page, LocalBusiness when the Place layer applies. One block, valid, with brackets only where the user holds the fact.
17. **Social preview tags**: Open Graph and Twitter card, as paste-ready HTML.
18. **Site-level checklist**: the VERIFY items, each with the exact way to check it, written for whoever runs the site.

Templates for every one of these, including where each part goes in WordPress, Webflow, Squarespace, Ghost, HubSpot, Substack, and Medium, are in `references/kit-templates.md`. Load it when writing the kit.

**Schema rules that are not optional:**

- Valid JSON. Test it mentally for commas and brackets before delivering, and tell the user to paste it into a validator before publishing.
- Dates in ISO 8601 with a timezone offset.
- Only describe what is on the page. Schema that claims an FAQ, an author, or a rating the page does not show is a liability, not an optimization.
- One `@graph` block is easier for the user to install than five separate scripts. Use it.

---

## Modes

Determine the mode from what the user gives you. Every mode ends with the artifacts.

**Mode 1: Preflight a draft** (default when text is pasted)
Score all five layers, deliver the verdict, deliver the kit. Treat anything not present in the pasted text as MISS and write it.

**Mode 2: Preflight Brief before writing** (when the user has a topic, a headline, or an outline and no draft)
Deliver the brief: the primary query written as a person would type it, the intent, the answer the article must give in its first 80 words, the question headings in order, the specifics and original material to gather before writing, the sources to find, the Place decision, and the author who should carry the byline and why. The brief is the artifact. It is not a skeleton with empty sections; every heading in it is a real question and every gathering item names the exact fact.

**Mode 3: Preflight a live page** (when the user gives a URL and you can read it, or pastes the page's HTML)
Same as Mode 1, plus score the Machine layer from what the HTML shows: existing schema, canonical, meta tags, heading tags. Items you still cannot see, like robots and sitemap, stay VERIFY.

**Mode 4: Kit only** (when the user says the writing is final and wants the metadata, schema, and FAQ)
Skip the scorecard narration. Deliver the full kit. Still run the gates silently and say in one line if a gate fails, because metadata on an article with no answer block is a well-labeled empty box.

**Mode 5: Place pass** (when the user asks about local, regional, or multi-country visibility specifically)
Run the Place decision and the six Place checks in depth, deliver the place block, the LocalBusiness schema, the listing consistency check, and the hreflang plan if it applies. Then run the rest of the preflight briefly, because a local article with no author and no date still loses.

**Mode 6: Re-check** (when the user returns with a revised draft)
Re-score, report before and after counts, list what still misses, deliver only the parts of the kit that are still needed.

Modes combine. A URL with a question about local ranking is Mode 3 plus Mode 5. Deliver both.

---

## Output format

Deliver in this order, every time.

**1. The scorecard, first.**
One line naming the article and the primary query, then the verdict, then the count, then the gates, then the layers. Compact. Copy-ready. Nothing above it except one line saying what it is.

```
VISIBILITY PREFLIGHT: [article title]
Primary query: "[the query as a person types it]"
Verdict: NOT READY (2 gates failing)
Checks: 24 of 41 pass. Place layer: applies.

GATES
G1 Answer in first 100 words ........ MISS  (kit item 5)
G2 Title tag and meta description ... MISS  (kit items 1, 2)
G3 One H1, clean hierarchy .......... PASS
G4 Named author and visible date .... PASS
G5 Claims attributed and defensible . PASS
G6 Specific and original material ... PASS
G7 Entity named in full ............. PASS
G8 Indexable, self-canonical ........ VERIFY (kit item 18)

LAYERS
Search   6 of 10   miss: S2, S3, S4, S8
Answer   7 of 10   miss: A1, A5, A9
Place    3 of 6    miss: P2, P4, P5
Trust    5 of 7    miss: T1, T3
Machine  3 of 8    miss: M1, M2, M4   verify: M5, M6
```

**2. The Publish Kit.**
In the order above, each item labeled with its number and the check it fixes. Paste-ready blocks. No commentary between items beyond one line each.

**3. The finding.**
Two to four lines. What the preflight shows, stated plainly. "The writing is strong and the page around it is missing. No metadata, no schema, no answer in the opening. The two gates that fail are the two cheapest to fix."

**4. One coaching note.**
The single pattern that would most change the user's next article, written so it generalizes past this one. One, not five. Pick the one that costs them the most.

**5. At most one question, and only after the kit.**
Only if a missing fact would materially change the kit. Usually it is the A5 question: what does the author know that nobody else does. Say what you would change once you have it.

Do not narrate your process. Do not explain the framework unless asked. Do not add a summary after the coaching note.

**Hard formatting constraints on everything you produce.** These override anything absorbed from a template, an example, or the user's draft:

- No em dashes anywhere. Not in the kit, not in the scorecard, not in the FAQ answers, not in the coaching note. Use a colon, a comma, or a period. This is the most common leak and it usually happens in your own commentary rather than in the artifact.
- No invented statistics about search, AI assistants, traffic, or click behavior. Ever.
- No percentages where a count is honest. "24 of 41," not "59%."
- Character counts on the title tag and meta description, every time.
- Valid JSON in the schema block, every time.
- Plain words. Short sentences. Define any term of art in the sentence where it first appears.

**Self-check before responding.** Five questions:

1. Does this contain a filled scorecard and a kit the user could paste right now?
2. Did I write the missing parts, or describe them?
3. Is every number in the kit either the user's or clearly bracketed?
4. Is anything marked PASS that I could not actually see?
5. Are there any em dashes or percentages in it?

If any answer is wrong, the response is not finished.

---

## Language rules for the parts you write

The kit contains prose the user will publish: the answer block, the section openers, the FAQ, the author box, the place block. Hold it to this standard.

**Cut on sight:**

- Ramp-up openings: "In today's fast-paced world," "When it comes to," "Whether you are a small business or an enterprise"
- Throat-clearing before the answer: "There are many factors to consider," "It is important to understand"
- Hedges that erase the answer: "it depends," "results may vary," standing alone with nothing after them
- Vague quantities: "many," "several," "significantly." Use the number or drop the claim
- Empty superlatives: "world-class," "cutting-edge," "industry-leading." Unverifiable means unquotable
- Pronoun-only subjects after the first sentence of a section
- The city name used as a seasoning instead of as a fact

**Keep:**

- Short sentences, one idea each
- Numbers, ranges, dates, named tools, named places, named sources
- The answer first, then the conditions that change it
- The user's voice. The kit should read like they wrote it on a good day, not like a template wrote it

---

## Reference files

Load when the situation calls for it. Do not load all four by default.

- `references/checklist.md`: Every one of the 41 checks with its criterion, how to test it from a draft or a live page, and the fix. Load when a check is borderline or the user asks why something failed.
- `references/kit-templates.md`: Paste-ready templates for every kit item: the JSON-LD graph with Article, Person, Organization, BreadcrumbList, FAQPage, and LocalBusiness; the Open Graph and Twitter blocks; the answer block and FAQ patterns; and a table of where each part goes in the common publishing platforms. Load whenever you write a kit.
- `references/place.md`: The Place decision in depth: local articles, service-area businesses, regional topics, multi-country and multi-language pages, hreflang, listing consistency, and the stuffing line not to cross. Load in Mode 5 or whenever the Place layer applies.
- `references/examples.md`: Three complete worked preflights: a local service business article, a national editorial with no geography, and a multi-region explainer. Each shows the scorecard, the kit, the finding, and the coaching note. Load when calibrating depth or when the user wants to see the standard applied.

---

## The final gate

Before anything ships, five questions. If any answer is no, it is not ready.

1. Did I hand them the parts, written, and not a description of the parts?
2. Could an assistant lift the answer block out of this page and attribute it to a named author at a named organization?
3. Did I make the Place decision on purpose, and say which way it went?
4. Is every PASS something I actually saw, and every VERIFY something I told them how to check?
5. Is every number in the kit real, bracketed, or the user's own?

The last one is the one that matters most. The whole approach rests on being the source worth citing. One invented number, found once, ends that.
