# Publish Kit Templates

Paste-ready shapes for every kit item. Fill them with the user's facts. Bracket only what you do not have, and name the exact fact inside the bracket.

Every name, number, and URL in the examples below is invented to show the shape. **Never carry an example value into a user's kit.**

---

## 1 and 2. Title tag and meta description

Always deliver with character counts.

```
Title tag (57): Commercial Roof Coating Cost in 2026: Per Square Foot Guide
Meta description (148): Most commercial roof coatings cost $1.50 to $4.00 per square foot installed. What moves the price, when coating beats replacement, and how to get a real quote.
```

Patterns that work for the title:

| Query shape | Title pattern |
|---|---|
| How much does X cost | X Cost: What You Will Pay and What Moves the Price |
| How to X | How to X (Step by Step, With What Goes Wrong) |
| X vs Y | X vs Y: Which to Choose and When |
| What is X | What X Is, How It Works, and When You Need It |
| Is X worth it | Is X Worth It? When It Pays Off and When It Does Not |
| Best X for Y | Best X for Y: How to Choose, With Real Trade-offs |

Patterns for the meta description:

- **Short-answer articles:** lead with the answer, then what the article adds. "Most jobs take 4 to 6 business days. Here is what makes it faster, slower, and more expensive."
- **No-short-answer articles:** lead with the specific promise. "The seven questions to ask before signing, and the two that most buyers skip."
- Never: "In this article we will explore," "Learn more about," "Click to find out."

## 3. URL slug

```
/commercial-roof-coating-cost
```

Not `/2026/03/the-complete-guide-to-commercial-roof-coating-costs-per-square-foot`.

## 5. Answer block

Sits directly under the H1. 40 to 80 words. Names the subject. Leads with the answer. One condition that changes it. One specific.

```
Commercial roof coating costs $1.50 to $4.00 per square foot installed in most U.S. markets,
or roughly a third of the cost of a full replacement on the same roof. Silicone sits at the
top of that range and acrylic at the bottom. The price rises when the existing roof needs
repair before coating, which is the case on about [share of your jobs that needed repair first].
```

The pattern: **answer, range or number, the main variable, the exception.** Nothing before the answer.

## 6. Heading outline

Deliver the whole structure, levels marked, with rewritten and added headings flagged.

```
H1  Commercial Roof Coating Cost: What You Will Pay in 2026
H2  How much does commercial roof coating cost per square foot?        (rewritten from "Pricing")
H2  What makes a roof coating cost more?                                (kept)
H3  Roof condition and repairs before coating                           (kept)
H3  Coating type: acrylic, silicone, polyurethane                        (rewritten from "Materials")
H3  Roof size and access                                                (added)
H2  Is coating cheaper than replacing the roof?                         (added, covers the comparison query)
H2  How long does a roof coating last?                                  (kept)
H2  How to get an accurate roof coating quote                           (rewritten from "Next Steps")
H2  Common questions about commercial roof coating costs                (added, FAQ)
```

## 7. Section openers

For each section that failed A2, the rewritten first two sentences.

```
H2  How long does a roof coating last?
Before: Roof coatings have come a long way in the past two decades, and the industry has
        seen significant improvements in formulation...
After:  A professionally applied silicone roof coating lasts 15 to 20 years before it needs
        a recoat, and acrylic lasts 10 to 15. Both numbers assume the roof was dry and
        repaired before application, which is where most early failures come from.
```

## 8. Definition sentence

```
A roof coating is a liquid membrane applied over an existing commercial roof to seal it and
reflect heat, as an alternative to tearing the roof off and replacing it.
```

Goes in the answer block or the first H2, before the term is used in argument.

## 9. FAQ block

Four to eight questions. Real phrasing. Standalone answers of 40 to 100 words. Subject named in the first sentence of each answer.

```
## Common questions about commercial roof coating costs

### Can you coat a roof that is already leaking?
A leaking commercial roof can be coated only after the leak is found and repaired. Coating
over an active leak traps moisture under the membrane and the coating fails within a season.
Most contractors inspect with a moisture scan first and price the repairs separately from the
coating, which is why a quote for a leaking roof arrives in two parts.

### Does roof coating lower energy bills?
A white reflective roof coating lowers cooling costs on buildings that run air conditioning
through the summer, because the roof surface stays cooler than a dark membrane. The saving
depends on the climate, the insulation under the roof, and how much of the building's energy
goes to cooling. [Your measured before-and-after figure from a real job, if you have one.]
```

Source the questions from: sub-questions the headings did not cover, the objections a buyer raises on a sales call, the edge cases, the "can I" and "do I need to" questions.

## 10. Author box

```
**[Author full name]** is [title] at [Organization], where [he/she/they] [the specific thing
that qualifies them on this topic, with a number if there is one: "has specified roof coatings
on more than 300 commercial buildings since 2011"]. [One line of credential or affiliation
if it is relevant to the topic.] [Link: author page] · [Link: LinkedIn]
```

Rules: the bio connects the person to this topic, not to their job in general. One or two sentences. A photo on the author page.

## 11. Date line

```
Published [Month D, YYYY]. Updated [Month D, YYYY]: [one line on what changed, e.g. "added
2026 regional price ranges"].
```

Omit the Updated clause until there is a substantive update.

## 12. Place block

Only when the Place layer applies. A paragraph of local specifics plus the location and service area lines.

```
In [City], the main cost driver on older flat roofs is [the local condition: freeze-thaw
cycling, hail, ponding from the region's flat-grade construction], which is why most
coating quotes here include a [the local norm: moisture scan, core sample]. The [County]
permit office treats a coating as maintenance rather than a re-roof, so no permit is
required for most buildings; [confirm with the county's current rule and link it].

[Organization] is located at [address exactly as on your contact page] and serves
[service area: the city plus named surrounding cities or counties, or "within N miles"].
```

The service area and any claim about the business (insurers accepted, warranties, sedation, a named lab) are the user's facts. Suggest, in brackets marked "confirm," and never state them as true. The `areaServed` list in the schema follows the same rule.

## 13. Internal link plan

```
1. Anchor: "how to tell whether your roof needs repair before coating"
   Sentence: Most early failures trace back to skipped repairs, so read [anchor] before you request quotes.
   Destination: [URL of your roof inspection or repair article]

2. Anchor: "silicone versus acrylic roof coatings"
   Sentence: The coating type sets the top and bottom of the price range, as covered in [anchor].
   Destination: [URL of your coating comparison page]

3. Anchor: "commercial roofing services in [City]"
   Sentence: For a quote on your building, see [anchor].
   Destination: [URL of your service or location page]

Inbound: your [existing page name] should link to this article with the anchor
"commercial roof coating cost" from the paragraph where it mentions pricing.
```

## 14. Source list

```
Claim: "Silicone coatings last 15 to 20 years"
   Needs: a manufacturer warranty document or an independent roofing association guide
   Status: [URL] or rewrite as "In our experience across [N] jobs, silicone coatings have lasted..."

Claim: "Coating costs about a third of replacement"
   Needs: your own quote data, or a named industry cost survey with a year
   Status: [URL or your figure]
```

Every claim ends as one of: sourced, rewritten as the author's observation, or cut.

## 15. Image plan

```
1. commercial-roof-coating-silicone-application.jpg
   Alt: A roofer applying white silicone coating with a roller on a flat commercial roof
   Role: social preview (1200 by 630)

2. roof-coating-cost-per-square-foot-table.png
   Alt: Table comparing acrylic, silicone, and polyurethane roof coating costs per square foot
```

Alt text describes the image for someone who cannot see it. It is not a keyword slot.

## 16. JSON-LD graph

One block. Valid JSON. ISO 8601 dates with an offset. Include FAQPage only when the FAQ is on the page. Include LocalBusiness only when the Place layer applies; otherwise use a plain Organization as the publisher.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Article",
      "@id": "https://www.example.com/commercial-roof-coating-cost#article",
      "mainEntityOfPage": { "@id": "https://www.example.com/commercial-roof-coating-cost" },
      "headline": "Commercial Roof Coating Cost: What You Will Pay in 2026",
      "description": "Most commercial roof coatings cost $1.50 to $4.00 per square foot installed. What moves the price, when coating beats replacement, and how to get a real quote.",
      "image": "https://www.example.com/images/commercial-roof-coating-silicone-application.jpg",
      "datePublished": "2026-03-04T09:00:00-06:00",
      "dateModified": "2026-03-04T09:00:00-06:00",
      "author": { "@id": "https://www.example.com/authors/jordan-reyes#person" },
      "publisher": { "@id": "https://www.example.com/#organization" },
      "spatialCoverage": { "@type": "Place", "name": "Austin, Texas" },
      "inLanguage": "en-US"
    },
    {
      "@type": "Person",
      "@id": "https://www.example.com/authors/jordan-reyes#person",
      "name": "Jordan Reyes",
      "url": "https://www.example.com/authors/jordan-reyes",
      "jobTitle": "Senior Estimator",
      "worksFor": { "@id": "https://www.example.com/#organization" },
      "description": "Has specified roof coatings on more than 300 commercial buildings since 2011.",
      "sameAs": [
        "https://www.linkedin.com/in/[profile]"
      ]
    },
    {
      "@type": "RoofingContractor",
      "@id": "https://www.example.com/#organization",
      "name": "Example Commercial Roofing",
      "url": "https://www.example.com/",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.example.com/images/logo.png"
      },
      "telephone": "+1-512-555-0100",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "[street address exactly as on your contact page]",
        "addressLocality": "Austin",
        "addressRegion": "TX",
        "postalCode": "[ZIP]",
        "addressCountry": "US"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": "[latitude]",
        "longitude": "[longitude]"
      },
      "areaServed": [
        { "@type": "City", "name": "Austin" },
        { "@type": "City", "name": "Round Rock" },
        { "@type": "City", "name": "Cedar Park" }
      ],
      "sameAs": [
        "https://www.google.com/maps/place/[your-listing]",
        "https://www.linkedin.com/company/[company]"
      ]
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.example.com/" },
        { "@type": "ListItem", "position": 2, "name": "Blog", "item": "https://www.example.com/blog/" },
        { "@type": "ListItem", "position": 3, "name": "Commercial Roof Coating Cost", "item": "https://www.example.com/commercial-roof-coating-cost" }
      ]
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can you coat a roof that is already leaking?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "A leaking commercial roof can be coated only after the leak is found and repaired. Coating over an active leak traps moisture under the membrane and the coating fails within a season. Most contractors inspect with a moisture scan first and price the repairs separately from the coating."
          }
        }
      ]
    }
  ]
}
</script>
```

Notes for the user, one line each:

- Swap `RoofingContractor` for the right LocalBusiness subtype (Dentist, Attorney, Plumber, Restaurant, and so on) or for `Organization` when the Place layer does not apply. Drop `address`, `geo`, and `areaServed` on a plain Organization.
- Use `BlogPosting` instead of `Article` for an informal blog; both are fine, pick one and keep it consistent across the site.
- `spatialCoverage` is valid schema with no documented ranking effect. Include it on local articles; leave it off placeless ones.
- Paste the finished block into a structured data validator before publishing. One missing comma invalidates the whole graph.
- Do not add HowTo schema for rich results; Google removed HowTo rich results in 2023. The numbered steps on the page are what matter.

## 17. Social preview tags

```html
<meta property="og:type" content="article">
<meta property="og:title" content="Commercial Roof Coating Cost: What You Will Pay in 2026">
<meta property="og:description" content="Most commercial roof coatings cost $1.50 to $4.00 per square foot installed. What moves the price, when coating beats replacement, and how to get a real quote.">
<meta property="og:url" content="https://www.example.com/commercial-roof-coating-cost">
<meta property="og:image" content="https://www.example.com/images/commercial-roof-coating-silicone-application.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:site_name" content="Example Commercial Roofing">
<meta property="article:published_time" content="2026-03-04T09:00:00-06:00">
<meta property="article:modified_time" content="2026-03-04T09:00:00-06:00">
<meta property="article:author" content="https://www.example.com/authors/jordan-reyes">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Commercial Roof Coating Cost: What You Will Pay in 2026">
<meta name="twitter:description" content="Most commercial roof coatings cost $1.50 to $4.00 per square foot installed. What moves the price and when coating beats replacement.">
<meta name="twitter:image" content="https://www.example.com/images/commercial-roof-coating-silicone-application.jpg">
```

Most platforms generate these from editor fields. The block shows what those fields should contain.

## 18. Site-level checklist

Written for whoever runs the site. Each item has the exact test.

```
SITE-LEVEL CHECKS (cannot be verified from the draft)

[ ] Canonical. View source. Confirm:
    <link rel="canonical" href="https://www.example.com/commercial-roof-coating-cost">
    If this article will also appear on Medium or a partner site, the copy's canonical
    must point here, or the copy must link here as "originally published at."

[ ] Indexable. View source. Confirm there is no
    <meta name="robots" content="noindex"> on the page.

[ ] In the sitemap. Open https://www.example.com/sitemap.xml and search for the article URL.

[ ] Crawler access. Open https://www.example.com/robots.txt. Read every Disallow line.
    Decide which AI crawlers to admit; common ones are GPTBot, OAI-SearchBot, ClaudeBot,
    PerplexityBot, and Google-Extended. Allowing or blocking them is your policy decision.
    Make it on purpose.

[ ] Content in the HTML. View source and search for this sentence from the answer block:
    "[first sentence of the answer block]". Then search for one FAQ question. Both must
    appear in the source, not only after scripts run.

[ ] One H1. View source and count <h1> tags. The site name or logo must not be one.

[ ] Internal link in. Add a link to this article from [existing page] with the anchor
    "[anchor text]".

[ ] Phone check. Open the page on a phone. Nothing should cover the first paragraph
    on load.

[ ] Validate the schema. Paste the JSON-LD block into a structured data validator and
    fix any error before publishing.
```

---

## Where each part goes, by platform

| Part | WordPress (Yoast or Rank Math) | Webflow | Squarespace | Ghost | HubSpot | Substack | Medium |
|---|---|---|---|---|---|---|---|
| Title tag | Plugin "SEO title" field | Page settings, Title Tag | Page SEO, SEO Title | Post settings, Meta title | Settings, Page title | Post title only (no separate tag) | Post title only |
| Meta description | Plugin "Meta description" | Page settings, Meta Description | Page SEO, SEO Description | Post settings, Meta description | Settings, Meta description | Subtitle serves as preview | Subtitle serves as preview |
| Slug | Permalink | Page slug | URL slug | Post URL | Content slug | Post URL (editable before publish) | Not controllable |
| Author box | Author bio in user profile, or theme author box | Collection field or CMS author reference | Author block or manual text | Author profile | Author profile | Publication About; author line fixed | Profile only |
| Date line | Theme shows it; add Updated line in body | CMS date field | Automatic; add Updated line in body | Automatic | Automatic | Automatic | Automatic |
| JSON-LD | Plugin schema settings, or a header/footer script plugin, or Custom HTML block | Page settings, custom code in head | Code injection (Business plan and above) | Code injection, per post | Settings, head HTML | Not supported | Not supported |
| OG and Twitter tags | Plugin social tab | Page settings, Open Graph | Social image per page | Post settings, Facebook/Twitter cards | Settings, featured image and meta | Automatic from title, subtitle, cover | Automatic |
| Canonical | Plugin advanced tab | Automatic self; custom via head code | Automatic self | Post settings, Canonical URL | Settings, Canonical URL | Not controllable | Import tool sets canonical to original |
| FAQ markup | Plugin FAQ block, or JSON-LD | JSON-LD in head | JSON-LD via code injection | JSON-LD in post code injection | JSON-LD in head | Not supported | Not supported |

Where a platform does not support a part, say so in one line and move on. Substack and Medium carry the writing; the rest of the kit lives on a page the user controls.
