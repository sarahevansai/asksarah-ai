# The 41 Checks

Every check has three parts: the criterion, how to test it from what the user gave you, and the fix. Score each PASS, MISS, or VERIFY. VERIFY is only for site-level facts that cannot be seen in pasted text or fetched HTML. A VERIFY is never a PASS.

Gate checks are marked. A failing gate makes the verdict NOT READY regardless of the count.

The ranges below are working guidance that holds up across many articles. They are not research findings and should never be presented as ones.

---

## Search layer

### S1. One primary query, matched to intent

**Criterion.** The article answers one question a real person types, and its shape matches why they typed it. Four intents: to learn (explainer, definition), to compare (X vs Y, best X for Y), to decide (is X worth it, should I), to do (how to, step by step). A how-to query answered by an essay fails. A comparison query answered by a single-product page fails.

**Test.** Write the query out in the person's words. Read the H1 and the first 100 words. Do they answer that query, or a neighboring one the writer preferred? Check the shape: does a "how to" query get numbered steps, does a "vs" query get a recommendation and a table?

**Fix.** Name the query at the top of the scorecard. If the article answers a different question, say which one, and recommend either retitling to the question it actually answers or restructuring to the one it should.

### S2. Title tag (gate G2)

**Criterion.** Roughly 50 to 60 characters. The query or its natural phrasing in the first half. Written to be clicked by a person, not assembled from keywords. May differ from the H1. No brand name unless the brand is the subject or there is room after a separator.

**Test.** Count the characters. Find the query. Read it as a search result among nine others: would you pick it?

**Fix.** Write it. Give the count. Offer one alternative only if the first makes a trade the user should decide, like dropping the brand.

### S3. Meta description (gate G2)

**Criterion.** Roughly 120 to 155 characters. States the answer or the specific promise. Contains the query naturally. The clause that carries the value is in the first 120 characters so it survives truncation on a phone. No "click here," no "learn more."

**Test.** Count. Find the answer or the promise. Cover everything after character 120 with your hand: does what remains still sell the click?

**Fix.** Write it. Give the count. Lead with the answer when the article has a short one ("Most commercial roof coatings cost $1.50 to $4.00 per square foot installed.") and with the specific promise when it does not.

### S4. URL slug

**Criterion.** Three to six lowercase words, hyphenated, built from the query. No dates, no years, no stop-word strings ("the-complete-guide-to-the"), no numbers that go stale ("7-ways" when the list will grow). Stable: changing it later means a redirect and a reset.

**Test.** Read the slug. Remove every word that is not in the query or necessary for sense. What remains should still describe the page.

**Fix.** Write it. If the page is already live with a worse slug, say to keep it unless the site can 301 redirect cleanly, because a stable bad slug beats a broken good one.

### S5. One H1 (gate G3)

**Criterion.** Exactly one H1. Names the subject. Matches the promise in the title tag, though the wording may differ.

**Test.** Count H1s. In pasted markdown, that is the single `#` line. In HTML, the `<h1>` tags. Check for a logo or site name wrapped in an H1 above the article, which makes two.

**Fix.** Write the H1 if it changes. If the theme wraps the site name in an H1, add it to the site-level checklist as a thing for the developer to change.

### S6. Query and answer in the first 100 words

**Criterion.** The query's words appear naturally in the first 100 words, and the answer appears with them. The word alone, with the answer further down, does not pass.

**Test.** Count 100 words from the start of the body. Find the query. Find the answer. Both, or MISS.

**Fix.** Usually solved by A1, the answer block. If the answer block is present and the query words are not, rework the block's first sentence to carry them.

### S7. Headings carry the sub-questions (gate G3)

**Criterion.** H2s and H3s are the follow-up questions a searcher would otherwise go back to search for. The hierarchy never skips a level (H2 to H4) and never uses a heading tag for visual size. Coverage is judged here: if finishing the article would leave a reader needing a second search, a heading is missing.

**Test.** List the headings in order with their levels. For each, ask: is this a question a person asks, or a label? List the questions a reader would still have at the end. Each one is a missing heading.

**Fix.** Deliver the full heading outline with rewritten headings marked and missing sections added. Patterns: "How much does X cost," "Is X better than Y for Z," "What is X," "When to choose X," "What can go wrong with X." A declarative heading that states the answer also passes: "Slab leak repair costs $1,500 to $4,000."

### S8. Internal links

**Criterion.** At least three links to related pages on the same site, each with anchor text that describes the destination (not "here," not "this article"). At least one existing page on the site links to this one, so it is not an orphan.

**Test.** Count internal links in the draft. Read each anchor. Ask the user, or infer from the site, which existing page would link in.

**Fix.** Deliver the internal link plan: three anchor texts, the sentence each sits in, a bracket for the destination URL naming the kind of page it should be. Name the existing page that should link in and the anchor it should use.

### S9. External links to primary sources

**Criterion.** Every borrowed fact links to its origin: the study, the regulation, the dataset, the original report. Not a news article that mentions the study, not an aggregator. The claim sits next to its link, not in a footer.

**Test.** Find every statistic, quote, or external claim. Is there a link? Does it go to the origin or to someone repeating it?

**Fix.** Deliver the source list: each claim, the kind of source that would satisfy it, and a bracket for the URL. If the origin cannot be found, the claim is a T4 problem as well, and it comes out or gets rewritten as the author's own observation.

### S10. Images carry meaning

**Criterion.** Every image has a descriptive filename (`commercial-roof-coating-application.jpg`, not `IMG_4471.jpg`) and alt text that describes what is in the image, naming the subject where that is honest. One image is sized to serve as the social preview, 1200 by 630. Images are compressed.

**Test.** List the images. Read filenames and alt text. Is any alt text a keyword string rather than a description? Is there a landscape image that could be the preview?

**Fix.** Deliver the image plan: filename and alt text per image, and which one is the preview. Alt text describes the image for a person who cannot see it; that is the whole rule.

---

## Answer layer

### A1. The answer block (gate G1)

**Criterion.** A complete answer to the primary question in roughly 40 to 80 words, directly under the H1 or after a one-line lede at most. It makes sense lifted out with nothing around it. It names the subject. It contains at least one specific.

**Test.** Read the first paragraph alone. Does it answer the question in the title? Would it be a complete answer if it were the only thing quoted?

**Fix.** Write it. Lead with the answer, then the one condition that most changes it. The rest of the article becomes the support.

### A2. Every section leads with its answer

**Criterion.** The first two sentences under each H2 answer the heading. Context, caveats, exceptions, and story come after.

**Test.** For each H2, read only the first two sentences. Do they answer the heading? The usual failure is the answer sitting in sentence four or five, behind setup the writer needed in order to think.

**Fix.** Deliver rewritten openers for each failing section. The usual fix is to move, not to write: the answer is already in the section, lower down.

### A3. One claim per paragraph, support attached

**Criterion.** Each paragraph makes one point and carries its own support, the number, example, or reason, in the same paragraph. Paragraphs run two to four sentences.

**Test.** Pick the three longest paragraphs. Count the claims in each. Any paragraph with three claims is quotable for none of them.

**Fix.** Name the paragraphs to split and how. Do not rewrite the whole body unless the user asks; this is a pattern note with examples.

### A4. Checkable specifics (gate G6)

**Criterion.** Numbers, dates, ranges, named tools, named sources, real examples: something a reader could verify or a competitor could not have guessed. At least one in every major section.

**Test.** For each H2 section, find one checkable thing. A section with none is interchangeable with every competitor's version.

**Fix.** Name each section that lacks one and the kind of specific that would fit, in brackets naming the exact fact: `[your average install time in days, from your last 20 jobs]`. Never supply the number yourself.

### A5. Original material (gate G6)

**Criterion.** At least one thing on the page that a competitor could not have written: the author's own data, a tested process, real pricing, a failure and what it taught, a practitioner detail only someone who does the work would know.

**Test.** Ask: could someone with no experience in this field have written this page from other pages? If yes, MISS.

**Fix.** This is the one question worth asking the user. Name three kinds of original material that would fit this article and ask for one. If they cannot answer, deliver the rest of the kit and mark the page as passable but interchangeable.

### A6. Entity clarity (gate G7)

**Criterion.** The subject, the company, the product, and the author are named in full on first use in each major section. The same name is used throughout. No passage runs on "we," "it," "our platform," or "the company" long enough that a lifted paragraph would not say who it is about.

**Test.** Lift any paragraph from the middle of the article. Does it say who or what it is about without the paragraphs around it?

**Fix.** Mark the passages where the name drops out and supply the sentence that restores it. Note the canonical name to use everywhere, matching the About page.

### A7. A definition where the topic has one

**Criterion.** When the article is about a thing with a name, the thing is defined early, in plain words, in "X is" form. "A sinking fund is money set aside each month for a known future expense."

**Test.** Does the topic have a term a reader might not know? Is it defined in one sentence before it is used in argument?

**Fix.** Write the definition sentence and say where it goes, usually the first or second sentence of the answer block or the first H2.

### A8. Lists and tables where the content is one

**Criterion.** Steps are numbered. Items are bulleted. Anything that compares two or more things across the same dimensions is a table with real values in every cell.

**Test.** Find prose that lists ("first, then, after that," or "X offers A, B, and C while Y offers D and E"). That prose is a list or a table wearing a paragraph.

**Fix.** Convert it. Deliver the table with the dimensions as rows and the options as columns, values bracketed only where the user holds them.

### A9. A real FAQ

**Criterion.** Four to eight questions in the words people actually ask, each with a standalone answer of roughly 40 to 100 words that would make sense quoted alone. No question invented to fill a slot. Questions do not duplicate the H2s; they catch what the body did not.

**Test.** Is there an FAQ? Are the questions real (could you imagine a person typing each one)? Does each answer stand alone?

**Fix.** Write the FAQ. Source the questions from the sub-questions the headings did not cover, the objections a buyer raises, and the edge cases. Each answer names the subject in its first sentence.

### A10. Language that can be quoted

**Criterion.** No ramp-up openings, no throat-clearing, no hedges standing alone, no unverifiable superlatives, no vague quantities. A sentence that says nothing cannot be lifted, and a page full of them gets passed over for one that commits.

**Test.** Read the first sentence of each section and the first sentence of the article. Scan for "in today's," "when it comes to," "it depends," "many," "significantly," "world-class."

**Fix.** List the sentences to cut or replace, with the replacement. Keep the user's voice. The fix for a hedge is the answer that is right most of the time followed by the condition that changes it.

---

## Place layer

Apply only when the Place decision says the article has a geography. Otherwise N/A, denominator 35. Full guidance in `place.md`.

### P1. The place is named where it matters

**Criterion.** For a local article, the place appears in the first 100 words and in at least one H2. It appears in the title tag and H1 only when the query itself is local. "Best time to seal an asphalt driveway in Minnesota" is a local query. "How to seal an asphalt driveway" is not, even if a Minnesota company wrote it.

**Test.** Is the query local? Where does the place first appear? Is it in a heading?

**Fix.** Place the name where it belongs and remove it from where it does not. Over-placement is a MISS too.

### P2. Local specifics, not a repeated city name

**Criterion.** The article contains things only someone who knows the place would write: the permit rule, the frost line, the neighborhoods where this problem is common, the typical local price, the local utility, the local court, the local source.

**Test.** Replace the city name with another city. Does the article still read as true? If yes, there are no local specifics, only a label.

**Fix.** Write the place block: a paragraph of local specifics with brackets naming the exact local fact to confirm. `[the name of the county permit office and its typical turnaround]`.

### P3. Business location signals, consistent

**Criterion.** Name, address, and phone number match the site's contact page and the business's map listing exactly, down to "Suite" versus "Ste." Service area stated. A link to the location or contact page.

**Test.** Compare the article's business details, if any, to the contact page and the map listing. Any variation is a MISS.

**Fix.** Deliver the location line in the exact form used on the contact page, and the service area sentence. Note any inconsistency across the site for the developer.

### P4. Place in the structured data

**Criterion.** The publisher is described as the local business it is (LocalBusiness or a subtype, with address, geo, and areaServed), on the location page at minimum, and referenced from the article's publisher field. The Article may carry `spatialCoverage` naming the place, which is valid schema with no documented ranking effect and no cost. No LocalBusiness markup on an article that is not about a business.

**Test.** Is there LocalBusiness schema anywhere on the site? Does the article's schema connect to it?

**Fix.** Deliver the LocalBusiness block in the JSON-LD graph, with brackets for address and coordinates.

### P5. Audience locale matches

**Criterion.** Spelling, currency, units, date format, phone format, and legal or regulatory references match the audience. An article for UK readers does not price in dollars. A page meant for two countries is two pages linked by hreflang, not one mixed page.

**Test.** Who is the reader? Does every locale signal match? Is there any place where two audiences are served by one paragraph?

**Fix.** List the mismatches and the corrections. If the article serves multiple regions, deliver the hreflang plan from `place.md`.

### P6. Local links and sources

**Criterion.** Links to local institutions, local data, local coverage, local partners where relevant. A map embed where it would help a reader find something. Local sources cited by name.

**Test.** Count links that resolve to something in the place. Zero is a MISS for a local article.

**Fix.** Name the kinds of local links that fit, in brackets: `[the city permit page for residential re-roofing]`, `[your Google Business Profile]`.

---

## Trust layer

### T1. A named author with a reason to be believed (gate G4)

**Criterion.** A byline with a real person's name. A link to an author page. A bio of one or two sentences that states why this person is qualified on this topic specifically, not a general résumé line.

**Test.** Is there a name? A link? Does the bio connect the person to the subject? "Marketing lead at Acme" does not qualify someone on roof coatings. "Has specified coatings on 300 commercial roofs since 2011" does.

**Fix.** Write the author box with brackets for the credential facts. Recommend an author page if none exists and say what it needs: photo, bio, links to profiles, list of articles.

### T2. Experience shown, where true

**Criterion.** First-hand evidence appears where the author has it: "in our last 40 installs," "I ran this process for six months," a screenshot or photo of the author's own work. Never invented, never implied where it does not exist.

**Test.** Is there any first-person evidence? Is it specific enough to be real?

**Fix.** Name where a first-hand line would fit and what it should contain, bracketed. If the author has no direct experience of the topic, say so; the fix is a different author or a sourced-explainer framing that does not claim experience.

### T3. Dates a reader can see (gate G4)

**Criterion.** A published date in plain text near the byline. An updated date only when something substantive changed, with one line saying what. Dates in the schema match the dates on the page.

**Test.** Is there a visible date? If there is an updated date, is there a reason given?

**Fix.** Write the date line. Recommend the review cadence: pages with prices, tools, laws, or availability get a calendar reminder; everything else can run longer.

### T4. Every statistic and external claim attributed inline (gate G5)

**Criterion.** Each borrowed number or claim names its source in the sentence or the one after, with a link to the origin. "According to the 2024 Census Bureau Housing Survey" passes. "Studies show" fails. "Experts agree" fails.

**Test.** Find every number not from the author's own work. Find its source. Find the link.

**Fix.** Deliver the source list. Each claim gets one of three outcomes: sourced, rewritten as the author's own observation, or cut.

### T5. Nothing the author cannot defend (gate G5)

**Criterion.** No invented statistics. No quotes without a real, named person who agreed to be quoted. No claim that would not survive a fact-check by a hostile competitor. No number that sounds right and was never checked.

**Test.** Read every number and every quote as the competitor would. Which one would they challenge first?

**Fix.** Name it. The fix is a source, a softer claim the author can stand behind, or removal. Never the same claim with a hedge attached.

### T6. Transparency

**Criterion.** Affiliate links, sponsorship, or paid placement disclosed where the law or the site's policy requires. AI assistance disclosed if the site's policy requires it. A corrections note if the piece was materially changed after publication. A reachable contact page on the site.

**Test.** Are there affiliate links or a sponsor? Is there a disclosure? Was the article changed?

**Fix.** Write the disclosure line in plain words. Add the contact page to the site-level checklist if it cannot be found.

### T7. Consistency across the web

**Criterion.** The author's name, title, and description match the About page, the author page, and the author's public profiles. The organization's name and one-line description match everywhere it appears. Inconsistent identity splits into fragments that each look smaller than the whole.

**Test.** Compare the byline and bio to whatever the user has given you about the author elsewhere. Note any variation in name form (initials, middle names, titles).

**Fix.** Recommend the canonical form and list the places to align it. Put the sameAs links in the Person and Organization schema so the names resolve to the profiles.

---

## Machine layer

### M1. Article schema

**Criterion.** Article or BlogPosting JSON-LD with headline, image, datePublished, dateModified, author (a Person with name, url, and sameAs), publisher (an Organization with name and logo), and mainEntityOfPage. Dates in ISO 8601 with a timezone offset. Headline matches the H1.

**Test.** In pasted text: MISS, always, and write it. In fetched HTML: find the `<script type="application/ld+json">` blocks and read them. Missing fields are a MISS.

**Fix.** Deliver the graph from `kit-templates.md` with the user's values filled and brackets only where you do not have the fact.

### M2. FAQ schema only when the FAQ is visible

**Criterion.** FAQPage JSON-LD present when, and only when, the FAQ is on the page, with questions and answers matching the visible text word for word. Google now shows FAQ rich results for few site types, mainly government and health. The markup still describes the page accurately for every other reader and costs nothing. Markup for questions not on the page is a liability.

**Test.** Is there an FAQ on the page? Is there FAQPage schema? Do they match?

**Fix.** Include FAQPage in the graph when the FAQ exists. Omit it when it does not, and say why.

### M3. Breadcrumb and identity schema

**Criterion.** BreadcrumbList describing the page's position (Home, Section, Article). sameAs arrays on the Person and the Organization pointing to their public profiles so the names resolve to known entities.

**Test.** Present in the HTML or not. In pasted text, MISS.

**Fix.** Include both in the graph. Brackets for profile URLs.

### M4. Social preview tags

**Criterion.** og:title, og:description, og:image (1200 by 630, absolute URL), og:url, og:type set to article, article:published_time, article:modified_time, article:author, plus twitter:card set to summary_large_image, twitter:title, twitter:description, twitter:image.

**Test.** Present in the HTML or not. In pasted text, MISS.

**Fix.** Deliver the block from `kit-templates.md`. Note that most platforms generate these from fields in the editor; the block shows what those fields should contain.

### M5. Canonical (gate G8)

**Criterion.** A `<link rel="canonical">` pointing at this page's own URL. If the piece is syndicated or cross-posted, the copy's canonical points at the original, or at minimum the copy links to the original as the source.

**Test.** From HTML: read the tag. From pasted text: VERIFY. Ask whether the piece will appear anywhere else.

**Fix.** Site-level checklist item with the exact tag. If syndication is planned, name which platforms honor canonical (Medium does, through its import tool; LinkedIn articles and Substack do not) and advise a one-line "originally published at" link where they do not.

### M6. Reachable by every reader that matters (gate G8)

**Criterion.** No noindex on the page. The page is in the XML sitemap. At least one internal link points to it. robots.txt allows the search crawlers and whichever AI crawlers the site has decided to admit. Common AI crawlers: GPTBot and OAI-SearchBot (OpenAI), ClaudeBot (Anthropic), PerplexityBot (Perplexity), Google-Extended (Google's AI products, separate from Search). Which to allow is the site owner's decision; the preflight's job is to make sure it was a decision and not an accident.

**Test.** Almost always VERIFY. Give the three checks: view source for a robots meta tag, open `/sitemap.xml` and search for the URL, open `/robots.txt` and read the Disallow lines.

**Fix.** Site-level checklist item with the three checks written out and the crawler list so the owner can decide.

### M7. The content is in the served HTML

**Criterion.** Headings are real heading tags. The FAQ is in the page source, not only built by a script after load. The body text is present when scripts are disabled. Google renders scripts, with a delay; several AI crawlers read only the raw HTML. The strictest reader sets the standard.

**Test.** From HTML: search the source for a sentence from the body and a question from the FAQ. From pasted text: VERIFY, with the test written out ("view source, search for this sentence").

**Fix.** Site-level checklist item. If the platform renders client-side only, say so and name the usual remedies: server rendering, static export, or a pre-render service.

### M8. Page basics

**Criterion.** Readable on a phone without zooming. Images have declared width and height so the page does not jump. Nothing covers the answer block on load: no newsletter modal, no cookie wall over the content, no autoplay video pushing the opening below the fold.

**Test.** From a live page: open it on a phone, or narrow the browser. From pasted text: VERIFY.

**Fix.** Site-level checklist item. Name the specific obstruction if you saw one.
