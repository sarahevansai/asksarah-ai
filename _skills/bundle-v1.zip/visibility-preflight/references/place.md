# The Place Layer

Geolocation is the layer most articles get wrong, in one of two directions. A local business publishes a genuinely useful article with no place in it and loses to a thinner article from a competitor that said where it was. A national publisher pastes a city name into a placeless explainer and reads as spam. Both failures come from skipping the decision.

---

## The decision

Make it before scoring, and say which way it went in one line on the scorecard.

**The Place layer applies when any of these is true:**

1. **The publisher serves a defined area.** A clinic, a law firm, a contractor, a restaurant, a school, a regional agency, a franchise location. Their articles are part of how they get found by people nearby, whether or not the article mentions the area.
2. **The topic is local or regional by nature.** A law, a permit, a code, a tax, a climate, a market price, a venue, an event, a school district, a transit line.
3. **The reader's answer changes by location.** Licensing, insurance, cost of living, availability, legal thresholds, growing seasons. "How much does a nanny cost" has a different answer in Boise and in Manhattan.
4. **The audience spans countries or languages.** The article needs to fit more than one locale, which is its own problem with its own fix.

**The Place layer does not apply when the subject is placeless:** an opinion on an industry trend, a software tutorial, a general explainer whose answer is the same everywhere, a piece of commentary. Mark it N/A, drop the six checks from the denominator (41 becomes 35), and move on.

**The line not to cross.** Forcing a place into a placeless article is stuffing. It is the one preflight fix that makes an article worse, because a reader can tell when a city name is seasoning, and so can anything that reads for meaning. If the only local thing you can add is the name, do not add it.

---

## What "local" actually means on a page

The goal is not to repeat a city name. It is to write the things only a local would know.

The test: **replace the city name with another city. Does the article still read as true?** If yes, there are no local specifics, only a label. The article is not local. It just says it is.

What passes:

- **The rule.** The permit, the code, the ordinance, the licensing board, the court, the agency, by name, with a link.
- **The condition.** The climate, the soil, the water, the frost line, the hurricane season, the building stock ("most houses in [neighborhood] were built before 1960 and have cast iron drains").
- **The price.** What the thing costs in this market, from the author's own quotes or jobs, stated as a range with the year.
- **The institution.** The hospital, the university, the utility, the transit authority, the chamber, the local trade association.
- **The geography.** The neighborhoods where this problem is common, the side of town where the soil is clay, the corridor where the traffic study was done.
- **The source.** Local coverage, local data, a local expert quoted by name.

A single paragraph of this does more than a hundred mentions of the city.

---

## Where the place goes

| Article type | Title tag and H1 | First 100 words | At least one H2 | Body |
|---|---|---|---|---|
| Local query ("in Austin," "for Texas landlords") | Yes | Yes | Yes | Local specifics throughout |
| Local business, general topic ("how to seal a driveway," written by a Minnesota company) | No | Yes, once, naturally | Yes, one section on local conditions | One local paragraph plus the location line |
| Regional topic, national audience ("how California's new solar rule works") | Yes, the region is the subject | Yes | Yes | The region is the article |
| Multi-country audience | One page per locale | Per page | Per page | Per page, with hreflang linking them |

The second row is where most local businesses lose. They write a good general article and never say where they are. The fix is one honest local section and the location line, not a rewrite.

---

## The six checks in depth

### P1. The place is named where it matters

Put the place in the title and H1 only when the query itself is local. "Best time to seal an asphalt driveway in Minnesota" is a local query; a person types the state because the answer depends on it. "How to seal an asphalt driveway" is not, even when a Minnesota company writes it. For the second kind, the place goes in the first 100 words once, in one H2 about local conditions, and in the location line. Not in the title.

Over-placement is a MISS as surely as under-placement.

### P2. Local specifics

Run the city-swap test. Deliver a place block: one paragraph of local specifics with brackets naming the exact local fact to confirm, so the user can verify each one before publishing.

```
In [City], [the local condition that changes the answer], which is why [the local norm it
produces]. [The local rule or permit, by name, with what it requires], per [the office or
agency, linked]. [The local price range from your own jobs, with the year].
```

### P3. Business location signals, consistent

Name, address, and phone must match across the article, the contact page, the location page, and the business's map listing, down to punctuation and abbreviation. "Suite 200" on one and "Ste. 200" on another is a mismatch. "(512) 555-0100" and "512-555-0100" is a mismatch to a strict reader.

Pick the form on the map listing as canonical, because it is the one the user controls least, and align everything else to it.

State the service area in words: the city plus the named surrounding cities or counties, or a radius. "Serving Austin, Round Rock, Cedar Park, and Georgetown" is a sentence a reader and a machine can both use.

The service area is the user's fact, not yours. Knowing which suburbs sit next to a city does not tell you which ones this business serves. Propose them inside a bracket marked "confirm" and let the user cut the list. The same goes for `areaServed` in the schema.

Link the article to the location or contact page with a descriptive anchor.

### P4. Place in the structured data

Three parts:

1. **The business as the publisher.** Describe the publisher as the LocalBusiness subtype it is (Dentist, Attorney, Plumber, RoofingContractor, Restaurant, MedicalClinic, and so on) with `address`, `geo`, `telephone`, `areaServed`, and `sameAs` pointing to the map listing. This block lives on the location or contact page and is referenced by `@id` from the article's `publisher`.
2. **The article's place.** `spatialCoverage` on the Article, naming the place. Valid schema, no documented ranking effect, no cost.
3. **What not to do.** Do not put LocalBusiness markup on an article that is not about a business, and do not invent a location for a publisher that does not have one. Schema describes what is true.

The full graph is in `kit-templates.md`, item 16.

### P5. Audience locale matches

Every locale signal must agree with the reader:

- Spelling: color or colour, organize or organise.
- Currency and its symbol and placement: $1,500, £1,500, 1 500 €.
- Units: square feet or square metres, Fahrenheit or Celsius.
- Date format: March 4, 2026 or 4 March 2026.
- Phone format and country code.
- Legal and regulatory references: the agency, the statute, the standard, for that jurisdiction.

One mismatch tells a reader the page was not written for them. Several tell them it was written for nobody in particular.

**One page per locale.** When an article must serve two countries or two languages, it becomes two pages, each fully in its locale, linked by hreflang. A single page that alternates between dollars and pounds, or that says "in the US... and in the UK..." every paragraph, serves neither reader well and competes with itself.

### P6. Local links and sources

A local article links to local things: the permit page, the utility, the hospital, the school district, the local news coverage, the local dataset, the business's own map listing. A map embed where it helps a reader find something physical.

Zero local links on a local article is a MISS. The links are also the slow-burn signal: an article that cites local institutions is the kind of article local institutions eventually cite back.

---

## Multi-region and multi-language pages

When the audience spans locales, the Place layer becomes a structure problem.

**The rule:** one URL per language-region pair, each a complete page in that locale, linked to every other version with hreflang tags, each one self-canonical.

**The hreflang plan to deliver:**

```
Pages:
  https://www.example.com/en-us/roof-coating-cost/   (English, United States)
  https://www.example.com/en-gb/roof-coating-cost/   (English, United Kingdom)
  https://www.example.com/es-mx/costo-recubrimiento-techo/   (Spanish, Mexico)

Every one of the three pages carries all of these tags in its head:
  <link rel="alternate" hreflang="en-us" href="https://www.example.com/en-us/roof-coating-cost/">
  <link rel="alternate" hreflang="en-gb" href="https://www.example.com/en-gb/roof-coating-cost/">
  <link rel="alternate" hreflang="es-mx" href="https://www.example.com/es-mx/costo-recubrimiento-techo/">
  <link rel="alternate" hreflang="x-default" href="https://www.example.com/en-us/roof-coating-cost/">

Each page's canonical points to itself, not to the English version.
```

Rules that trip people up:

- Every page in the set lists every page in the set, including itself. Hreflang is reciprocal; a one-way tag is ignored.
- `x-default` names the page to show when no locale matches. Usually the main English page or a language picker.
- Each page's canonical is itself. Pointing all canonicals at the English page tells engines the others are duplicates, which undoes the whole structure.
- Language codes are ISO 639-1, region codes are ISO 3166-1 alpha-2, joined by a hyphen: `en-gb`, not `en-uk`.
- A translated page is a different page. Translate the title tag, meta description, slug, headings, FAQ, and schema, not only the body.
- Machine-translate a page and publish it unedited and you have a page that fails A4, A5, and A10 in a second language.

For a site with one language but several regions in the same language (US and UK English, for example), the same rule holds: separate pages, separate locale signals, hreflang between them. The temptation to write one English page "for everyone" produces a page with no prices, no units, and no laws in it, which is a page with no specifics, which fails the Answer layer.

---

## The business listing

For a local business, the article is one of three things a reader and an engine connect: the article, the website's location page, and the business's map listing. The preflight checks the article and says what the other two must match. It does not manage the listing, but it names what to confirm:

- Business name, address, and phone identical to the website.
- Primary category correct.
- Hours current.
- A link from the listing to the website, and from the location page to the listing (in `sameAs`).
- The same business description in the listing, the About page, and the Organization schema.

An article about a local topic from a business whose listing says a different address than its website is an article with a credibility problem it cannot fix on its own.

---

## Things people ask about that do not matter much

Say these plainly when they come up, so the user spends effort where it counts.

- **Geotagging image files.** Writing coordinates into a photo's metadata. There is no public evidence it affects how a page ranks or gets cited. It is harmless and cheap, so do it if the workflow already supports it, and never do it instead of writing the local paragraph.
- **Repeating the city in every heading.** Stuffing. One honest local section outperforms a page where every H2 ends in "in Austin."
- **Buying "local citations" in bulk.** Directory listings that nobody reads. Consistency across the few listings that matter (the map listing, the major review sites, the chamber or trade association) is the goal, not volume.
- **A separate page for every suburb with the same text.** Doorway pages. If the content is identical with the place name swapped, it fails the city-swap test by construction, and it is the pattern engines are built to discount.
