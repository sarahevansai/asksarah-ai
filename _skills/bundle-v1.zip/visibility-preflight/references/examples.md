# Worked Preflights

Three complete runs showing the standard applied: a local service business article, a national editorial with no geography, and a multi-region explainer. Each shows the scorecard, the kit, the finding, and the coaching note at the depth a real run should have.

Every company, person, number, and URL below is invented to show the shape. **Never carry a value from this file into a user's kit.**

---

## Example 1: Local service business article

**What the user gave.** A 1,400 word draft pasted as plain text, titled "Everything You Need to Know About Sewer Line Repair," from a plumbing company in Portland, Oregon. The user said: "Check this before I publish. We want it to show up when people around here search."

**What the draft looked like.** A friendly, competent piece. Opened with two paragraphs about how stressful plumbing problems are. Headings were "Overview," "Signs of a Problem," "Repair Options," "Costs," "Why Choose Us." No byline, no date. One mention of Portland, in the last paragraph. Costs section gave national ranges "according to industry sources." No FAQ. No links.

**The Place decision.** Applies. The publisher serves a defined area, and the answer to "what does sewer line repair cost" changes by city.

### The scorecard

```
VISIBILITY PREFLIGHT: Everything You Need to Know About Sewer Line Repair
Primary query: "sewer line repair cost portland"
Verdict: NOT READY (5 gates failing)
Checks: 9 of 41 pass. Place layer: applies.

GATES
G1 Answer in first 100 words ........ MISS   (kit item 5)
G2 Title tag and meta description ... MISS   (kit items 1, 2)
G3 One H1, clean hierarchy .......... MISS   (kit item 6: headings are labels, H2 to H4 skip in "Repair Options")
G4 Named author and visible date .... MISS   (kit items 10, 11)
G5 Claims attributed and defensible . MISS   (kit item 14: "industry sources" is not a source)
G6 Specific and original material ... PASS   (the trenchless vs dig comparison has real detail)
G7 Entity named in full ............. PASS
G8 Indexable, self-canonical ........ VERIFY (kit item 18)

LAYERS
Search   2 of 10   miss: S1, S2, S3, S4, S6, S7, S8, S9
Answer   4 of 10   miss: A1, A2, A7, A9, A10, A3 borderline (pass)
Place    0 of 6    miss: P1, P2, P3, P4, P5 (pass, US locale consistent), P6
Trust    2 of 7    miss: T1, T3, T4, T5, T7
Machine  1 of 8    miss: M1, M2, M3, M4   verify: M5, M6, M7, M8
```

Note the S1 miss. The draft's title promised "everything" and the body was really about cost and repair choice. The query a Portland homeowner types is about cost. The preflight renames the article to the question it actually answers.

### The kit

**1. Title tag (56):** Sewer Line Repair Cost in Portland: What Homeowners Pay

**2. Meta description (151):** Sewer line repair in Portland runs [your low] to [your high] for trenchless and more for a full dig. What drives the price, how to tell which one you need, and what the city requires.

**3. Slug:** `/sewer-line-repair-cost-portland`

**4. H1:** Sewer Line Repair Cost in Portland: What Homeowners Actually Pay

**5. Answer block (71 words):**

> Sewer line repair in Portland costs [your typical range for trenchless lining, from your last 20 jobs] for trenchless methods and [your typical range for excavation] when the line has to be dug up and replaced. The price depends on the length of the run, the depth of the line, and whether the break is under the yard or under the street, where the City of Portland requires a permit and a licensed contractor.

**6. Heading outline:**

```
H1  Sewer Line Repair Cost in Portland: What Homeowners Actually Pay
H2  How much does sewer line repair cost in Portland?             (rewritten from "Costs", moved up)
H3  Trenchless lining and pipe bursting                            (added)
H3  Excavation and full replacement                                (added)
H2  How do you know your sewer line needs repair?                  (rewritten from "Signs of a Problem")
H2  Trenchless or dig: which repair does your line need?           (rewritten from "Repair Options"; H4s under it become H3s)
H2  What does the City of Portland require for sewer repairs?      (added: covers P2 and the permit question)
H2  Does homeowners insurance cover sewer line repair?             (added: a question every buyer asks)
H2  How to get an accurate sewer repair quote in Portland          (rewritten from "Why Choose Us")
H2  Common questions about sewer line repair in Portland           (added, FAQ)
```

**7. Section openers.** Three sections rewritten; one shown:

> **How do you know your sewer line needs repair?**
> Before: Plumbing issues can be stressful, and it is not always obvious what is going on beneath your home...
> After: The three signs that point to the sewer line rather than a single drain are multiple fixtures backing up at once, gurgling from a toilet when a sink drains, and a wet or sunken patch in the yard along the line's path. One slow drain is almost never the sewer line.

**8. Definition sentence:** A sewer line is the single pipe that carries all of a home's wastewater from the house to the city main, and in most Portland homes it runs under the front yard to the street.

**9. FAQ block.** Six questions written; two shown:

> **Who is responsible for the sewer line in Portland, the homeowner or the city?**
> In Portland, the homeowner is responsible for the sewer lateral from the house to the connection at the city main, including the section under the sidewalk and street. The City of Portland maintains the main itself. [Confirm against the current Bureau of Environmental Services rule and link it.] This is why a break under the street is still the homeowner's repair, and why the permit matters.
>
> **Can a sewer line be repaired without digging up the yard?**
> Most sewer lines can be repaired without excavation using trenchless lining or pipe bursting, as long as the pipe has not collapsed and the access points are reachable. A camera inspection decides it. [Share of your Portland jobs done trenchless, if you track it.] Lines that have fully collapsed or that have a severe belly still need to be dug.

**10. Author box:**

> **[Author full name]** is [title] at [Company], a licensed Oregon plumbing contractor ([CCB license number]) that has [repaired or replaced N sewer lines in the Portland area since year]. [One line on a relevant credential, such as trenchless certification.]

**11. Date line:** Published [Month D, 2026].

**12. Place block:**

> Portland's older neighborhoods, including [name two or three where you see the most sewer calls], have a high share of homes with original concrete or clay laterals from before 1960, which crack at the joints and admit tree roots. The city's wet season adds ground pressure that turns a cracked joint into a collapse. The City of Portland requires a plumbing permit for any sewer lateral repair and a right-of-way permit when the work reaches the sidewalk or street; [link the Bureau of Development Services permit page]. [Company] is located at [address exactly as on your contact page] and serves Portland, [named surrounding cities], and [county].

**13. Internal link plan:**

```
1. Anchor: "sewer camera inspection"
   Sentence: A [anchor] is how a plumber decides between lining and digging, and it is the first thing to ask for.
   Destination: [URL of your inspection service page]
2. Anchor: "trenchless sewer repair in Portland"
   Sentence: For how lining works and when it is the right call, see [anchor].
   Destination: [URL of your trenchless service page]
3. Anchor: "emergency plumbing in Portland"
   Sentence: If sewage is backing into the house right now, start with [anchor].
   Destination: [URL of your emergency page]
Inbound: your main plumbing services page should link here with the anchor "sewer line repair cost."
```

**14. Source list:**

```
Claim: national cost ranges "according to industry sources"
   Outcome: cut. Replace with your own Portland ranges from recent jobs, with the year.
Claim: "Homeowners are responsible for the lateral to the main"
   Needs: City of Portland Bureau of Environmental Services page stating it. [URL]
Claim: "A permit is required"
   Needs: Bureau of Development Services permit page. [URL]
Claim: "Trenchless lining lasts 50 years"
   Needs: manufacturer warranty or a named industry standard; or rewrite as your observed experience.
```

**15. Image plan:**

```
1. sewer-camera-inspection-portland-clay-pipe.jpg
   Alt: Camera inspection footage of a cracked clay sewer pipe with root intrusion
   Role: social preview (1200 by 630)
2. trenchless-sewer-lining-access-pit.jpg
   Alt: A small access pit in a front yard used for trenchless sewer lining instead of a full trench
```

**16. JSON-LD.** Full graph delivered: Article, Person, Plumber (as the LocalBusiness subtype) with address, geo, areaServed for Portland and the named surrounding cities, BreadcrumbList, FAQPage with all six questions. Brackets on street address, coordinates, license number, and profile URLs.

**17. Social preview tags.** Delivered, matching the title tag and meta description.

**18. Site-level checklist.** Delivered with the eight checks. Flagged specifically: the site's theme wraps the logo in an H1 on every page, which the user should confirm and have changed.

### The finding

The writing knows the trade and the page around it is missing. No title, no answer, no author, no date, no place, and the one number on the page is attributed to nobody. Five gates fail and four of them are paste-in fixes from this kit. The fifth, sourcing, needs your own Portland job data, which is also the thing that makes this article impossible for a national content farm to copy.

### The coaching note

Lead with the number. Every article you publish about a service should open with what it costs here, from your own jobs, with the year. That one sentence does more for a Portland homeowner, and for anything reading on their behalf, than the rest of the page combined.

### The one question

What were your actual price ranges on the last 20 sewer repairs, split trenchless versus dig? With those two ranges the answer block, the meta description, and the first H2 all become real, and G5 and G6 are settled.

---

## Example 2: National editorial, no geography

**What the user gave.** A 900 word op-ed draft from a fintech founder titled "The Case Against Annual Planning," written for the company blog, with a byline and a date already on it. The user said: "Will AI find this? Is it optimized?"

**What the draft looked like.** A real argument with a real position: annual plans are stale by March, quarterly commitments with a rolling 12-month view work better. Good prose. Headings were "The Problem," "What We Tried," "What Happened," "What I'd Tell Other Founders." A specific number from the company's own experience: planning cycle cut from six weeks to four days. No sources beyond the author's experience, which is appropriate for an opinion piece. No FAQ. No answer at the top; the argument built for three paragraphs before stating the position.

**The Place decision.** Does not apply. The subject is placeless. Layer N/A, denominator 35.

### The scorecard

```
VISIBILITY PREFLIGHT: The Case Against Annual Planning
Primary query: "should startups do annual planning"
Verdict: READY WITH FIXES
Checks: 19 of 35 pass. Place layer: N/A (placeless subject).

GATES
G1 Answer in first 100 words ........ MISS   (kit item 5)
G2 Title tag and meta description ... MISS   (kit items 1, 2)
G3 One H1, clean hierarchy .......... PASS
G4 Named author and visible date .... PASS
G5 Claims attributed and defensible . PASS   (every claim is the author's own experience, stated as such)
G6 Specific and original material ... PASS   (six weeks to four days; the rolling-twelve process)
G7 Entity named in full ............. PASS
G8 Indexable, self-canonical ........ VERIFY (kit item 18)

LAYERS
Search   4 of 10   miss: S2, S3, S6, S7, S8, S9 (no sources needed for opinion; one link to the planning method's origin would pass it)
Answer   6 of 10   miss: A1, A2, A7, A9
Trust    6 of 7    miss: T2 borderline pass; T7 miss (bio says "CEO", LinkedIn says "Co-founder and CEO")
Machine  3 of 8    miss: M1, M3, M4   verify: M5, M6   pass: M2 (no FAQ, correctly no schema), M7, M8 (fetched)
```

Wait: G1 is marked MISS and the verdict says READY WITH FIXES. That is wrong by the rules, and it is a mistake worth showing because it is the most common one. A failing gate is NOT READY. The corrected header:

```
Verdict: NOT READY (2 gates failing, both paste-in fixes)
```

An opinion piece is still an article. The position has to be in the first 100 words.

### The kit

**1. Title tag (54):** Should Startups Do Annual Planning? A Founder's Case Against It

**2. Meta description (139):** Annual plans are stale by March. One fintech founder on replacing them with quarterly commitments and a rolling 12-month view, and what changed.

**3. Slug:** `/case-against-annual-planning`

**5. Answer block (58 words):**

> Startups should not do annual planning in the traditional sense, because a plan written in December is wrong by March and nobody updates it. At [Company], we replaced the annual plan with quarterly commitments reviewed against a rolling 12-month view. Planning went from six weeks a year to four days a quarter, and the plan is never more than 90 days stale.

**6. Heading outline:**

```
H1  The Case Against Annual Planning
H2  Why annual plans fail startups                          (rewritten from "The Problem")
H2  What replaces annual planning: quarterly commitments on a rolling 12 months   (rewritten from "What We Tried")
H3  How the quarterly cycle runs                             (added, from existing content)
H2  What changed when we stopped planning annually          (rewritten from "What Happened")
H2  When annual planning still makes sense                  (added: the honest exception makes the position credible and quotable)
H2  What I would tell another founder                        (kept, lightly)
H2  Common questions about dropping annual planning         (added, FAQ)
```

**7. Section openers.** Two rewritten; one shown:

> **Why annual plans fail startups**
> After: Annual plans fail startups because the inputs change faster than the plan does. A 12-month revenue target set in December assumes a market, a team, and a product that will all be different by spring, and the plan has no mechanism for admitting it.

**8. Definition sentence:** A rolling 12-month view is a forecast that always extends one year from today, updated each quarter, so the horizon never shrinks the way a calendar-year plan does.

**9. FAQ block.** Four questions written; one shown:

> **How do investors react when a startup does not have an annual plan?**
> Investors want a credible view of the next 12 months, not a document with "annual plan" on the cover. A rolling 12-month view updated quarterly gives them a fresher number than a calendar-year plan would. [What your board actually said, if you can share it.] The pushback comes when a founder has no 12-month view at all, which is a different problem.

**10. Author box.** Kept, with one change for T7: "Co-founder and CEO" to match the author's public profile.

**13. Internal link plan.** Three anchors to the company's existing posts on OKRs, quarterly reviews, and the product roadmap. Inbound from the "How we work" page.

**14. Source list.** One item: the origin of the rolling-forecast method the author adapted, so the piece gives credit and gains a link. Bracketed.

**16. JSON-LD.** BlogPosting, Person with sameAs, Organization, BreadcrumbList, FAQPage. No LocalBusiness, no spatialCoverage.

**17. Social preview tags.** Delivered.

**18. Site-level checklist.** Canonical and robots to confirm. Noted that the page was fetched and the body is in the served HTML, so M7 is a PASS and not a VERIFY.

### The finding

The argument is real and the specifics are yours, which is the hard part. The page buries its own position for three paragraphs and has no title tag, which are the easy parts. Two gates fail and both are in this kit. Once the answer block is in, this is a piece an assistant can quote with your name on it.

### The coaching note

State the position in the first sentence, then earn it. You wrote the opening the way a good essay is written, with the turn in paragraph four. Nothing that reads on a buyer's behalf gets to paragraph four. Put the conclusion first and let the essay become the proof.

---

## Example 3: Multi-region explainer

**What the user gave.** A URL to a live 2,000 word article, "How Long Do You Have to Keep Business Records?", on an accounting software company's blog. The company sells in the US, UK, and Australia. The user said: "This gets traffic from all three countries but it only talks about the IRS. What do we do?"

**What the page looked like.** Well built. Author, date, schema, canonical, real sources linked to the IRS. Answer block present: "The IRS requires most business records to be kept for three years, and seven in some cases." Headings were questions. A good FAQ with FAQPage schema that matched. A UK reader lands on it from a UK search and gets US law.

**The Place decision.** Applies, under the fourth condition: the audience spans countries and the answer changes by jurisdiction.

### The scorecard

```
VISIBILITY PREFLIGHT: How Long Do You Have to Keep Business Records?
Primary query: "how long to keep business records" (US, UK, and AU readers, three different answers)
Verdict: READY WITH FIXES (for US readers); NOT READY for UK and AU readers, who have no page
Checks: 33 of 41 pass. Place layer: applies (multi-region).

GATES
G1 through G7 ....................... PASS
G8 Indexable, self-canonical ........ PASS  (fetched: self-canonical, indexable, in sitemap)

LAYERS
Search   9 of 10   miss: S1 (the query has three answers and the page gives one)
Answer  10 of 10
Place    1 of 6    miss: P1, P2, P5, P6; P3 N/A (software company, no service area); P4 pass (Organization correct, no false local claim)
Trust    7 of 7
Machine  6 of 8    miss: none; verify: none; pass: all fetched
```

The Machine layer is fully PASS because the page was fetched and every tag was visible. This is what Mode 3 buys.

### The kit

This kit is mostly a structure plan, because the article itself is nearly done and the problem is that there is one of it.

**The hreflang plan:**

```
Pages to create:
  /en-us/how-long-to-keep-business-records/   (existing page, moved or kept at current URL as en-us)
  /en-gb/how-long-to-keep-business-records/   (new: HMRC rules, six years for most records, pounds, UK date format)
  /en-au/how-long-to-keep-business-records/   (new: ATO rules, five years for most records, AUD, AU date format)

Each page carries all four tags:
  <link rel="alternate" hreflang="en-us" href="https://www.example.com/en-us/how-long-to-keep-business-records/">
  <link rel="alternate" hreflang="en-gb" href="https://www.example.com/en-gb/how-long-to-keep-business-records/">
  <link rel="alternate" hreflang="en-au" href="https://www.example.com/en-au/how-long-to-keep-business-records/">
  <link rel="alternate" hreflang="x-default" href="https://www.example.com/en-us/how-long-to-keep-business-records/">

Each page is self-canonical. Do not point the UK and AU canonicals at the US page.
```

**Per-page kit for the UK version** (the AU version follows the same shape):

**1. Title tag (58):** How Long to Keep Business Records in the UK: HMRC Rules

**2. Meta description (147):** HMRC requires most UK businesses to keep records for six years from the end of the accounting period, and longer in some cases. What to keep, for how long, and in what form.

**5. Answer block (66 words):**

> UK businesses must keep most records for six years from the end of the last company financial year they relate to, under HMRC rules, and longer when a transaction covers more than one period, when an asset is expected to last more than six years, or when a return was filed late. Self-employed sole traders keep records for at least five years after the 31 January submission deadline. [Confirm current HMRC guidance and link it.]

**6. Heading outline.** Same question set as the US page, each answered for the UK: what HMRC requires, which records, digital versus paper under Making Tax Digital, what happens if you do not, when the clock starts, and the FAQ. Every number, agency, and date format changes. The structure does not.

**12. Place block for the UK page.** Not a paragraph about a city; the whole page is the place block. The check is P5: pounds, UK spelling, "31 January 2027" format, HMRC and Companies House as the institutions, Making Tax Digital as the regime.

**14. Source list for the UK page:** HMRC guidance on record keeping for companies and for the self-employed, Companies House retention requirements, Making Tax Digital rules. Bracketed URLs; the author confirms each is current.

**16. JSON-LD per page.** Same graph shape as the US page with `inLanguage` set to `en-GB` and `en-AU`, the headline and description translated into each locale's phrasing, and no `spatialCoverage` (the jurisdiction is in the content and the hreflang, and the publisher is not a local business).

**18. Site-level checklist.** Confirm the hreflang set is reciprocal across all three pages after publishing, confirm each page is self-canonical, add both new pages to the sitemap, and link the three pages to each other from a visible "Reading this from the UK? See the UK version" line near the top, because hreflang is for engines and the line is for people.

### The finding

The US page is the standard the other two should copy. The problem is not quality, it is that one page is being asked to answer three questions. A UK reader who lands here gets the wrong law in the first sentence, which is worse than no page. Two more pages, each as good as this one, each in its own locale, linked by hreflang, and all three readers get the right answer.

### The coaching note

When an answer changes by jurisdiction, the jurisdiction is part of the query, and one page cannot hold three answers. Build the page once, well, then build it again per locale. The structure is reusable. The numbers, the agencies, and the dates are not.

---

## What the three have in common

- The scorecard came first, compact, with the count and the denominator stated.
- Every MISS had a numbered kit item, and every kit item was written out, not described.
- Brackets named the exact fact and who holds it. No bracket said `[statistic]` or `[URL]` alone.
- Nothing was marked PASS that had not been seen. Pasted text produced VERIFYs; fetched pages produced PASSes.
- The Place decision was made out loud each time, and it went three different ways: local, N/A, multi-region.
- One coaching note each, chosen for the pattern that would cost the writer the most next time.
- One question at most, after the kit, and only the one that would change the kit.
