# Answer Ready Content

A Claude skill that restructures any page so an AI assistant can find the answer inside it and quote it, and teaches you the pattern, so your next piece needs less work.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most business writing is built to persuade a reader who is already on the page. It opens with context, builds toward a point, and rewards the person who stays.

AI assistants do not read that way. They look for the passage that most cleanly answers a question, lift it, and move on. A page that buries its answer under three paragraphs of setup gets skipped in favor of a competitor's page that says it in the first two sentences.

Good writing and quotable writing are not the same thing. This skill closes the gap.

Paste in a page, or name a topic, and Claude will:

1. Hand you the finished content, written out in full and ready to publish
2. Score it against seven structural checks, so you see exactly what was missing
3. Give you one coaching note that generalizes to everything you write after this

**You always get content back.** Ask for an audit and you get the audit plus the rewrite. Name a topic and you get the whole piece, not an outline. Missing a number? It comes back as a `[BRACKET]` that names the exact fact to go get, not a question you have to answer first.

It works on service pages, comparison pages, pricing pages, how-to guides, definitional posts, buying guides, FAQ sections, product pages, blog articles, and documentation.

Two things it handles that most content tools do not:

**It moves the answer up.** The most common reason a page does not get quoted is that the answer is in paragraph four, sitting behind setup the writer needed in order to think and the reader does not need in order to understand. Every section comes back with a complete, standalone answer of roughly 60 to 150 words directly under the heading, before any context or story. That one change does more than everything else combined.

**It refuses to make things up.** No invented statistics, no invented studies, no invented case studies, and specifically no invented numbers about AI search behavior or citation rates. Nobody has those numbers. The argument does not need them.

## The Seven Structures

Every page passes seven checks before it publishes:

1. **Question-shaped headings**: phrased the way a person asks, not as noun stacks
2. **The answer first**: complete and standalone, directly under the heading
3. **One claim per paragraph**: with the number or example that supports it attached
4. **Specifics that can be checked**: a figure, a date, a named source, a real example
5. **Original material**: your data, your process, the detail nobody outside the work knows
6. **Entity clarity**: the subject named in full, so a lifted passage still says who it is about
7. **Machine-readable structure**: real heading levels, lists, tables, a visible date, schema where it fits

You get a score out of 7 on every run, with the misses named.

Plus the extraction test: pull any single section out of the page and read it alone. Does it answer a real question completely, with a specific in it, and make clear who it is about? If not, it is not finished.

## Try it

Once installed, say any of these:

- "Will AI cite this?" and paste your page
- "Make this page answer ready"
- "Rewrite this so ChatGPT quotes it"
- "Write an FAQ for our onboarding process"
- "Structure this article"
- "Score this page against the seven"
- "Rewrite my headings"
- "Write a comparison page: our service vs doing it in house"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `answer-ready-content.zip` in your skills settings. Claude loads it automatically whenever a page needs it.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/answer-ready-content/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and paste any page with "make this answer ready." You should get the rewritten page in full, a score out of 7, and one coaching note.

## What is in the package

```
answer-ready-content/
├── SKILL.md                The seven structures, the rules, and the output format
├── README.md               This file
├── LICENSE
└── references/
    ├── structures.md       Skeletons and filled examples for 8 page types, plus plain-language schema
    └── examples.md         4 full before-and-after rewrites from 4 industries
```

## Notes

Claude will never invent a number, a study, a source, a quote, or a case study to make a page look authoritative. Anything it does not know comes back in `[BRACKETS]` that name the exact fact needed and where to find it. That is deliberate. The whole approach depends on being the source worth quoting, and one invented number ends that.

This does not make your writing formulaic. The structure is fixed. The substance is where the voice lives, and a page with a real position and real specifics has never read as formulaic. If a page feels generic after this treatment, the problem is that it has nothing in it that only you could say, and the skill will tell you that plainly.

It will ask at most one question, and only after the content is already in front of you.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
