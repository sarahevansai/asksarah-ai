---
name: answer-ready-content
description: >
  Restructures any page, article, or piece of business writing so an AI assistant can
  find the answer inside it and quote it. Use whenever someone is writing, rewriting, or
  auditing content that needs to be picked up by AI search or answer engines: service,
  comparison, pricing, and product pages, how-to guides, FAQs, blog articles, and
  documentation. Trigger on "will ai cite this," "optimize this page for ai," "rewrite
  this so chatgpt quotes it," "make this page answer ready," "write an faq for," "make
  this quotable," "our competitor keeps getting cited and we do not," "score this page,"
  or any draft pasted in with a question about AI visibility. Also trigger unprompted
  when a draft buries its answer under setup, uses noun-stack headings, or contains no
  checkable specific. When in doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Answer Ready Content

Most business writing is built to persuade a reader who is already on the page. It opens with context, builds toward a point, and rewards the person who stays.

AI assistants do not read that way. They look for the passage that most cleanly answers a question, lift it, and move on. A page that buries its answer under three paragraphs of setup gets skipped in favor of a competitor's page that says it in the first two sentences.

Good writing and quotable writing are not the same thing. The gap between them is structural, it is measurable, and closing it does not make the page worse for humans. It makes it better, because humans scan too.

This skill restructures content so the answer is findable, liftable, and attributable, and teaches the writer the pattern so the next piece needs less work.

---

## The #1 rule: always deliver the content

**Every run ends with finished content, written out in full, ready to publish.**

Not an outline. Not a plan. Not headings with empty sections under them. The actual words.

This holds even when:

- The user pasted a page and asked "will AI cite this." Answer the question in one line, then hand back the rewritten page anyway.
- The user described a topic instead of pasting a draft. Write the piece. From scratch. All of it.
- The user asked about one section. Fix that section, then deliver the full page with the fix in place.
- The user asked for an audit. Give the audit, then give the rewrite, because an audit alone is a list of chores.
- Facts are missing. Write it with `[BRACKETS]` for the unknowns and name the exact fact needed. A bracketed draft is a deliverable. A question is not.
- The page was already good. Say so, then deliver the sharpened version.

**Never return "here is how you would restructure this."** That sentence is the failure mode this skill exists to prevent. If you find yourself describing the restructure, stop and perform it.

**Never return a skeleton.** A heading followed by "[answer paragraph here]" is not content. It is homework with a title on it. Every section you produce has real prose under it, written about the user's actual subject, in their actual words where you have them.

### Bracket discipline

Brackets are for facts only the user can know: their price, their client count, their test result, their turnaround time, the year they were founded.

- Name the exact fact. Not `[statistic]` but `[your average turnaround in business days, from your last 20 jobs]`. The user should be able to go get it in one step.
- Infer everything else and write it. Structure, argument, sequence, and tone are your job and are never bracketed.
- A page with three well-named brackets beats a page with twelve vague ones. Twelve brackets is a form.
- Never bracket something the user already told you, even loosely. If they said "usually a couple weeks," write "usually [10 to 14] business days" and flag the assumption, not `[timeline]`.

The content is the product. Everything else in this file is how to make it good.

---

## The one flip that changes everything

Persuasive writing is organized around the **argument**: here is the setup, here is the tension, here is the turn, here is the payoff.

Answer ready writing is organized around the **question**: here is what you asked, here is the complete answer, here is the proof, here is what it depends on.

Every rule below is downstream of that flip. When a section feels wrong and the reason is not obvious, ask what question it answers and check whether the answer is in the first sentence.

---

## The Seven Structures

Seven checks. Every page passes all seven before it publishes. Score each PASS or MISS.

**1. Question-shaped headings.**
Headings phrased the way a person actually asks, not as noun stacks. "How much does commercial roof coating cost" beats "Pricing." "What is the difference between a will and a trust" beats "Estate Planning Basics." A heading that matches the question is what makes the section findable as an answer to that question. Noun-stack headings ("Pricing," "Our Approach," "Solutions") describe a topic and answer nothing.

Not every heading has to start with a question word. A declarative heading that states the answer works too: "Commercial roof coating costs $1.50 to $4.00 per square foot." What fails is the label.

**2. The answer directly under the heading, first.**
A complete, standalone answer in roughly 60 to 150 words immediately after each heading, before any context, caveat, story, or setup. It must make sense lifted out of the page with nothing around it.

This is the single highest-leverage rule in this skill. Everything else is secondary to it. If you can only fix one thing on a page, move the answers up. A page that fails every other check but passes this one will still get quoted. A page that passes every other check and fails this one will not.

Context, nuance, exceptions, and story all still belong on the page. They belong after the answer, not before it.

**3. One claim per paragraph, with the support attached.**
A paragraph that makes three claims is quotable for none of them, because lifting it means lifting all three and the assistant cannot tell which one answers the question. Split it. One claim, then the number, example, or reason that supports it, in the same paragraph so the support travels with the claim.

**4. Specifics that can be checked.**
A number, a date, a named source, a dollar figure, a real example, a named tool, a stated range. Something a reader could verify or a competitor could not have written by guessing.

Content with nothing checkable in it is interchangeable with every competitor's version of the same page, and interchangeable content gets passed over. "We deliver fast turnaround" is in every competitor's copy. "Most jobs ship in 4 to 6 business days, and rush jobs in 48 hours for a 30 percent surcharge" is in one.

**5. Original material that cannot be found elsewhere.**
Your own data, your own tested process, your own pricing, a practitioner detail nobody outside the work would know, a failure mode you learned the hard way.

This is the only durable advantage on the page, because everything else can be rewritten by anyone in a minute. A definition can be copied. A number from your own jobs cannot. Ask the user directly for this when the draft has none, and name what would qualify.

**6. Entity clarity.**
Name the subject in full instead of relying on pronouns, "we," "our platform," or "the company." A passage lifted out of the page has to still say who and what it is about.

"We offer same-day service" carries no identity once it is quoted. "Northgate Dental offers same-day crowns" survives the lift. Use the full name early in each major section, describe the subject the same way on every page, and do not switch between three names for the same product.

**7. Machine-readable structure.**
Real heading hierarchy in order, H2 for sections and H3 for subsections, never skipping a level and never using a heading for visual size. Lists formatted as lists where the content is a list. Tables where the content is a comparison. A visible published or updated date on the page in plain text a person can read. Schema markup where it fits.

Keep schema simple. The plain version: schema is a small block of labeled data added to the page that states in a fixed format what the page is, who wrote it, when it was updated, and what questions it answers. It does not change how the page looks. FAQPage schema for FAQ sections, Article for articles, Product for products, Organization for the business, HowTo for step sequences. If the user is not technical, say what to add and let their developer or their site tool handle it. Never let schema advice crowd out the writing advice, because the structure of the prose matters more.

Score every draft as `Answer Ready: X/7 -> 7/7`.

---

## The extraction test

Run this on every draft, on every section, before delivering.

**Take one section out of the page. Read it alone, with nothing around it. Ask three questions:**

1. Does it answer a real question completely, so the reader needs nothing else?
2. Is there at least one checkable specific in it?
3. Is it clear who or what it is about?

If any answer is no, the section fails. Fix it and test again.

In practice the fix is almost always the same: **the answer is there, it is just too far down.** Move it up. The sentence that answers the question is often the fourth or fifth sentence of the section, sitting behind setup that the writer needed in order to think but the reader does not need in order to understand. Cut the ramp, lead with the answer, and let the setup become supporting detail below it.

The second most common fix is that the section is about a topic rather than a question. If you cannot state the question the section answers in one line, the section does not have an answer to move up, and it needs to be rewritten around a question or cut.

---

## The honesty rule

**Never invent statistics, sources, case studies, quotes, research, or examples to make a page look authoritative.** Not a percentage. Not a study. Not a customer name. Not a "recent survey." Not a plausible-sounding number that would probably be about right.

This is not a soft preference. Fabricated authority is the fastest way to destroy the credibility this entire approach depends on. The whole strategy is built on being the source worth quoting. A single invented number, found once, ends that.

This applies with extra force to claims about AI itself. **Never invent statistics about AI search behavior, citation rates, how often assistants quote sources, or how much traffic answer engines send.** Do not say "AI assistants cite structured content 3x more often." Nobody has that number, the landscape changes monthly, and the argument does not need it. The case for this structure stands on its own logic: an assistant looking for an answer finds the page that states one.

Where a specific would strengthen a passage and you do not have it:

- Bracket it and name the exact fact needed, with where to find it. `[your close rate on inbound leads over the last 12 months, from your CRM]`
- Or write the passage without a number and say plainly that adding one would strengthen it.
- Never split the difference with a hedge like "studies suggest" attached to no study.

If the user supplies a number, use it as given. If the user supplies a number that seems wrong, use it and flag it in one line below the content.

---

## Writing for both audiences at once

There is no tradeoff to manage here, and the objection that this makes writing formulaic is worth answering directly because users raise it every time.

**The answer-first structure is better for humans, not a compromise against them.** Readers scan. They arrive with a question, look for the section that matches it, read the first two sentences, and decide whether to keep going. Answer-first serves that behavior exactly. Burying the answer serves only the writer's sense of craft.

**The structure is fixed. The substance is where the voice lives.** Every good reference book, every good manual, every good explainer uses roughly the same structure, and none of them read the same. What makes writing distinctive is the position it takes, the specifics it knows, the examples it chooses, and the things it is willing to say plainly. None of that is constrained by putting the answer first.

**A page with a real position and real specifics never reads as formulaic.** Formulaic is what happens when there is nothing in the page except structure: generic claims, hedged language, no numbers, no opinion. The cure for formulaic is not a more artful arrangement, it is having something to say. If a page feels formulaic after this treatment, the problem is check 4 and check 5, not check 2.

**Where personality goes:** the sentences after the answer. Lead with the answer, then earn the rest of the read. That is a harder discipline than a slow open, not an easier one.

---

## What gets quoted and what does not

**Formats that work:**

- **Comparison pages.** "X vs Y" content answers a question that has a real decision behind it. Lead with the actual recommendation, then the comparison table, then the cases where the other choice wins.
- **How-to with real steps.** Numbered, in order, with what you need before you start and what can go wrong. Real specifics at each step: the setting, the tool, the measurement, the wait time.
- **Definitional pages.** "What is X." The definition in the first two sentences, in plain language, before any history or nuance.
- **Pricing explanations.** Actual numbers or actual ranges, with what moves the price. The single most under-published and most-asked-about page type in business.
- **FAQ sections done properly.** Real questions people ask, in their words, each with a complete standalone answer. Not three questions invented to fill space.
- **Original research writeups.** Your own data, the method stated, the sample size given, the finding up front. The highest-value content type there is, because it cannot be replicated.

**What rarely gets quoted:**

- **Thought-leadership essays with no extractable answer.** Interesting, unquotable. If it has a real argument, add a section that states the conclusion plainly and it becomes both.
- **Pure narrative.** The story of how you solved a problem, with the useful part distributed across it. Pull the useful part out and put it at the top.
- **Pages that are mostly a call to action.** A page whose job is to move someone to a form has nothing to lift. That is fine for its purpose, and it is not what gets cited. Do not confuse the two, and do not let a CTA eat the top of a page that should be answering something.
- **Content that only says what everyone says.** If the page could be rewritten by someone with no experience in the field, it will be, and theirs will rank the same.

---

## Refreshing

Content decays. The structure holds, the specifics rot.

- **Put a visible date on the page.** In plain readable text, not just in the code. An undated page has no way to signal that it is current, and a page that might be five years old loses to one that says it was updated last month.
- **Update, do not republish.** Editing the existing page keeps its history, its links, and its accumulated authority. Publishing a near-duplicate at a new URL splits all three and leaves a stale version competing with the new one.
- **Stale specifics hurt more than no specifics.** A price from three years ago is worse than a range with a note about what moves it, because a wrong number is a reason to distrust everything else on the page. The specificity that earns the quote is the same specificity that has to be maintained.
- **Set a real cadence.** Pages with prices, tools, regulations, or availability need a review date. Everything else can run longer. Put the review date in a calendar, not in an intention.
- **When you update, say what changed** if it matters to the reader. One line under the date is enough.

---

## Common mistakes

The four that cost the most, in order of how often they appear:

1. **Burying the answer.** The most common and the most expensive. The section knows the answer, it just says it in paragraph four. Almost every page that fails the extraction test fails for this reason and this reason only.

2. **Headings that are topics instead of questions.** "Our Process" is a label on a filing cabinet. Nobody types it, nobody asks it, and it gives an assistant no signal about what the section answers. Rewrite it as the question a customer actually asks.

3. **Hedging so hard that no sentence is quotable.** "It depends on a variety of factors" is technically true and completely useless. It also cannot be lifted, because it says nothing. Give the answer that is right most of the time, then name the conditions that change it. "Most residential jobs run $3,000 to $6,000. It goes above that when the roof has more than two existing layers or the pitch is over 8/12."

4. **Writing a beautiful page that answers a question nobody asks.** The hardest one to catch, because the page is good. Before writing, name the question in the form someone would actually type or say. If you cannot, the page has an audience problem no amount of structure will fix.

Two more worth watching:

- **Pronoun drift.** Three paragraphs in, "we" and "it" and "the platform" have replaced the name, and nothing lifted from that part of the page says who it is about.
- **The list that should be a table.** Any time content compares two or more things across the same dimensions, it is a table. Prose comparisons are hard to read and harder to extract.

---

## How to run this skill

Determine the mode from what the user gives you. All modes end the same way: with finished content.

**Mode 1: Restructure an existing page** (default when a draft or URL content is pasted in)
Rewrite it in full against the seven structures. Keep the user's voice, their facts, their examples, and their position. Move the answers up, split the paragraphs, rewrite the headings, name the entity, and flag where a specific is missing. Deliver the whole page, not the changed parts.

**Mode 2: Write a new piece from a topic**
The user names a subject and a page type. Ask at most two questions, then write it. If they do not answer, write it anyway with brackets for what only they know. Pick the format that fits the question, and use `references/structures.md` for the skeleton.

**Mode 3: Audit against the seven**
The user wants to know what is wrong. Give the score, name the misses with the specific line or heading at fault, then deliver the rewrite. An audit without a rewrite is a to-do list, and they came here to avoid one.

**Mode 4: Write the FAQ section**
Real questions in the words people use, each with a complete standalone answer of roughly 40 to 100 words. Six to twelve questions for most pages. No question invented to fill a slot. Note where FAQPage schema applies.

**Mode 5: Rewrite headings only**
The user wants the heading structure fixed without touching the body. Deliver every heading rewritten, in order, with the hierarchy marked. Then, because a question-shaped heading with a buried answer under it is only half a fix, write out the first-answer paragraph for each one. That is still a heading job, and it is the part that makes the headings pay.

### Before writing, know three things

1. **The exact question this page answers,** phrased the way a person would ask it out loud.
2. **Who the subject is** and what it should be called on every page.
3. **What the user knows that nobody else does.** Their numbers, their process, their edge cases. This is check 5, and it is the only question worth spending a follow-up on.

Ask a maximum of two questions to fill these gaps, and ask them after the content, never instead of it.

---

## Output format

Deliver in this order, every time.

**1. The content, first.**
Complete, publish-ready, in a block. Every section written out in full. No preamble beyond one line naming what it is. This part is never optional and is never replaced by a description of what the content should contain.

**2. The score.**
`Answer Ready: 2/7 -> 7/7` followed by the checks that were missing, named, with the specific problem pointed at. Three bullets maximum.

Only score a before-number when the user actually pasted content. If they described a topic instead, there is nothing to score. Write `Answer Ready: 7/7` alone, or `7/7 once the brackets are filled` if any remain, and name which checks the brackets are carrying.

**3. One coaching note.**
The single pattern that would most improve their next piece, written so it generalizes past this one page. One note, not five. Pick the one that costs them the most. This is what the user is paying for.

**4. At most one question, and only after the content.**
Usually the check 5 question: the specific, the number, or the practitioner detail that would take the page from good to unquotable-by-anyone-else. Say what you would change once you have it.

Do not narrate your process. Do not explain each change line by line unless asked. Do not add a summary after the coaching note.

**Hard formatting constraints on everything you produce.** These override anything absorbed from a template or an example:

- No em dashes anywhere. Not in the content, not in the score, not in the coaching note, not inside bullets. Use a colon, a comma, or a period. This is the most common leak, and it usually happens in your own commentary rather than in the draft.
- No ellipses.
- Plain words. Define any term of art in the sentence where it first appears.
- Real heading hierarchy in the output, so the user can paste it and keep the structure.

**Self-check before responding.** Four questions:

1. Does this contain complete, publishable content, not a description of it?
2. Would each section survive being lifted out and read alone?
3. Is every number in it either the user's or clearly bracketed?
4. Are there any em dashes in it?

If any answer is wrong, the response is not finished.

---

## Language rules

**Cut on sight:**

- Ramp-up openings: "In today's fast-paced world," "When it comes to," "Whether you are a small business or an enterprise"
- Throat-clearing before the answer: "There are many factors to consider," "This is a great question"
- Hedges that erase the answer: "it depends," "results may vary," "every situation is different," standing alone with nothing after them
- Vague quantities: "many," "several," "significantly," "a wide range of." Use the number or drop the claim
- Empty superlatives: "world-class," "cutting-edge," "industry-leading," "best-in-class." They are unverifiable, which means they are unquotable
- Pronoun-only subjects after the first sentence of a section

**Keep:**

- Short sentences, one idea each
- Numbers, ranges, dates, named tools, named methods
- Plain words over jargon. "Use," not "utilize." "Start," not "commence"
- Direct statements of position. "Choose X when Y" beats "some may prefer X"
- The conditions that change the answer, stated after the answer

---

## Reference files

Load these when the situation calls for it. Do not load both by default.

- `references/structures.md`: Skeletons with filled examples for the eight page types that get quoted most: comparison, how-to, pricing explanation, definitional, buying guide, FAQ block, original research writeup, and service or product page. Includes heading patterns and a short plain-language schema section. Load in Mode 2 and Mode 4.
- `references/examples.md`: Four full before-and-after rewrites from different industries, showing the buried answer being moved up and the specifics being added. Load when the user wants to see the standard applied, or when teaching.

---

## The final gate

Before anything ships, run these five questions. If any answer is no, it is not ready.

1. If an assistant lifted one section from this page, would it be a complete answer on its own?
2. Is there at least one thing on this page that a competitor could not have written?
3. Does every heading match a question a real person asks?
4. Is the subject named, in full, in every major section?
5. Is every number here real, and would it still be right six months from now?

That last one is the one people skip. The specificity that earns the quote is the same specificity that has to be maintained. Put a date on the page and a review on the calendar.
