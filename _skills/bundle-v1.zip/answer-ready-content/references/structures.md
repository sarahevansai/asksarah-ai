# Page Structures

Skeletons for the eight page types that get quoted most, each with a filled example so the shape is obvious.

Use these as raw material. They are a starting arrangement, not a form to hand the user. Every one of them still has to pass the extraction test section by section, and the filled examples show the level of specificity that passes it.

The examples below use invented companies and invented numbers to demonstrate structure. **Never carry a number from this file into a user's page.** Every figure here is a placeholder for a real one the user supplies.

---

## Heading patterns that work

Rewrite noun-stack headings into one of these four shapes.

| Shape | Pattern | Example |
|---|---|---|
| Direct question | How much does X cost | How much does a commercial water heater replacement cost |
| Comparison question | Is X better than Y for Z | Is a heat pump better than a gas furnace for a cold climate |
| Declarative answer | X costs $A to $B | Slab leak repair costs $1,500 to $4,000 |
| Conditional | When to choose X | When to choose a fixed-fee audit over hourly |

| Replace this | With this |
|---|---|
| Pricing | How much does [thing] cost |
| Our Process | What happens after you sign |
| Overview | What is [thing] |
| Benefits | What you get with [thing] |
| Solutions | What problems [thing] solves |
| FAQ | Common questions about [thing] |
| Getting Started | How to set up [thing] in [N] steps |
| Why Choose Us | Who [company] is a good fit for |

Rules that apply to every heading:

- H1 once, at the top, naming the page's subject.
- H2 for each question the page answers. H3 for parts of an answer. Never skip a level, never use a heading tag for font size.
- Put the entity name in at least the H1 and the first H2.
- Keep headings under about 12 words. A heading that is a full sentence with a subordinate clause is not a question anybody asks.

---

## 1. Comparison page

**Answers:** should I pick X or Y.

**Skeleton:**

```
H1: [X] vs [Y]: which one to choose in [year]
   Answer paragraph: the recommendation, stated. Who should pick X, who should pick Y,
   in 2 to 4 sentences. No suspense.

H2: What is the difference between [X] and [Y]?
   Answer paragraph: the single core difference in one sentence, then the consequence of it.
   Comparison table: 5 to 8 rows, same dimensions for both, real values.

H2: When [X] is the better choice
   Answer paragraph, then 3 to 5 specific situations.

H2: When [Y] is the better choice
   Answer paragraph, then 3 to 5 specific situations. Make this section genuinely good.
   A fake losing option is visible and it costs credibility.

H2: How much does [X] cost compared to [Y]?
   Answer paragraph with real numbers or ranges, then what moves the price.

H2: Can you switch from [X] to [Y] later?
   Answer paragraph: yes or no, then the cost and effort of switching.

H2: Common questions about [X] and [Y]
   4 to 6 Q and A pairs.

Visible updated date.
```

**Filled example, first section:**

> ## Flat-rate vs hourly bookkeeping: which one to choose
>
> Choose flat-rate bookkeeping if your monthly transaction volume is steady and under about 400 transactions, because you get a predictable bill and the provider absorbs the risk of a messy month. Choose hourly if your volume swings hard month to month, if you are mid-cleanup on prior-year books, or if you only need someone a few hours a week. Most small businesses with a single bank account and one payment processor pay less under flat-rate. Most businesses in the middle of a catch-up project pay less hourly, because the work ends.
>
> ## What is the difference between flat-rate and hourly bookkeeping?
>
> The difference is who carries the risk of a hard month. Under flat-rate, the provider quotes a fixed monthly fee based on your expected volume and absorbs the overage when a month runs long. Under hourly, you pay for the actual time, so a clean month is cheap and a messy month is not.
>
> | | Flat-rate | Hourly |
> |---|---|---|
> | Typical cost | $400 to $1,200 per month | $45 to $110 per hour |
> | Bill predictability | Fixed | Varies month to month |
> | Best transaction volume | Under 400 per month, steady | Any, especially variable |
> | Cleanup work | Usually quoted separately | Billed as it runs |
> | Contract | Usually 6 or 12 months | Usually none |

**Notes:** the recommendation goes above the table, not below it. A table alone is data with no answer attached.

---

## 2. How-to with real steps

**Answers:** how do I do X.

**Skeleton:**

```
H1: How to [do X]
   Answer paragraph: what the process is, how long it takes, what it costs, and the
   one thing most people get wrong. 60 to 150 words.

H2: What you need before you start
   A real list: tools, access, documents, time, skill level.

H2: How to [do X], step by step
   H3: Step 1: [action verb + object]
       What to do, the specific setting or measurement, and how to know it worked.
   H3: Step 2 through N, same shape.

H2: How long does [X] take?
   Answer paragraph with a real range and what makes it longer.

H2: What can go wrong
   3 to 5 named failure modes with the fix for each.

H2: When to call a professional instead
   Honest answer. This section builds more trust than any claim on the page.

Visible updated date.
```

**Filled example, opening and one step:**

> ## How to replace a bathroom faucet
>
> Replacing a bathroom faucet takes about 60 to 90 minutes for a first-timer and costs $80 to $350 for the faucet plus about $15 in supplies. The job is four steps: shut off the water, disconnect and remove the old faucet, set and secure the new one, reconnect and test. The step most people skip is checking the hole spacing on the sink before buying. A widespread faucet needs 8 inches between the outer holes and a centerset needs 4, and a mismatch means a return trip.
>
> ### Step 1: Shut off the water and drain the lines
>
> Turn both shutoff valves under the sink clockwise until they stop. Open the faucet and let it run until it stops dripping, which takes about 20 seconds and relieves the pressure in the lines. Put a bucket and a towel under the connections, because about a cup of water stays in each supply line. If a shutoff valve will not turn or keeps weeping after it is closed, stop and shut off the main, because a stuck valve will fail while you are working on the connection above it.

**Notes:** "how to know it worked" is what makes a step quotable. "Turn the valve" is instruction. "Turn it clockwise until it stops, then run the faucet for 20 seconds until it stops dripping" is an answer.

---

## 3. Pricing explanation

**Answers:** how much does this cost.

The most asked-about and least published page type in business. A real range beats "contact us" every time, and "contact us" cannot be quoted at all.

**Skeleton:**

```
H1: How much does [thing] cost?
   Answer paragraph: the range, the typical case, and the unit. First sentence.

H2: What is included at each price
   Table or tiered list with real inclusions, not adjectives.

H2: What makes the price go up
   4 to 6 named factors, each with the direction and rough size of the effect.

H2: What makes the price go down
   Same treatment. Most pages skip this one and it is the most trusted section on the page.

H2: How [thing] is priced: [per unit / per month / per project]
   Explain the pricing model in plain words.

H2: What you would pay in a typical [case]
   One worked example with real arithmetic.

H2: Common questions about [thing] pricing

Visible updated date, because this page goes stale first.
```

**Filled example, opening:**

> ## How much does commercial HVAC maintenance cost?
>
> Commercial HVAC maintenance runs $150 to $600 per rooftop unit per visit, with most buildings on a quarterly plan landing between $1,200 and $4,800 per year for a typical 4-unit setup. Price is driven mostly by unit count, unit age, and whether the contract includes filters and belts or bills them separately. A building with units over 15 years old usually pays 20 to 40 percent more per visit, because older units need more time on each inspection and fail more between visits.
>
> ## What makes the price go up
>
> **Unit age over 15 years.** Adds roughly 20 to 40 percent per visit. Older units take longer to inspect and need more parts replaced during routine service.
>
> **Roof access difficulty.** Adds $50 to $150 per visit when the units require a lift, a ladder over 20 feet, or a scheduled escort.
>
> **After-hours scheduling.** Adds about 50 percent. Buildings that cannot take a shutdown during business hours pay a night rate.

**Notes:** one claim per paragraph with the number attached, exactly as check 3 requires. A bulleted list of factors with no sizes attached is not an answer.

---

## 4. Definitional page

**Answers:** what is X.

**Skeleton:**

```
H1: What is [X]?
   Answer paragraph: the definition in the first two sentences, in plain language,
   before any history, nuance, or origin story. Then what it is for and who uses it.

H2: How [X] works
   The mechanism in 3 to 5 sentences, then detail.

H2: What [X] is used for
   3 to 5 real applications, named.

H2: [X] vs [nearest confusable thing]
   The distinction people actually get wrong, with a table if there are several.

H2: What [X] is not
   Directly correct the most common misunderstanding.

H2: Example of [X] in practice
   One concrete worked example.

H2: Common questions about [X]
```

**Filled example, opening:**

> ## What is a mechanic's lien?
>
> A mechanic's lien is a legal claim filed against a property by a contractor, subcontractor, or supplier who was not paid for work or materials they provided to that property. It attaches to the property itself rather than to the person who owes the money, which means the owner cannot sell or refinance cleanly until it is resolved. Every US state allows them, but the filing deadlines vary widely, commonly between 60 and 120 days after the last day of work. A missed deadline usually voids the right permanently.
>
> ## What a mechanic's lien is not
>
> A mechanic's lien is not a lawsuit and it does not by itself force payment. It creates pressure by clouding the title. Enforcing it and actually collecting requires a separate foreclosure action, which has its own deadline, commonly one year from filing.

**Notes:** the definition is the whole game. If someone lifts only the first three sentences, they should have a correct and complete definition.

---

## 5. Buying guide

**Answers:** how do I choose the right X.

**Skeleton:**

```
H1: How to choose [a X]: a buyer's guide
   Answer paragraph: the one decision that matters most, and the default pick for
   the most common buyer.

H2: The [N] things that actually matter when choosing [a X]
   One H3 per factor. Each H3 gets its own answer paragraph with a threshold or number,
   not an adjective.

H2: What to ignore
   The specs and features that get marketed hard and rarely change the outcome.
   High-trust section, rarely written.

H2: How to choose based on your situation
   3 to 5 named buyer profiles, each with a direct recommendation.

H2: What it should cost
   Range, by tier.

H2: Questions to ask before you buy
   6 to 10 questions the buyer can take to a vendor, with what a good answer sounds like.

H2: Common questions
```

**Filled example, one factor:**

> ### How much lift capacity do you actually need?
>
> Buy for your heaviest routine load plus 25 percent, not for your heaviest possible load. A shop that moves 3,000 pound pallets all day needs a 4,000 pound rated truck, and going to 6,000 adds about $4,000 to the purchase and roughly 1,100 pounds of curb weight that your floor and your ramps have to carry every day. Capacity you use twice a year is better rented. The exception is a shop with a documented plan to change what it moves within 24 months, where buying up once beats buying twice.

---

## 6. FAQ block

**Answers:** the eight to twelve things people actually ask.

FAQ sections are the highest-density answer-ready content there is, and most are wasted because the questions are invented and the answers are one line long.

**Rules:**

- Use the words people use. Take questions from sales calls, support tickets, and the search bar, not from a brainstorm.
- Each answer is 40 to 100 words and stands alone. It repeats enough of the question that a lifted answer makes sense without it.
- No question exists to fill a slot. Eight real questions beat twenty padded ones.
- Answer the uncomfortable ones. The page that answers "why are you more expensive" gets trusted and quoted. The page that dodges it does not.
- One question per heading. Never bundle two questions under one heading.
- FAQPage schema applies here.

**Skeleton:**

```
H2: Common questions about [X]
   H3: [Question in the customer's words]
       40 to 100 word standalone answer, restating enough of the question to stand alone.
   H3: [Next question]
```

**Filled example:**

> ### Do I need to be home for the inspection?
>
> You do not need to be home for a standard four-point home inspection, as long as we have access to the property, the electrical panel, the water heater, and the attic hatch. Most clients leave a lockbox code. That said, being there for the last 30 minutes is worth it, because walking the findings in person is faster than reading them and you can ask about what you are looking at. We schedule the walkthrough for the end of the inspection window so you only need that half hour.
>
> ### Why is your inspection more expensive than the $250 quotes I am seeing?
>
> Our standard inspection is [$X] because it includes a full thermal imaging pass and a sewer scope, which are usually quoted as add-ons at $150 to $300 each. A $250 inspection is typically visual only, which is a real service and the right choice on a newer build. On a house over 30 years old, the two most expensive surprises after closing are hidden moisture and a failed sewer line, and neither shows up in a visual pass.

---

## 7. Original research writeup

**Answers:** what does the data say about X.

The highest-value page type, because it is the only one nobody can copy. It is also the one with the strictest honesty requirements.

**Skeleton:**

```
H1: [The finding, stated as the headline]
   Answer paragraph: the single most important finding with the number, the sample size,
   and the time period, in the first two sentences.

H2: What we found
   3 to 6 findings, one H3 each, each stated as a sentence with a number in it.
   Not "Response Times" but "Median response time was 4.2 hours."

H2: How we collected this data
   Sample size, time period, source, method, and inclusion criteria. Plain language.
   This section is what makes the page citable rather than just interesting.

H2: What this data does not show
   Limits, honestly stated. Skipping this is how research writeups lose credibility.

H2: What this means for [audience]
   The practical read, 3 to 5 implications.

H2: Methodology notes and definitions
   How each term was counted.

Visible published date and a note if the data set is updated.
```

**Filled example, opening:**

> ## Median time to first response on inbound quote requests was 19 hours across 1,240 requests
>
> We sent identical quote requests to 1,240 contractors across 12 US metros between [date] and [date] and measured the time to first human response. The median was 19 hours. Roughly [X] percent never responded at all within 14 days. Contractors who responded within one hour were [X] times more likely to still be in contact at day 7 than those who responded the next day.
>
> ## How we collected this data
>
> Every request used the same job description, the same budget range, and the same submission method, sent through the contact form listed on each company's own site. Requests went out on weekdays between 9am and 11am local time. We counted a response as the first message from a person, not an autoresponder. We excluded [X] companies whose forms returned an error.

**Notes on honesty:** every number on a research page must come from the user's own data. If they have the data but not the exact figure, bracket it precisely: `[median response time in hours, from your dataset]`. If they do not have data, this is not the page type to write, and say so directly rather than producing something that looks like research.

---

## 8. Service or product page

**Answers:** what is this, who is it for, what does it cost, what happens next.

The hardest page type to make answer ready, because its commercial job pulls it toward persuasion and away from answers.

**Skeleton:**

```
H1: [Service name] in [location or category]
   Answer paragraph: what the service is, who it is for, what it costs, and how long
   it takes. All four, in the first paragraph. This is the passage that gets lifted.

H2: What [Company] does in [service]
   Answer paragraph naming the company in full. What is actually performed, in
   concrete terms.

H2: Who this is a good fit for
   3 to 4 specific situations, with the numbers or thresholds that define them.

H2: Who this is not a good fit for
   Honest. The single most trust-building section on any service page.

H2: How much does [service] cost?
   Range and what moves it. Link to the pricing page if there is one, and still
   put the range here.

H2: What happens after you [sign / call / book]
   Numbered steps with real timing on each.

H2: How long does [service] take?

H2: Common questions about [service]

Visible updated date.
```

**Filled example, opening:**

> ## Commercial fleet washing in the Dallas-Fort Worth metro
>
> Northline Fleet Services provides on-site commercial vehicle washing for fleets of 5 to 200 vehicles across the Dallas-Fort Worth metro. Crews come to your yard, typically overnight between 10pm and 5am, so no vehicle leaves service for a wash. Pricing runs [$X] to [$Y] per vehicle per wash depending on vehicle class and frequency, on a monthly contract. A 20-vehicle box truck fleet on a weekly schedule takes about 3 hours per visit.
>
> ## Who this is not a good fit for
>
> Northline Fleet Services is not the right fit for fleets under 5 vehicles, because the per-visit minimum makes the per-vehicle cost higher than a local wash bay. It is also not a fit for yards without a water connection within 150 feet of the parking area or without overnight gate access, since both are required for the overnight schedule that keeps vehicles in service.

**Notes:** notice how often the company is named. That is check 6. A service page written entirely in "we" produces passages that cannot be attributed to anyone once they are lifted.

---

## Schema, in plain language

Schema is a small block of labeled data added to a page that states, in a fixed format machines already understand, what the page is, who published it, when it was updated, and what questions it answers. It does not change how the page looks to a visitor.

It is a helper, not the strategy. A page with perfect schema and a buried answer still does not get quoted. A page with a great answer and no schema often does. Do the writing first.

**Which type fits:**

| Page type | Use |
|---|---|
| FAQ section | FAQPage |
| Blog post, article, guide | Article |
| Step-by-step instructions | HowTo |
| Product page | Product |
| Service page | Service, plus LocalBusiness if there is a physical location |
| The business itself, on the homepage | Organization |
| Original research | Article, plus Dataset if the data is published |

**The fields worth getting right, on every page:**

- The name of the thing the page is about
- A one-sentence description that matches what the page actually says
- The author or the organization
- The published date and the last updated date
- For FAQ, every question and its answer, matching the visible text on the page exactly

**Three rules:**

1. **Schema must match the visible page.** Marking up an answer that is not on the page, or a price that is not shown, is a violation of every major platform's guidelines and it can get a site penalized.
2. **Do not mark up what is not there.** Do not add FAQPage schema to a page with no FAQ section.
3. **Non-technical users should not hand-write this.** Most site platforms have a schema setting or a plugin. Tell the user which type to select and which fields to fill, and let the tool generate it.

When advising on schema, keep it to a few lines. The prose structure is what does the work.
