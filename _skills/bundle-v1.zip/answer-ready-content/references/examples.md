# Before and After

Four full rewrites, four industries. Each one shows the same two moves: the buried answer comes up to the top, and vague claims get replaced with specifics.

The "after" versions use invented companies and invented numbers to show what the level of specificity looks like. **Never carry a number from this file into a user's page.** In real work, every figure comes from the user or goes in a bracket that names the exact fact to go get.

Read these when you want to see the standard applied end to end, or when a user needs to be shown rather than told.

---

## Example 1: Dental practice, service page

### Before

> ### Advanced Restorative Dentistry
>
> At our practice, we believe that every smile tells a story. For over two decades, our team has been dedicated to providing exceptional care in a comfortable, welcoming environment where patients feel like family.
>
> Modern dentistry has come a long way. Where patients once faced multiple appointments, uncomfortable impressions, and long waits for laboratory work, today's technology has transformed the experience. Our commitment to staying at the forefront of dental innovation means we are always investing in the latest equipment and training.
>
> One of the ways we do this is through our state-of-the-art CEREC technology, which allows us to design and mill a permanent ceramic crown right here in our office. This means many patients can complete their crown in a single visit, avoiding the temporary crown and the second appointment entirely. Of course, not every case is a candidate, and our doctors will evaluate your specific situation during your consultation.
>
> Contact us today to schedule your appointment and experience the difference.

**Score: Answer Ready 0/7.**

The answer is in the fourth paragraph. A patient searching "can I get a crown in one day" would have to read 180 words of philosophy and technology narrative to reach the sentence that answers them. The heading is a category label. There is not one number on the page. The practice is never named. Nothing here could be lifted and understood.

### After

> ## Same-day dental crowns in [city]
>
> [Practice name] places permanent ceramic crowns in a single visit, typically in 2 to 3 hours from numbing to final bite check. The crown is designed and milled in our office using CEREC, so there is no temporary crown, no physical impression tray, and no second appointment. About [X] percent of the crowns we place are completed same-day. The remainder are cases that need a lab, which we explain below.
>
> ### How long does a same-day crown take?
>
> A same-day crown at [Practice name] takes 2 to 3 hours in one appointment. That breaks down to about 45 minutes to prepare the tooth and take the digital scan, 15 to 20 minutes to design the crown, 20 to 40 minutes of milling depending on the size, and about 30 minutes to fit, adjust, and bond it. You are free to leave during the milling and come back. Most patients bring something to read and stay.
>
> ### Who is not a candidate for a same-day crown?
>
> Not every case can be finished in one visit. A same-day crown is usually not the right choice when the tooth needs a root canal first, when there is active gum disease at the site, when the tooth is broken below the gum line and needs crown lengthening, or when a front tooth requires custom shade layering that a milled block cannot match. In those cases we place a temporary and use a lab, which adds about [X] weeks. Our doctors can tell you which path applies after the scan, not before.
>
> ### How much does a same-day crown cost?
>
> A same-day ceramic crown at [Practice name] costs [$X] before insurance. Most PPO plans cover 50 percent of a crown after the deductible, which puts the typical out-of-pocket at [$Y] to [$Z]. Same-day and lab-made crowns are billed under the same code, so choosing same-day does not change what your plan pays. We verify your specific coverage before the appointment and give you the number in writing.
>
> ### Does a same-day crown last as long as a lab crown?
>
> Yes. Same-day milled ceramic crowns and lab-made ceramic crowns have comparable lifespans, and both commonly last 10 to 15 years with normal wear. The material is the difference that matters, not where it was made. The one case where a lab crown has an edge is a front tooth that needs multi-layer shading to match neighboring teeth, which is a cosmetic difference, not a durability one.
>
> *Updated [month year].*

**Score: Answer Ready 7/7.**

**What changed:**

- The answer moved from paragraph four to sentence one.
- "Advanced Restorative Dentistry" became four questions patients actually ask.
- Vague claims became numbers: 2 to 3 hours, the four-stage breakdown, 10 to 15 years.
- "We" became the practice name, so a lifted passage still says who it is about.
- The "who is not a candidate" section was one buried clause. It is now a full section, and it is the most trust-building part of the page.
- The philosophy opening was cut. It was not saying anything a competitor's page was not also saying.

---

## Example 2: Industrial equipment, product spec page

### Before

> ### Series 400 Industrial Air Compressor
>
> The Series 400 represents the next generation in industrial air compression. Engineered for demanding environments, it delivers reliable performance, exceptional efficiency, and industry-leading uptime.
>
> **Key Benefits**
> - Superior energy efficiency
> - Robust, heavy-duty construction
> - Low maintenance requirements
> - Quiet operation
> - Advanced control system
>
> **Specifications**
> - Horsepower: 40 HP
> - Tank: 120 gallon
> - Voltage: 460V/3PH
> - Weight: 1,850 lbs
>
> Built to last and backed by our comprehensive warranty, the Series 400 is the smart choice for facilities that cannot afford downtime. Request a quote today.

**Score: Answer Ready 1/7.**

It scores one point for having a spec table with real values. Everything else fails. The bullets are adjectives with no measurements. A buyer's real question, "will this run my shop," is never asked or answered. No maintenance interval, no CFM, no duty cycle, no noise number, no price, no comparison to the model it replaces. Nothing here distinguishes it from any competitor's page.

### After

> ## Series 400 40 HP rotary screw air compressor
>
> The Series 400 is a 40 HP rotary screw air compressor rated at 170 CFM at 125 PSI, with a 100 percent duty cycle and a 120 gallon receiver tank. It is sized for shops running 8 to 15 pneumatic tools simultaneously, or a single CNC cell with high intermittent demand. At 72 dBA it can be installed on the production floor without an enclosure in most facilities. Typical installed cost is [$X] to [$Y] including electrical.
>
> ### What can a 40 HP compressor run?
>
> A 40 HP rotary screw compressor delivering 170 CFM will support roughly 8 to 15 shop air tools running at the same time, based on 10 to 20 CFM per typical tool at 50 percent utilization. As specific reference points: a 1/2 inch impact wrench draws about 5 CFM, a die grinder about 8, a media blast cabinet 15 to 30, and a plasma cutter 5 to 7 continuous. Size against your simultaneous peak, not the sum of every tool you own. If your peak calculation lands above 150 CFM, size up rather than running the Series 400 at the top of its range continuously.
>
> ### What is the maintenance schedule and what does it cost?
>
> The Series 400 needs an air filter and separator change every 2,000 running hours, an oil change every 4,000 hours, and a full service inspection annually. At 2,000 hours per year, which is a single shift five days a week, that is one filter service and one inspection per year, and an oil change every other year. Parts run about [$X] per year and a service visit runs [$Y] to [$Z] in most markets. There are no scheduled belt replacements, because the drive is direct coupled.
>
> ### How does the Series 400 compare to the Series 300 it replaces?
>
> | | Series 300 | Series 400 |
> |---|---|---|
> | Output at 125 PSI | 148 CFM | 170 CFM |
> | Duty cycle | 75 percent | 100 percent |
> | Noise at 3 feet | 79 dBA | 72 dBA |
> | Oil change interval | 2,000 hours | 4,000 hours |
> | Drive | Belt | Direct coupled |
> | Footprint | 64 x 32 in | 68 x 34 in |
>
> The Series 400 produces 15 percent more air, runs 7 dBA quieter, and doubles the oil change interval, at the cost of about 4 inches of width. Shops replacing a Series 300 in a tight mechanical room should measure before ordering.
>
> ### What is required to install it?
>
> The Series 400 requires 460V three-phase power on a 60 amp circuit, a level pad rated for its 1,850 pound operating weight, and 36 inches of clearance on the service side for filter access. It needs a condensate drain within 10 feet. Ambient temperature must stay between 40 and 104 degrees F. Most installations take a licensed electrician [X] hours. The compressor does not require a separate dryer for general shop air, but a refrigerated dryer is required for paint or instrument air.
>
> *Specifications current as of [month year].*

**Score: Answer Ready 7/7.**

**What changed:**

- "Superior energy efficiency" became 170 CFM at 125 PSI and a 100 percent duty cycle. Adjectives became measurements.
- "Low maintenance requirements" became an interval schedule with hours and costs.
- "Quiet operation" became 72 dBA, with the comparison that makes the number mean something.
- The buyer's real question, "will this run my shop," got its own section with per-tool CFM figures. That section is original material a competitor's marketing page will not have, because it takes practitioner knowledge to write.
- The comparison table admits the Series 400 is 4 inches wider. Naming the tradeoff makes the rest of the table believable.

---

## Example 3: Accounting firm, service page

### Before

> ### Tax Planning Services
>
> Tax planning is one of the most valuable services we offer our clients. Unlike tax preparation, which looks backward at the year that has already passed, tax planning looks forward and helps you make decisions today that reduce what you owe tomorrow.
>
> Every business is different, and there is no one-size-fits-all approach. That is why our experienced team takes the time to understand your unique situation, your goals, and your risk tolerance before making any recommendations. We work with businesses across a wide range of industries and sizes.
>
> Our tax planning services may include entity structure review, retirement plan design, timing of income and expenses, and multi-year projections. We meet with clients regularly throughout the year, not just at tax time.
>
> If you are interested in learning more about how proactive tax planning could benefit your business, we would love to hear from you. Reach out to schedule a consultation.

**Score: Answer Ready 1/7.**

It earns one point: the difference between planning and preparation is stated clearly in paragraph one, which is genuinely useful. Everything else fails. No cost, no fit criteria, no cadence beyond "regularly," and "a wide range of industries and sizes" is the phrase that tells a reader this page will not help them decide. The firm is never named.

### After

> ## Tax planning for business owners
>
> [Firm name] provides year-round tax planning for business owners with [$X] to [$Y] in annual revenue, on a flat annual fee of [$Z]. Planning is different from tax preparation: preparation reports what already happened, planning changes what happens next by adjusting entity structure, compensation, retirement contributions, and the timing of income and expenses before the year closes. Most clients meet with us four times a year, in [months]. The work has to happen during the year, because after December 31 most of the levers are gone.
>
> ### What is the difference between tax planning and tax preparation?
>
> Tax preparation is the return itself: it reports the year that already happened and it cannot change the outcome. Tax planning is the work done during the year to change that outcome, and it involves decisions with real deadlines. An S corp election generally has to be filed within 2 months and 15 days of the start of the tax year it applies to. A solo 401(k) has to be established before the plan year ends. A cost segregation study has to be planned before a property is placed in service to be worth the most. Preparation done in March cannot recover any of those.
>
> ### Who is tax planning worth it for?
>
> Tax planning is generally worth the fee for business owners with over [$X] in annual profit, owners taking distributions from an S corp, owners who bought or sold property or equipment in the last year, and owners whose income swings by more than [X] percent year to year. Below about [$X] in profit, the available strategies are usually limited to a retirement contribution and a mileage log, and a good preparer handles both. We will tell you if that is your situation rather than sell you a plan.
>
> ### How much does tax planning cost?
>
> [Firm name] charges a flat [$X] per year for tax planning, billed [monthly or quarterly], separate from the [$Y] to [$Z] for preparing the returns. The fee covers four planning meetings, a multi-year projection updated at each one, and unlimited email questions during the year. We do not bill hourly for planning, because hourly billing makes clients hesitate to call, and the calls are where the savings come from.
>
> ### What happens in the first 90 days?
>
> 1. **Week 1: Document intake.** We collect the last three years of returns, current-year financials, and your entity documents.
> 2. **Weeks 2 to 3: Baseline projection.** We build your current-year projection and identify the gaps. You get the projection in writing.
> 3. **Week 4: First planning meeting.** 90 minutes. We walk the projection, name the three highest-value moves available to you, and put a deadline on each one.
> 4. **Weeks 5 to 12: Execution.** We handle the filings we can file and give you a dated checklist for the ones you have to act on.
>
> ### What tax planning cannot do
>
> Tax planning cannot fix a year that is already closed, and it cannot make a bad business decision good because of its tax treatment. A deduction returns your marginal rate on a dollar you spent, so buying equipment you do not need to reduce taxes leaves you worse off. [Firm name] will say that plainly when it applies, and it applies more often than most owners expect.
>
> *Updated [month year].*

**Score: Answer Ready 7/7.**

**What changed:**

- The one genuinely good sentence in the original, planning versus preparation, was kept and then given real deadlines: the S corp election window, the solo 401(k) deadline, the cost segregation timing. Those specifics are what turn a definition into an answer.
- "Every business is different" became fit criteria with thresholds, plus an explicit "here is who should not buy this."
- "Regularly throughout the year" became four meetings in named months.
- "Reach out to schedule a consultation" was replaced by a numbered 90-day sequence with weeks on it, which answers the same question the CTA was gesturing at.
- The "what tax planning cannot do" section is original material. It is also the section a business owner will remember.

---

## Example 4: Software, comparison page

### Before

> ### Choosing the Right Project Management Tool
>
> Selecting a project management platform is one of the most important decisions a growing team will make. The right tool becomes the backbone of how work gets done. The wrong one becomes a source of friction that teams quietly work around.
>
> There are many excellent options on the market today, each with its own philosophy and strengths. Some are built for engineering teams with deep integrations and sprint tooling. Others prioritize flexibility and can be shaped to fit almost any workflow. Still others focus on simplicity and ease of adoption.
>
> When evaluating tools, teams should consider factors such as ease of use, integration ecosystem, reporting capabilities, scalability, and of course, cost. It is also worth considering the learning curve, since a powerful tool that nobody adopts provides no value at all.
>
> Ultimately, the best tool is the one your team will actually use. We recommend running a pilot with a small group before committing to a company-wide rollout.

**Score: Answer Ready 0/7.**

This page has a comparison in its title and does not compare anything. No tool is named. No price appears. The advice, "the best tool is the one your team will actually use," is true and completely unquotable, because it says nothing that would change a decision. Someone with no experience could have written this in ten minutes, which means it will be written again by someone else and rank the same.

### After

> ## Linear vs Jira vs Asana: which to choose in [year]
>
> Choose Linear if you are an engineering team under about 200 people and speed matters more than configurability. Choose Jira if you need custom workflows, granular permissions, or compliance reporting, and you have someone who will own administering it. Choose Asana if the tool has to be used by non-engineers, especially marketing, operations, and leadership, alongside the engineering team. Most teams that regret their choice picked Jira for a 20 person team, or picked Linear and then needed non-engineers in the tool six months later.
>
> ### What is the actual difference between them?
>
> The difference is who the tool assumes is using it. Linear assumes an engineer who wants keyboard shortcuts and no configuration screens, and it is fast because it removed the options. Jira assumes an administrator who will build the workflow, and it is configurable because it kept every option. Asana assumes a mixed audience where most people are not technical, and it trades sprint-specific tooling for a shared vocabulary that a marketer and an engineer can both use.
>
> | | Linear | Jira | Asana |
> |---|---|---|---|
> | Best fit | Eng teams under 200 | Eng orgs with an admin | Cross-functional teams |
> | Setup time | Hours | Weeks | Days |
> | Custom workflows | Limited | Extensive | Moderate |
> | Non-technical adoption | Poor | Poor | Strong |
> | Per-user cost | [$X] | [$Y] | [$Z] |
> | Needs a dedicated admin | No | Usually yes | No |
>
> ### When Jira is the right choice
>
> Jira is the right choice in four situations. First, when you need workflow states that differ by team and someone will maintain them. Second, when compliance or audit requires a permanent, permissioned audit trail on every status change. Third, when you are already running Confluence and Bitbucket, because the integration is genuinely tighter than any third-party connection. Fourth, when the engineering organization is over roughly 300 people, where the configurability that slows down a small team starts paying for itself. Jira is the wrong choice for a 20 person team with nobody to administer it, which is the most common way teams end up hating it.
>
> ### How much does each one cost for a 50 person team?
>
> At 50 users, expect roughly [$X] per year for Linear, [$Y] for Jira Standard, and [$Z] for Asana Premium, at list price before annual discounts. Jira's list price is the lowest of the three at small seat counts and the comparison is misleading, because the real cost includes administration. Teams running Jira well typically have someone spending 5 to 10 hours a month on it, which at a loaded rate is [$X] to [$Y] a year that does not appear on the invoice.
>
> ### Can you migrate between them later?
>
> Yes, and it is more painful than the vendors suggest. Issues, titles, descriptions, and assignees migrate cleanly between all three. What does not migrate cleanly is comment threading, custom field history, attachments over the size limit, and any automation you built. Budget [X] to [Y] weeks for a migration at 50 people and expect to rebuild your automations by hand. The practical consequence: it is worth spending two extra weeks on the decision now.
>
> *Updated [month year]. Pricing checked [month year].*

**Score: Answer Ready 7/7.**

**What changed:**

- The recommendation moved to sentence one. The original never made one.
- Named tools replaced "many excellent options." A comparison page that names nothing compares nothing.
- The generic factor list, "ease of use, integrations, reporting, scalability, cost," became a table with values in it.
- The cost section names the hidden administration cost, which is the practitioner detail that makes this page worth quoting over the twenty other pages comparing the same three tools. That single paragraph is check 5 on its own.
- The migration section states a real consequence rather than a caveat.
- Two dates on the page, one for the page and one for the pricing, because pricing goes stale first.

---

## The pattern across all four

Every one of these rewrites did the same two things.

**The answer moved up.** In all four cases the answer already existed somewhere in the draft, or in the writer's head, sitting behind an opening the writer needed in order to start. The dental page had it in paragraph four. The accounting page had it in paragraph one and then abandoned it. The compressor page had it in the spec list with no context attached. The software page never wrote it down. Moving the answer to the top of the section was the highest-value edit in all four.

**The vague became checkable.** "Quiet operation" became 72 dBA. "Regularly throughout the year" became four meetings. "A wide range of industries" became a revenue threshold. "Many excellent options" became three named tools with prices. Every replacement made the page harder for a competitor to duplicate, which is the entire point.

The third thing, which only two of the four did well, is the section that says who the thing is not for. The dental page named the cases that need a lab. The accounting page said who should not buy planning. Those sections cost the page nothing in conversions and they are the passages most likely to be quoted, because they are the ones nobody else is willing to write.
