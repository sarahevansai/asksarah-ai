# AI Visibility Audit

A Claude skill that finds out whether AI assistants recommend your business when a buyer asks for help, and tells you what to fix first.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Buyers now ask an assistant for a recommendation before they ever run a search. They describe their problem, they get a short list of companies back, and they start from that list. You can rank well in traditional search and be completely absent from it. Nothing warns you, because the customer who never arrives leaves no trace.

Most owners have never checked. The ones who have checked did the wrong test: they typed their own company name into an assistant, read an accurate paragraph about themselves, and decided they were fine. That is a description test. It proves nothing about whether you get recommended.

Tell Claude what your business does and it will:

1. Write 20 to 40 decision prompts in your buyers' actual words, ready to paste
2. Score the results against three separate things most people conflate: mentioned, cited, recommended
3. Diagnose which of four gap types you have, because each one has a different first move
4. Sequence the fixes by how close each prompt is to a purchase decision

**You always get the working artifact.** The prompt set written out. The baseline table already built with your competitors in the rows. The fix list, in order. Give it only a company name and a category and it will infer the rest and write the whole audit anyway, marking unknowns in `[BRACKETS]`. You will never get "here is how you would run an audit."

## The core insight

Audit the questions a buyer actually types, not keywords.

Nobody types "best CRM software." They type "we are a 12 person agency drowning in spreadsheets and losing track of who owes what to which client, what should we use." That is the sentence that produces a short list of companies. That is the sentence worth auditing.

The prompt set covers seven categories: category recommendation, problem-first (where the buyer names a pain and never names a product category), comparison, buying criteria, trust and vetting, local or segment qualified, and brand-direct as a control that runs last and counts least.

## The four stages

1. **Write the decision prompts.** In the buyer's language, not your marketing language. A prompt that names your brand is not a visibility test.
2. **Run and record.** Fresh conversations, no personalization, every prompt run twice, because a single run is an anecdote. Record whether you appear, in what position, recommended or only mentioned, which competitors show up, and what the answer cites.
3. **Build the baseline table.** You versus your top competitors on three axes: mentioned, cited, recommended. Mentioned without recommended is a positioning problem. Recommended without cited means someone else's content is doing your persuading.
4. **Diagnose and sequence.** Four gap types, each with a different first move, then fix the highest-intent prompts first, not the highest-volume ones.

## What it will not do

It will not tell you how to game a ranking, because no assistant publishes its ranking factors and anyone selling certainty about them is guessing.

It will not invent a statistic about AI search. Not how many buyers use assistants, not how much traffic has shifted. If a number would help your case, it tells you to go find a current source and cite it yourself.

It will not report a snapshot as a metric. You get counts, not scores. "Appeared in 4 of 22 prompts," never "27%" or a grade out of 100. Results vary by user, region, and model version, and the audit says so before it says anything else.

The real signal is the comparison across months. The skill includes a re-run cadence and a reporting format built so a boss or a client cannot mistake one day's snapshot for a rank.

## Try it

Once installed, say any of these:

- "Does ChatGPT recommend us? We are a [what you do] in [where]."
- "Build me an AI visibility prompt set for my business"
- "Here are the answers I got, what do they say" and paste them in
- "Why does my competitor keep coming up and we don't?"
- "Build the baseline table"
- "What should I fix first?"
- "Write this up for my client"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `ai-visibility-audit.zip` in your skills settings. Claude loads it automatically whenever the question comes up.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/ai-visibility-audit/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation and say "does AI recommend us" with one line about your business. You should get a full prompt set, a recording sheet, and one coaching note.

## What is in the package

```
ai-visibility-audit/
├── SKILL.md                  The framework, the rules, and the output format
├── README.md                 This file
├── LICENSE
└── references/
    ├── prompt-sets.md        Ready-to-paste prompt sets for 8 business types,
    │                         plus the recording sheet layout
    └── examples.md           3 complete worked audits with filled tables,
                              diagnosed gaps, and sequenced fix lists
```

## Notes

Claude will never invent a competitor, a result, or a citation to fill a gap. Anything it cannot know comes back in `[BRACKETS]`. A confident audit built on a made-up finding is worse than no audit.

It asks at most one question, and only after the artifact is already in front of you. Nothing is held back waiting on an answer.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
