# Worked Audits

Three complete audits from different industries, start to finish: the prompt set, the findings, the filled baseline table, the diagnosed gap, and the sequenced fix list.

Every company name in these examples is fictional and every result is illustrative. They exist to show the shape and depth of a finished audit, not to report anything about a real business. Never present numbers from this file as findings about a user.

Read these when you need to calibrate how much detail a finished audit carries. Notice three things in all of them: the limits are stated before the findings, the counts are never converted to percentages, and the fix list names something a person could start on Monday.

---

# Audit 1: Local service business

**Business:** Ridgeline Plumbing, a 14 person residential and light commercial plumbing company in Boise, Idaho. Twenty two years in business. Strong local reputation, ranks on page one for "plumber Boise," owner has never checked an assistant.

**Named competitors:** Cascade Plumbing Co, Treasure Valley Plumbing, All-Hours Rooter, plus two national booking platforms the owner did not consider competitors.

## The prompt set, 24 prompts

**Category recommendation**
1. best plumber in boise
2. who should i call for a plumbing emergency in boise
3. good plumbing company in boise for a whole house repipe
4. reliable plumber near meridian idaho

**Problem-first**
5. water heater is leaking from the bottom, what do i do and who do i call
6. my water bill tripled and i cannot find a leak
7. slab leak under my house in boise, who handles that
8. sewer smell in the basement after it rains
9. my 1970s house has galvanized pipes and low pressure everywhere, is repiping worth it
10. no hot water and the pilot will not stay lit
11. i got quoted 9000 for a sewer line replacement, is that reasonable

**Comparison**
12. cascade plumbing vs treasure valley plumbing boise
13. is it better to use a local plumber or a national booking service
14. repair vs replace a 12 year old water heater

**Buying criteria**
15. what should i look for when hiring a plumber
16. what questions should i ask before a big plumbing job
17. what licensing does a plumber need in idaho
18. how do i avoid being overcharged by a plumber

**Trust and vetting**
19. is cascade plumbing reputable
20. what do people say about plumbers in boise
21. how do i check if a plumber is licensed and insured in idaho

**Segment or local qualified**
22. plumber in boise who works on older homes
23. emergency plumber in boise on a sunday

**Brand-direct control**
24. is ridgeline plumbing a good company

## Conditions

Two assistants, fresh conversations, no account history, two runs each prompt, run over two days in the same week. Sources were shown on roughly half the answers.

## Findings

Ridgeline appeared in 3 of 24 prompts. All three were the two local qualified prompts and the brand-direct control. On all seven problem-first prompts, Ridgeline appeared zero times.

The competitor column told the real story. Across 24 prompts the two most frequently named entities were not local plumbing companies at all. They were two national booking platforms, named 18 and 11 times. Cascade Plumbing appeared 9 times. Treasure Valley appeared 7 times.

The sources column explained why. Answers about Boise plumbers overwhelmingly cited a mix of directory listings, a local news "best of" roundup from two years ago, and review aggregators. Ridgeline appeared in none of them, because the owner had never claimed the directory profiles and had not been in the roundup.

The two runs disagreed on four prompts, all of them in the category recommendation group, which suggests those answers are unstable and a small change in footprint could move them.

## Baseline table

Counts out of 24 prompts.

|  | Mentioned | Cited | Recommended |
|---|---|---|---|
| Ridgeline Plumbing | 3 | 0 | 2 |
| Cascade Plumbing Co | 9 | 0 | 7 |
| Treasure Valley Plumbing | 7 | 1 | 6 |
| National booking platform A | 18 | 4 | 15 |
| National booking platform B | 11 | 2 | 9 |

## Diagnosed gap

**Absent**, with a specific shape: absent from the problem-first prompts entirely, and absent from every source the assistants are drawing on.

This is not a reputation problem. Ridgeline's reputation is good and shows up the moment someone names them. It is a supply problem. There is nothing published, anywhere, that connects "slab leak in an older Boise home" to Ridgeline, so nothing can be retrieved.

The secondary finding matters more than the primary one: the real competitors in these answers are booking platforms, not plumbing companies. The category as assistants understand it is "how do I find a plumber," and the platforms own that question.

## Sequenced fix list

Ranked by intent. The emergency and big-ticket prompts are closest to a purchase.

1. **Claim and complete every directory and review profile, with identical naming and description.** Prompts 1, 2, 19, 20, 21 all draw on these. This is unglamorous and it is the fastest thing on the list, because the sources already being cited are the ones missing an entry. Same company name, same service description, same service area on all of them.

2. **Publish four pages that answer the four highest-intent problem prompts directly.** Slab leaks, galvanized repipe, water heater failure, sewer line replacement. Each page answers the question a homeowner actually asked, in their words, with real specifics: what it costs in this market, how long it takes, what makes a house a candidate, and what to do tonight if it is an emergency. Not service pages. Answer pages. Prompt 11 alone, the person who was quoted 9000, is one phone call away from a five figure job.

3. **Get into the local roundups and comparison content that assistants are already citing.** The two year old "best of" list is still being retrieved. Find the current equivalents and get genuinely included.

4. **Publish a straight pricing page for the top five jobs.** Prompts 11, 14, and 18 are all price anxiety, and nothing in the current answer set addresses price with real numbers from this market.

**Next run:** same 24 prompts, same conditions, 30 days out. Expect movement on 1, 2, 19, 20, and 21 first, because directory changes propagate faster than new pages.

---

# Audit 2: B2B software company

**Business:** Loomwork, a project and profitability tracking tool for services businesses. 40 employees, roughly 900 customers, most between 10 and 60 people. Strong content operation, ranks well for category keywords, sales team keeps hearing "we found you through a comparison article."

**Named competitors:** Trellisworks, Bandway, Sixpoint, plus the general purpose tools buyers substitute.

## The prompt set, 27 prompts

**Category recommendation**
1. best project management software for a small agency
2. what tool should a services business use to track client work and profitability
3. best software for tracking billable hours across a team
4. what do small consulting firms use for project and financial tracking

**Problem-first**
5. we are a 12 person agency drowning in spreadsheets and losing track of who owes what to which client
6. we keep finding out a project went over budget after we already delivered it
7. i have no idea which of our clients are actually profitable
8. our team uses slack, sheets and quickbooks and nothing talks to each other
9. we lost a retainer client because we missed deadlines nobody was tracking
10. how do i stop chasing my team for timesheets every week
11. we outgrew our current tool but an erp feels like overkill
12. our margins are shrinking and i cannot tell which service line is the problem

**Comparison**
13. trellisworks vs bandway for a 20 person agency
14. is trellisworks worth it compared to sixpoint plus spreadsheets
15. trellisworks vs bandway vs sixpoint for professional services
16. best alternative to trellisworks for a small agency

**Buying criteria**
17. what should i look for in project management software for a services business
18. what features actually matter in agency management software
19. what should i ask a vendor before signing an annual software contract
20. how do i make sure my team actually adopts a new project tool

**Trust and vetting**
21. is trellisworks reliable
22. what do people say about bandway support
23. what are common complaints about agency management software

**Segment qualified**
24. project management software for a marketing agency under 25 people
25. tool for a firm that bills hourly and on retainer
26. software for tracking project profitability in a consulting firm

**Brand-direct control**
27. is loomwork good for agencies

## Conditions

Three assistants, fresh conversations, two runs each, over three days. Sources shown on most answers in two of the three assistants.

## Findings

Loomwork appeared in 14 of 27 prompts, which the marketing lead initially read as good news. The breakdown said otherwise.

Of those 14 appearances, 11 were mentions rather than recommendations. The typical sentence was some version of "other tools in this category include Loomwork." Loomwork was recommended in 3 prompts: the brand-direct control, one comparison prompt where it was named in the question, and one segment prompt.

On the eight problem-first prompts, Loomwork appeared 4 times and was recommended zero times. Trellisworks was recommended in 6 of those 8.

The sources column was the most useful finding in the audit. Loomwork's own material was cited 9 times, more than any competitor's owned content. The assistants were reading Loomwork's blog, treating it as a credible explanation of the category, and then recommending someone else.

## Baseline table

Counts out of 27 prompts.

|  | Mentioned | Cited | Recommended | Recommended for |
|---|---|---|---|---|
| Loomwork | 14 | 9 | 3 | general category, one segment |
| Trellisworks | 22 | 3 | 19 | most situations, all sizes |
| Bandway | 17 | 2 | 12 | larger teams, enterprise |
| Sixpoint | 12 | 1 | 8 | budget and solo |

## Diagnosed gap

**Mentioned but not recommended**, in its purest form. Loomwork is in the model's picture of the category, and nothing in that picture says who Loomwork is the right answer for.

The cited column makes this a specific and slightly painful diagnosis. Loomwork's content is educating buyers on how to evaluate the category, that content is being retrieved and trusted, and the recommendation that follows goes to a competitor. Loomwork is paying to write the buying criteria that another company wins on.

Trellisworks is not recommended more because it is better. It is recommended more because its material makes situation-specific claims: team sizes, billing models, named use cases. Loomwork's material describes features.

## Sequenced fix list

Ranked by intent. The problem-first prompts are the closest to a buyer with a budget and no vendor yet.

1. **Rewrite the top four problem-first pages to name the situation and the fit, explicitly.** Prompts 5, 6, 7, and 12 are the highest intent failures on the sheet, and they are asked by someone who has already felt the pain. Each page needs a sentence that reads like a recommendation: who this is for, at what size, with what billing model, and who it is not for. Saying who it is not for is the single most under-used move in this category, and it is what makes the rest of the claim credible.

2. **Add fit criteria to every piece of educational content that is already being cited.** Nine citations is an asset. Right now each of those pages ends without a conclusion. Each should end with a plain statement of what kind of firm should use what kind of tool, with Loomwork named where it is genuinely the right answer.

3. **Publish real comparison content, including the cases where Loomwork loses.** Prompt 16, best alternative to Trellisworks, is a high intent prompt with a buyer already in motion, and Loomwork does not appear. An honest comparison that concedes the cases where a competitor is the better fit is more likely to be retrieved and repeated than a page that claims to win everywhere.

4. **Fix the segment story.** Loomwork appeared in only 1 of 3 segment prompts despite most of its customers being in exactly that segment. Publish the customer profile it actually serves, in the buyer's words, with sizes and billing models in it.

**Coaching note for this client:** the win condition is not more mentions. Loomwork has plenty of mentions. The win condition is the sentence that turns a mention into a recommendation, and that sentence has to exist somewhere in writing before an assistant can say it.

**Next run:** same 27 prompts, same three assistants, 30 days. Watch the recommended column, not the mentioned column.

---

# Audit 3: Healthcare practice

**Business:** Northfield Physical Therapy, a three location, nine clinician outpatient physical therapy practice in a mid-sized metro. Half of new patients come from physician referral, and referral volume has been flat for two years while the owner suspects self-referral is where growth now lives.

**Named competitors:** Hillcrest Sports Medicine, MoveWell PT, plus the hospital system's outpatient rehab network.

## The prompt set, 22 prompts

**Category recommendation**
1. best physical therapy clinic in [metro]
2. where should i go for physical therapy in [metro]
3. good physical therapist in [metro] who takes blue cross

**Problem-first**
4. my knee hurts when i run and my doctor said try pt, where do i start
5. i had a rotator cuff repair six weeks ago and my recovery has stalled
6. shoulder has been bothering me for months and i keep putting it off
7. i want to keep lifting but my back keeps flaring up
8. is physical therapy or a chiropractor better for lower back pain
9. how do i find a physical therapist who works with runners
10. can i do physical therapy without a referral

**Comparison**
11. hillcrest sports medicine vs movewell pt
12. hospital outpatient rehab vs a private physical therapy clinic
13. in person physical therapy vs an app based program

**Buying criteria**
14. what should i look for in a physical therapy clinic
15. what questions should i ask before starting physical therapy
16. how do i know if a physical therapist is any good
17. how much does physical therapy cost without insurance

**Trust and vetting**
18. is hillcrest sports medicine a good clinic
19. what credentials should a physical therapist have

**Segment qualified**
20. physical therapy for runners in [metro]
21. pelvic floor physical therapy in [metro]

**Brand-direct control**
22. is northfield physical therapy good

## Conditions

Two assistants, fresh conversations, two runs each. One assistant surfaced sources consistently, the other did not, which is itself recorded as a condition rather than treated as an absence of sources.

## Findings

Northfield appeared in 7 of 22 prompts and was recommended in 5. On the surface this is the strongest of the three audits.

The context column is where it turned. Every one of the five recommendations was for post-surgical rehabilitation. Northfield was recommended in prompt 5, the rotator cuff recovery, in both runs and both assistants. It appeared in zero of the running, lifting, or general pain prompts, and zero of the two segment prompts, including the runner prompt.

Post-surgical rehab is roughly a fifth of Northfield's business, it is the lowest margin work they do, it is entirely referral driven already, and it is not what the owner has spent two years trying to grow. The sports and active adult population, which is the growth target, is where Hillcrest is recommended in 9 of 22 prompts.

The reason was visible in the sources. The material about Northfield that exists online is almost entirely hospital and surgeon referral pages describing them as a post-op rehab provider. Their own site has a sports page, but it is three paragraphs long and says nothing specific.

Prompt 10, whether a referral is needed, was answered without naming any local clinic in three of four runs. Nobody local has published a plain answer to it.

## Baseline table

Counts out of 22 prompts.

|  | Mentioned | Cited | Recommended | Recommended for |
|---|---|---|---|---|
| Northfield PT | 7 | 1 | 5 | post-surgical rehab only |
| Hillcrest Sports Medicine | 12 | 3 | 9 | athletes, running, lifting |
| MoveWell PT | 8 | 2 | 6 | general orthopedic, convenience |
| Hospital rehab network | 14 | 5 | 10 | post-surgical, insurance driven |

## Diagnosed gap

**Recommended for the wrong thing.**

This is the most dangerous of the four gap types because it looks like success in every summary view. Seven mentions and five recommendations out of 22 is a respectable line on a report. It is also a machine pointing the wrong buyers at a business, in the one segment the owner is trying to move away from, while the growth segment goes to a competitor.

Secondary gap: **absent** on the segment prompts, where the intent is highest and the field is narrowest.

## Sequenced fix list

Ranked by intent. Prompts 9, 20, and 21 are people actively looking for a specific kind of clinician, which is as close to booking as this category gets.

1. **Build out the sports and active adult material until it is more substantial than the post-op material.** Prompts 4, 6, 7, 9, and 20 are all the same buyer at different stages. Specific clinician backgrounds, what a running assessment actually involves, what a return to lifting progression looks like, who on staff does this work and what they have done. Three paragraphs will not be retrieved over a competitor's substantial material.

2. **Publish the plain answer to the referral question.** Prompt 10 currently has no local answer at all. It is a first-time patient, actively blocked, one clear paragraph away from booking. This is the cheapest win on the list.

3. **Publish the pelvic floor page or drop the claim.** Prompt 21 is high intent and highly specific, and Northfield appeared zero times. If the practice genuinely offers it, the page needs to say who provides it and what the first visit involves. If it does not, remove it from the services list, because a thin claim with nothing behind it is what produced the current mismatch.

4. **Rebalance the referral-facing material.** The surgeon and hospital pages describing Northfield as post-op only are the strongest signal about Northfield on the internet. Nothing here says stop being good at post-op rehab. It says the growth segment needs an equally strong footprint before the association will shift.

5. **Do not chase the general category prompts yet.** Prompts 1, 2, and 3 are dominated by the hospital network and are the hardest to move. They are also lower intent than the segment prompts. Come back to them after the segment material is in place.

**Coaching note for this client:** the count went up and the business would have gone the wrong direction. Always score what you were recommended for, not only whether you were recommended. A visibility number with no context column is how a practice grows the part of itself it was trying to shrink.

**Next run:** same 22 prompts, 30 days. The specific thing to watch is prompt 9 and prompt 20, and the specific question is whether Northfield enters the answer at all, not where it lands.
