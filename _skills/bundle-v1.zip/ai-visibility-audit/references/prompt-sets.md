# Prompt Sets

Ready-to-paste starting sets for eight business types, written in real buyer language.

These are raw material for you, not output for the user. Never hand one of these back unchanged. Swap in the user's real category words, their real segment, their real geography, and their real competitors, then add prompts for anything specific to their business. The value of the audit lives in how closely the prompts match how their buyers actually talk.

Rules that apply to every set below:

- Brand-direct prompts run last and count least. They are the control.
- Run each prompt in a fresh conversation with no history.
- Run each prompt twice.
- Replace every bracket before running. A bracket left in the prompt changes the answer.
- Do not clean up the buyer's grammar. Real prompts are messy and messy prompts retrieve differently than tidy ones.

---

## 1. Local service business

Example used here: a residential HVAC company. Swap the trade and the city.

**Category recommendation**
1. best hvac company in [city]
2. who should i call for ac repair in [city]
3. most reliable heating and air company near [neighborhood or suburb]
4. good hvac contractor in [city] that does same day service

**Problem-first**
5. my ac is running constantly but the house is still hot, who do i call
6. upstairs is 10 degrees warmer than downstairs, how do i fix this
7. got quoted 14k for a new furnace, is that normal and who else should i get a quote from
8. my heat went out and it is 20 degrees, what are my options tonight
9. energy bill doubled this summer and nothing changed in the house
10. buying a house with a 19 year old furnace, what should i do about it

**Comparison**
11. [competitor a] vs [competitor b] for hvac in [city]
12. is it better to use a big hvac franchise or a local family company
13. should i repair or replace a 15 year old ac unit

**Buying criteria**
14. what should i look for when hiring an hvac company
15. what questions should i ask before signing an hvac maintenance plan
16. what licenses and insurance should an hvac contractor have in [state]
17. what is a fair price for a full hvac system replacement in [region]

**Trust and vetting**
18. is [competitor a] a good hvac company
19. how do i know if an hvac contractor is overcharging me
20. what do people say about hvac companies in [city]

**Segment or local qualified**
21. hvac company in [city] that works on older homes
22. hvac contractor in [city] for a small commercial building
23. emergency hvac in [city] on a weekend

**Brand-direct control, run last**
24. what is [brand]
25. is [brand] a good hvac company
26. how much does [brand] charge

---

## 2. B2B software company

Example used here: a project and client tracking tool for services businesses.

**Category recommendation**
1. best project management software for a small agency
2. what tool should a services business use to track client work and profitability
3. best software for tracking billable hours across a team
4. what do small consulting firms use to manage projects and invoicing

**Problem-first**
5. we are a 12 person agency drowning in spreadsheets and losing track of who owes what to which client, what should we use
6. we keep finding out a project went over budget after we already delivered it
7. our team uses slack, google sheets, and quickbooks and nothing talks to each other
8. i have no idea which of our clients are actually profitable
9. we lost a retainer client because we missed two deadlines nobody was tracking
10. how do i stop chasing my team for timesheets every friday
11. we outgrew our current tool but a full erp feels like overkill

**Comparison**
12. [competitor a] vs [competitor b] for a 20 person agency
13. is [competitor a] worth it compared to just using [competitor b] plus spreadsheets
14. [competitor a] vs [competitor b] vs [competitor c] for professional services

**Buying criteria**
15. what should i look for in project management software for a services business
16. what features actually matter in agency management software
17. what should i ask a vendor before signing an annual contract for team software
18. how do i evaluate whether a project tool will actually get adopted by my team

**Trust and vetting**
19. is [competitor a] reliable
20. what do people say about [competitor a] support
21. has [competitor a] had any security issues

**Segment qualified**
22. project management software for a marketing agency under 25 people
23. client tracking tool for a firm that bills hourly and on retainer
24. software for an agency that works with regulated clients

**Brand-direct control, run last**
25. what is [brand]
26. is [brand] good for agencies
27. how much does [brand] cost

---

## 3. Professional services firm

Example used here: an accounting and advisory firm serving small businesses.

**Category recommendation**
1. best accounting firm for small businesses in [city]
2. who should i hire to do my business taxes
3. best cpa firm for a business doing 5 million in revenue
4. what kind of accountant does a growing company need

**Problem-first**
5. my bookkeeper quit and i have no idea what state my books are in
6. i got a letter from the irs and i do not know what to do
7. we are about to raise money and our financials are a mess
8. i think my business is profitable but i never have cash, what is going on
9. i have been doing my own books for six years and i think i am past that now
10. we are hiring in three states and i have no idea what that means for payroll

**Comparison**
11. should i hire a bookkeeper or a cpa firm
12. [competitor a] vs [competitor b] for small business accounting
13. is an outsourced cfo worth it versus hiring a controller

**Buying criteria**
14. what should i look for when choosing an accountant for my business
15. what questions should i ask a cpa before hiring them
16. how much should a small business expect to pay for accounting services
17. how do i know if my accountant is doing a good job

**Trust and vetting**
18. is [competitor a] a reputable accounting firm
19. what do reviews say about [competitor a]
20. red flags when hiring an accountant

**Segment qualified**
21. accounting firm for a construction company with 40 employees
22. cpa in [city] who works with ecommerce businesses
23. accountant for a nonprofit that needs an audit

**Brand-direct control, run last**
24. what is [brand]
25. is [brand] a good accounting firm
26. who does [brand] work with

---

## 4. E-commerce brand

Example used here: a direct to consumer home goods brand.

**Category recommendation**
1. best [product category] to buy online
2. best [product category] for the money
3. what brand makes the best [product category]
4. best [product category] that is not [dominant mass brand]

**Problem-first**
5. my [product] keeps [common failure], what should i buy instead
6. i have a small apartment and need [product category] that does not take up space
7. i am allergic to [material], what [product category] can i use
8. i have replaced this thing three times in two years, what actually lasts
9. moving into a first apartment, what do i actually need for [room]
10. need a gift for someone who already has everything for [use case]

**Comparison**
11. [competitor a] vs [competitor b] [product category]
12. is [competitor a] worth the price compared to buying from [big retailer]
13. [premium competitor] vs [budget competitor], is the difference real

**Buying criteria**
14. what should i look for when buying [product category]
15. what materials matter in [product category]
16. how do i tell if [product category] is actually good quality
17. what is a reasonable price for [product category]

**Trust and vetting**
18. is [competitor a] a legit brand
19. what do reviews say about [competitor a] shipping and returns
20. is [competitor a] actually made where they say

**Segment qualified**
21. best [product category] for [specific use case, for example small dogs, hard water, dorm rooms]
22. sustainable [product category] brands
23. [product category] made in [country or region]

**Brand-direct control, run last**
24. what is [brand]
25. is [brand] worth it
26. what do people say about [brand]

---

## 5. Healthcare practice

Example used here: a physical therapy clinic. Keep every prompt on the buyer's decision, not on medical advice.

**Category recommendation**
1. best physical therapy clinic in [city]
2. where should i go for physical therapy in [neighborhood]
3. good physical therapist in [city] who takes [insurance]

**Problem-first**
4. my knee hurts when i run and my doctor said try pt, where do i start
5. i had surgery six weeks ago and my recovery has stalled
6. shoulder has been bothering me for months and i keep putting off doing anything
7. i want to keep lifting but my back keeps flaring up
8. is physical therapy or a chiropractor better for lower back pain
9. how do i find a physical therapist who works with runners

**Comparison**
10. [competitor a] vs [competitor b] physical therapy in [city]
11. hospital affiliated physical therapy vs private clinic
12. in person physical therapy vs a virtual program

**Buying criteria**
13. what should i look for in a physical therapy clinic
14. what questions should i ask before starting physical therapy
15. how do i know if a physical therapist is any good
16. how much does physical therapy cost without insurance in [state]

**Trust and vetting**
17. is [competitor a] a good physical therapy clinic
18. what do patients say about [competitor a]
19. what credentials should a physical therapist have

**Segment qualified**
20. physical therapy in [city] for athletes
21. pelvic floor physical therapy in [city]
22. physical therapy clinic in [city] with evening hours
23. pediatric physical therapy near [city]

**Brand-direct control, run last**
24. what is [brand]
25. is [brand] clinic good
26. does [brand] take [insurance]

---

## 6. Manufacturer

Example used here: a contract manufacturer of custom metal components.

**Category recommendation**
1. best contract manufacturer for custom metal parts in [region]
2. who does short run cnc machining in the us
3. best sheet metal fabricator for prototype to production

**Problem-first**
4. our overseas supplier keeps missing lead times and we need a backup
5. we need 500 units of a custom bracket and nobody will quote a run that small
6. our current shop cannot hold the tolerance we need
7. we are redesigning a part and need someone who can help with manufacturability
8. tariffs made our current sourcing uneconomical, what are our options
9. we need a supplier who can scale from 100 units to 50000 without requalifying

**Comparison**
10. [competitor a] vs [competitor b] for cnc machining
11. domestic vs overseas manufacturing for [component type]
12. contract manufacturer vs building the capability in house

**Buying criteria**
13. what should i look for in a contract manufacturer
14. what certifications should a manufacturer have for [industry, for example medical, aerospace, automotive]
15. what questions should i ask a manufacturer before sending a drawing
16. how do i evaluate a manufacturer's quality system

**Trust and vetting**
17. is [competitor a] a reliable manufacturer
18. what is [competitor a] lead time reputation
19. how do i vet a manufacturer i found online

**Segment qualified**
20. iso certified manufacturer for medical device components
21. manufacturer in [region] for low volume high mix production
22. manufacturer who can do assembly and not just parts

**Brand-direct control, run last**
23. what is [brand]
24. what does [brand] manufacture
25. is [brand] a good supplier

---

## 7. Nonprofit

Example used here: a regional food security nonprofit. Two audiences, so run donor prompts and beneficiary prompts as separate groups.

**Category recommendation, donor side**
1. best food bank to donate to in [city or region]
2. what nonprofits actually make a difference on hunger in [state]
3. where should i donate to have the most impact locally

**Problem-first, donor side**
4. i want to give 10000 this year and i want it to stay in my community
5. our company wants a local nonprofit partner for volunteering, who is doing good work in [city]
6. i am setting up a donor advised fund and want to support food access, where do i start
7. how do i know my donation is not just going to overhead

**Problem-first, beneficiary side**
8. i cannot afford groceries this month, where can i get help in [city]
9. where can i get food assistance in [county] on a weekend
10. my family does not qualify for snap but we are still short every month

**Comparison**
11. [competitor a] vs [competitor b] for hunger relief in [region]
12. is it better to donate to a national food charity or a local one

**Buying criteria**
13. how do i evaluate a nonprofit before donating
14. what should i look for in a charity's financials
15. what makes a food bank effective

**Trust and vetting**
16. is [competitor a] a reputable charity
17. what is [competitor a] rating on charity evaluators
18. how much of my donation to [competitor a] goes to programs

**Segment qualified**
19. nonprofits serving [specific population] in [region]
20. food access organizations in rural [state]
21. nonprofits in [city] that accept corporate volunteer groups

**Brand-direct control, run last**
22. what is [brand]
23. is [brand] a good charity
24. what does [brand] do

---

## 8. Solo consultant

Example used here: an independent operations consultant. The hardest case, because a single person has the smallest footprint.

**Category recommendation**
1. best operations consultant for a small business
2. who should i hire to fix my company's internal processes
3. best fractional coo for a company under 50 people

**Problem-first**
4. our team keeps missing deadlines and i cannot tell where the process breaks
5. we grew from 8 to 40 people and nothing works the way it used to
6. i am the founder and i am still the bottleneck on everything
7. everyone is busy and nothing ships, who do i bring in
8. our onboarding for new hires is nonexistent and it is costing us
9. we need someone to fix operations but cannot afford a full time coo

**Comparison**
10. consultant vs fractional executive vs full time hire for operations
11. big consulting firm vs an independent consultant for a small company
12. [competitor a] vs [competitor b] for operations consulting

**Buying criteria**
13. what should i look for when hiring an operations consultant
14. what questions should i ask a consultant before signing an engagement
15. how should a consulting engagement be structured and priced
16. how do i know a consultant will actually deliver

**Trust and vetting**
17. is [competitor a] a good consultant
18. how do i vet an independent consultant with no firm behind them
19. what are red flags in a consulting proposal

**Segment qualified**
20. operations consultant for a [industry] company
21. consultant who works with founder led companies
22. operations help for a company preparing for an acquisition

**Brand-direct control, run last**
23. who is [name]
24. is [name] a good consultant
25. what does [name] do

---

## The recording sheet

One row per prompt per assistant per run. Build this as a spreadsheet or paste it as a table. Do not summarize as you go, because the pattern only appears once every row is in.

| # | Prompt | Assistant | Run | Brand appeared | Position | Recommended or mentioned | Competitors named, in order | Sources cited | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 1 | | | 1 | Y / N | 1st / mid / last / n/a | Rec / Mention / n/a | | | |
| 1 | | | 2 | | | | | | |

Column definitions, so two people scoring the same run agree:

- **Brand appeared**: the brand name is in the answer anywhere, including a passing list. Binary.
- **Position**: where in the answer, not on a page. First named, mid-list, or last. Mark n/a if absent.
- **Recommended or mentioned**: "Recommended" means the answer suggests the buyer look at them. "Mention" means the name appears without a suggestion attached, for example in a list of players in the space. When it is genuinely ambiguous, score it as a mention and note why.
- **Competitors named, in order**: every company named, in the order they appear. This column becomes the most useful one in the audit, because it shows which category the assistant actually thinks you are in.
- **Sources cited**: publications, directories, review sites, forums, or specific pages. Write "none shown" where the assistant does not surface sources, and note that as a condition of the run rather than as a zero.
- **Notes**: anything that would change how a reader interprets the row. A hedge, a caveat, a wrong fact about the brand, an outdated claim.

### Summary block to fill after the run

```
Prompts run: [N]
Assistants: [names]
Runs per prompt: [N]
Date: [date]

Appeared: [N] of [N]
Recommended: [N] of [N]
Cited: [N] of [N]

Appearances by category:
  Category recommendation: [N] of [N]
  Problem-first:           [N] of [N]
  Comparison:              [N] of [N]
  Buying criteria:         [N] of [N]
  Trust and vetting:       [N] of [N]
  Local or segment:        [N] of [N]
  Brand-direct (control):  [N] of [N]

Competitors by frequency: [name, count] ...
Sources by frequency:     [name, count] ...
Runs that disagreed with each other: [N]
```

The category breakdown is where the diagnosis usually starts. A business that scores well on category recommendation and zero on problem-first has a very specific and very fixable gap.
