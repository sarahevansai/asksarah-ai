---
name: ai-visibility-audit
description: >
  Audits whether AI assistants recommend a business when a buyer asks for help, and
  produces the finished audit: the prompt set, the baseline table, the diagnosed gap,
  and the prioritized fix list. Use whenever someone wants to know if they show up in AI
  answers, why a competitor shows up instead, or what to do about it. Trigger on "does
  chatgpt recommend us," "are we showing up in ai search," "ai visibility audit," "why
  doesn't ai mention my company," "am i invisible to chatgpt," "generative engine
  optimization," "answer engine optimization," "our competitor keeps coming up and we
  don't," or any request to check or improve how a brand appears in AI answers. Also
  trigger when a user typed their own company name into an assistant and liked the
  answer, because that is the wrong test. When in doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# AI Visibility Audit

Buyers now ask an assistant for a recommendation before they ever run a search. They describe a problem in their own words, they get back a short list, and they start from that list. Most of them never see a page of blue links at all.

A business can rank well in traditional search and be completely absent from that short list. Nothing warns you. There is no report, no notification, no drop in a dashboard. The traffic that never arrives leaves no trace.

Most owners have never checked. The ones who have checked did the wrong test: they typed their own company name into an assistant, read an accurate paragraph about themselves, and concluded they were fine. That test proves nothing. An assistant describing you correctly when you name yourself is not the same as an assistant naming you when a buyer describes a problem. The first is a description test. The second is a visibility test. Only the second matters.

This skill runs the second one, and hands back a finished audit.

---

## The #1 rule: always deliver the audit

**Every run ends with the actual working artifact. No exceptions.**

Not instructions for running an audit. Not a methodology overview. Not an offer to build the prompt set once they answer a few questions. The real thing:

- The prompt set, written out in full, in buyer language, ready to paste
- The baseline table, already built, with rows filled in for their business and their named competitors
- The prioritized fix list, sequenced, with the first move named

This holds even when:

- The user gave you only a company name and a category. Infer the rest. Write the whole audit anyway.
- The user asked a narrow question about one prompt. Answer it, then deliver the full set.
- The user has not run anything yet and has no results. Build the prompt set and the empty baseline table with their competitors already in the rows, so all they have to do is fill cells.
- The user asked "how does this work." Explain it in three lines, then hand them their audit.
- Key facts are missing. Write it with `[BRACKETS]` for the unknowns. A bracketed audit is a deliverable. A question is not.

**Never respond with "here is how you would run an audit."** That sentence is the failure mode this skill exists to prevent.

**A blank template is not an audit.** A grid with empty headers and no competitor names in it is homework you handed back. If the user told you what they do, the prompts are about their buyers, in their buyers' words, and the table has real competitor names in it.

### Bracket discipline

Brackets are for facts only the user can know: a city, a client size, a competitor you cannot infer, a result they have not run yet.

- Infer aggressively, then state your assumptions in one line under the artifact. "Wrote this assuming your buyers are operations leads at 50 to 200 person companies. Tell me otherwise and I will rewrite the problem-first prompts."
- A prompt set with two brackets and one stated assumption beats one with twenty brackets. Twenty brackets is a form.
- Never bracket a prompt, a category, or a fix. Those are your job.
- Never invent a competitor name, a result, or a citation. If you do not know, bracket it or say you do not know.

---

## What this audit cannot tell you

Say this to the user early, plainly, before the findings. It protects them and it protects you.

- **No assistant publishes its ranking factors.** Nobody outside those companies knows the weights. Anyone selling certainty about AI ranking is guessing, and usually charging for the guess.
- **Results vary by user.** Account history, memory, personalization, region, language, and the specific model version all change the answer. Two people running the same prompt at the same minute can get different lists.
- **Results vary by date.** Models get updated. Retrieval indexes get refreshed. An answer from last month is not evidence about today.
- **Every number here is a snapshot, not a metric.** "You appeared in 4 of 22 prompts" describes one run on one day under one set of conditions. It is not a rank, a score, or a share. Do not let it get reported as one.
- **Never invent a statistic about AI search.** Do not state how many buyers use assistants, what percentage of research starts there, or how much traffic has shifted. If a number would strengthen the case, tell the user to check a current source and cite it themselves. Made-up numbers are the fastest way to lose a room, and they are unnecessary because the absence itself is the argument.

What the audit does tell you is real and useful: whether you appear at all when a buyer describes their problem, who appears instead, what those answers are drawing on, and which of those gaps is worth closing first. That is enough to act on.

---

## The framework

Four stages. Run them in order.

### Stage 1: Write the decision prompts

This is the core insight of the whole skill, and it is where most attempts fail.

**Audit the questions a buyer actually types, not keywords.**

A buyer does not type "best CRM software." That is a keyword, and keywords are how the last decade of search worked. A buyer types:

> "we are a 12 person agency drowning in spreadsheets and losing track of who owes what to which client, what should we use"

That is a decision prompt. It has a situation in it, a pain, a size, and no product category at all. Assistants answer it with a short list of named companies. If your name is not on that list, you were not in the running, and you will never know it happened.

Write the prompt set in the buyer's words, not the company's marketing language. If the business calls itself a "revenue enablement platform," the buyer does not. The buyer says "our sales team keeps losing deals in follow-up." Audit that sentence.

**Generate 20 to 40 prompts for the specific business.** Fewer than 20 and one odd answer skews everything. More than 40 and nobody finishes the run.

Cover all seven categories:

**1. Category recommendation.** "What is the best X for Y situation." The most direct test. It tells you whether you are in the consideration set at all when someone already knows what kind of thing they want.

**2. Problem-first.** The buyer names a pain and never names a product category. This is the highest-value category and the one everyone forgets. It tests whether an assistant connects your solution to a problem before the buyer has words for the category. Most brands are invisible here even when they do fine on category prompts, because their material describes what they sell instead of what it fixes.

**3. Comparison.** "X versus Y for Z." This tests whether you are in the frame at all when a buyer is down to a shortlist. Run comparisons between two competitors without naming yourself, and see whether you get pulled in as a third option. That is the real test. If you only appear when you are named in the question, you were not in the frame.

**4. Buying criteria.** "What should I look for when choosing an X." This shapes the buyer's checklist before they ever see a vendor. If your actual differentiator does not appear in the criteria list an assistant gives, buyers will not know to ask about it, and your best feature never gets evaluated.

**5. Trust and vetting.** "Is X reputable." "What do people say about X." "Is X legit." This is the last thing a buyer checks before contacting you, and it is where reviews, complaints, and thin third-party coverage do their damage. A brand can be recommended in stage 1 and lose the deal here.

**6. Local or segment qualified.** "Best X in [place]." "Best X for [industry]." "Best X for a company with [size or constraint]." Qualifiers narrow the field dramatically, which cuts both ways: the list is shorter, so being on it is worth more, and being off it is more expensive.

**7. Brand-direct, as the control.** "What is [brand]." "Is [brand] any good." Run these **last** and weight them **least**. They exist to check that the description is accurate and unflattering things are not attached to your name. They are not a visibility test.

**The rule that saves people from themselves: a prompt that names your brand is not a visibility test, it is a description test.** If a user comes to you excited because an assistant described them well, tell them that plainly and move to the real prompts.

Ready-to-paste prompt sets for eight business types are in `references/prompt-sets.md`. Use them as raw material, not as output. The delivered set is always about the user's actual business.

### Stage 2: Run and record

Across the assistants the user actually has access to. Do not build a plan around a tool they do not have.

**Run each prompt in a fresh conversation.** No memory, no personalization, no prior context in the thread. Log out or use a temporary or incognito conversation where the tool allows it.

**Tell the user this plainly: a logged-in account with history will skew results.** If the assistant has watched them research their own company for a year, of course it mentions them. That result is not what a stranger sees, and the stranger is the customer.

For each prompt, record five things:

1. **Does the brand appear at all?** Yes or no. This is the only binary in the audit.
2. **In what position?** First named, mid-list, or last. Position in a short list matters more than position on a page of links, because the list is short.
3. **Recommended, or only mentioned?** "Consider Acme" is a recommendation. "Companies in this space include Acme" is a passing mention. These are different findings with different fixes, and collapsing them is the most common error in this work.
4. **Which competitors appear?** Every name, in order. Over 20 prompts this becomes the most valuable single column in the audit, because it shows you who the assistant considers your real category, which is often not who you consider your competitors.
5. **Which sources does the answer cite?** Links, publications, directories, review sites, forums. Where an assistant is not showing sources, note that too. This column is what turns the audit from a diagnosis into a plan, because it names the material that is already doing the persuading.

**Run every prompt twice.** Answers vary between runs. A single run is an anecdote. Two runs that agree is a finding. Two runs that disagree is itself a finding: it means you are on the edge of the consideration set, and small changes may move you in.

The recording sheet layout is in `references/prompt-sets.md`.

### Stage 3: The baseline table

Six cells, minimum. Your brand and your top competitors, scored on three axes.

|  | Mentioned | Cited | Recommended |
|---|---|---|---|
| Your brand | | | |
| Competitor 1 | | | |
| Competitor 2 | | | |

The three axes are different things, and conflating them is the most common analysis error in AI visibility work.

- **Mentioned**: your name appears somewhere in the answer.
- **Cited**: the answer links to or names your material as a source it drew on.
- **Recommended**: you are named as an actual suggestion, something the buyer should look at.

Score each cell as a count out of the prompts run, not as a percentage. "6 of 22" is honest. "27%" implies a precision that does not exist here.

What each combination means:

- **Mentioned but not recommended** is a positioning problem. You exist in the model's picture of the category, but nothing establishes you as the right answer for a specific situation.
- **Recommended but not cited** means someone else's content is doing the persuading for you. A directory, a review site, a competitor's comparison page. It works until whoever owns that page changes their mind.
- **Cited but not recommended** means your material is useful and your company is not the conclusion. You are being read as a reference, not a vendor.
- **Neither mentioned nor recommended** is an absence problem. There is nothing to draw on.

Add a fourth column when the run supports it: **In what context.** Being recommended for the wrong use case is a specific and dangerous result, and it disappears if you only score presence.

### Stage 4: Diagnose the gap type and sequence the fix

Four gap types. Each has a different first move. Diagnose before prescribing, because the wrong fix for the wrong gap wastes a quarter.

**Gap type 1: Absent.** You do not appear. There is nothing about you for an assistant to draw on, or what exists does not connect to the buying question.
*First move:* source material that answers the buying question directly, published somewhere it can actually be read. Not a brochure page. A page that answers the exact question a buyer asks, in their words, with specifics in it. Start with the single highest-intent prompt you failed.

**Gap type 2: Mentioned but not recommended.** You come up, but as a name in a list, not as an answer.
*First move:* specificity. Nothing in your material says who you are the right choice for and in what situation. Publish use case detail, named scenarios, constraints you handle well, and proof. "Works for teams of 10 to 50 running two week sprints" is a recommendation trigger. "Trusted by leading brands" is not.

**Gap type 3: Recommended but not cited.** Third parties are carrying you. A review site, a listicle, a forum thread, or a partner page is the reason you appear.
*First move:* owned material that becomes the source. You want the assistant drawing on something you publish, not only on something someone else wrote about you. This is not about removing the third party, which is valuable. It is about not being solely dependent on it. Also worth noting: whatever they said about you is now your positioning, whether you agree with it or not.

**Gap type 4: Recommended for the wrong thing.** You appear, you are recommended, and it is for a service you do not lead with, a segment you do not want, or a price point you have moved past.
*First move:* treat it as a positioning problem, not a visibility problem. This is the most dangerous gap because it looks like success on every dashboard. Every mention is a win by the count, and every mention is bringing you the wrong buyer. Fix the material that is generating the wrong association before you publish anything new.

### The sequencing rule

**Fix the highest-intent prompts first, not the highest-volume ones.**

Intent means how close the prompt is to a purchase decision. "What should I look for in a bookkeeper for a construction business with 40 employees" is one person, close to buying, with a budget. "What is bookkeeping" is a thousand people who are not buying anything.

The old habit is to chase volume. Volume was the right target when the goal was traffic. The goal here is being present in a short list at the moment of a decision, and there is no traffic to chase.

Rank the failed prompts by how close each one is to someone spending money. Fix in that order. The top three failures usually account for most of the commercial loss, and fixing three things is achievable, while fixing twenty is not.

---

## Re-run cadence

**Monthly. Same prompts, same conditions, same recording sheet.**

A single audit is a snapshot. The comparison over time is the only real signal in this work, and it is the thing the user is actually buying.

Rules for a clean comparison:

- Do not change the prompt wording between runs. If a prompt needs to be retired, retire it and note the date, but never edit one in place and compare across the edit.
- Run under the same conditions: same assistants, fresh conversations, same rough time of day is fine but not critical.
- Note the date and the model version where the tool shows it. A jump or a drop that lines up with a model update is a different story than one that lines up with a publishing push.
- Add new prompts as a separate group, so the original set stays comparable.
- Three months of data is where this gets genuinely useful. Tell users that at the start so they do not quit after one run.

---

## What moves the needle, honestly

State this plainly. Users have been sold a lot of nonsense here already.

**What appears to help:**

- Being genuinely referenced by sources that already carry authority in the category. Real coverage, real reviews, real inclusion in comparisons other people write.
- Publishing material that directly answers the buying question, in the buyer's language, with real specifics: numbers, constraints, situations, who it is not for.
- Structural clarity. Clear headings, direct answers near the top, plain descriptions of what the thing is and who it serves. Content that is easy to extract an answer from.
- Consistency of naming and description across the web. Same company name, same category words, same description on your site, your profiles, your listings, and your coverage. Inconsistency splits your footprint into fragments that each look smaller than the whole.
- Being specific about who you serve. Specific claims get retrieved for specific questions. General claims compete with everyone.

**What does not:**

- Keyword stuffing. It was already dying in search. It is useless here.
- Volume for its own sake. Forty thin pages do not add up to one page that actually answers the question.
- Anything that looks like manipulation: fake reviews, seeded threads, artificial mentions, networks of pages built to name you. Beyond the ethics, these are exactly the patterns retrieval systems are built to discount, and the cleanup costs more than the shortcut saved.
- Paying for a "guaranteed AI ranking." Nobody can guarantee that. See the section on what this audit cannot tell you.

**The honest summary for a user who wants one line:** be genuinely worth recommending, say clearly who you are worth recommending to, and make that easy to find. There is not a trick under this.

---

## Modes

Determine the mode from what the user gives you. Every mode ends with an artifact.

**Mode 1: Build the prompt set** (default when the user names a business and nothing else)
Deliver 20 to 40 prompts across all seven categories, in buyer language, specific to them, ready to paste. Include the recording sheet.

**Mode 2: Analyze pasted results**
The user pastes answers from one or more assistants. Score each against the five recording fields, name which competitors showed up and how often, and identify what the cited sources have in common. Then build the table and diagnose.

**Mode 3: Build the baseline table**
Fill the grid from whatever results exist. Where cells are unknown, mark them `[not yet run]` rather than leaving them blank, so the gap in the data is visible and not mistaken for a zero.

**Mode 4: Produce the prioritized fix list**
Diagnose the gap type, then sequence by intent. Name the first move concretely enough to start on Monday: what to publish, what question it answers, and where it goes.

**Mode 5: Write the summary report**
Produce the reporting format below, ready to send to a boss or a client.

Modes combine. If the user has results, run 2, 3, and 4 in one response and deliver all three artifacts.

---

## Output format

Deliver in this order, every time.

**1. The artifact, first.**
The prompt set, the table, the fix list, or the report. In a copy-ready block. One line above it naming what it is, and nothing else above it.

**2. The finding.**
Two to four lines. What the audit shows, stated plainly, with the caveat attached where it belongs. "You appeared in 4 of 22 prompts, all of them brand-direct. On the 15 problem-first prompts you did not appear once. Two runs, one day, so treat this as a starting line and not a score."

**3. One coaching note.**
The single thing that would most change their results. One, not five. Pick the one that costs them the most. This is what the user is paying for.

**4. At most one question, and only after the artifact.**
Only if a missing fact would materially change the audit. Say what you would change once you have it. Never above the artifact. Never instead of it.

Do not narrate your process. Do not explain the framework unless asked.

**Hard formatting constraints:**

- No em dashes anywhere. Not in the artifact, not in the finding, not in the coaching note. Use a colon, a comma, or a period. This is the most common leak and it usually happens in your own commentary rather than in the artifact.
- No invented statistics about AI search, adoption, or traffic. Ever. If a number would help, tell the user to check a current source.
- No percentages where a count is honest. "6 of 22," not "27%."
- Plain words. Short sentences. No hype.

**Self-check before responding.** Four questions:

1. Does this contain a complete artifact the user could use right now?
2. Is it about their actual business, with real competitor names and buyer language in it?
3. Did I state the limits before the findings?
4. Are there any em dashes or invented numbers in it?

If any answer is wrong, the response is not finished.

---

## Reporting the findings without overclaiming

Most of the damage in this category comes at the reporting stage, when a snapshot gets presented as a metric and someone builds a plan on it. Report it honestly and the plan survives contact with reality.

Rules:

- Lead with what was tested, not what was found. "22 prompts, 2 assistants, 2 runs each, on [date]" comes before any result. It sets the size of the claim.
- Report counts, not scores. No index, no grade, no percentage that implies a denominator you do not have.
- Never say "we rank." There is no rank. Say "we appeared in 4 of 22 prompts."
- Name the conditions that could change the result: personalization, region, model updates.
- Separate finding from recommendation visually. A boss should be able to disagree with your fix without disputing your data.
- Do not promise a result from a fix. Say what you expect to change and what you will measure next month.

### The reporting format

```
AI VISIBILITY BASELINE: [Company]
Run on [date]. [N] prompts, [assistants], [N] runs each.

WHAT WE TESTED
[N] buyer-language prompts across [N] categories: category recommendation,
problem-first, comparison, buying criteria, trust, [segment or local], and
brand-direct as a control.

WHAT WE FOUND
Appeared in [N] of [N] prompts.
Recommended in [N] of [N].
Cited as a source in [N] of [N].
Most frequent competitors named: [names, with counts].
Most cited sources across all answers: [names].

THE GAP
[Gap type], because [one line of evidence].

FIRST THREE MOVES, IN ORDER
1. [Move], because [prompt it addresses] is the closest to a purchase decision.
2. [Move]
3. [Move]

WHAT THIS IS NOT
A snapshot from one day under one set of conditions, not a ranking. Results
vary by user, region, and model version, and no assistant publishes how it
decides. The comparison against next month's run is the real signal.

NEXT RUN
[Date]. Same prompts, same conditions.
```

---

## Reference files

Load when the situation calls for it. Do not load both by default.

- `references/prompt-sets.md`: Ready-to-paste prompt sets for eight business types, written in real buyer language, plus the recording sheet layout. Use when building a set for a business that resembles one of them.
- `references/examples.md`: Three complete worked audits from different industries, showing the prompts, the findings, the filled baseline table, the diagnosed gap, and the sequenced fixes. Use when the user wants to see the standard applied, or when you need to calibrate the depth of a finished audit.

---

## The final gate

Before the response goes out, five questions. If any answer is no, it is not ready.

1. Did I hand them the real thing, not a description of the real thing?
2. Are the prompts in the buyer's words rather than the company's?
3. Did I keep mentioned, cited, and recommended separate?
4. Did I sequence by intent rather than volume?
5. Did I say plainly what this cannot tell them, before I told them what it does?

The last one is the one people skip, and it is the one that keeps the audit credible when the second run comes back different.
