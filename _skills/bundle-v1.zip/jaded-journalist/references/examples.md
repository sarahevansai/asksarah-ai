# Before and After

Five full pitches, five industries, scored before and after. Every company, number, person, and publication here is invented for illustration. Use these to calibrate the standard, never as facts.

Outlets are described by type on purpose. "A trade publication covering logistics" is how the fit assessment should always be phrased.

---

## 1. Logistics software

**Target:** a trade publication covering freight and supply chain operations. Reporter covers carrier economics.

### Before: 29/70

```
Subject: Introducing Northbay Freight Cloud, the future of logistics

Hi there,

I hope this email finds you well! Northbay is a leading provider of
innovative supply chain solutions, on a mission to transform how the
logistics industry operates.

We are excited to announce the launch of Northbay Freight Cloud, our
game-changing platform that seamlessly connects carriers, brokers and
shippers in one place. Our CEO is available for an interview to discuss
how AI is disrupting the logistics industry.

I have attached our press kit and product one-pager.

Let me know if you would like to learn more!
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 2 | A product exists. Nothing changed for anyone outside the company. |
| Source Credibility | 3 | Unnamed CEO, no stated expertise, no availability. |
| Data Exclusivity | 1 | No number anywhere. |
| First Sentence | 1 | Opens with a pleasantry, then the company name and its mission. |
| Audience Fit | 6 | Right publication type. Nothing written for its readers. |
| Story Feasibility | 4 | An interview and a press kit. Not enough for anything. |
| Competition Check | 3 | "AI is disrupting logistics" ran everywhere last quarter. |

Banned language: leading provider of, innovative, game-changing, seamlessly, disrupting the industry, we are excited to announce. Deductions applied above.

Attachments on a cold email. Exclamation point. No news.

### After: 58/70

```
Subject: Carrier rates rose 11% after the emissions rule

Hi [Reporter],

Mid-size carriers raised freight rates an average of 11% in the three
weeks after the new emissions rule took effect on [date], with the
steepest increases on lanes under 400 miles. That comes from pricing
across 41,000 shipments moved on our network between [start] and [end].

The pattern is the opposite of what most brokers expected. Short-haul
lanes were supposed to absorb the cost. They did not, and smaller
carriers are the ones passing it through fastest.

What I can offer:

- The full data set with methodology, broken out by lane length and
  carrier size
- [Name], our head of carrier operations, who built the pricing model.
  Available Tuesday or Wednesday for 30 minutes
- [Confirm whether one of the carriers in the data will talk on record.
  A named carrier makes this a much stronger story.]

Worth 20 minutes this week?

[Signature]
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 9 | Dated regulatory event, story is a direct consequence. |
| Source Credibility | 8 | Named operator who built the model, window stated. |
| Data Exclusivity | 9 | Original network data with method offered. |
| First Sentence | 9 | Subject is a headline. First sentence is publishable. |
| Audience Fit | 9 | Carrier economics, written for that readership. |
| Story Feasibility | 8 | Data plus a source plus a window. One gap bracketed. |
| Competition Check | 6 | The rule is being covered. This angle contradicts the expected take. |

**Critical fix:** confirm the carrier source before sending. A named carrier moves this from a data story to a reported story.

---

## 2. Community healthcare

**Target:** a regional business daily. Reporter covers healthcare and employers.

### Before: 24/70

```
Subject: Meadowline Health celebrates 25 years of caring

Hello,

Meadowline Health is celebrating our 25th anniversary this month. Since
1999 we have been dedicated to providing compassionate, patient-centered
care to families across the region.

To mark the occasion we are hosting a community event and would love
coverage. Our founder is a thought leader in community health and can
speak to how healthcare has changed over 25 years.

Thanks so much!
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 1 | A company anniversary. Nobody outside the company marks it. |
| Source Credibility | 4 | Founder is relevant, but "thought leader" is not a credential. |
| Data Exclusivity | 1 | No numbers. |
| First Sentence | 2 | Company name first, then a celebration. |
| Audience Fit | 5 | Right publication, but nothing here for a business reader. |
| Story Feasibility | 7 | An event and an available founder is workable if there were a story. |
| Competition Check | 4 | Anniversary pitches arrive constantly and almost never run. |

There is no story here. The rewrite has to find one, and the only honest place to look is what the organization actually knows that nobody else does.

### After: 51/70

```
Subject: Employer clinic visits shifted 40% to evenings since 2022

Hi [Reporter],

Since 2022, the share of visits at our five clinics happening after 5pm
has gone from [X]% to [Y]%, and the largest jump came from patients
insured through employers rather than individual plans. Shift workers
are not the ones driving it. Salaried office employees are.

That has a cost side for employers in the region: [bracket the concrete
consequence you can actually evidence, for example appointment
no-show rates, or the number of local employers who have asked about
extended-hours coverage]. Do not include this line unless you have the
number.

What I can offer:

- Visit-time data across five clinics from 2019 to now, with the
  methodology
- [Name], our chief medical officer, who can talk about what changed in
  scheduling and what it cost to staff it. Available [window]
- [Confirm whether an employer client will speak on record about why
  they asked for evening coverage]

Happy to send the data ahead of a call.

[Signature]
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 6 | Not a dated event, but a measurable shift with a start date. |
| Source Credibility | 8 | Named CMO with direct operational standing and a window. |
| Data Exclusivity | 9 | Multi-year internal visit data nobody else has. |
| First Sentence | 8 | Subject carries a number and a change. First sentence is the news. |
| Audience Fit | 8 | Employer angle is exactly what a regional business desk runs. |
| Story Feasibility | 7 | Data and a source. Employer voice still unconfirmed. |
| Competition Check | 5 | Healthcare access is covered often. This local data is not. |

**Critical fix:** the anniversary is not the story and should not appear anywhere in this email. If the founder wants it mentioned, it goes in the boilerplate at the bottom, not in the pitch.

**Outlet fit:** right publication. If the evening-hours data turns out to be thin, this is a trade publication story for a healthcare operations title instead, not a business daily story.

---

## 3. Consumer packaged food

**Target:** a national consumer news desk. Reporter covers food and retail.

### Before: 31/70

```
Subject: New product launch: Harvest Table launches oat crackers

Hi,

Harvest Table, an innovative better-for-you snack brand, is launching a
new line of oat crackers in three flavors. We are excited to announce
they will be available nationwide starting next month.

According to a leading market research firm, the healthy snacking
category is projected to reach $XX billion by 2030. Our founder is
available to discuss how we are disrupting the snack aisle.

Samples available on request!
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 3 | A product launch is a peg only if it changes something. |
| Source Credibility | 4 | Founder is a spokesperson, no stated standing. |
| Data Exclusivity | 2 | A market projection every pitch in the category quotes. |
| First Sentence | 3 | Company name first, then a category claim. |
| Audience Fit | 6 | Consumer food desk is plausible, but this is a trade story. |
| Story Feasibility | 8 | Samples and a founder. Easy to report. |
| Competition Check | 5 | Snack launches are covered constantly and rarely alone. |

### After: 49/70

```
Subject: Oat prices doubled. Small snack brands are reformulating.

Hi [Reporter],

Oat costs on our contracts rose [X]% between [month] and [month], which
is why our new cracker line uses a blend rather than pure oat flour. Two
other independent brands we buy alongside made the same call this
quarter [only include this if you can name them or verify it].

The consumer-visible part: the ingredient list on shelf changed, and
the price did not. Small brands are absorbing the cost rather than
raising shelf prices into a slow category, and that is not sustainable
past [bracket your own estimate with the reasoning you can defend].

What I can offer:

- Our actual contract cost movement over 24 months, with the caveat
  that it is one buyer's view, not the market
- [Name], our founder, who does the sourcing personally, on why the
  reformulation happened and what gets cut next. Available [window]
- Samples, plus before and after ingredient panels

The launch itself is the smaller half of this. The sourcing story is
the one I would read.

[Signature]
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 7 | Commodity cost movement with dates, visible on shelf now. |
| Source Credibility | 7 | Founder has genuine standing because she does the sourcing. |
| Data Exclusivity | 8 | One buyer's real contract data, honestly caveated. |
| First Sentence | 8 | Subject is a story. First sentence carries the cause. |
| Audience Fit | 7 | Consumer desk will take a price story. Would also fit a grocery trade title. |
| Story Feasibility | 8 | Data, a source, samples, panels. |
| Competition Check | 4 | Food inflation is heavily covered. The small-brand angle is less so. |

**Critical fix:** verify the two other brands before naming them, or cut that sentence entirely. An unverified claim about competitors is the fastest way to lose this reporter permanently.

---

## 4. Construction and trades

**Target:** the pitch went to a national technology publication. It should not have.

### Before: 22/70

```
Subject: Rowan Builders is revolutionizing construction with AI

Hi there,

Rowan Builders, a family-owned general contractor, is proud to announce
we are now using AI-powered scheduling software on all our projects. In
today's fast-paced world, technology is transforming construction.

Our CEO would be happy to discuss how AI is the future of the trades.

Attached please find our company brochure.
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 2 | A contractor bought software. Not an event. |
| Source Credibility | 4 | CEO available, but on a topic where he has no standing. |
| Data Exclusivity | 1 | Nothing. |
| First Sentence | 1 | Company name, then "revolutionizing," then a cliche. |
| Audience Fit | 1 | A national tech desk does not cover one contractor's tooling. |
| Story Feasibility | 6 | An interview exists. There is nothing to report. |
| Competition Check | 7 | Nobody has written this because it is not a story. |

**Outlet fit, stated plainly:** wrong publication. A national technology desk covers the companies that build the software, not the companies that buy it. This belongs in a trade publication covering construction and contracting, or a regional business daily if the local employment or cost angle is real. As written it belongs nowhere.

### After: 47/70, retargeted to a trade publication covering construction

```
Subject: Scheduling software cut our rework hours by [X]%

Hi [Reporter],

We put scheduling software on [N] projects last year and rework hours
dropped [X]% against the [N] projects we ran the old way. The savings
did not come from the schedule. They came from subcontractors seeing
changes the same day instead of at the Monday meeting.

The part worth writing about is what it cost to get there: [bracket the
real onboarding cost and how many weeks of resistance from crews, with
your own numbers. This is the detail other contractors will not
publish and it is the reason this is a story.]

What I can offer:

- Project-level before and after numbers across [N] jobs, with the
  method and the honest caveats about what else changed
- [Name], our project executive, who ran both the old way and the new
  way. Available [window]
- [Confirm whether a subcontractor foreman will talk. A trade reader
  believes the foreman over the executive.]

Happy to send the numbers first so you can decide if it holds up.

[Signature]
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 5 | No dated event, but a completed year of comparison data. |
| Source Credibility | 7 | Project executive with direct operational standing. |
| Data Exclusivity | 8 | Project-level rework data that contractors do not publish. |
| First Sentence | 8 | Subject is a result. First sentence carries the mechanism. |
| Audience Fit | 8 | Trade readers want operational detail from a peer. |
| Story Feasibility | 7 | Data plus a source. Foreman unconfirmed. |
| Competition Check | 4 | Construction tech adoption gets covered. The cost-of-adoption detail less so. |

**Critical fix:** the honest cost of adoption is the story. If the user will not publish that number, this drops back to a vendor case study and no trade desk runs it.

---

## 5. Financial services

**Target:** a vertical newsletter read by credit union and community bank operators.

### Before: 36/70

```
Subject: Riverbend Credit Union announces new mobile app

Hi [Reporter],

Riverbend Credit Union is excited to announce the launch of our
redesigned mobile app, featuring a best-in-class user experience for
our 80,000 members.

Digital banking adoption continues to grow across the industry. Our
Chief Digital Officer is a thought leader in financial technology and
is available to discuss the future of digital banking.

Please let me know if you are interested.
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 3 | An app launch. Common, and not an event for readers. |
| Source Credibility | 5 | Named role with genuine relevance, undermined by "thought leader," no window. |
| Data Exclusivity | 4 | 80,000 members is a real number but it is not the story. |
| First Sentence | 3 | Company name, then excitement, then a product. |
| Audience Fit | 8 | Exactly the right readership for a peer institution's digital work. |
| Story Feasibility | 7 | An executive and a shipped product. Reportable. |
| Competition Check | 6 | App launches are common. Results from one are not. |

### After: 57/70

```
Subject: Support calls fell 34% after we cut app features

Hi [Reporter],

Member support calls dropped 34% in the 90 days after we shipped the
new app, and the change that did it was removing [N] features rather
than adding any. We cut the ones under [X]% monthly use, including
[two you are willing to name].

That is the opposite of how most of our peers are approaching digital
right now, and it was not an easy internal sell.

What I can offer:

- Call volume and app usage data across 80,000 members, before and
  after, with the caveat that [name any confounding change in the same
  window. If there was one, say it. A reporter will find it anyway.]
- [Name], our chief digital officer, who can walk through which
  features got cut and the two that came back. Available [window]
- The internal decision framework we used, which other institutions
  could copy

Full numbers available before a call if that is easier.

[Signature]
```

| Criterion | Score | Why |
|---|---|---|
| News Peg | 6 | Not a dated external event, but a completed 90 day result. |
| Source Credibility | 8 | Right executive, direct ownership, window stated. |
| Data Exclusivity | 9 | Member-level before and after data with confounders disclosed. |
| First Sentence | 9 | Subject is counterintuitive and specific. First sentence delivers it. |
| Audience Fit | 9 | Peer operators will read this to the end. |
| Story Feasibility | 8 | Data, source, and a framework. |
| Competition Check | 8 | The subtraction angle runs against the category consensus. |

**Critical fix:** name the confounding change in the same window before a reporter finds it. Disclosing it costs one sentence. Being caught omitting it costs the relationship.

---

## What these five have in common

Every rewrite did the same four things:

1. **Moved the number to the front.** In all five, the strongest asset was already in the sender's possession and buried, or missing because nobody asked for it.
2. **Cut the company from the first sentence.** Not one of the after versions leads with the organization.
3. **Made the offer concrete.** A named person, a window, a data set with a method, and one honest caveat.
4. **Told the truth about the weak part.** Every after version has a bracket or a disclosure that makes the pitch slightly less shiny and considerably more credible.

The average lift across these five is 25 points, and none of it came from better adjectives.
