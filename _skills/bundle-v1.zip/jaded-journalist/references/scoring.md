# The Scoring Rubric

The full anchored rubric for all seven criteria. Use this when a score is close to a band boundary, when the user disputes a score, or when you need to explain why a criterion landed where it did.

Two people using this rubric on the same pitch should land within a few points of each other. If they would not, the rubric is being used loosely.

---

## How to score

1. Read the pitch once at editor speed. Subject line, first sentence, stop. Note whether you would have kept going. That instinct is the First Sentence Survival score before you rationalize it.
2. Read it properly. Score all seven criteria against the anchors below.
3. Apply banned-language deductions: 2 points off the most relevant criterion per phrase, floor of 1.
4. Total. Do not adjust the total to feel right. If the parts say 31, the total is 31.

**Score the pitch, not the potential.** A great story buried under a bad pitch scores low. The rewrite is where the story gets rescued.

**Use the whole range.** A pitch that lands 5 or 6 on every criterion is almost always a scorer avoiding a decision. Most real pitches have two or three things badly wrong and one thing genuinely working.

---

## Band meanings

| Band | Editor behavior |
|---|---|
| 9-10 | Forwards it, or replies the same day |
| 7-8 | Keeps reading, replies this week |
| 5-6 | Would survive only a slow week |
| 3-4 | Stops reading here |
| 1-2 | Deletes, and remembers the sender for the wrong reason |

Totals:

| Total | Meaning |
|---|---|
| 60-70 | A reporter replies. Send it. |
| 48-59 | Credible. Likely a reply from the right reporter on the right week. |
| 35-47 | Real story, badly packaged. Fixable in one revision. |
| 22-34 | Thin story or wrong target. Needs a new angle, not a new draft. |
| 7-21 | No story. Stop and go find one. |

---

## 1. News Peg

Is there a dated reason this is a story now?

**10.** A specific event inside a two week window on either side of the send date, and the story is a direct consequence. "The rule that takes effect on the first of next month changes how mid-size carriers price freight, and here is what three of them are doing about it."

**8.** A dated event slightly further out, or a strong seasonal or cyclical hook that the outlet reliably covers. Enrollment season, tax deadline, back to school, quarterly earnings.

**6.** A real event, but the connection to the story takes a sentence of explanation. The reporter can see it, but has to be walked there.

**4.** A trend with a plausible recent driver, but no dated event. "Adoption has picked up over the last year."

**3.** A general industry direction. "The sector is changing." "Companies are increasingly focused on."

**1.** The peg is internal to the company: an anniversary, a rebrand, a hire, a new website, a milestone only the company counts.

**Edge cases.** A funding round is a peg for business and sector desks and almost nothing else. A new product is a peg only if it changes what someone can do, not that it exists. A survey the company ran is a peg only if the survey is the news and the method holds.

---

## 2. Source Credibility

Is there a named, quotable human with standing, available fast?

**10.** Named person, title, credential a reader would recognize, availability window stated, and a specific thing only they can say. "Our head of clinical operations, who ran the pilot across eleven sites, can walk through what failed in the first six months. Available Tuesday or Wednesday."

**8.** Named person with real relevant standing and stated availability, but the unique angle is not spelled out.

**6.** Named executive at the company, relevant to the topic, no availability window. Usable but the reporter has to chase.

**4.** "Our CEO is available." No stated relevance beyond running the company.

**3.** An unnamed "spokesperson" or "our team." Nobody to quote.

**1.** The offered source cannot speak to the central claim, will only speak on background, or requires copy approval.

**Edge cases.** A customer willing to talk on the record is often worth more than the founder, and is scored as a source. An outside expert with no relationship to the company is the strongest possible offer if they are genuinely willing.

---

## 3. Data Exclusivity

Is there a number here the reporter could not get themselves?

**10.** Original data, method stated in the same breath, bearing on a live question. "Across 41,000 shipments on our network last quarter, delivery windows missed by more than a day rose from 4% to 11%. Full data set and methodology available."

**8.** Original data, method available on request rather than stated, or original data on a slightly narrow question.

**6.** A partial original number: real internal data, but framed so vaguely that the reporter cannot tell what it measures. Fixable with one sentence.

**4.** A number from the company's own marketing materials with no method and no way to check it.

**3.** A statistic quoted from a public report. The reporter can cite the source directly.

**2.** A market-size projection from a research firm, which every pitch in the category also quotes.

**1.** A number presented as research that is actually a customer survey, with no sample size, no dates, and no disclosure. This is worse than no number, because it costs the whole pitch its credibility.

**Edge cases.** Anonymized aggregate platform data is usually the strongest asset a company has and the most consistently underused. If the user has it and buried it, say so in the critical fix.

---

## 4. First Sentence Survival

Subject line and first sentence together. Would a reader looking for an exit keep going?

**10.** Subject line under nine words with a concrete noun or number, no company name. First sentence delivers the news and the stakes and could sit under a headline with light editing. Subject: "Freight rates jumped 11% after the new rule." First sentence: "Mid-size carriers raised rates an average of 11% in the three weeks after the emissions rule took effect, according to pricing data across 41,000 shipments."

**8.** Subject line is specific and story-led. First sentence delivers the news but needs a trim or leans on one piece of jargon.

**6.** Subject line is generic but not damaging. First sentence gets to the news by the second clause.

**4.** Subject line names a category rather than a story. First sentence sets up context before delivering anything.

**3.** First sentence is about the company: what it does, what it believes, what it is excited about. Any first sentence beginning with the company name caps this criterion at 2.

**1.** The pitch opens with pleasantries, flattery about the reporter's recent work with no article named, or "I wanted to reach out."

**Edge cases.** A subject line that is a question almost always underperforms a subject line that is a statement. A subject line with a colon stacking two ideas usually means neither is strong enough alone.

---

## 5. Audience Fit

Do these readers care, and does this publication run this kind of story?

**10.** Named outlet, named reporter, story sits inside a category the outlet demonstrably publishes, angle written for that readership. The pitch references something the outlet has actually run and says what is different here.

**8.** Right outlet, right beat, but the angle is written generically enough that it could have gone to three publications.

**6.** Plausible outlet, but the pitch shows no evidence of knowing what this publication covers.

**4.** Visibly templated. No named reporter, no reference to the outlet. Sent to a list.

**2.** Wrong section of the right publication. A supply chain story sent to the consumer tech desk of an outlet that has a business desk.

**1.** Wrong publication entirely. The readership has no reason to care.

**Cap:** if no target outlet has been named by the user, this criterion cannot score above 5. Say the target is missing rather than guessing.

---

## 6. Story Feasibility

Can a reporter finish this piece with what is offered, in the time they have?

**10.** Offer matches ask. Named interview subject with a window, data with method, a customer or third party who will talk, images or documents if the format needs them, no approval gauntlet.

**8.** Strong offer with one gap the reporter can work around.

**6.** The offer supports a short piece but the pitch is asking for a long one. Feasible if the ask shrinks.

**4.** Large ask, thin offer. "Exclusive feature opportunity" with one call behind it.

**3.** Vague on everything. "Happy to provide more information."

**1.** Structurally impossible. The central claim can only be discussed off the record, the source needs copy approval, or the material requires an NDA.

**Edge cases.** Internal approval time counts. A pitch to a daily news desk where quotes take three weeks to clear is not feasible, however good the story. Say so.

---

## 7. Competition Check

Has this angle run already, repeatedly, in the last ninety days?

**10.** Genuinely fresh, or a familiar topic from a vantage point nobody has used. The pitch names the existing coverage and says explicitly what is new here.

**8.** Fresh angle, but the pitch does not acknowledge the surrounding coverage, so the reporter has to check.

**6.** Adjacent to heavily covered territory, with one element that has not been done.

**4.** A better-written version of a story that has run several times this quarter.

**3.** Saturated. The topic is one every company in the category is pitching.

**1.** The outlet has already published a near-identical piece. The pitch is dead before it is read, and it signals the sender did not check.

**Edge cases.** You cannot verify current coverage. Score on how saturated the category is on its face, and say in the critical fix that the sender should search the outlet's own site for the last ninety days before sending. Do not claim a specific article exists.

---

## Banned language deductions

Two points off the most relevant criterion, floor of 1, named explicitly in the scorecard line.

| Phrase | Usually hits |
|---|---|
| thought leader | Source Credibility |
| game-changing, revolutionary, unprecedented | Data Exclusivity |
| innovative solution, cutting-edge, best-in-class | News Peg |
| disrupting the industry | Competition Check |
| in today's fast-paced world | First Sentence |
| we are excited to announce | First Sentence |
| leading provider of | First Sentence |
| seamlessly, robust, synergy | Data Exclusivity |
| any first sentence starting with the company name | First Sentence, capped at 2 |

---

## Scoring edge cases

**No target outlet named.** Audience Fit caps at 5. Say the target is missing.

**Not a pitch, just source material.** Say so in one line, then write the pitch from it. Do not score raw material as if it were a pitch.

**A genuinely strong pitch.** Score it high. A 62 is a real score and a user who earns it should be told. Inflation is a failure, but so is refusing to acknowledge good work. The critical fix on a strong pitch is the smallest remaining improvement, honestly labeled as small.

**A pitch with no story at all.** Score it honestly, which will be low, and put the truth in the critical fix. Then write the best honest version anyway, so the user can see the distance between what they have and what would work.

**A revision.** Score fresh, never relative to the old score. Then state the delta. A pitch that started at 34 and reaches 58 after two disciplined passes is a normal outcome. A pitch that reaches 68 usually means new facts arrived, not better writing.
