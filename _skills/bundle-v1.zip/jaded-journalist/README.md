# The Jaded Journalist

A Claude skill that reads your media pitch the way a real editor reads it, scores it out of 70, and hands you back the rewritten pitch, ready to send.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

An editor decides in about three seconds. Subject line, first sentence, delete. This skill puts that editor in the room before you hit send.

Paste in a pitch, and Claude will:

1. Hand you the rewritten pitch, complete and copy-ready
2. Score the original against seven criteria out of 70, with a line on each
3. Tell you honestly whether you are pitching the right kind of publication
4. Give you THE single most critical fix, one thing, specific enough to do today

**You always get a pitch back.** Ask for a score and you get the score plus the rewrite. Ask about your subject line and you get three options plus the whole email built around the best one. A score with no rewrite is homework, and you came here to avoid homework.

## The persona

It runs as a senior editor with fifteen years across national and trade newsrooms, who gets two to four hundred pitches a week and is looking for a reason to stop reading. It has been burned by broken embargoes, inflated statistics, and executives who turned out not to be available. It is blunt and unimpressed. It is never abusive, and it never withholds the fix.

## The seven criteria

Each scored 1 to 10, out of 70 total, with anchored definitions so the same pitch scores the same way twice:

1. **News Peg**: is there a dated reason this is a story this week
2. **Source Credibility**: a named human with standing, quotable inside 48 hours
3. **Data Exclusivity**: a number the reporter could not find themselves
4. **First Sentence Survival**: subject line and opening line, together
5. **Audience Fit**: do these readers care, and does this publication run this
6. **Story Feasibility**: can a reporter actually finish this piece
7. **Competition Check**: has this angle run everywhere already

Plus the instant-kill list: a subject line that describes the company instead of the story, a first paragraph about the mission, attachments on a cold email, "hope you are well," a pitch with no news in it, the wrong beat, and following up more than twice.

## What it will not do

It will never invent a statistic, a customer count, a funding figure, or an executive quote to make your pitch stronger. It will never claim an exclusive or an embargo you have not actually offered. Anything it does not know comes back in `[BRACKETS]` that name the exact fact to go get and where to find it.

That is deliberate. A pitch that gets picked up on a false claim is a burned relationship with that reporter, permanently, and reporters talk to each other.

It also will not rank publications into tiers or hand you an outlet list. It assesses fit on what a publication covers, who reads it, and whether the story sits inside a beat. When a pitch is aimed at the wrong place, it says so and names the type of outlet that actually fits.

## Try it

Once installed, say any of these:

- "Score this pitch" and paste it in
- "Would a reporter open this?"
- "Is this subject line good?"
- "Am I pitching the right outlet?"
- "Nobody responded to this. What went wrong?"
- "Write my follow-up"
- "Be a jaded editor and tear this apart"

## Modes

| You ask for | You get |
|---|---|
| A score | The rewrite, the score out of 70, the critical fix |
| A subject line | Three options, then the full pitch with the best one on it |
| Outlet fit | An honest read, plus the pitch rewritten for the right outlet |
| A follow-up | The follow-up written, under 60 words, with the rules on timing |
| A diagnosis of silence | The most likely cause with the evidence, plus what to send instead |
| A revision | A fresh score, the delta from last time, and what moved it |

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `jaded-journalist.zip` in your skills settings. Claude loads it automatically whenever a pitch shows up.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/jaded-journalist/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste any pitch, and say "score this." You should get a rewritten pitch first, then a score out of 70 with seven line items, then one critical fix.

## What is in the package

```
jaded-journalist/
├── SKILL.md                The persona, the seven criteria, the rules, the output format
├── README.md               This file
├── LICENSE
└── references/
    ├── scoring.md          The full rubric with anchored examples at every band
    └── examples.md         5 full before-and-after pitches across 5 industries
```

## Notes

The score is not the product. The rewrite is. The score exists so you can see which of the seven things was actually broken, and so the second draft is better without help.

It uses the whole range. A pitch with no story in it will score in the twenties and be told so plainly. A genuinely strong pitch will be told that too. Nothing is softened to be kind.

It asks at most one question, and only after the rewritten pitch is already in front of you.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
