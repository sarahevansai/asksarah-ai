# Editorial QA

A Claude skill that runs any written deliverable through a five-pass editorial review and hands back a PASS or HOLD verdict with the corrected document attached.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

This is the last check before something publishes. Not a writing coach, not a voice pass. The final gate: is it correct, is it consistent, is it safe to publish, is it sourced and linked properly.

Paste in a draft and Claude will:

1. Give you a one-word verdict, PASS or HOLD, with the blocking items named first
2. Hand back the corrected document with every fix applied and marked
3. Flag separately the items only you can resolve, each with what would clear it
4. Give you one coaching note that generalizes to your next document

**You always get the corrected document back.** A QA report with no corrected draft attached leaves you doing the work twice: once reading the findings, once applying them. Claude already did the reading.

It works on blog posts, articles, press releases, newsletters, landing pages, white papers, case studies, reports, patient and product information pages, policy memos, internal documentation, and proposals.

## PASS or HOLD

Every run opens with one word. **HOLD means do not publish.** Not "consider revising." One item from this list makes the whole document a HOLD:

1. An unsourced factual claim
2. A legal or regulatory exposure
3. A broken or wrong link
4. An unverified statistic
5. An unapproved quote
6. A claim the publisher cannot substantiate

A single unverified statistic in an otherwise excellent 3,000 word article is a HOLD, because the correction notice will be about that statistic and nothing else. The verdict does not get softened, averaged out, or buried under the things that went well.

## The five passes

**1. Accuracy.** Every factual claim traced to a source. Every number checked against what the source actually reports, including the arithmetic, the units, the dates, and the difference between a percentage change and a percentage point change.

**2. Sourcing.** Not whether a source is cited but whether the citation holds: is it real, is it primary where it matters, is it current, and does the sentence say what the source says. The last one is the most common failure and the hardest to catch.

**3. Consistency.** Names, titles, capitalization, numbers, dates, terminology, and formatting used the same way from the first line to the last.

**4. Safety.** Claims that need substantiation, comparative claims, superlatives and absolutes, guarantee language, regulated categories including health, finance and legal, permissions for quotes and images, privacy, and whether the document places its subject next to something the subject would not want to sit next to.

**5. Mechanics.** Links that work and go where the text says, a real heading hierarchy, spelling and grammar including the places spellcheck skips, and length measured against the stated target.

## Two things it handles that a proofreading pass does not

**Quotes get their own hard rules.** Never invent a quote. Never alter a provided quote, including its punctuation, including when the grammar is wrong. Confirm attribution and approval before publication. Any quote failing any of the three is a HOLD.

**AP style, the practical parts.** The conventions people actually get wrong: numbers, dates and times, titles, state and place names, percentages, attribution with "said," serial commas, and quotation punctuation. Your house style overrides all of it, and if you provide a style guide Claude runs the whole pass against yours instead.

## Modes

- **Full QA pass**, all five passes. The default.
- **Accuracy and sourcing only**, when the document is already copyedited and the question is whether it is true
- **Style and consistency only**, when accuracy is confirmed and the question is whether it reads as one document
- **Fast pre-publish check**, ten minutes before it goes live, covering only what causes corrections and takedowns
- **QA against your house style guide**, where your rules override every default

## Try it

Once installed, say any of these:

- "Run QA on this" and paste your draft
- "Is this ready to publish?"
- "Fact check this article"
- "Check this before it goes out"
- "Proof this against our style guide" and attach the guide
- "Fast pre-publish check, we ship in an hour"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `editorial-qa.zip` in your skills settings. Claude loads it automatically whenever a document needs a review.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/editorial-qa/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste any draft, and say "run QA on this." You should get a PASS or HOLD verdict, the corrected document, author flags, and one coaching note.

## What is in the package

```
editorial-qa/
├── SKILL.md                 The five passes, the verdict rules, and the output format
├── README.md                This file
├── LICENSE
└── references/
    ├── checklist.md         The full five-pass checklist, runnable by hand, plus the AP style reference
    └── examples.md          3 full QA runs across healthcare, financial services, and internal comms
```

## Notes

Claude will never invent a source, a statistic, a quote, a link, or a date to fill a gap. Anything it cannot verify comes back bracketed and flagged. A fabricated citation is worse than a missing one, because a missing one gets caught and a fabricated one gets published.

It will also never quietly rewrite a factual claim into something that sounds right. Spelling, style, and formatting get fixed silently. Facts get flagged and left for you.

If the problem is that the draft reads machine-written rather than incorrect, that is a different job. Claude will say so in one line and point you to **AI Slop Detector**, which finds the tells and rewrites the copy.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
