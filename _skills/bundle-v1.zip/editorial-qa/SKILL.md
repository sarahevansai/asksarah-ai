---
name: editorial-qa
description: >
  The last check before something publishes. Runs any written deliverable through a
  fixed five-pass review covering accuracy, sourcing, consistency, publishing safety,
  and mechanics, then returns a PASS or HOLD verdict with the corrected document
  attached. Use on blog posts, articles, press releases, newsletters, landing pages,
  reports, proposals, and anything else about to go in front of readers. Trigger on
  "proof this," "is this ready to publish," "editorial review," "fact check this
  article," "run qa on this," "proofread this," "check my sources," "final read," "does
  this need legal," "check the links," or any document handed over for a last look. Also
  trigger unprompted when a draft carries an unsourced statistic, an unverifiable link,
  a name spelled two ways, or a regulated claim about health, money, or law. When in
  doubt, run it.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Editorial QA

Every published mistake was preventable. The wrong number, the source that says the opposite of what the sentence claims, the executive's title from two jobs ago, the link that 404s, the guarantee nobody in legal approved. None of it is hard to catch. It just requires someone to actually look before the thing ships.

That is this skill. It is not a writing coach and not a voice pass. It is the final gate: is this correct, is it consistent, is it safe to publish, is it sourced and linked properly. Everything else already happened upstream.

---

## The #1 rule: always deliver the corrected document

**Every run ends with the full corrected document. No exceptions.**

Not a list of problems. Not a table of findings. Not an offer to fix it if the user says the word.

A QA report with no corrected draft attached leaves the author doing the work twice: once reading your findings, once applying them. You already did the reading. Apply them.

Inside the corrected document, mark what you changed. Below it, flag separately the items only the author can resolve, because you cannot verify them from the text alone.

This holds even when:

- The user only asked "is this ready to publish." Answer in one line, then hand over the corrected version anyway.
- The user only asked for a verdict. Give the verdict, then the corrected document under it.
- The document is long. Correct all of it. Do not fix the first three sections and describe what you would do to the rest.
- The user asked about one paragraph. Fix the paragraph, then deliver the whole document with the fix in place.
- The document is clean. Say so, then deliver it with the small mechanical fixes applied.
- The verdict is HOLD. Especially then. Correct everything you can, and let the HOLD items stand clearly marked so the author knows exactly what is blocking.

**Never respond with findings only.** A numbered list of what is wrong, followed by "want me to fix it?", is the most common way this skill fails.

**What you may fix silently in the document:** spelling, grammar, punctuation, style inconsistencies, capitalization, number and date formatting, heading hierarchy, terminology used two ways, formatting drift.

**What you may never fix silently:** anything factual. A wrong number, a misrepresented source, a broken link, a claim that needs substantiation. Those get flagged, never quietly rewritten into something that looks right. Rewriting an unverified fact into a confident-sounding one is the worst outcome this skill can produce.

---

## The hard rule on facts, sources, and quotes

**This skill never invents anything.** Not a statistic, not a source, not a study, not a URL, not a date, not a credential, not a quote.

When a claim needs a source and you do not have one, the answer is `[SOURCE NEEDED: ...]` naming what is required. Never a plausible-looking citation. A fabricated citation is worse than a missing one, because a missing one gets caught and a fabricated one gets published.

Same rule on numbers. If a statistic cannot be traced, it gets bracketed and flagged, not smoothed over.

---

## The verdict: PASS or HOLD

Every run opens with one word.

**PASS** means this can publish as corrected. Everything factual traces to something. Nothing exposes the publisher. The mechanics are clean.

**HOLD** means do not publish. Not "consider revising." Not "you may want to look at this." Do not publish, and here is the specific thing blocking it.

A single item from this list makes the whole document a HOLD:

1. **An unsourced factual claim.** A statement of fact presented as true with nothing behind it.
2. **A legal or regulatory exposure.** Anything that could draw a regulator, a plaintiff, or a demand letter.
3. **A broken or wrong link.** A link that fails, redirects somewhere unexpected, or points to something other than what the text says it points to.
4. **An unverified statistic.** A number with no traceable origin, or one the cited source does not actually contain.
5. **An unapproved quote.** Any quotation not confirmed as accurate and cleared by the person or organization it is attributed to.
6. **A claim the publisher cannot substantiate.** If asked to prove it tomorrow, they could not.

Do not soften a HOLD. Do not bury it under the things that went well. Do not average it out against a document that is otherwise excellent. One unverified statistic in an otherwise perfect 3,000 word article is a HOLD, because the correction notice will be about that statistic and nothing else.

When you issue a HOLD, name the count in the same line: `HOLD: 2 blocking items.` Then list them first, before anything else.

If the only blocking issue is something you cannot check from the text, such as whether a quote was approved, say so plainly: the verdict is HOLD until the author confirms. Unverifiable is not the same as fine.

---

## The five passes

Run all five, in order, every time. Full expanded checklist in `references/checklist.md`.

### Pass 1: Accuracy

Every factual claim traced. Every number checked.

- Read for claims, not for flow. A claim is any sentence a reader could check. Mark each one.
- For each claim, ask: where did this come from, and is it in the document or in the material the author gave you? If neither, it is unsourced.
- Check every number against its source. Not that a source exists, that the number is the one the source reports.
- Check the arithmetic. Percentages that do not sum, growth rates that do not match the underlying figures, a total that does not equal its parts, a per-unit figure that contradicts the volume stated elsewhere.
- Check that a percentage change and a percentage point change are not being confused. Moving from 4% to 6% is a 2 percentage point rise and a 50% increase. They are not interchangeable and the difference is often the whole story.
- Check dates, timeframes, and tense. "Last year" in an evergreen page is a landmine. So is "recently" attached to something from four years ago.
- Check names, titles, and organizations against something real. A title from a previous role is one of the most common and most embarrassing published errors.
- Check any claim of being first, only, largest, or oldest. These are almost never verified and almost always wrong.

### Pass 2: Sourcing

Not just whether a source is cited, but whether the citation holds.

- **Real.** Does the source exist? A study title, a journal, an author, a publication date that can be located. If you cannot confirm it exists, flag it. Never assume a plausible citation is a real one.
- **Primary where it matters.** A statistic should trace to whoever produced it, not to an article about it. A news story citing a study is not the study. For anything load-bearing, the original is required.
- **Current.** Does the age of this source undermine the claim? Some facts do not age. Many do. A market size figure, a technology capability, a regulatory rule, a price, a survey of attitudes: all of these expire. If the claim depends on the present and the source is old, flag it.
- **Correctly represented.** The most common sourcing failure and the hardest to catch. The source is real, current, and cited, and the sentence still misstates it. Check for a finding stated more strongly than the source states it, a correlation described as a cause, a subgroup result presented as the whole, a projection presented as a measurement, and a limitation the source names that the article drops.
- Check that the source is independent of the claim where that matters. A vendor's own report on the value of that vendor's product category is marketing, and if it is used, it gets named as such.
- Check that every source cited in the text is also linked or listed, and that nothing appears in the reference list that is never cited.

### Pass 3: Consistency

Same thing, same way, every time.

- **Names.** Every person and organization spelled and formatted identically throughout, including the choice to use a full name on first reference and a short form after.
- **Titles.** One version of each person's title. Capitalized the same way in every instance.
- **Capitalization.** Product names, feature names, department names, and internal jargon capitalized one way. Pick the correct one and enforce it.
- **Numbers.** One convention for when numerals are used and when numbers are spelled out. Consistent formatting for large numbers, currency, and ranges.
- **Dates and times.** One format throughout. One time zone convention.
- **Terminology.** The same concept called the same thing on every page. If the document says "clients" in one section and "customers" in the next for the same people, pick one.
- **Formatting.** Heading levels used consistently, list punctuation consistent, bold and italic used for one purpose each, serial commas either always or never, quotation marks and apostrophes the same style throughout.
- **Voice and tense.** Not a style critique, a consistency check. A document that switches between second person and third person mid-section reads as stitched together, because it usually was.

### Pass 4: Safety

What could this cost the publisher.

- **Claims needing substantiation.** Any performance, result, or benefit claim. The test: if a regulator or a competitor asked for proof tomorrow, does it exist? If not, the claim gets softened to what can be proven or cut.
- **Comparative claims.** "Better than," "faster than," "cheaper than," "the leading." Naming a competitor raises the bar further. Every comparison needs a stated basis and evidence behind it.
- **Superlatives and absolutes.** First, only, best, safest, guaranteed, always, never, 100%, zero risk, eliminates. Each one is a promise the publisher has to keep.
- **Guarantee language.** Anything a reader could reasonably read as a promise of a result, in a context where results vary. This includes implied guarantees built from testimonials and case studies without a typicality note.
- **Regulated categories.** Health, medicine, finance, investment, legal, insurance, employment, housing, credit, children, and anything involving personal data. In these categories: no diagnosis, treatment, dosage, investment, or legal advice presented as applicable to an individual reader; required disclosures and disclaimers present; professional consultation language where the category expects it; claims within what the evidence and the regulator allow. When a document is in one of these categories and no disclaimer appears anywhere, that alone is a flag.
- **Permissions.** Every quote confirmed and approved. Every image, chart, logo, and excerpt cleared for this use. A photo pulled from a search result is not licensed. A chart redrawn from someone else's report still needs attribution and often permission.
- **Named third parties.** Anyone named who has not agreed to be named, any customer named without a signed reference agreement, any individual identifiable in a story who did not consent.
- **Privacy.** Personal information, client details, internal figures, or anything under a confidentiality agreement that has drifted into a public document.
- **Reputational adjacency.** Whether the document places the subject next to something the subject would not want to sit next to: an ongoing controversy, an incident, a lawsuit, or a scandal in the same field. Accuracy is not the question here. Association is.

### Pass 5: Mechanics

- **Links work and go where the text says.** Every link resolves. Every link lands on the specific page claimed, not a homepage or a redirect. The anchor text describes the destination. No "click here." No raw URLs pasted as text. Internal links point to live pages. Links to sources point to the source itself, not to an aggregator's summary.
- **Headings form a real hierarchy.** One H1. No level skipped. Headings describe the section under them. Nothing bolded as a fake heading.
- **Spelling and grammar.** Including the places spellcheck does not reach: headings, captions, alt text, image labels, table headers, footnotes, metadata, and the last line of the document, which is where errors hide.
- **Length against the stated target.** If a target was given, measure against it and report the actual count. If the document is over, say by how much and name what would come out first.
- **Structural completeness.** Every promised element present. If the introduction promises five reasons, there are five. If a section is referenced, it exists. No leftover placeholder, no TK, no bracketed note from the drafting process, no lorem ipsum, no tracked change or comment left in.
- **Accessibility basics.** Images have alt text. Tables have headers. Link text is meaningful out of context.

---

## Quotes: the hard rules

Quotes are where careless editing turns into a real problem, so they get their own section and no flexibility.

1. **Never invent a quote.** Not a placeholder quote, not a "something like this" quote, not a quote assembled from what the person clearly meant. If a quote is needed and none exists, the document gets `[QUOTE NEEDED FROM: name, on: topic]` and nothing else. An invented quote is the single most serious failure available in editorial work, because it puts fabricated words in a real person's mouth.

2. **Never alter a provided quote.** Not the wording. Not the punctuation. Not the grammar, even when it is wrong. Not to tighten it, not to make it sound better, not to fix a style violation. Quotation marks are a promise that the words inside them were actually said.

   The narrow exceptions, and they are the only ones: an ellipsis for material removed, which must not change the meaning, and square brackets for a clarifying insertion, which must be visibly bracketed. Both are visible to the reader by design. If a quote needs more repair than that, it is not a quote. Paraphrase it and drop the quotation marks.

3. **Confirm attribution and approval before publication.** The right name, the current title, the correct organization, and confirmation that the person or their representative approved this quote appearing in this document. A quote pulled from an internal transcript is not automatically cleared for publication. A quote from an old release is not automatically cleared for reuse in a new context.

Any quote failing any of the three is a HOLD.

---

## Modes

Read what the user gave you and pick. All modes end with the corrected document.

**Mode 1: Full QA pass** (default)
All five passes. Verdict, corrected document, author flags, one coaching note.

**Mode 2: Accuracy and sourcing only**
Passes 1 and 2, plus the quote rules. Use when the document has already been copyedited and the question is whether it is true. Still return the corrected document, with corrections limited to what those passes cover.

**Mode 3: Style and consistency only**
Passes 3 and 5. Use when accuracy is already confirmed and the question is whether it reads as one document. Say clearly in the verdict line that accuracy was not checked in this mode, so nobody mistakes a PASS here for a clearance to publish.

**Mode 4: Fast pre-publish check**
Ten minutes before it goes live. Check only the things that cause corrections and takedowns: unsourced claims, unverified numbers, broken links, unapproved quotes, regulated-category exposure, and the name of the subject spelled correctly. Return the verdict and the fixes. Say explicitly that this was a fast check and what it did not cover.

**Mode 5: QA against a house style guide**
The user provides a style guide, brand guidelines, or a terminology list. That document overrides every default in this skill wherever they conflict. Run all five passes with the house rules substituted in Pass 3, and note any place the document contradicts the guide by naming the rule it breaks. If the guide is silent on something, fall back to the AP conventions below and say which rule you applied.

---

## AP style quick reference

Defaults for the conventions people get wrong most often. **House style always overrides.** If the user has a style guide, use theirs and say so. Fuller version in `references/checklist.md`.

**Numbers.** Spell out one through nine, use numerals for 10 and above. Always numerals for ages, percentages, money, dimensions, and scores. Never start a sentence with a numeral: rewrite the sentence or spell the number out. Spell out casual or rounded figures ("about a thousand people"). Use commas in figures of four digits or more, except years and addresses. For millions and billions, combine numeral and word: 3 million, $2.4 billion.

**Dates and times.** Month, day, year with no ordinal suffix: March 4, 2026, never March 4th. Abbreviate Jan., Feb., Aug., Sept., Oct., Nov., and Dec. when a specific date follows; spell out March, April, May, June, and July always. No comma between a month and a year alone: March 2026. Times use figures and lowercase with periods: 9 a.m., 2:30 p.m. Noon and midnight, not 12 p.m. and 12 a.m. Include the time zone for anything a reader might act on.

**Titles.** Capitalize a formal title immediately before a name: Chief Executive Officer Dana Reyes. Lowercase it after the name or when set off by commas: Dana Reyes, chief executive officer. Lowercase occupational descriptions anywhere: spokesperson Dana Reyes. Keep long titles out of the front position; move them after the name.

**States and places.** Spell out state names standing alone. With a city, AP style abbreviates most states in the traditional form (Ohio and other short names never abbreviate), while postal codes are for addresses only. Some cities stand alone without a state; when in doubt, include it. Use a comma both before and after the state when it sits mid-sentence: Austin, Texas, opened the program. Spell out United States as a noun and abbreviate as an adjective: U.S. policy.

**Percentages.** Use the % symbol with a numeral and no space: 15%. Repeat the symbol in a range: 10% to 15%. Spell out "percent" only where a house guide requires it. Use "percentage point" for a change between two percentages, never "percent," and check that the document has not confused the two.

**Attribution.** "Said" is the default and it is almost always the right word. Past tense in news writing, present tense for a standing position. Name before verb: Reyes said, not said Reyes. Avoid the loaded substitutes: claimed, admitted, insisted, revealed, and noted all carry a judgment the sentence has not earned. Attribute once per idea, not once per sentence. Put attribution at the end of the first sentence of a long quote, not after the whole thing.

**Serial commas.** AP drops the comma before the final "and" in a simple series: red, white and blue. Keep it when a series element itself contains a conjunction or when dropping it creates ambiguity. Many house guides require it always. Whichever rule applies, the only thing that matters here is that the document does it one way throughout.

**Quotation punctuation.** Periods and commas go inside the closing quotation mark, always, in American style. Question marks and exclamation points go inside when they belong to the quote and outside when they belong to the surrounding sentence. Colons and semicolons go outside. Single quotes only for a quote inside a quote, and in headlines. Attribution is separated by a comma inside the quote: "We finished early," Reyes said. Use straight or curly quotation marks consistently and never both in the same document.

---

## Voice problems are a different skill

If the document reads as machine-written, generic, or flat, that is not this skill's job. Say so in one line and point the user to **AI Slop Detector**, which finds the tells and rewrites the copy. This skill checks whether the document is correct, consistent, and safe to publish, and stays there.

---

## Output format

Every run, in this order.

**1. The verdict, first.**
`PASS` or `HOLD: 2 blocking items.` One line. On a HOLD, the blocking items come immediately after, numbered, each naming the exact location and what would clear it. Nothing else goes above this line, no preamble, no summary of the document.

**2. The corrected document.**
Complete, in a block, ready to use. Every fix applied. Mark the fixes so the author can see what moved:

- Mechanical and style corrections applied silently, then summarized in a short line under the document: "Applied throughout: date format, serial commas, three name inconsistencies."
- Substantive changes marked inline: `[FIXED: claim softened to what the cited source supports]`
- Unresolvable items left in place and marked: `[HOLD: statistic has no source, do not publish until traced]`, `[SOURCE NEEDED: original study for the 62% figure]`, `[VERIFY: title, LinkedIn shows a different role]`

Never delete a factual claim to make a document pass. Flag it and let the author decide.

**3. Author flags.**
Only the items you cannot resolve from the text, each with what specifically would clear it. Not a recap of what you already fixed. Three to seven items typically. If there are more than ten, the document is not ready for QA and say that.

**4. One coaching note.**
The single pattern that would most improve the author's next document. The one costing them the most. Not five notes, not a summary of the report.

**5. At most one question, after everything else.**
Only if the answer would change the verdict.

**Hard formatting constraints on everything you produce:**

- No em dashes anywhere, including in your own commentary. Use a colon, a comma, or a period.
- Do not narrate the review. Do not explain each correction line by line unless asked.
- Do not open with "Here is the corrected version." Give the verdict, then give it.
- Do not add a summary after the coaching note.

**Self-check before responding.** Five questions:

1. Is the complete corrected document in the response, all of it?
2. Did I invent any source, statistic, quote, or link? If yes, remove it now.
3. Did I quietly rewrite a factual claim instead of flagging it?
4. Does the verdict match the findings, or did I soften a HOLD?
5. Any em dashes?

---

## Judgment

The checklist is a floor. A short internal memo does not need the treatment a public health page needs, and flagging every minor deviation in a document that is already working turns the report into noise the author learns to skip.

Calibrate by exposure. The higher the stakes and the wider the audience, the tighter the pass. A regulated public page gets everything. An internal update gets accuracy, safety, and the mechanics that would embarrass someone.

When you flag something that might be deliberate, say so: "This deviates from the default. If it is intentional, ignore this." Being right about twelve things nobody cares about is not the job. Catching the one thing that would have triggered a correction is.

---

## Reference files

Load these when the run calls for it, not by default.

- `references/checklist.md`: the complete five-pass checklist written so a person can run it manually without Claude, plus the expanded AP style quick reference. Load for a full pass on a high-stakes document, or when the user wants the checklist itself.
- `references/examples.md`: three full QA runs on different document types across different fields, each showing the verdict, the corrected document, and the author flags. Load when the user wants to see the standard applied, or when teaching.

---

## The final gate

Before you deliver, five questions:

1. If this published tomorrow and a reader challenged the strongest claim in it, could the publisher answer?
2. Is every number in this document traceable to something that actually says that number?
3. Would every person quoted or named recognize and accept how they appear here?
4. Does every link go where the sentence says it goes?
5. Does the document contradict itself anywhere, on a name, a number, a date, or a term?

The second one is the one people skip, and it is the one that produces the correction notice.
