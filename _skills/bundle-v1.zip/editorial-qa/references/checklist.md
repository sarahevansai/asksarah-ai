# The Editorial QA Checklist

The complete five-pass checklist, written so a person can run it manually with no tools beyond a browser and the source material. Work top to bottom. Do not skip a pass because the document looks clean. Clean-looking documents are where errors survive.

Print it, paste it into a doc, or work down it on screen. Mark each line PASS, FAIL, or N/A. Any FAIL in the blocking list at the end makes the whole document a HOLD.

---

## Before you start

Collect these. A QA pass without them is a guess.

- [ ] The document, in final draft form, not a version two edits behind
- [ ] The source material behind every claim: the studies, the reports, the data, the transcripts
- [ ] The style guide, if one exists. House style overrides everything in this file.
- [ ] The stated length target, if there is one
- [ ] The list of approved quotes and who approved them
- [ ] The publication destination, because a public page and an internal memo get different levels of scrutiny
- [ ] Any prior corrections on this subject, so you do not reintroduce a fixed error

---

## PASS 1: ACCURACY

Every factual claim traced to a source. Every number checked.

### Finding the claims

- [ ] Read the document once for claims only, not for flow. Mark every sentence a reader could check.
- [ ] For each marked sentence, write where it came from. If you cannot, it is unsourced.
- [ ] Check the claims hiding in the parts people skim: the headline, the subheadline, the pull quotes, the captions, the chart labels, the meta description, the social copy, and the last paragraph.

### Numbers

- [ ] Every number appears in the source it is attributed to, exactly as stated
- [ ] Percentages and totals add up
- [ ] Growth rates match the underlying figures
- [ ] Parts sum to the stated total
- [ ] Percentage change and percentage point change are used correctly and not confused
- [ ] Units are right and consistent: millions vs billions, monthly vs annual, per user vs total
- [ ] Currency is specified where more than one is plausible
- [ ] Rounding is consistent and does not overstate precision
- [ ] Any number that seems surprising has been checked twice, because surprising numbers are usually transcription errors

### Names, titles, organizations

- [ ] Every personal name spelled correctly, verified against a real source, not memory
- [ ] Every title is the person's current title, not one from a previous role
- [ ] Every organization name matches its own official usage, including capitalization and punctuation
- [ ] Product names match the maker's own formatting
- [ ] Pronouns for each named person are correct
- [ ] Nobody is named who should not be named

### Time

- [ ] Dates are correct, including the year
- [ ] Days of the week match the dates given
- [ ] Tense is right: is this still true, or was it true when drafted?
- [ ] Relative time references ("last year," "recently," "currently," "now") are safe for how long this will stay published
- [ ] Anything seasonal or event-linked will still make sense on the publish date

### Logic

- [ ] The document does not contradict itself
- [ ] Cause and effect claims are actually causal, not correlations described as causes
- [ ] Examples support the point they are attached to
- [ ] Any claim of first, only, largest, oldest, or best has been verified. These are almost always wrong.
- [ ] Any "studies show" or "research suggests" or "experts agree" has a named study, a named researcher, or gets cut

---

## PASS 2: SOURCING

### Real

- [ ] Every cited source exists and can be located
- [ ] Author, publication, title, and date all check out
- [ ] No citation was accepted because it looked plausible
- [ ] Any source that cannot be located is flagged, not assumed

### Primary where it matters

- [ ] Statistics trace to whoever produced them, not to coverage of them
- [ ] The load-bearing claims cite the original, not a summary, not an aggregator, not a listicle
- [ ] Where a secondary source is used for convenience, the primary one has still been checked
- [ ] Data with a methodology has had that methodology at least glanced at: sample size, population, dates, who paid for it

### Current

- [ ] Each source is recent enough for the claim it supports
- [ ] Nothing time-sensitive rests on old data: market sizes, prices, technology capabilities, regulations, headcounts, survey attitudes
- [ ] Where an older source is the best available, its age is stated in the text
- [ ] Superseded sources have been replaced: a newer edition, a revised figure, a corrected study
- [ ] Any retracted or corrected study has been checked for that status

### Correctly represented

- [ ] Each sentence says what its source says, no stronger
- [ ] No correlation described as causation
- [ ] No subgroup finding presented as the whole population
- [ ] No projection or model output presented as a measurement
- [ ] No limitation the source names that the document drops
- [ ] No number lifted out of a context that changes its meaning
- [ ] Sources with an interest in the finding are identified as such: vendor research, sponsored studies, trade association reports
- [ ] Everything cited in the text appears in the reference list, and nothing in the reference list is uncited

---

## PASS 3: CONSISTENCY

- [ ] **Names.** Every person and organization identical throughout, including first-reference and short-form conventions
- [ ] **Titles.** One version each, capitalized the same way every time
- [ ] **Capitalization.** Product names, features, departments, and internal terms handled one way
- [ ] **Numbers.** One rule for numerals vs words, applied everywhere
- [ ] **Large numbers, currency, ranges.** One format throughout
- [ ] **Dates.** One format throughout
- [ ] **Times and time zones.** One convention throughout
- [ ] **Terminology.** One word per concept. No customers in one section and clients in the next for the same people.
- [ ] **Abbreviations.** Spelled out on first use, used consistently after, and not introduced if used only once
- [ ] **Headings.** Same grammatical pattern at the same level, same capitalization style
- [ ] **Lists.** Same punctuation and same grammatical form within a list
- [ ] **Emphasis.** Bold and italic each doing one job
- [ ] **Serial commas.** Always or never, one way
- [ ] **Quotation marks and apostrophes.** Straight or curly, not both
- [ ] **Spelling variant.** One national variant throughout
- [ ] **Person and tense.** No unexplained switching mid-document
- [ ] **Spacing.** One space after periods, consistent paragraph spacing, no stray double spaces

---

## PASS 4: SAFETY

### Claims

- [ ] Every performance, result, or benefit claim has evidence behind it that exists today
- [ ] The test applied to each: if a regulator or a competitor demanded proof tomorrow, could it be produced?
- [ ] Claims that fail that test are softened to what can be proven, or cut

### Comparative claims

- [ ] Every comparison states its basis: better at what, faster by how much, measured how
- [ ] Comparisons naming a competitor have evidence sufficient to defend them
- [ ] "Leading," "top," "number one," and "preferred" are backed by a citable ranking or removed

### Absolutes

- [ ] No unearned superlatives: first, only, best, safest, most
- [ ] No absolutes the publisher cannot honor: always, never, every, zero, 100%, eliminates, guarantees, ensures
- [ ] No implied guarantee built from testimonials or case studies without a typicality note

### Regulated categories

Apply when the document touches health, medicine, finance, investment, legal, insurance, employment, housing, credit, children, or personal data.

- [ ] No individualized advice: no diagnosis, treatment plan, dosage, investment recommendation, or legal conclusion aimed at a reader
- [ ] Required disclaimers present, visible, and near the claim rather than buried at the bottom
- [ ] Professional consultation language present where the category expects it
- [ ] Claims within what the evidence supports and what the category's regulator allows
- [ ] Outcome language reflects that results vary
- [ ] Risk stated alongside benefit where the category requires it
- [ ] The document has been routed to whoever reviews this category, if the publisher has such a reviewer
- [ ] If the document is in one of these categories and carries no disclaimer anywhere, that is flagged on its own

### Permissions

- [ ] Every quote is confirmed accurate and approved for this use
- [ ] Every image is licensed for this use, and the license covers commercial use if applicable
- [ ] Every chart, table, or figure taken from elsewhere is attributed and permitted
- [ ] Every logo used has permission
- [ ] Every excerpt is within fair use or separately licensed
- [ ] Any person identifiable in a photo or a story has consented
- [ ] Any customer or client named has agreed to be named

### Privacy and confidentiality

- [ ] No personal information that should not be public
- [ ] No internal figures, client details, or unannounced plans
- [ ] Nothing covered by a confidentiality agreement
- [ ] No employee or customer identifiable without consent

### Reputational adjacency

- [ ] The document does not place its subject next to a controversy, incident, lawsuit, or scandal in the same field
- [ ] The opening in particular does not lead with a negative event the subject would not want to be associated with
- [ ] Test: would the subject be comfortable seeing any given sentence quoted next to their name, out of context?

---

## PASS 5: MECHANICS

### Links

- [ ] Every link opens
- [ ] Every link lands on the specific page the text claims, not a homepage, not a redirect, not a paywall the reader cannot pass
- [ ] Anchor text describes the destination
- [ ] No "click here," no "read more," no raw URLs in body text
- [ ] Links to sources point to the source, not to a summary of it
- [ ] Internal links point to live pages
- [ ] Nothing points to a competitor unintentionally
- [ ] Nothing points to a page that has moved since drafting
- [ ] Link count is reasonable for the length, and no paragraph is a wall of links

### Headings

- [ ] One H1
- [ ] No heading level skipped
- [ ] Each heading describes what is under it
- [ ] Nothing bolded to fake a heading
- [ ] Heading text matches the table of contents, if there is one

### Spelling and grammar

- [ ] Body text clean
- [ ] Headings and subheadings checked, because spellcheck often skips them
- [ ] Captions, alt text, table headers, footnotes, and image file names checked
- [ ] Metadata checked: title tag, description, slug
- [ ] Subject lines, preview text, and social copy checked
- [ ] The last line of the document checked, which is where errors hide
- [ ] Homophone check: their and there, its and it's, affect and effect, principal and principle, complement and compliment
- [ ] Subject and verb agreement across long sentences
- [ ] Modifiers attached to the right noun

### Length and completeness

- [ ] Actual word count measured against the stated target, with the number reported
- [ ] If over, the first cut is identified
- [ ] Every promised element delivered: if the intro says five reasons, there are five
- [ ] Every referenced section exists
- [ ] No placeholder text, no TK, no bracketed drafting note, no lorem ipsum
- [ ] No tracked changes, comments, or highlights left in
- [ ] Required elements present for the format: byline, date, disclosure, contact, boilerplate, disclaimer, whatever this format needs

### Accessibility

- [ ] Images have alt text that describes the image
- [ ] Tables have headers
- [ ] Link text is meaningful out of context
- [ ] Color is not the only carrier of meaning
- [ ] Any acronym is expanded on first use

---

## The blocking list

Any one of these makes the document a HOLD. Do not publish.

1. An unsourced factual claim
2. A legal or regulatory exposure
3. A broken or wrong link
4. An unverified statistic
5. An unapproved quote
6. A claim the publisher cannot substantiate

Everything else gets fixed and the document publishes.

---

# AP Style Quick Reference

The conventions people get wrong most often. **House style overrides all of it.** When a house guide exists, follow it and note which rule you applied.

## Numbers

- Spell out one through nine. Use numerals for 10 and above.
- Always numerals: ages, percentages, money, dimensions, temperatures, scores, votes, addresses, times.
- Never start a sentence with a numeral. Rewrite, or spell it out. The exception is a year.
- Spell out casual or approximate figures: about a hundred people, a thousand times over.
- Commas in figures of four digits and up: 1,200. No commas in years, addresses, or page numbers.
- Millions and billions combine numeral and word: 3 million, $2.4 billion, 1.5 million users.
- Ordinals: first through ninth spelled out, 10th and up as numerals.
- Fractions less than one are spelled and hyphenated: two-thirds. Larger use numerals: 2 1/2.
- Ranges: use "to" in text. Be consistent about whether units repeat.
- Do not mix conventions inside one comparison. If one number in a pair needs numerals, use numerals for both.

## Dates and times

- Month day, year: March 4, 2026. No ordinal suffix. Never March 4th.
- With a specific date, abbreviate Jan., Feb., Aug., Sept., Oct., Nov., Dec. Spell out March, April, May, June, July always.
- Month and year alone take no comma: March 2026.
- A full date mid-sentence takes a comma on both sides: On March 4, 2026, the program opened.
- Days of the week are spelled out. Use the day for events within a week either side of today, the date beyond that.
- Times use figures, lowercase, with periods: 9 a.m., 2:30 p.m. Omit :00 for an even hour.
- Use noon and midnight, not 12 p.m. and 12 a.m.
- Include the time zone whenever a reader might act on the time.
- Decades take no apostrophe before the s: the 1990s, the '90s.

## Titles

- Capitalize a formal title immediately before a name: Chief Executive Officer Dana Reyes.
- Lowercase after the name or when set off by commas: Dana Reyes, chief executive officer.
- Lowercase occupational descriptions in any position: spokesperson Dana Reyes, researcher Lee Park.
- Move long titles after the name rather than stacking them in front of it.
- Academic and courtesy titles: use on first reference only where relevant, and follow the house guide.
- Composition titles take quotation marks in AP, not italics. House guides often differ here.

## States and places

- Spell out a state name standing alone.
- With a city, AP abbreviates the longer state names in traditional form. Eight never abbreviate: Alaska, Hawaii, Idaho, Iowa, Maine, Ohio, Texas, Utah.
- Postal codes are for mailing addresses only, not for running text.
- Comma before and after the state when it sits mid-sentence: Austin, Texas, opened the program.
- Some large cities stand alone with no state. When in doubt, include it. International readers are always the tiebreaker.
- United States is spelled out as a noun, abbreviated as an adjective: U.S. policy.
- Do not abbreviate street, avenue, or boulevard except in a specific numbered address.

## Percentages

- Numeral plus the % symbol, no space: 15%.
- Repeat the symbol across a range: 10% to 15%.
- Spell out "percent" only where a house guide requires it, and then do it everywhere.
- Zero point something takes a leading zero: 0.6%.
- Use "percentage point" for a change between two percentages. A move from 4% to 6% is 2 percentage points, and also a 50% increase. Never call it a 2% increase.
- Percentages take a singular verb when the noun is singular, plural when plural.

## Attribution

- "Said" is the default and almost always right.
- Past tense in news writing. Present tense for a standing position stated in the document.
- Name before verb: Reyes said. Not: said Reyes.
- Avoid the loaded alternatives: claimed, admitted, insisted, revealed, noted, pointed out, explained. Each smuggles in a judgment.
- Attribute once per idea, not once per sentence.
- On a multi-sentence quote, attribute at the end of the first sentence, not after the whole block.
- Attribute clearly enough that a reader never wonders who is talking.
- Anonymous sourcing needs a reason stated in the text, and follows the publisher's own rules.

## Serial commas

- AP drops the comma before the final "and" in a simple series: red, white and blue.
- Keep it when an element contains its own conjunction: bacon, eggs, and biscuits and gravy.
- Keep it when dropping it creates ambiguity.
- Many house guides require it always. Either rule is defensible. Mixing the two inside one document is not.

## Quotation punctuation

- Periods and commas go inside the closing quotation mark. Always, in American usage.
- Question marks and exclamation points go inside when they belong to the quoted material, outside when they belong to the surrounding sentence.
- Colons and semicolons go outside.
- Single quotes only for a quote inside a quote, and in headlines.
- Attribution inside a quote is separated by a comma: "We finished early," Reyes said.
- Introduce a full-sentence quote with a comma, or with a colon for a longer or more formal one.
- Do not use quotation marks for emphasis. That reads as sarcasm.
- Use one style of quotation mark, straight or curly, throughout.
- Partial quotes take quotation marks around only the words actually spoken.

## Other high-frequency items

- Em dashes: this skill's default is not to use them. Use a comma, a colon, or a period. Where house style permits them, they must at least be used consistently.
- Hyphenate a compound modifier before a noun: a well-known researcher. Not after: the researcher is well known.
- No hyphen after an adverb ending in -ly: a highly rated program.
- Numbers in compound modifiers hyphenate: a 10-year study.
- Ampersands only where they are part of an official name.
- One space after a period.
- Capitalize a proper noun. Do not capitalize a common noun for emphasis or importance.
- Spell out an acronym on first use unless it is more familiar than its expansion.
