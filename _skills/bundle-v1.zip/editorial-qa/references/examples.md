# Editorial QA: Worked Examples

Three full runs on different document types from different fields. Each shows the verdict, the corrected document with fixes marked, and the author flags.

Every organization, person, and figure in these examples is fictional. Where a real-world statistic would normally appear, it is left bracketed, because this skill never invents one, not in a review and not in an example.

Read these for the shape of the output, not for the specific findings. The findings change with every document. The shape does not.

---

# Example 1: A healthcare clinic's patient information page

**Document type:** Public patient education page for a physical therapy clinic
**Stated target:** 600 to 800 words
**Category:** Regulated. Health.

## The draft as submitted

> ## Recovering From Knee Replacement Surgery: What to Expect
>
> Knee replacement is one of the most common orthopedic procedures performed today, and recovery is faster than most patients expect. At Northline Physical Therapy, our therapists have guided over 4,000 patients through post-surgical recovery since 2011.
>
> ### The First Two Weeks
>
> Most patients are walking with support within 24 hours of surgery. Studies show that early mobilization dramatically improves outcomes and reduces the risk of complications. Our protocol gets you moving on day one.
>
> Pain is normal during this period. Most patients find that over-the-counter anti-inflammatories are enough after the first week, and you should be able to taper off prescription pain medication quickly. If pain persists, increase your icing to 20 minutes every hour.
>
> ### Weeks Three Through Six
>
> This is when the real progress happens. Our patients typically regain 90% of their range of motion by week six, well ahead of the national average. Dr. Amara Osei, Northline's Clinical Director, says "our approach is simply better than what most clinics offer, and the numbers prove it."
>
> By week 6 you will be back to daily activities. Most people return to work in 4-6 weeks, and our program guarantees you will be back to full function by week 12.
>
> ### Long Term
>
> A modern knee implant lasts 25 years. That means for most patients, this is a one-time surgery. Research indicates that patients who complete a structured PT program have significantly better long-term outcomes than those who don't.
>
> Northline Physical Therapy has locations in Portland, Oregon and Vancouver, WA. Learn more [here](https://example-clinic-site.test).

## The QA run

**HOLD: 6 blocking items.**

1. **Guaranteed medical outcome.** "Our program guarantees you will be back to full function by week 12." A clinic cannot guarantee a clinical outcome. This is the single highest-exposure sentence on the page. It must be removed, not softened.
2. **Individualized medical instruction.** "Increase your icing to 20 minutes every hour" tells a reader in pain to change their own treatment without contacting anyone. Persistent pain after knee replacement can indicate infection or a clot. This must redirect to the surgeon.
3. **Medication guidance.** "You should be able to taper off prescription pain medication quickly" is prescribing advice on a page that is not written by the prescriber.
4. **Unverified comparative claim.** "Well ahead of the national average" compares clinic outcomes to a national benchmark with no benchmark named and no clinic data cited.
5. **Unapproved quote making a comparative claim.** The Osei quote says the clinic is "simply better" than other clinics and that "the numbers prove it." No numbers are shown. Confirm the quote was said and approved, or cut it.
6. **Three unsourced factual claims.** "Studies show that early mobilization," "research indicates" structured PT improves outcomes, and "a modern knee implant lasts 25 years" are all presented as established fact with nothing behind them.

## The corrected document

> ## Recovering From Knee Replacement Surgery: What to Expect
>
> *This page is general information, not medical advice. Follow the recovery plan your surgeon and physical therapist give you. It is written for your specific situation and this page is not.*
>
> Knee replacement is one of the most common orthopedic procedures performed in the United States. At Northline Physical Therapy, our therapists have guided more than 4,000 patients through post-surgical recovery since 2011.
>
> Recovery is different for every patient. What follows is a general timeline, not a schedule you should measure yourself against.
>
> ### The First Two Weeks
>
> Many patients begin walking with support within a day of surgery, though your surgeon decides when you start and how much weight you can put on the joint. [FIXED: "most patients are walking within 24 hours" changed to "many," and the decision returned to the surgeon. The original stated a clinical norm as universal.]
>
> Early, supervised movement is a standard part of post-surgical recovery protocols. [SOURCE NEEDED: the original said "studies show that early mobilization dramatically improves outcomes." If you want that claim, cite the specific clinical guideline or study. If not, this softened sentence stands.]
>
> Some pain and swelling are expected in this period. Your surgical team will tell you which pain medications to take and when to change them. Do not adjust your medication on your own. [FIXED: removed the tapering guidance and the icing instruction. Both were individualized medical advice.]
>
> **Call your surgeon right away if you have** increasing pain rather than decreasing pain, a fever, redness or drainage at the incision, or new swelling or pain in your calf. [FIXED: the original told readers with persistent pain to ice more. Persistent or increasing pain is a reason to call a doctor.]
>
> ### Weeks Three Through Six
>
> Most patients see their largest gains in range of motion during this stretch, and this is where consistent attendance at therapy matters most.
>
> [HOLD: the original claimed patients "typically regain 90% of their range of motion by week six, well ahead of the national average." If Northline tracks this, provide the internal data, the number of patients it covers, and the date range, and name the benchmark being compared against. Without all four, this sentence cannot publish in any form.]
>
> [HOLD: quote from Dr. Amara Osei removed pending confirmation. As written it claimed Northline is "simply better" than other clinics and that "the numbers prove it," with no numbers on the page. If she said it and approves it, it still needs the numbers or a rewrite. Send the version you want and it goes back in verbatim.]
>
> Many people return to desk work around four to six weeks after surgery, depending on the job and how recovery is going. Physical work takes longer. Your surgeon clears you to return, not a timeline on a webpage. [FIXED: the guarantee of full function by week 12 is removed. A clinic cannot guarantee a clinical outcome, and this page is a claim the practice would have to defend.]
>
> ### Long Term
>
> Modern knee implants are designed for long service, and how long yours lasts depends on your age, activity level, weight, and the implant itself. Your surgeon can tell you what to expect from the specific implant you received. [FIXED: "a modern knee implant lasts 25 years" removed. It states a single lifespan as fact for all implants and all patients.] [SOURCE NEEDED: if you want a durability figure, cite the implant manufacturer's published data or a specific registry report.]
>
> Completing a structured physical therapy program is a standard recommendation after knee replacement. [SOURCE NEEDED: the original said "research indicates" better long-term outcomes. Cite the specific research or leave this as the softer statement.]
>
> ---
>
> Northline Physical Therapy has locations in Portland, Oregon, and Vancouver, Washington. [Book an appointment or ask a question](https://example-clinic-site.test).
>
> *This page is for general education. It does not replace guidance from your surgeon or your physical therapist.*

**Applied throughout:** state names spelled out and made consistent, "WA" changed to Washington, comma added after Oregon in the mid-sentence position, "week 6" changed to "week six" for consistency with the spelled-out numbers elsewhere, "4-6 weeks" changed to "four to six weeks," "don't" changed to "do not" to match the rest of the page, link anchor text changed from "here" to a description of the destination, disclaimer added at the top and bottom, the "call your surgeon" block added.

## Author flags

1. **The 90% range-of-motion claim.** Provide the underlying data, the patient count, the date range, and the benchmark you are comparing against. Without all four this stays out.
2. **The Osei quote.** Confirm she said it and approves it for this page. As written it is a comparative claim about other clinics with nothing supporting it. A quote about the clinic's protocol, rather than about competitors, clears easily.
3. **Three source gaps.** Early mobilization, implant lifespan, and long-term PT outcomes. Any clinical guideline or registry report you already rely on internally will do.
4. **Clinical review.** Every sentence on this page that describes what a patient should do needs a clinician's sign-off before publication. That is a workflow gap, not a text gap, and it is the one that matters most.
5. **The 4,000 patient figure.** Confirm it is current. It has been on the site for a while and it is a number a reader could ask you to back up.

## Coaching note

The pattern driving five of the six blocking items is the same one: describing what usually happens as what will happen. "Most patients walk within 24 hours" became a promise, "typical recovery" became a guarantee, "implants are durable" became 25 years. In a regulated category, every general statement gets read by one specific reader as a statement about them. Write the range and the variation into the sentence itself, and the legal exposure disappears without the page losing anything a patient came for.

One question: does Northline track recovery outcomes internally? If yes, the strongest version of this page uses your own numbers, and I would rebuild the middle section around them.

---

# Example 2: A financial services blog post

**Document type:** Public blog post for an independent advisory firm
**Stated target:** 1,000 words
**Category:** Regulated. Finance.

## The draft as submitted (excerpt)

> ## Why Now Is the Time to Rebalance Your Portfolio
>
> If you haven't rebalanced in the last year, you're leaving money on the table. Market conditions have shifted dramatically, and investors who fail to act now will regret it.
>
> Meridian Wealth Partners has managed assets for families across the midwest since 2008. Our clients have consistently outperformed the market. Here's what we're telling them to do right now.
>
> ### The 60/40 Portfolio Is Dead
>
> The traditional 60/40 split between stocks and bonds no longer works. Experts agree that this model is outdated. According to a recent report, allocation strategies built in the 1990's are failing modern investors.
>
> Our chief investment officer, Marcus Bell, put it best: "the old rules don't apply anymore." Marcus has been with Meridian since 2015 and previously served as a Senior Portfolio Manager at a top-10 asset manager.
>
> ### What To Do Instead
>
> We recommend shifting to a 70/20/10 allocation, with 10 percent in alternatives. This approach has delivered superior risk-adjusted returns for our clients over the past 3 years. It's the safest way to protect your wealth in this environment.
>
> Read our full market outlook [here](https://example-advisory-site.test/outlook).

## The QA run

**HOLD: 5 blocking items.**

1. **Individualized investment advice on a public page.** "We recommend shifting to a 70/20/10 allocation" is a specific recommendation aimed at every reader regardless of their situation. This is the central problem with the piece and it is structural, not a wording fix.
2. **Unsubstantiated performance claim.** "Our clients have consistently outperformed the market." No period, no benchmark, no composite, no disclosure. This is the claim most likely to draw a regulator.
3. **Safety claim.** "It's the safest way to protect your wealth." An allocation cannot be called safest, and "protect your wealth" reads as a guarantee against loss.
4. **Unsourced claims presented as consensus.** "Experts agree" and "according to a recent report" with no report named.
5. **No disclosures anywhere.** A public investment commentary page from a registered firm with no disclosure language at all.

Also blocking on link check: the outlook link resolves to a 404. The page it points to was moved or renamed.

## The corrected document (excerpt)

> ## Rebalancing Your Portfolio: Questions Worth Asking This Year
>
> [FIXED: headline changed. "Why Now Is the Time to Rebalance" told every reader to take an action without knowing anything about them.]
>
> If it has been a year or more since you last looked at your allocation, it is worth a review. Drift happens quietly: the positions that performed well grow into a larger share of the portfolio than you chose, and the risk profile you signed up for is not the one you are holding. [FIXED: removed "you're leaving money on the table" and "investors who fail to act now will regret it." Both are pressure claims about outcomes nobody can predict.]
>
> Meridian Wealth Partners has advised families across the Midwest since 2008. [FIXED: "our clients have consistently outperformed the market" removed. A performance claim requires a defined composite, a benchmark, a time period, a net-of-fees basis, and disclosure. If you want to make it, provide those and it can go back in properly framed.] [VERIFY: confirm 2008 is the founding year on the firm's ADV.]
>
> ### The 60/40 Question
>
> [FIXED: subhead changed from "The 60/40 Portfolio Is Dead." A declarative claim of that size needs evidence the piece does not have.]
>
> The traditional 60 stock, 40 bond split has been debated more actively in recent years, particularly around how bonds behave when both stocks and bonds fall together. [SOURCE NEEDED: the original said "experts agree that this model is outdated" and cited "a recent report." Name the report, the author, and the date, or this stays as a description of the debate rather than a verdict on it.]
>
> [HOLD: quote from Marcus Bell removed pending confirmation. Confirm he said "the old rules don't apply anymore," confirm he approves it here, and confirm his current title. Separately, "previously served as a Senior Portfolio Manager at a top-10 asset manager" needs either the firm named or the phrase cut. "Top-10" is a ranking claim with no ranking cited.]
>
> ### Questions To Bring To Your Advisor
>
> [FIXED: section retitled and rebuilt. The original recommended a specific 70/20/10 allocation to every reader. A public page cannot make an individualized recommendation, and the right allocation depends on the reader's timeline, risk tolerance, tax situation, and existing holdings.]
>
> - How far has my allocation drifted from my target, and when did that happen?
> - Does my current mix still match the timeline I set it for?
> - What would rebalancing cost me in taxes this year, and does a tax-advantaged account change the answer?
> - What role, if any, do alternatives play in a portfolio my size?
> - What would have to be true for me to change my target rather than rebalance back to it?
>
> [HOLD: "this approach has delivered superior risk-adjusted returns for our clients over the past 3 years" removed. Same requirements as the earlier performance claim.]
>
> [FIXED: "it's the safest way to protect your wealth in this environment" removed entirely. No allocation is the safest, and "protect your wealth" reads as a guarantee against loss.]
>
> Read our current market outlook. [HOLD: the original link returns a 404. Supply the working URL.]
>
> ---
>
> [DISCLOSURE NEEDED: this page has no disclosure language of any kind. At minimum it needs the firm's standard advisory disclosure, a statement that this is general information and not personalized investment advice, and a note that past performance does not indicate future results. Use your compliance-approved block. Do not let me write it.]

**Applied throughout:** "midwest" capitalized to Midwest, "1990's" corrected to 1990s, "10 percent" changed to 10% for consistency with the numerals used elsewhere, "3 years" changed to three years, contractions made consistent, "Senior Portfolio Manager" lowercased where it follows the name, link anchor text changed from "here" to a description of the destination, headline and one subhead rewritten as noted.

## Author flags

1. **Compliance review.** This piece needs it before publication, not after. Two removed performance claims and a removed recommendation are the reason.
2. **The performance claims.** If you want either one in, supply the composite definition, the benchmark, the period, whether the figures are net of fees, and the disclosure your compliance team requires.
3. **The Bell quote and bio.** Confirm the quote, confirm his current title, and either name the previous firm or cut "top-10."
4. **The broken outlook link.**
5. **The "recent report."** Name it or the sentence stays as written.
6. **Disclosure block.** Use your approved language.

## Coaching note

The piece was written to persuade a reader to do something specific, and in this category that is the thing you cannot do on a public page. The version that works uses the same expertise to sharpen what the reader asks their advisor, rather than telling them what to hold. That reframe costs you nothing in authority, and it removes almost every compliance problem in the draft at once. Write toward the question, not toward the allocation.

---

# Example 3: An internal policy memo

**Document type:** Company-wide memo announcing a policy change
**Stated target:** none given
**Category:** Internal, but forwardable, which is the part people forget.

## The draft as submitted

> **To:** All Staff
> **From:** People Operations
> **Re:** Updates to our Remote Work Policy
>
> Team,
>
> After careful consideration, leadership has decided to update our remote work policy effective Jan 1st. Going forward, all employees will be expected in the office three days per week.
>
> We know this is a change. Research shows that in-person collaboration significantly improves team performance and innovation. Our own data supports this: teams that were co-located last quarter shipped 30% more.
>
> The new policy applies to everyone except employees hired as fully remote, who will be grandfathered in. Managers will work with their teams to determine which days.
>
> If you have concerns, please reach out to your manager or to People Ops. We're also aware that some folks have accommodations in place and those will be honored.
>
> We appreciate your flexibility as we navigate this transition. More details will be shared soon. Please review the updated handbook section on the intranet [here].
>
> Thanks,
> People Operations

## The QA run

**HOLD: 3 blocking items.**

1. **Unverified internal statistic.** "Teams that were co-located last quarter shipped 30% more." This will be the most quoted sentence in the memo and the first one challenged. It needs the data source, the definition of "shipped," the teams compared, and the time period. An internal number is not exempt from sourcing.
2. **Unsourced external claim.** "Research shows that in-person collaboration significantly improves team performance and innovation." Presented as settled. It is a contested area.
3. **Broken link.** The handbook link has no URL. The bracket is empty in the source document.

Also: this memo creates an employment obligation and names an accommodations process. It should be reviewed by whoever handles employment matters before it goes out. That is a routing flag, not a text flag, but this memo will be produced in any dispute about the policy, so it belongs at the top.

## The corrected document

> **To:** All staff
> **From:** People Operations
> **Re:** Remote work policy change, effective January 1
>
> [FIXED: subject line now carries the change and the date. "Updates to our Remote Work Policy" tells a reader nothing they can act on.]
>
> Team,
>
> **Starting January 1, employees will work from the office three days a week.** [FIXED: moved to the first line. The original opened with "after careful consideration, leadership has decided," which delays the only sentence in the memo everyone needs.]
>
> Here is what that means and what happens next.
>
> **Who this applies to.** Everyone except employees hired into fully remote roles, whose arrangements do not change. If you are not sure which category you are in, your manager can confirm, and People Ops can confirm if there is any question after that. [FIXED: "grandfathered in" replaced with plain language. The original left a reader who was unsure with no way to find out.]
>
> **Which days.** Managers will set the schedule with each team by [DATE NEEDED: when will teams know? A memo announcing a January 1 change with no date for the schedule generates a week of individual questions].
>
> **Accommodations.** Existing accommodations remain in place. If you have an approved accommodation, nothing here overrides it. To request one, contact [NAME OR ADDRESS NEEDED: the memo mentions accommodations without saying where to go. This line is the one people will need most, and it should name a specific route.] [FIXED: moved up from the second-to-last paragraph. The original mentioned accommodations in passing near the end, after the request for flexibility.]
>
> **Why.** [HOLD: the original gave two reasons and neither can publish as written. "Research shows that in-person collaboration significantly improves team performance and innovation" needs a specific source. The internal claim that co-located teams "shipped 30% more" needs the source, the definition of shipped, which teams were compared, and over what period. Provide both, or state the reason as a leadership decision without the supporting numbers. A memo that cites a number everyone can question is weaker than a memo that cites none.]
>
> **Questions.** Bring them to your manager first. For anything about your specific arrangement, contact People Ops at [ADDRESS NEEDED].
>
> The updated handbook section is here: [LINK NEEDED: the URL is missing from the draft].
>
> People Operations

**Applied throughout:** "Jan 1st" corrected to January 1, "All Staff" lowercased to match the rest of the header block, "we're" and "folks" replaced for register consistency with the rest of the memo, the closing paragraph of appreciation removed as it added no information and delayed nothing but the reader, sections given bold labels so the memo can be skimmed for the part that applies to each reader.

## Author flags

1. **The 30% figure.** Source, definition, comparison group, period. Or cut it.
2. **The research claim.** Name the research or state the decision without it.
3. **The handbook link.** Missing entirely.
4. **The accommodations contact.** Name a person or an address.
5. **The date managers will set schedules.**
6. **Employment review.** This memo changes a condition of employment and describes an accommodations process. Route it before sending.

## Coaching note

The two numbers in this memo were meant to make the decision feel justified, and they do the opposite: they hand every person who disagrees a specific thing to argue with, and they invite a reply asking which teams and how "shipped" was measured. If a number is not solid enough to survive that question in a public channel, it makes the memo weaker than saying nothing. Either bring the real analysis, or state the decision plainly and own it as a decision. Both are defensible. A soft number is not.

One question: has the accommodations process actually been confirmed with whoever administers it? The memo promises existing accommodations will be honored, and that promise should be verified before it is made in writing to everyone.
