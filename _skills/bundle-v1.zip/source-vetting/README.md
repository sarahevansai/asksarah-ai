# Source Vetting

A Claude skill that turns any topic, claim, draft, or pile of links into a research brief built on real, named, checkable sources, plus a written log of everything it threw out and why.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

## What it does

Most bad writing is not badly written. It is badly sourced. A number nobody can trace. A study that says something different from what the article claimed. An outlet that turned out to be selling the thing it was measuring.

Give Claude a topic, a thesis, a draft, or a list of links, and you get back:

1. A research brief organized by section, with a real source and a real link for each argument
2. A rejection log naming every source that was evaluated and killed, the reason, and what replaced it
3. A section listing what could not be sourced, and exactly what would have to be found to close each gap
4. One coaching note that makes your next piece stronger without help

**You always get the brief.** Ask whether one link is any good and you get the answer plus the sourced section it belongs to. Give a thin topic and Claude forms the thesis itself, says so in one line, and produces the brief anyway. You never have to reply to get something you can use.

It is built for anyone who has to write something defensible: analysts, consultants, policy writers, journalists, graduate students, founders, researchers, and anyone whose document will be read by someone motivated to take it apart.

## The rule the whole skill is built on

**Never fabricate a source, a URL, a study, a statistic, a quote, or an author.**

A single invented citation destroys the credibility of the entire document and of the person who published it. A reader who catches one fake reference does not conclude that one reference was wrong. They conclude nothing in the piece was checked, and they stop reading.

So if a source cannot be verified, it does not go in the brief. Where a claim needs support that cannot be found, the brief says so plainly and names what would need to be found. That honest gap is more useful than a citation that will not survive a click.

The skill also chases every statistic to its origin. News coverage and industry summaries are maps, not destinations. Numbers get rounded, qualifiers get dropped, and a finding about one industry in one year becomes a universal fact by the fourth retelling.

## The method: thesis first

Generic topic research returns a reading list. Thesis-first research returns something you can cite.

You decide what you are arguing before you go looking. Every section of the piece gets its own claim and its own sources, rather than a pile of links assigned to a subject. That makes searches specific enough to succeed, puts every source where it is needed, and exposes the argument you cannot support early, while you can still change it.

It also searches for the evidence against you. If the disconfirming evidence is stronger, the brief says the thesis is wrong and proposes the corrected one.

## What gets a source rejected

Six questions on every source: who published it and what their incentive is, whether it is primary or a retelling, how old it is and whether age matters for that particular claim, whether the methodology is stated, whether the number has a traceable origin, and whether the outlet has a named author and a corrections policy.

Six hard gates, each with a defined next move:

1. A vendor page selling the thing it is measuring
2. Content marketing dressed as research
3. A survey run by the company that benefits from the result
4. An outlet with no named author or corrections policy
5. A statistic circulating with no primary source anyone can find
6. Anything behind a claim your reader cannot check

Default age cutoff is three years, tightening to eighteen months for fast-moving subjects, with labeled exceptions for foundational work, law, long-cycle data, and deliberate historical comparison.

## The rejection log

Every run produces one, and an empty log is treated as a red flag rather than a clean result.

It is the part people skip and the part that compounds. Bad sources are usually well optimized and sit at the top of every search. Without a written record, the same attractive vendor report gets re-found and re-evaluated next week, and half the time it slips through. The log also proves the work happened and answers the "why didn't you use the obvious source" challenge before it arrives.

## Five modes

- **Build a research brief** from a thesis, an outline, or a topic
- **Vet a list of sources** you already have, with a verdict and a replacement for each
- **Find support for a specific claim**, and get told plainly when it is unsupported or only supported in a narrower form
- **Extract the checkable statistics** from a document, sorted into verified, misstated, and unsourced
- **Audit a finished piece** for unsupported claims, including causal language sitting on correlational evidence

## Try it

Once installed, say any of these:

- "Find sources for this" and paste your outline
- "Is this source credible?"
- "Where did this statistic come from?"
- "Fact check these claims"
- "Can I cite this?"
- "Audit my draft for anything I cannot support"
- "Back this paragraph up with data"

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `source-vetting.zip` in your skills settings. Claude loads it automatically whenever research or sourcing comes up.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/source-vetting/
```

For a single project instead, use `.claude/skills/` inside the project.

**Verify it is working**

Start a new conversation, paste a paragraph containing a statistic, and say "where did this number come from." You should get a traced origin or an explicit finding that the origin is not locatable, plus a rejection log.

## What is in the package

```
source-vetting/
├── SKILL.md                      The method, the honesty rule, the gates, the output format
├── README.md                     This file
├── LICENSE
└── references/
    ├── vetting-rules.md          Full criteria and gates, with 12 worked borderline judgments
    └── examples.md               3 complete research briefs: a policy memo, an investigative
                                  feature, and a school board decision paper
```

## Notes

Claude will not invent a citation to fill a gap. If a source cannot be verified, it does not appear, and the gap is named instead with what would need to be found. That is deliberate. A confident document built on one made-up reference is worse than an honest document with a hole in it.

Sources in the example briefs are described generically on purpose, so that nothing in the package can be mistaken for a real citation. Real runs use real, retrieved links.

Claude will ask at most one question, and only after the brief is already in front of you.

## Support

Questions, or want this adapted for your team: [asksarah.ai](https://asksarah.ai)
