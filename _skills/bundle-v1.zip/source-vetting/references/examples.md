# Examples

Three complete research briefs, on three different kinds of work: a policy memo, an investigative feature, and a school board decision paper.

**Read this first.** Every source below is described **generically**, for example "the national transit agency's annual ridership release" or "a peer-reviewed sleep medicine journal article." That is deliberate. These examples teach the shape of a finished brief, and inventing realistic titles, authors, and URLs to make them look real would break the Hard Honesty Rule the skill exists to enforce.

**A real run must use real, retrieved sources with live links, opened in that session.** Where these examples show `[Link]`, a real brief shows the actual URL. Where these examples say "a national statistical agency release," a real brief names the agency, the release, the publication date, and the data collection date.

---

# Example 1: Policy memo

**Requested as:** "I need to write a memo on whether we should make the bus system free. Find me the research."

**What the user gave:** a topic, not an argument.

**Opening line delivered before the brief:**

> You gave me a topic, not an argument, so I am arguing that fare-free transit raises ridership mostly among people who already had a bus alternative, and that the decisive variable for a mid-size city is service frequency rather than fare. Tell me if you wanted the opposite case and I will re-source it.

---

## The Brief

### Section 1: What fare removal actually does to ridership

**Thesis:** Removing fares produces a measurable ridership increase, concentrated in short trips and off-peak hours, and smaller than the increase produced by comparable spending on frequency.

**Source:** Peer-reviewed transport policy journal article synthesizing outcomes across multiple fare-free programs
**Link:** [Link]
**Type:** Primary. The authors compiled and analyzed the underlying agency data.
**What it supports:** Ridership rises after fare removal, with the largest proportional increases on short and off-peak trips, and the authors state that service-level changes in the comparison cases produced larger absolute gains.
**Key figures:** Ridership change is reported as a range across the programs studied, per program, per year. Record each figure with the city, the program duration, and the baseline it is measured against. Never compress a range into a single headline number.
**Validation:** Academic publisher, no commercial stake. Primary analysis. Published within two years, and transit patterns shifted materially in the preceding period, so recency matters and was checked. Method and inclusion criteria stated. Underlying agency data named and traceable. Journal has a stated corrections process.
**Caveats:** The programs studied differ in size, duration, and pre-existing service quality, which limits how far any single figure transfers to another city. The authors say so explicitly.

**Source 2:** The transit agency's own published ridership series for a city that ran a multi-year fare-free program
**Link:** [Link]
**Type:** Primary. The agency counts its own boardings.
**What it supports:** The month-by-month boarding counts before, during, and after the program, which lets the memo show the shape of the change rather than a single percentage.
**Validation:** Agency publishes on itself, so the incentive runs toward the program looking successful. Counting method is published. Checked whether the counting methodology changed during the program period. It did not.
**Caveats:** Boardings are not riders. A rider transferring twice counts three times. State this in the memo, because it is the most common misreading of transit data.

**Counter-evidence checked:** Searched for programs that were discontinued and for evaluations finding no significant effect. Found discontinued programs and, in at least one case, a stated reason that was fiscal rather than a ridership failure. Recorded in Section 4.

---

### Section 2: Who the new riders are

**Thesis:** The ridership gain comes disproportionately from people substituting away from walking, cycling, and existing transit trips, not from people leaving cars.

**Source:** Peer-reviewed travel behavior study using before-and-after rider surveys in a fare-free city
**Link:** [Link]
**Type:** Primary
**What it supports:** The reported mode that new trips were substituted from, broken out by previous mode.
**Key figures:** Share of new trips substituted from each prior mode, with the sample size and the survey window. Record the response rate.
**Validation:** Academic. Method and instrument published. Survey population and sampling frame described. Recent enough that travel patterns are comparable.
**Caveats:** Self-reported prior mode is subject to recall error. Sample is one city. This is a directional finding, not a coefficient to apply elsewhere.

**Counter-evidence checked:** Looked for studies finding meaningful car substitution. Found the claim asserted in advocacy material but did not locate a study with a published method supporting it. That is a finding, and it appears in the unsourced-claims section rather than being quietly omitted.

---

### Section 3: What it costs and what the money displaces

**Thesis:** Fare revenue as a share of operating cost is low enough in mid-size systems that replacement is fiscally feasible, and the binding constraint is what the same money would otherwise buy in service hours.

**Source:** The national transit statistics program's annual release, which publishes fare revenue and operating cost by agency
**Link:** [Link]
**Type:** Primary. The statistical program collects the data directly from agencies.
**What it supports:** Farebox recovery ratio for the peer agencies the memo compares against, plus operating cost per service hour.
**Key figures:** Recovery ratio per agency, operating cost per revenue hour, and the fiscal year each figure covers. Publication date and data year differ here by roughly one reporting cycle, so record both.
**Validation:** Government statistical program, mandatory reporting, published methodology, long consistent series. Checked whether definitions changed between the compared years. Named author is the agency itself, which is standard and acceptable for official statistics.
**Caveats:** Recovery ratio excludes the cost of fare collection itself, which is part of the honest arithmetic. The memo should state whether the collection cost is netted out and where that figure came from.

**Link priority:** The statistics release is the inline citation. The journal synthesis is the supporting citation for the framing sentence.

---

## Rejection Log

| Source | Why rejected | Replacement |
|---|---|---|
| A fare collection technology vendor's white paper on fare policy trends | Vendor selling the thing the memo measures. Gate 1. | Followed its citations to the transit statistics program release, verified, used in Section 3. |
| An advocacy organization's "economic benefits of free transit" report | Advocacy output with an unpublished multiplier assumption driving the headline figure. Gate 2 and Question 4. | Used the peer-reviewed synthesis in Section 1 instead. The advocacy report's descriptive account of program design was retained as background, not cited. |
| A widely repeated figure on car trips eliminated by fare-free programs | No locatable primary source. Every page asserting it cites another page asserting it. Gate 5. | None. Claim cut and moved to unsourced claims. |
| A 2016 evaluation of an early fare-free program | Age. The service context and travel patterns changed materially since. | Current agency ridership series, Section 1. |
| A syndicated listicle of transit statistics with no byline | No named author, no corrections policy, no original data. Gate 4. | Not needed. Its claims were either sourced elsewhere or unsupported. |

---

## What Could Not Be Sourced

**Claim: "Fare-free transit takes cars off the road."**
Could not be supported. The available behavior studies find substitution mostly from walking, cycling, and existing transit. The car-reduction claim appears in advocacy material without a published method.
*What would need to be found:* a before-and-after study measuring vehicle kilometres travelled, or household car ownership, in a fare-free city, with a control comparison.
*Recommendation:* cut it, or replace with the supported sentence: new trips come predominantly from riders substituting away from walking, cycling, and previously paid transit trips.

**Claim: "Free fares reduce operator assault incidents by removing fare disputes."**
Partially supported at best. Agencies report incident counts, but incident reporting practices change alongside policy changes, which confounds the comparison, and no study was found that controls for reporting change.
*What would need to be found:* an incident series with a stable reporting definition spanning the policy change, ideally with an unaffected comparison system.
*Recommendation:* state it as a mechanism operators describe, attributed to operators, not as a measured effect.

**Claim: the specific cost of fare collection in this city.**
Not publicly available. This is internal to the agency.
*What would need to be found:* the agency's own budget line for fare collection, obtainable by request.
*Recommendation:* request it before the memo is finalized. It is load bearing for the fiscal argument, and the memo should not estimate it.

---

## Coaching Note

Your instinct was to research "free transit," and that returns advocacy on both sides because it is a topic rather than a claim. The three claims in this memo each have a different literature behind them, and two of them turn out to be well measured while the popular one is not. Decide the sentence before you search, every time. It is the difference between finding out what is true and finding out what people say.

---

# Example 2: Investigative feature

**Requested as:** "I'm writing about a farming region running out of water. Vet what I have and fill the gaps."

**What the user gave:** eleven links and a rough outline. Mode 2 into Mode 1.

---

## The Brief

### Section 1: The aquifer is being drawn down faster than it recharges

**Thesis:** Groundwater levels in the region have declined continuously over the measured period, and the decline is structural rather than an artifact of a dry cycle.

**Source:** The national geological survey's groundwater monitoring well data for the region
**Link:** [Link]
**Type:** Primary. The survey operates the wells and publishes the readings.
**What it supports:** Water level readings per well, per year, over the full monitoring period, which is what establishes that the decline persists across wet years as well as dry ones.
**Key figures:** Level change per well over the period, number of wells in the network, and the years covered. Report the range across wells, not an average, because the spatial variation is part of the story.
**Validation:** Government scientific agency, no commercial stake, method and instrument documented, continuous long series. Age is not a concern because the series is current and the historical readings are the point. Checked for gaps in the record and for wells that were relocated or decommissioned.
**Caveats:** Monitoring wells are unevenly distributed. Areas with no wells are not areas with no decline. Say so in the piece.

**Source 2:** Peer-reviewed hydrology article estimating recharge rates for the aquifer system
**Link:** [Link]
**Type:** Primary
**What it supports:** The estimated natural recharge rate, which is what turns a declining level into a statement about sustainability.
**Validation:** Academic, method and model assumptions published, uncertainty range reported. Cite the range, never the midpoint alone.
**Caveats:** Recharge estimates are model output, not measurement. The piece must say "estimated" and give the range.

**Counter-evidence checked:** Looked for published work arguing the decline is cyclical. Found regional variation in the rate but no published challenge to the direction over the full period.

---

### Section 2: Irrigation is the dominant withdrawal

**Thesis:** Agricultural irrigation accounts for the large majority of withdrawals from the aquifer, which means municipal conservation cannot arithmetically solve the problem.

**Source:** The national water use survey, most recent release, county-level withdrawal estimates by category
**Link:** [Link]
**Type:** Primary
**What it supports:** Withdrawal volume by use category for the counties in the region.
**Key figures:** Volume by category and the share irrigation represents. Record both the publication year and the data year, which differ by several years in this program. That gap is material and belongs in the piece.
**Validation:** Government statistical program with published estimation methodology. Note for the reader that these are estimates built from reported and modeled components, not meter readings.
**Caveats:** The estimation method means precision is lower than the digits suggest. Round appropriately and say the figures are estimates.

---

### Section 3: The regulatory structure allocates more water than exists

**Thesis:** The volume of water allocated under existing rights exceeds the sustainable yield, and the allocation instrument has no mechanism that adjusts to measured levels.

**Source:** The state water authority's published allocation register and the governing statute as enacted
**Link:** [Link]
**Type:** Primary. The register is the authority's own record. The statute is the law itself.
**What it supports:** Total allocated volume, and the statutory text showing what triggers a reduction and what does not.
**Validation:** Official record and primary legal text. **Age exception, labeled:** the statute predates the three-year cutoff by a wide margin, which is correct because it is the operative law. Checked for amendments and for litigation altering its interpretation. Both checks are part of citing law, and both were run.
**Caveats:** Allocated volume is not withdrawn volume. Many rights go partly unused in a given year. The piece must not conflate the two, and this is the most likely place for a knowledgeable reader to catch an error.

---

### Section 4: The economic consequence is already visible in land use

**Thesis:** Acreage in the region has shifted toward lower-water crops and out of production entirely, and the shift began before any regulatory change.

**Source:** The agricultural census and its intercensal survey, county-level acreage by crop
**Link:** [Link]
**Type:** Primary
**What it supports:** Acreage by crop and by irrigation status across census years.
**Validation:** Government statistical program, mandatory response, long series, published method. **Checked whether crop categories or county boundaries were redefined between the compared census years,** which is the standard failure point for this kind of comparison.
**Caveats:** Census years are spaced several years apart, so the series shows steps rather than a continuous trend.

---

## Rejection Log

| Source | Why rejected | Replacement |
|---|---|---|
| An irrigation equipment manufacturer's report on regional water efficiency | Vendor selling the thing being measured. Gate 1. | Its technical specification was retained as a primary source for equipment capability only, attributed as the manufacturer's own specification. All market and need claims dropped. |
| A commodity group's study on the economic contribution of regional agriculture | Trade association economic impact study with an unpublished multiplier. Vetting rules, Case 2. | Agricultural census acreage data, Section 4. The association's description of the industry's structure was kept as background, uncited. |
| A widely quoted figure on years of water remaining | Traced to a conference presentation with no published method, then repeated across dozens of pages. Gate 5, and a mutation case: the original was a scenario, not a projection. | Cut. Moved to unsourced claims with the correction. |
| Three news articles summarizing the geological survey data | Retellings. Question 2. | Went to the survey data directly, Section 1. One of the three was retained as a source of a named on-record quote, which is what it was actually primary for. |
| A 2015 hydrology paper on the same aquifer | Superseded by a more recent estimate using the same method with a longer record. | The current paper, Section 1. |
| A regional blog aggregating water statistics | No named author, no corrections policy, no original data. Gate 4. | Not needed. |

---

## What Could Not Be Sourced

**Claim: "The aquifer will be exhausted within a specific number of years."**
Unsupported as stated. The widely circulated figure traces to a scenario presented at a conference, not a published projection, and scenarios are conditional by construction.
*What would need to be found:* a peer-reviewed depletion projection with published assumptions and an uncertainty range, or the modeling agency's own published scenario set with its conditions stated.
*Recommendation:* cut the number. Replace with the measured decline rate and the estimated recharge rate, both sourced, and let the reader do the arithmetic that the evidence actually supports.

**Claim: individual farm-level withdrawal volumes.**
Not publicly available in this jurisdiction. Withdrawal reporting is confidential.
*What would need to be found:* a records request outcome, an aggregated release at a coarser level, or on-record interviews with operators willing to state their own figures.
*Recommendation:* pursue the records request, and in the meantime write at the county level where the data is public.

**Claim: "Regulators knew and did nothing."**
Not supported by any document reviewed. This is a characterization, not a finding.
*What would need to be found:* internal correspondence, meeting minutes, or a commissioned assessment showing what was known and when. Meeting minutes are often public and are the first place to look.
*Recommendation:* do not publish the characterization. Publish the document trail if the records produce one, and let it speak.

---

## Coaching Note

Six of the eleven links you brought were retellings of two underlying datasets. That is the normal ratio, and it is why the primary-source rule matters more than any other habit here. When you find four articles saying the same number, you have not found four sources. You have found one source and three repetitions, and only one of the four is worth citing.

---

# Example 3: School board decision paper

**Requested as:** "Audit my draft. Someone on the board is going to try to take it apart."

**What the user gave:** a finished six-page paper arguing for a later high school start time. Mode 5.

---

## The Brief

### Section 1: Adolescent sleep timing is biological

**Thesis:** The shift toward later sleep onset in adolescence is driven by developmental changes in circadian timing, not solely by behavior or device use.

**Source:** Peer-reviewed sleep medicine review of adolescent circadian phase
**Link:** [Link]
**Type:** Primary for its synthesis, and it names the underlying studies.
**What it supports:** The documented developmental shift in circadian phase during adolescence and its typical timing.
**Validation:** Academic publisher, named authors with verifiable affiliations, funding disclosed, method for the review stated. **Age exception, labeled:** the foundational chronobiology work predates the cutoff and has not been superseded. Paired with a recent review confirming it still stands, which is the correct way to use a foundational source.
**Caveats:** Population averages. Individual variation is wide, and the paper says so.

**Draft audit result:** the draft said devices cause the shift. The evidence says devices can worsen it and do not cause it. **Corrected sentence supplied.**

---

### Section 2: Start times are the binding constraint on total sleep

**Thesis:** In districts that moved start times later, students gained sleep, and the gain was not offset by correspondingly later bedtimes.

**Source:** Peer-reviewed study measuring student sleep before and after a district-wide start time change, with a comparison district
**Link:** [Link]
**Type:** Primary
**What it supports:** Measured change in total sleep duration, and measured bedtime change, which is the specific objection this section exists to answer.
**Key figures:** Minutes of additional sleep, change in bedtime, sample size, grade levels, measurement method, and study duration. If sleep was self-reported rather than measured with actigraphy, that belongs in the brief and in the paper.
**Validation:** Academic, comparison group present, method published, funding disclosed. Recent.
**Caveats:** One district. Transfers to a comparable district with caution stated.

**Counter-evidence checked:** Searched for studies finding bedtimes drifted later and cancelled the gain. Found the concern raised in commentary. Did not locate a study with a published method demonstrating full offset. Recorded in unsourced claims as a live open question rather than treated as settled in either direction.

---

### Section 3: The operational cost is transport, not staffing

**Thesis:** The dominant cost of a start time change is bus fleet scheduling, and its size depends on how many tiers the district runs.

**Source:** A published cost analysis from a district that made the change, with its own line-item figures
**Link:** [Link]
**Type:** Primary for that district's own costs.
**What it supports:** The categories of cost incurred and their relative size in one real implementation.
**Validation:** Public body reporting on itself, which is primary and also interested, since the district had a position. Line items are auditable in the published budget. Attribute plainly.
**Caveats:** Fleet size, geography, and tier structure differ by district. This is an illustration of cost structure, not a cost estimate for another district. The paper must not present another district's number as its own forecast.

**Draft audit result:** the draft used another district's total cost figure as this district's expected cost. **Rejected.** Replaced with the cost structure plus a named request for the district's own transport analysis.

---

## Rejection Log

| Source | Why rejected | Replacement |
|---|---|---|
| A sleep product company's survey of teen sleep habits | Survey run by a company that benefits from the result. Gate 3. | Peer-reviewed measured study, Section 2. |
| An advocacy campaign's summary page of start time research | Retelling, and selectively assembled. Question 2. | Followed its citations to the underlying studies, verified each, used two. |
| A statistic on academic performance gains from later start times | Traced to a single study reporting a small effect on one outcome in one district, circulating as a general claim. Mutation case, vetting rules Case 8. | Narrow sentence supplied. Broad claim cut. |
| A news article about the sleep review in Section 1 | Retelling. | Went to the review. |
| An eleven-year-old survey of district start times | Age, and the underlying distribution has shifted. | Current national education statistics release on school start times. |

---

## What Could Not Be Sourced

**Claim: "Later start times raise graduation rates."**
Not supported at the strength stated. The available evidence is observational, and the draft used causal language. Vetting rules, Case 9.
*What would need to be found:* a study with a design capable of supporting a causal claim, such as a staggered rollout across districts with a credible comparison.
*Recommendation:* rewrite as association, or cut. The supplied replacement sentence states the association and names the study design, which is both true and more persuasive to a skeptical reader than an overreach they can dismantle.

**Claim: "This will cost the district roughly [figure]."**
Unsupported. The figure came from another district with a different fleet and tier structure.
*What would need to be found:* the district's own transport department analysis of a tier change.
*Recommendation:* request it. Until it exists, present the cost structure and the range from comparable districts, labeled as comparable and not as a forecast.

**Claim: "Most parents support the change."**
Unsupported. No survey of this district's parents was found.
*What would need to be found:* a district survey with a published instrument and response rate.
*Recommendation:* cut, or run the survey. A board member will ask, and "we did not measure it" is survivable while an unsourced "most parents" is not.

---

## Coaching Note

The paper's weakest point was not a missing source. It was one verb: your draft said later start times "improve" graduation rates where the evidence supports "are associated with." A board member who knows the difference will use that one word to discredit the eleven things you got right. Match the verb to the study design, every time, and the argument gets harder to attack rather than softer.
