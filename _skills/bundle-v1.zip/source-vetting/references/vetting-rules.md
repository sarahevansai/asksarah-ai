# Vetting Rules

The full criteria, the gates, and worked judgments on the cases that are genuinely hard.

Everything here serves the Hard Honesty Rule in SKILL.md: never fabricate a source, a URL, a study, a statistic, a quote, or an author. If it cannot be verified, it does not go in the brief. The rules below are the machinery for deciding what "verified" means in practice.

All sources described in this file are described generically for illustration. A real run cites real, retrieved sources with live links.

---

## Part 1: The six questions in full

### Question 1: Who published it, and what is their incentive?

Identify the actual publishing body, not the domain. A named institute, an agency, a journal with a publisher behind it, a company, a trade group, a foundation, an individual.

Then write one sentence naming what outcome benefits them. Every source has an incentive. Naming it is not an accusation, it is a disclosure the reader is owed.

Typical incentive shapes and what they do to a finding:

| Publisher type | Incentive to watch for | Effect on use |
|---|---|---|
| Government statistical agency | Program justification, political pressure on definitions | Generally strong. Check whether definitions changed between releases. |
| Peer-reviewed journal | Novel and positive results are easier to publish | Strong. Watch for publication bias in a thin literature. |
| University research center | Funder priorities, institutional promotion | Strong when funding is disclosed. Look for the funding statement. |
| Trade association | The industry it represents looks healthy and deserving | Usable with the incentive stated. Never the sole source on the industry's importance. |
| Consultancy or analyst firm | Sizing a market they sell advice into | Usable for framing, weak for magnitude. Chase their underlying data. |
| Advocacy organization | The problem they exist to solve looks large | Usable when the method is published. State the affiliation inline. |
| Company reporting on itself | Almost everything | Primary and citable for facts about itself: revenue, headcount, product specification, official position. Never for the size or urgency of the need it sells into. |
| Individual writer, no affiliation | Attention | Reject unless they hold original data and a verifiable expertise. |

The one asymmetry worth internalizing: a source is strongest when it reports something **against its own interest**. An industry body reporting that its sector shrank, a company disclosing a defect, an agency publishing a program's failure. Weight those heavily.

### Question 2: Is this a primary source or a retelling?

**Primary** means the body that produced the information is the one publishing it.

Primary includes: an agency publishing its own survey, researchers publishing their own study, a company's own regulatory filing or technical specification, a court publishing its own ruling, an archive holding an original document, a dataset from the body that collected it, a transcript or recording of the event itself.

**Retelling** is everything else, including good journalism about a study, an analyst note summarizing a report, a blog citing a paper, and an encyclopedia entry.

Retellings have one legitimate use: navigation. They tell you the primary source exists and roughly where it lives. Then you go get it.

The one exception where the retelling is the citation: when the retelling itself did original work. An investigation that assembled its own dataset, a reporter who obtained a document nobody else had, an analysis that computed something new from public data. Then that piece is primary for its own contribution and a retelling for everything else it mentions. Split the difference explicitly in the brief.

### Question 3: How old is it, and does age matter for this claim?

Default cutoff is three years, preferring two. Eighteen months for fast-moving subjects.

The real test is not the number. It is: **has the underlying reality changed since this was measured, in a way that affects this specific claim?**

A five-year-old measurement of a physical constant is fine. A five-year-old measurement of software adoption is worthless. A five-year-old measurement of a labor market is worthless if you are describing the present and essential if you are describing change over time.

Always separate the publication date from the data collection date and record both when they differ. Reports commonly publish data that is one to three years old at the moment of release. The finding is as old as the data, not as old as the PDF.

Exceptions are listed in SKILL.md. Each one must be labeled in the brief as an explicit age exception with a one line justification. An unlabeled old source looks like carelessness even when it was a deliberate and correct choice.

### Question 4: Is the methodology stated?

For anything empirical you should be able to answer:

- How many were sampled or measured
- Who or what was sampled, and how they were selected
- What exactly was asked or measured, in what words
- Over what time period
- What the authors say the limits are
- Who funded it

If a source will not tell you these, you cannot evaluate it, and an unevaluable source cannot be load bearing.

Specific method problems worth catching:

- **Self-selected samples.** An online poll of a company's own newsletter list is a measurement of that list, not of a market or a population.
- **Tiny subgroups.** A survey of 2,000 people is robust overall and can be worthless for the 43-person subgroup whose result made the headline.
- **Leading questions.** Wording drives results. If the instrument is not published, treat the number as directional at best.
- **Changed definitions.** A series that redefined its terms mid-run is not a trend. Check the notes.
- **Model output presented as measurement.** A projection is a model with assumptions. Name the assumptions or do not cite the number.

### Question 5: Does the number have a traceable origin?

Follow it back one link at a time until you reach the body that generated it, or until the trail dies.

The trail dies in three recognizable ways:

1. **Circular citation.** A cites B, B cites C, C cites A. Common with round numbers.
2. **The dead end.** Everyone cites one article and that article cites nothing.
3. **The mutation.** You reach the origin and it says something different: a different population, a different year, a narrower scope, or a hedged version of the confident number in circulation.

All three mean the same thing. The figure does not go in the brief as fact. The mutation case is the most useful to report, because you can hand the user the correct version of a number they were about to publish wrong.

### Question 6: Does the outlet have an editorial standard?

Look for:

- A named author whose identity and expertise can be verified elsewhere
- A masthead, an editorial team, or a named responsible institution
- A stated corrections or retraction policy, and evidence it has been used
- Disclosure of funding, ownership, and conflicts
- A separation between editorial content and sponsored content that is actually visible on the page

The corrections point is the sharpest single test. An outlet that has published for years and never corrected anything is not more accurate than everyone else. It just does not correct.

---

## Part 2: The exclusion gates and what to do with each

Restating the gates from SKILL.md with the operational detail.

### Gate 1: A vendor page selling the thing it is measuring

**Reject.** Includes product pages, solution pages, ROI calculators, and "the state of the industry" pages hosted on a seller's domain and shaped around their category.

*Next move:* read it for its citations, follow those to origin, verify, cite the origin. Never cite the seller. Log the rejection so nobody re-finds it.

*The exception that is not an exception:* a vendor is a legitimate primary source for facts about itself. Its own published technical specification, its own pricing, its own filing, its own stated position. Cite it for those, attribute it plainly, and never let it carry a claim about the market's need for what it sells.

### Gate 2: Content marketing dressed as research

**Reject.** Signals, any three of which is enough: a form in front of the download, no methodology section, suspiciously round numbers, a conclusion that maps onto a product category, no named researcher, a survey of the sponsor's own customers, and heavy design with thin evidence.

*Next move:* mine it for citations and discard the wrapper.

*The narrow admission:* if it contains genuinely original data, publishes its method, and discloses the sponsor, it can be used with the sponsorship stated inline in the brief and in the finished piece. That is a downgrade, not a pass. Never the sole support for a load-bearing claim.

### Gate 3: A survey run by the company that benefits from the result

**Reject as an independent finding.** Commissioning a reputable third party to run it does not fix the conflict. The sponsor chose the questions, the population, and whether to publish.

*Next move:* look for an independent measurement of the same phenomenon. If none exists, that absence is itself a reportable finding. Put it in the unsourced-claims section: the only available measurement of this is produced by an interested party, and an independent measurement would need to come from a named type of body.

### Gate 4: An outlet with no named author or corrections policy

**Reject.** No byline, no masthead, no contactable human, no correction history.

*Next move:* re-source the underlying claim from somewhere accountable. If the claim exists nowhere accountable, it is not established, and it belongs in the unsourced section.

### Gate 5: A statistic with no locatable primary source

**Reject.** The tell is many confident repetitions and no origin.

*Next move:* state in the brief, explicitly, that the figure is widely repeated and has no locatable origin, and recommend it be cut. Then look for a real measurement of the same phenomenon.

This is one of the highest value things a brief does. Orphan statistics are how otherwise careful documents get embarrassed, because they are so widely repeated that they feel like common knowledge.

### Gate 6: Anything behind a claim the reader cannot check

**Reject as load bearing.** Hard paywalls with no abstract or method, private datasets, internal figures, off-the-record conversation, a document available to you and not to the reader.

*Next move:* find the public equivalent: preprint, author's copy, the funding body's summary, a regulatory filing, an archived version, the agency's data portal. If nothing public exists, the claim may appear but must be labeled as unverifiable by the reader and may not be the sole support for anything important.

*A note on paywalls:* a paywalled journal article with a public abstract, method summary, and DOI is usually acceptable, because a motivated reader has a defined path to it and the record is permanent. A number with no public trace at all is not.

---

## Part 3: Worked judgments on borderline cases

These are the calls that actually come up. Each is written as the situation, the judgment, and the reasoning.

### Case 1: The consultancy report with real data inside it

*Situation.* A large advisory firm publishes an annual report on adoption of a technology, based on a survey of several thousand executives. Method is described in an appendix. The firm sells implementation services for that technology.

*Judgment.* Usable, with the incentive stated inline, and never as the sole source for the headline growth number.

*Reasoning.* Real method plus real sample beats no method. The conflict is real and specific: the firm benefits from the technology looking inevitable, and executive self-report on adoption is optimistic even without a conflict. Use it for direction and texture. For the magnitude of a claim, corroborate with a source that has no stake, and if none exists, say so.

### Case 2: The trade association's economic impact study

*Situation.* An industry body publishes a study finding its sector contributes a large sum to the national economy.

*Judgment.* Reject for the headline number. Usable for descriptive detail about the industry's structure, membership, and practices.

*Reasoning.* Economic impact studies are the most reliably inflated genre in professional publishing, because multiplier assumptions are chosen and the choosing is not neutral. But the association genuinely does know how many members it has and how the industry is organized. Split the source: reject the advocacy output, keep the descriptive fact, and say which is which.

### Case 3: The eight-year-old study that everyone still cites

*Situation.* One study established a finding, it is cited constantly, and no replication or update exists.

*Judgment.* Usable as an explicit age exception, labeled, with two additions: state that it is unreplicated, and put the replication in the unsourced-claims section as what would need to be found.

*Reasoning.* Sometimes one study is the entire literature. Pretending otherwise by finding a fresher but weaker source is worse. The honest move is to use the best evidence there is and be precise about how thin it is. Also check whether the intervening years produced a failed replication, which changes the answer completely.

### Case 4: The government statistic whose definition changed

*Situation.* An official series shows a sharp move, and the agency's notes reveal the definition or collection method changed in that period.

*Judgment.* Do not cite the change as a trend. Cite each period separately, or cite the agency's own reconciled series if it published one.

*Reasoning.* A definitional break looks exactly like a real move and is the most common way an honest writer publishes something false. Always read the methodological notes on any series before citing a change over time. This is the single most under-performed check in the whole method.

### Case 5: The preprint with a striking result

*Situation.* A preprint reports a strong finding. It has not been peer reviewed.

*Judgment.* Usable with the preprint status stated in the brief and in the finished piece. Never the sole support for the central claim of a document.

*Reasoning.* Preprints are real research and they are also unfiltered. The reader deserves to know which they are getting. Check whether it has since been published, whether the published version changed the finding, and whether anyone credible has publicly disputed it.

### Case 6: The news article that did original work

*Situation.* An outlet obtained records nobody else had and built an analysis from them.

*Judgment.* Primary for its own analysis and its own documents. Retelling for everything else it mentions.

*Reasoning.* Original reporting is original evidence. Cite it for what it produced, and follow its other citations to their origins as normal. Where the underlying documents were published alongside the piece, cite those too, because they will outlive the article.

### Case 7: The company's own technical specification

*Situation.* You need the capability of a product and the only source is the manufacturer's published specification.

*Judgment.* Cite it, attributed as the manufacturer's own published specification.

*Reasoning.* The maker is the primary source for what the thing is. It is not a source for whether the thing is better than alternatives, or for how large the need for it is. Attribute plainly and let the reader apply the discount. Where an independent test exists, cite that alongside.

### Case 8: The number that is real but narrower than the claim

*Situation.* The user wants to say a practice is widespread. The best evidence is a well-run study of one industry in one country over one year, showing it is common there.

*Judgment.* Reject the broad claim, deliver the narrow sentence.

*Reasoning.* This is the most frequent and most fixable failure in professional writing. The evidence is good. The sentence is too big for it. Hand the user the exact sentence the evidence supports, in quotation-ready form, and put the broad version in the unsourced-claims section naming what would need to be found: a multi-country or multi-industry measurement from a comparable design.

### Case 9: Correlation written as cause

*Situation.* An observational study finds an association. The draft says one thing causes the other.

*Judgment.* Reject the causal sentence. Supply the associational one.

*Reasoning.* Study design determines the verb. Observational work supports "is associated with." Causal language needs an experiment, a natural experiment with a credible identification strategy, or a body of work the authors themselves describe as causal. Flag this separately in any audit, because it is the most damaging error that careful writers make, and it is invisible until someone knowledgeable reads it.

### Case 10: Two credible sources that disagree

*Situation.* Two well-run studies report materially different numbers for the same thing.

*Judgment.* Report both, with the reason for the divergence if you can find it, and do not silently pick the friendlier one.

*Reasoning.* Picking the convenient number and hiding the other is a quiet form of fabrication: the document asserts a settled fact where the evidence is contested. Usually the divergence has a findable explanation such as different populations, different definitions, or different years. Explaining it makes the piece stronger than either number alone. If there is no explanation, say the measurement is contested and give the range.

### Case 11: The source you cannot open

*Situation.* A link fails, is region blocked, or resolves to a page that does not contain the cited material.

*Judgment.* It does not go in the brief. Full stop.

*Reasoning.* This is the Hard Honesty Rule in its most literal form. A citation you could not open is a guess about what a page says. Try the archived version and the publishing body's own site. If neither works, log it as unverifiable and move on. Never cite from a description of a page.

### Case 12: The user's own data

*Situation.* The user wants to cite internal figures their organization holds.

*Judgment.* Usable, labeled as internal and unaudited, with the method stated, and never as the sole support for a claim about anyone other than themselves.

*Reasoning.* An organization is primary for facts about itself. The reader cannot check it, so the label is mandatory and the claim must stay within the organization's own boundary. "Our support volume fell by a third after the change" is fine when labeled. "This approach cuts support volume by a third" is a claim about the world that internal data cannot carry.

---

## Part 4: The rejection log format

One line per rejected source. Keep it terse and specific.

```
| Source | Why rejected | Replacement |
|---|---|---|
| [Name, link] | Vendor selling the category | [Origin study it cited, verified and used in Section 2] |
| [Name, link] | Sponsored survey, sponsor benefits from result | None found. Logged as a gap in Section 4. |
| [Name, link] | 2018 data, subject moved | [Current release from the same agency] |
| [Name, link] | No locatable primary source | Claim cut. See unsourced claims. |
```

Rules:

- Every rejection names a replacement or says explicitly that none was found. A rejection with no replacement and no note is an unfinished job.
- Reasons that expire, such as age, get re-checked on the next run. Reasons that do not expire, such as a vendor conflict, carry forward permanently.
- Carry the log between runs on the same subject. Its whole value is preventing the same attractive bad source from being re-found and re-evaluated next week.
- An empty log means the search was too narrow or the gates were not applied. Retrace before delivering.
