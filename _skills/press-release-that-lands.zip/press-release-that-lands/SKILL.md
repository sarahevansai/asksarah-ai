---
name: press-release-that-lands
description: >
  Writes press releases a journalist can actually use, and tells you honestly whether you
  have news before a word gets written. Use whenever someone is announcing, launching,
  hiring, raising, partnering, expanding, publishing data, winning something, or responding
  to an event. Trigger on "write a press release," "draft an announcement," "is this
  newsworthy," "do we even have news," "announce our funding," "we're launching," "we just
  hired," "we signed a partnership," "rewrite this release," "fix this headline," "punch up
  our announcement," "write the media alert," "our release got no pickup," "why did nobody
  cover this," "make this sound like news," or any draft release pasted in for review. Also
  trigger unprompted when someone describes something they plan to announce, when a draft
  leads with the company instead of the change, when a quote says the word "excited," or
  when the one fact that makes the story interesting is missing or buried below the fold.
  When in doubt, run it. It is better to hand someone a usable release and an honest verdict
  than to let an internal announcement go out dressed as news.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Press Release That Lands

Most press releases are internal announcements wearing a costume.

They lead with the company instead of the change. They quote an executive saying something no human has ever said out loud. They bury, or leave out entirely, the one fact that made the thing worth writing about. Then the release goes out, nothing happens, and everyone blames distribution.

Distribution is almost never the problem. The problem is that there was no news in the release, or there was news and it was on line fourteen.

This skill does two jobs. It tells you honestly whether you have news, and it writes the release a general assignment reporter could file from without calling you.

---

## The #1 rule: always deliver the release

**Every run ends with a complete, written release and an honest verdict on whether it is news.**

Never a critique with no release attached. Never a refusal to write. Never an offer to write it once they answer some questions.

This holds even when:

- The newsworthiness gate fails. Say so in one line, write the strongest possible version anyway, and name the one fact that would turn it into real news.
- The user only asked "is this newsworthy." Answer the question, then hand them the release.
- The user only asked about the headline. Fix the headline, then deliver the whole release with the fix in place.
- Facts are missing. Draft with `[BRACKETS]` and name exactly what goes in each one. A bracketed release is a deliverable. A list of questions is not.
- The draft they pasted was already decent. Say so, then deliver the tighter version.
- There is no quote and no quotable person named. Write the bracketed placeholder per the quote rules below and keep going.

**Never end a response with a question instead of a release.** If a missing fact would change the story, deliver the release first, then ask the one question that would sharpen it.

**A template is not a release.** Handing back a skeleton with blank slots is the most common way this rule gets broken while appearing to be followed. If the user described a real announcement, the release is about their announcement, with their details in it. Skeletons live in `references/templates.md` and are raw material for you, not output for the user.

The user gets a usable document every time. That is the product.

---

## Part One: The Newsworthiness Gate

Run this before writing a word. It takes ten seconds and it is the difference between a release and a memo.

A release needs at least one of these five. Not a version of one. One of them, plainly present.

**1. A number that is new or surprising.**
Not a number that exists. A number nobody outside the company had. Revenue growth, adoption, cost, time, failure rate, survey result, price change.

**2. A first, a largest, or a genuine change of state.**
Something is now true that was not true before, and the change is verifiable. First in a category, largest of its kind, a threshold crossed, a status changed. "First" claims must be narrow enough to be true and broad enough to matter.

**3. A decision with consequences for someone outside the company.**
Customers pay less. A market gets a product it did not have. A policy changes for people who did not ask for it. If the only people affected work there, it is an internal announcement.

**4. A conflict, a reversal, or a risk being addressed.**
The company changed its mind, took a side, is fixing something that went wrong, or is moving against the direction of its industry. Journalists are drawn to tension. Most companies write it out of the release on purpose.

**5. A human being who is actually affected.**
A named person whose situation changed because of this. Not a persona, not a segment, not "customers." A person a reporter could call.

### How to run the gate

Name which one you are running on, in one line, before the release. Be specific: not "this has a number," but "running on element 1: the 40 percent reduction in claim processing time is a figure nobody outside the company had."

If two or three apply, name the strongest one. That is the one the headline is built on.

**If none of the five is present:** say it once, plainly, in a single line. No lecture, no paragraph on what news is. Then write the best possible version of the release, and name the one specific fact that would move it into news. Something like: "Running on none of the five. This is an announcement, not news. Get the number of customers on the waitlist, or one named customer who will speak to what changed for them, and this becomes a story."

Do not soften the verdict and do not repeat it. Say it once and move on to the work.

---

## Part Two: The Build

Eight elements. Every release has all eight, in this order.

### 1. Headline

Under about 12 words. Active voice. Contains the news, and a number where a number exists.

- No colons stacking two ideas. "Riverbend Logistics Expands: A New Chapter in Regional Freight" is two headlines pretending to be one.
- No company name first unless the company is genuinely the news. "Riverbend Logistics Announces" wastes the three most valuable words in the release. Lead with the change.
- No "announces," "unveils," "is proud to introduce," or "is pleased to." The release is the announcement. Saying so is a wasted verb.
- A number in the headline outperforms almost anything else you can put there.

Weak: "Cobalt Health Announces New Partnership With Regional Provider Network"
Strong: "Cobalt Health Cuts Rural Wait Times From 31 Days to 9"

### 2. Subhead

One line. Adds the second most important fact. Never restates the headline in different words.

If you cannot think of a second fact worth a subhead, that is a signal about the strength of the story, not a reason to pad.

### 3. Dateline and lead

Format: `CITY, State, Month Day, Year` followed by the lead sentence.

**The lead is the release.** Who did what, when, and why it matters, in the first sentence. If a journalist reads only that sentence, they should be able to decide whether to keep reading.

Rules:
- One sentence where possible, two at the absolute most.
- Under about 35 words.
- The most surprising fact goes in the first half of the sentence, not the second.
- No subordinate clause opening. Never start with "In an effort to," "As part of its ongoing commitment," or "Following months of."
- The company can appear in the lead. It should not be the subject of the first four words unless the company is the news.

### 4. Second paragraph: the evidence

The number, the scope, the proof. This is where the claim in the lead gets substantiated.

If the lead says wait times dropped, this paragraph says by how much, measured how, over what period, across how many locations. A reporter who believes paragraph two will use the release. A reporter who cannot verify paragraph two will not.

### 5. The quote

The rules here matter more than anywhere else in the release. See the full quote section below. In short:

A quote must say something **only that person could say.** It carries judgment, a decision, or a consequence. It never repeats facts already stated, and it never contains adjectives about how anyone feels.

**Kill on sight:** "excited," "thrilled," "proud," "delighted," "honored," "committed to excellence," "passionate about," "next level," "game changer," "perfect partner," "shared values." A quote built from these says nothing and signals that nobody senior read the release.

### 6. Supporting paragraphs

Context first, then detail, in descending order of importance.

The test: any paragraph can be cut from the bottom without breaking the story. Editors cut from the bottom. Write so that cutting costs you nothing important.

Two to four paragraphs. Include the second quote here if there is a genuine second voice, usually a customer, a partner, or someone affected. A second quote from a second executive at the same company adds nothing.

### 7. Boilerplate

What the company is, in plain words, in one short paragraph. Three or four sentences maximum.

- What it does, who it serves, where it is, when it was founded.
- No mission statement language. No "leading provider of innovative solutions."
- If the boilerplate could describe four other companies, rewrite it.

### 8. Contact block

A real name, a real email, a real phone number.

A release with only `press@company.com` reads as unserious. Reporters work on deadline. They call a person.

If the user has not given you a contact, bracket all three fields and say plainly that a generic inbox will cost them coverage.

### Scoring

After the release, score it:

`Release Standard: 4/8 → 8/8`

Then name the elements that were missing or weak in the original. Three bullets maximum.

Only score a before-number when the user actually pasted a draft. If they described a situation instead, there is nothing to score. Write `Release Standard: 8/8` alone, or `8/8 once the brackets are filled` if any remain, and name which elements the brackets are carrying.

---

## The quote rules

This is the hardest section in the skill and the one with real consequences attached.

**Never invent a quote and attribute it to a real person.** Not as a draft, not as a placeholder in disguise, not with a note saying "feel free to edit." A fabricated quote from a real executive is a serious problem, not a drafting shortcut. It can go out under that person's name, it can be repeated by a reporter as something they said, and it can end up in a story they never approved. Treat it the way you would treat inventing a revenue figure.

**Never alter a quote that was provided.** Not the wording, not the punctuation, not the capitalization. If a provided quote is weak, use it exactly as given and say so below the release: "The quote as provided restates paragraph two. Here is a stronger angle [name] could speak to if they want to revise it." Then suggest, and let them decide.

**When no quote exists,** write a bracketed placeholder that does three things:

1. Names who should say it.
2. States in one line what the quote needs to accomplish that the surrounding copy cannot.
3. Offers two or three angles the person could speak to, clearly marked as suggestions for that person to approve or replace.

Format:

```
[QUOTE TO BE APPROVED BY DANA WHITFIELD, CHIEF OPERATING OFFICER]

What this quote needs to do: explain why the company took on the cost of
rebuilding the routing system rather than patching it, which is the one
thing the facts above cannot say on their own.

Suggested angles for Dana to approve, revise, or replace:
- Why the patch approach was rejected after the second outage
- What the company is willing to trade for reliability, in her words
- What she expects customers to notice by spring
```

That block is a deliverable. It is honest, it is useful to the person who has to produce the quote, and nothing in it can go out as a fabricated statement.

**Angles are suggestions, never drafts.** Do not write out a sample sentence in the person's voice, because sample sentences get pasted in and shipped. Describe what the quote should address, not the words.

**A quote that passes:** a decision, a tradeoff, a judgment, a consequence, or something the person is willing to be held to.

**A quote that fails:** anything a competitor's CEO could say word for word about their own company.

---

## Never invent facts

Same discipline as quotes, applied to everything else.

Never invent: statistics, percentages, customer counts, employee counts, funding amounts, valuations, investor names, revenue figures, growth rates, dates, locations, awards, rankings, certifications, or client names.

Bracket them and name what is needed. Be specific about the fact, not the category.

- Good: `[NUMBER OF CLINICS LIVE AS OF LAUNCH DATE]`
- Bad: `[insert impressive stat here]`

A bracket that names the exact fact is useful. A bracket that says "add data" is homework.

**Infer structure aggressively. Never infer facts.** If the user said "a lot of customers," write `[CUSTOMER COUNT]`, not "thousands of customers." If they said the round was "led by a fund in Boston," write `[LEAD INVESTOR NAME]`, not a plausible fund name.

---

## What gets a release rejected

Wire services and newsrooms reject releases for predictable reasons. Most of them are avoidable at the drafting stage.

**Promotional review or endorsement framing.** A release that reads as a product review, a testimonial reel, or a recommendation to buy. State what the product does and what changed. Do not evaluate it on the reader's behalf.

**Comparative claims about named competitors.** "Faster than [named company]" invites a legal letter and gets rejected by most services outright. Compare to a prior state, an industry benchmark, or a published standard instead.

**Superlatives with no substantiation.** "Best," "leading," "number one," "world's first," "most advanced." Either attach the source and the measurement, or cut the word. "First" and "largest" claims need the qualifying scope right there in the sentence.

**Regulated claims in health and finance.** Anything that reads as a medical claim, a treatment outcome, an investment return, or a guarantee of financial result carries real regulatory exposure. These need legal review before distribution, not after. Flag them; do not soften them and move on.

**Anything that reads as an advertisement.** Second person address to the reader, calls to action, pricing promotions, discount codes, urgency language. A release announces. An ad sells.

Also commonly rejected: unsubstantiated financial projections, releases with no verifiable contact, releases about a company that cannot be confirmed to exist, and content that is essentially a blog post with a dateline stapled on.

**Policies differ by service and they change.** Check the current guidelines of whichever wire service or newsroom is being used before distribution. Nothing in this section replaces that check.

---

## Style

AP style conventions, applied in plain language. Practical rules, not the whole stylebook.

**Numbers.** Spell out one through nine. Use figures for 10 and above. Always use figures for ages, percentages, dollars, dimensions, and times. Spell out a number that starts a sentence, or rewrite the sentence so it does not.

**Percentages.** Use figures and the word percent in body copy: 40 percent. The % symbol is acceptable in headlines and tables.

**Money.** $5 million, $1.2 billion, $40. No cents unless the cents matter.

**Dates.** Abbreviate Jan., Feb., Aug., Sept., Oct., Nov., Dec. when a specific date follows. Spell out March, April, May, June, July always. No "th" or "st" on the day: Sept. 9, not Sept. 9th. No year for dates in the current year.

**Titles.** Capitalize a formal title directly before a name: Chief Executive Officer Dana Whitfield. Lowercase it after the name or when it stands alone: Dana Whitfield, chief executive officer.

**States.** Spell out state names standing alone. Use AP abbreviations with a city: Springfield, Ill. Eight states are never abbreviated: Alaska, Hawaii, Idaho, Iowa, Maine, Ohio, Texas, Utah. Well-known cities stand alone without a state.

**Attribution.** Use "said." Always "said." Not stated, noted, remarked, explained, shared, or commented. Name first, then said: "Whitfield said," not "said Whitfield."

**Time.** Lowercase with periods: 9 a.m., 2:30 p.m. Noon and midnight, not 12 p.m. or 12 a.m. Include the time zone for anything scheduled.

**Serial comma.** AP omits it in a simple series. Keep it where dropping it creates ambiguity.

**First reference.** Full company name on first reference, short form after. Do not put the short form in parentheses after the full name unless it is genuinely unfamiliar.

---

## Formatting and length

- **400 to 500 words** for the body. Under 350 usually means the evidence is thin. Over 600 means an editor is cutting, and they will not cut what you would have chosen.
- **Short paragraphs.** Two or three sentences. Never more than four lines on screen.
- **No bold sprinkled through the body.** Bold belongs in the headline and section labels only. Bold inside body copy reads as marketing.
- **No exclamation points.** None. Not one.
- **No jargon a general assignment reporter would not know.** No "leveraging," "synergies," "solutioning," "end-to-end," "best-in-class," "robust," "seamless," "revolutionary," "disruptive." If an internal term is unavoidable, define it in six words the first time.
- **No second person.** A release is not addressed to the reader.
- **### and ends.** Center `###` at the end, the standard end-of-release marker. Use `-more-` at a page break only when the release genuinely runs long.
- **Embargo or release timing** goes at the top: `FOR IMMEDIATE RELEASE` or `EMBARGOED UNTIL [DATE], [TIME] [TIME ZONE]`.

---

## Related assets

Two shorter things often serve better than a release. Offer them when they fit, and write them when asked.

### The media alert

For an event: something happening at a specific time and place that a reporter could attend or cover live. A launch event, a groundbreaking, a public hearing, a demonstration, a store opening.

Five lines, no prose:

```
WHAT:    [The event, in one line]
WHO:     [Named people available, with titles]
WHEN:    [Day, date, time, time zone]
WHERE:   [Full address, plus access or parking notes]
WHY:     [One or two sentences on why it matters now]

CONTACT: [Name, mobile, email]
```

An alert is 150 words at most. It is an invitation, not a story. Send it three to five days out, with a reminder the morning of.

Use the alert instead of a release when the news is that something is happening at a time and place. Use both when the event is the visible part of a larger announcement.

### The pitch email that carries the release

The release is the document. The pitch is how it gets read. Keep this brief here, since a dedicated pitching skill may handle it in depth.

The minimum viable pitch:

- **Subject line:** the headline, shortened further. No "Press Release:" prefix. No "For your consideration."
- **First line:** why this reporter, specifically. One clause, and it has to be true.
- **Second and third lines:** the news, in the same shape as the lead.
- **Fourth line:** what you can offer. An interview, data, a named customer, an image, an early look.
- **Then the release,** pasted below the signature. Not attached. Attachments go unopened.
- **Under 150 words** above the release.

No follow-up more than once, and not within 48 hours.

---

## How to run this skill

Determine the mode from what the user gives you. All modes end with a complete release.

**Mode 1: Gate an idea before writing.**
The user asks whether something is worth announcing. Run the gate, give the verdict in one line, then write the release anyway. If it fails, name the missing fact. They asked a yes or no question; give them the yes or no and the document.

**Mode 2: Write from facts provided** (the default).
The user gives you the announcement and the details. Run the gate, write the release, score it.

**Mode 3: Rewrite a weak release.**
A draft is pasted in. Run the gate on what the draft contains, deliver the rewrite, score before and after, and name the three things that were costing them.

**Mode 4: Fix the headline and lead only.**
The user asks about the top of the release. Fix it, give two or three headline options with the strongest one first, then deliver the full release with the fix in place. A headline alone is not a deliverable.

**Mode 5: Write the media alert version.**
The news is an event. Write the alert. If a release is also warranted, say so in one line and write it too.

### Before writing, know three things

1. **What actually changed,** stated as a fact rather than an intention.
2. **Who outside the company is affected,** and how.
3. **What can be proven,** and by what evidence.

Ask a maximum of two questions to fill these gaps, and only if the answers would change the structure. Otherwise draft with brackets. Never stall a release over a missing fact.

---

## Output format

Deliver in this order, every time.

**1. The release, first.**
Complete, in a copy-ready block, with the release timing line, headline, subhead, dateline, body, boilerplate, contact block, and `###`. One line above it naming what it is. Nothing else before it.

**2. The gate verdict and the score.**
Two lines:

```
Gate: running on element 2, first regional network to publish per-clinic wait times.
Release Standard: 8/8 once the brackets are filled. Brackets carry the contact block and the clinic count.
```

If the gate failed, that line says so plainly and names the missing fact.

**3. One coaching note.**
The single pattern that would most improve their next release. Written so it generalizes past this one document. One note, not five. Pick the one that costs them the most.

**4. At most one question, and only after the release.**
If a missing fact would materially change the story, ask for it below the coaching note and say what you would change once you have it. Never above the release. Never instead of it.

Do not narrate your process. Do not explain each change line by line unless asked. Do not add a summary after the coaching note.

**Hard formatting constraints on everything you produce.** These override anything absorbed from a template or an example:

- No em dashes anywhere. Not in the release, not in the gate line, not in the coaching note, not inside bracketed placeholders. Use a colon, a comma, or a period. This is the most common leak and it usually happens in your own commentary rather than in the release.
- No ellipses.
- No exclamation points.
- No bold inside the body of a release.

**Self-check before responding.** Four questions:

1. Does this contain a complete release the user could send?
2. Did I name which gate element it runs on, or say plainly that it runs on none?
3. Is every quote either provided verbatim or a bracketed placeholder with angles?
4. Are there any em dashes in it?

If any answer is wrong, the response is not finished.

---

## Reference files

Load these when the situation calls for it. Do not load all of them by default.

- `references/templates.md`: Full skeletons for the eight most common release types, each with a filled headline and lead so the shape is visible rather than described. Load when writing a release of a type you have not seen in the conversation yet.
- `references/examples.md`: Complete before-and-after rewrites across different industries, with the gate verdict and score shown, including one where the gate fails and the release gets written anyway. Load when teaching, when the user wants to see the standard applied, or when a rewrite needs a model.

---

## The final gate

Before the release goes out, five questions. If any answer is no, it is not ready.

1. Can a reporter file a short story from this without calling anyone?
2. Does the first sentence carry the whole story?
3. Would the quote be embarrassing if it appeared next to a competitor's identical quote?
4. Is every number in it something someone can verify?
5. If an editor cut everything below paragraph three, does it still work?

Number five is the one people skip. Assume the bottom half gets cut. Write so that being cut does not hurt you.
