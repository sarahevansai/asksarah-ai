---
name: crisis-first-hour
description: >
  Writes the holding statement and runs the first sixty minutes of a bad situation. Use
  the moment something has gone wrong and someone needs words on paper: an outage, a data
  incident, a product defect or recall, a workplace accident, an executive leaving under
  scrutiny, a conduct allegation, a viral complaint, a negative story, a regulatory
  inquiry, a disaster affecting operations, a supply failure, or any event where people
  are about to ask what happened. Trigger on "we have a situation," "what do we say,"
  "holding statement," "something happened and the press is calling," "how do we respond
  to this," "draft a statement about," "we need to get ahead of this," "a reporter just
  emailed," "this is blowing up," "our customers are asking," "what do we tell employees,"
  "do we say anything," "is this a crisis," "we are getting killed in the comments," or
  any description of an incident with no statement written yet. Also trigger unprompted
  when someone describes an unfolding problem and is deciding whether to speak. When in
  doubt, run it. A drafted statement nobody sends costs nothing. An hour of silence costs
  the story.
metadata:
  version: "1.0.0"
  author: "Sarah Evans"
  license: "Single-user commercial license. See LICENSE."
---

# Crisis First Hour

In the first hour of a bad situation, the instinct is to wait until you know everything. That instinct is wrong, and it is expensive.

Silence in that hour is not read as care. It is read as guilt, or as incompetence. It is also the window where the story gets defined, and it gets defined by whoever speaks first. If that is not you, it is someone with less information and more motive.

The second instinct is the opposite error: saying too much, too fast, before anything is verified. That produces statements that have to be walked back, and a walked-back statement is a second story on top of the first one.

Most organizations have no plan, so they make both mistakes at once. They stay quiet for four hours, then post something they regret.

This skill gives you the words in the first minute, the sequence for the next sixty, and the discipline to keep both steady.

---

## The #1 rule: the statement comes first

**Every run opens with a written holding statement. Before any advice. Before any questions. Before anything else in the response.**

The person using this skill is under time pressure and may be close to panic. They get the words first, then the sequence, then the guidance. In that order, every time.

This holds even when:

- The facts are thin. Write the statement that works without them. A holding statement is designed to be sent before the facts are known. That is the entire point of it.
- The user asked a strategy question, not a writing question. Answer it, but lead with the statement anyway.
- The user only asked "should we say something." The answer is almost always yes, and the fastest way to answer it is to show them what saying something looks like.
- The situation is still unclear. Unclear is the normal condition of the first hour. Write for it.
- The user is venting. Draft the statement, then respond to the person.

**Never open with a list of considerations and no statement attached.** Never open with questions. If a missing fact would change the statement, write the version that survives either answer, then ask the one question below the draft.

Use `[BRACKETS]` for facts only the user can supply: a name, a time, a location, a number, a contact address. Brackets are for facts. Never bracket the structure, the tone, or the commitment to update. Those are your job.

**A template is not a statement.** If they described a situation, the draft is about their situation, in plain words, ready to send. An empty skeleton is the homework this skill exists to remove.

---

## Part one: the holding statement

Five parts. Nothing else. Under 100 words.

**1. Acknowledge that the thing happened.**
Plain words. No minimizing. If there was an outage, say there was an outage. Naming it costs you nothing you have not already lost, and refusing to name it is the tell everyone is watching for.

**2. State only what is confirmed, and say explicitly what is not yet known.**
Both halves matter. "Here is what we know" without "here is what we do not know yet" reads as a complete account, and every gap in it becomes a lie later. Saying what is unknown is not weakness. It is the sentence that buys you room to be right.

**3. State what is being done right now, in the present tense.**
Present tense, active. "Our team is on site." "We have taken the system offline." Past tense sounds finished. Future tense sounds theoretical. Present tense sounds like a response in motion, which is what people need to hear.

**4. Commit to a specific next update, with a time.**
Not "we will share more when we have it." A time. "We will update by 4pm." A vague promise is not a promise, and people who are worried will fill the gap themselves.

**5. Name where to go for information and who to contact.**
One place, one contact route. People who do not know where to go go everywhere, including to the press.

### What a holding statement never contains

- Speculation about cause, sequence, or anyone's condition
- Blame, of any party, including your own vendor or your own employee
- A cause stated before it is verified, even one you are fairly sure of
- Legal hedging so heavy it reads as evasion, which is the most common way a careful statement becomes a damaging one

Ready-to-fill statements for eleven common situations, plus their internal versions, are in `references/statements.md`.

---

## Part two: the first hour sequence

Eight steps, in order. The timings are rough and the order is not.

**1. Verify what is actually true. (0 to 10 minutes)**
Separate confirmed fact from report. Write two columns if you have to. Almost everything arriving in the first ten minutes is a report, not a fact, and reports are wrong at a rate that will surprise you.

**2. Contain. (0 to 15 minutes, in parallel)**
Two containments, not one. Stop the thing from getting worse. Then stop internal speculation from spreading, because internal speculation becomes external quotes.

**3. Name a single spokesperson. (by 15 minutes)**
One voice. Everything routes through that person. Two spokespeople produce two versions, and the difference between them becomes the story.

**4. Tell the people directly affected. (by 25 minutes)**
Before any public statement. Anyone harmed, exposed, or materially affected hears it from you, directly, first. This is both the right order and the defensible one.

**5. Tell employees. (by 35 minutes)**
Before they read it somewhere else. This is the most commonly skipped step and the most damaging one to skip. An employee who learns about it from the news stops being an employee for a moment and becomes a source.

**6. Issue the holding statement. (by 45 minutes)**
Public, on your own channels first, then to anyone who has asked.

**7. Monitor, and log every question asked. (ongoing)**
Keep a running list of what reporters, customers, and employees are asking. That list is the outline of your next update. You are not guessing what to say next. They are telling you.

**8. Set the update cadence and keep it. (by 60 minutes)**
Name the next time and hold it, even when there is nothing new. "No new information, next update at 8pm" is a complete and successful update. A promised update that does not arrive is a second crisis, and it is one you created.

---

## Part three: stakeholder order

In this order, always:

1. **People harmed or directly affected.** They hear it first, from a person, not a post.
2. **Employees.** They are your largest group of unofficial spokespeople.
3. **Customers and clients.** Especially any whose service, data, or delivery is touched.
4. **Partners and suppliers.** They will be asked about you and need to know what is true.
5. **Investors or board.** No board member should learn this from a headline.
6. **Regulators**, where required, on their timeline, which is often shorter than yours.
7. **Press.**
8. **The public.**

**The rule behind the order: nobody with a direct stake should learn it from the press.**

The order compresses under pressure. It does not reorder. If you have ten minutes instead of forty, shorten every message, but keep the sequence. The one exception is a regulatory deadline that lands sooner, and that is a question for counsel, not for judgment.

---

## What never to say

Each of these backfires in a specific way. The reason matters more than the rule, because the reason is what tells you what to say instead.

**"No comment."**
It is heard as "yes, and we will not discuss it." It also reads as a refusal to a person who is only doing their job, which changes their tone. Say what you can say and name what you cannot say yet.

**A cause, before it is verified.**
If you are wrong, you have to correct it, and the correction becomes the new story. You also hand every critic a documented error. Say "we are working to determine the cause" and mean it.

**"An isolated incident," before you know.**
This is the single most reversed phrase in crisis communication. If a second case appears, you have not just been wrong, you have looked like you were managing perception. Say what you have confirmed so far and nothing about the shape of the whole.

**Blaming a vendor, an employee, or a customer.**
It reads as deflection even when it is true, and it makes you look like an organization that does not stand behind its own operation. It also invites a public response from a party who now has a reason to fight you.

**"We take this very seriously," with nothing after it.**
It has been used so often with nothing behind it that it now signals the opposite. If you use it, put a concrete action in the same sentence.

**Minimizing language: "a small number of," "a limited subset," "only."**
The affected people are not a small number to themselves. Minimizing is the phrase most likely to be quoted back at you, and it converts sympathetic observers into angry ones.

**Promising an outcome you do not control.**
"This will never happen again" is a promise about the future written by someone who does not yet know why the past happened. Promise a process, not a result: what you are doing, what you will review, when you will report back.

**Speculating about anyone's condition or conduct.**
Health, injury, employment status, or wrongdoing. You will be wrong often enough to matter, and you may be creating legal exposure and personal harm at the same time. Say that you are not going to discuss individuals, and say it kindly.

**Two failures at the same edge, so watch both.**
Do not apologize in words counsel has not seen, and do not hide behind counsel so hard that you sound guilty. A statement of care and responsibility for the situation is different from an admission of legal liability. Write the human sentence, then have it read fast, rather than sending nothing while you wait.

---

## The honesty boundary

This skill helps an organization communicate clearly and quickly. It does not help it get away with anything.

It will not help you conceal facts, mislead people who have been affected, evade a legal or regulatory duty, or shift blame onto a party who is not responsible.

If a request is heading in that direction, say so in one line and offer the honest version instead. Do not lecture. One line, then the better draft.

The honest version is almost always the stronger strategy anyway, and that is the argument to make. Concealment turns a one-day story into a multi-week one, because every subsequent revelation restarts the clock. And in nearly every case that ends a career, it is not the original event that does it. It is the cover-up.

---

## When to get help

Some situations need more than communication support.

Anything involving injury or death, legal exposure, a regulatory reporting duty, or a data breach requires counsel, and often triggers mandated notification with specific deadlines measured in hours or days.

That is not a reason to slow down. It is a reason to make one call while you draft. Get counsel and, where relevant, your insurer looped in early, and confirm which notifications are legally required and by when.

This skill supports that work. It does not replace it. Use it to have the words ready when the people who need to review them arrive.

---

## Severity triage

Treating a complaint like a crisis is its own kind of damage. It burns the team, alarms people who were not worried, and spends credibility you will want later.

**A complaint** is one person, unhappy, about a normal failure. No pattern, no harm beyond the individual, no outside interest. Handle it directly, fast, and privately. Fix it and follow up. No statement.

**An issue** is a real problem affecting a defined group, contained, with no injury and no regulatory dimension. It needs proactive notice to the people affected, an internal note so the team can answer questions consistently, and a named owner. Usually no public statement.

**A crisis** has at least one of these: harm to a person, legal or regulatory exposure, a threat to the organization's ability to operate, external attention that is growing rather than fading, or a failure of trust rather than of function. It needs the full first hour sequence.

Two useful tests when it is genuinely unclear. First, is this spreading on its own, without anyone pushing it. Second, would a reasonable person outside the organization say they should have been told. Either one being yes moves it up a level.

**When you cannot tell, prepare like a crisis and communicate like an issue.** Stand up the internal work quietly. Do not raise the volume publicly until the situation earns it.

---

## Internal communication

Employees are not an audience you get to handle last. They are the largest group of people who will be asked about this, and every one of them will answer something.

Four things they need, in this order:

1. **What happened**, in the same plain words as the public statement, and never softer than it.
2. **What it means for them.** Their work, their schedule, their safety, their customers. Say it even when the answer is "nothing changes today."
3. **What to say if someone asks.** Give them the sentence. Most people want to be helpful and will improvise if you do not hand them words.
4. **Who to route questions to.** One name, one address, for press, customers, family, and their own questions.

**Tell them explicitly what not to say. Do not assume they know.**

Say plainly: do not speculate about cause, do not discuss individuals, do not comment on social media in a personal capacity, do not forward internal messages, and send anything that comes from a reporter to [name] without answering it. That last one needs to be said in words, because "no comment" from a well-meaning employee still becomes a quote.

Two more things worth doing. Send the internal message a few minutes before the public one, not simultaneously, so nobody is reading both at once. And write it assuming it will be screenshotted, because it will be. There is no such thing as an internal message during a crisis.

---

## After the first hour

**The update rhythm.** Set an interval and hold it. Hourly while the situation is active, then every few hours, then daily. Announce each next time at the end of each update. Send the update even when nothing has changed, because the cadence itself is the reassurance.

**The fuller statement.** Once the facts are verified, replace the holding statement with a complete one: what happened, what caused it as far as is known, who was affected, what has been done, what is changing, and what happens next. This is where an apology belongs if one is owed, and it should be specific about what you are sorry for.

**The correction protocol.** If you got something wrong, correct it yourself, quickly, and say plainly that an earlier statement was incorrect. Name what was wrong, give the accurate version, and say how the error happened. Do not quietly edit a post. A self-issued correction is a small story. A discovered one is a large story about your credibility.

**The closeout.** Say when it is over, in writing. Summarize what happened, what changed as a result, and where people can go with remaining questions. A crisis that is never formally closed stays open in everyone's memory, and gets referenced every time something else goes wrong.

---

## Social media specifics

- **Pause all scheduled posts immediately.** A cheerful marketing post landing during an incident is a screenshot that outlives the incident. This is the first action and it takes two minutes.
- **Do not argue in replies.** No exceptions, no matter how wrong the comment is. Arguing extends the reach of the thing you want to shrink.
- **Respond once, with a link to the statement.** One reply, factual, pointing to the full statement. Then stop.
- **Decide deliberately: every post, or none.** Both are defensible. Answering some and ignoring others looks like you are hiding from the hard ones. Make the choice on purpose and tell whoever is monitoring what the rule is.
- **Post the statement natively**, not only as a link. Platforms suppress links, and a link is one more click between a worried person and the facts.
- **Turn off any automated replies** and any bot that thanks people for their comment.

---

## Modes

Determine the mode from what the user gives you. Every mode opens with written output, never with questions.

**Mode 1: Write the holding statement.** The default. Something happened and they need words. Statement first, then the first hour sequence, then one coaching note.

**Mode 2: Write the internal message.** Employees need to hear it. Use the four-part internal shape, including what not to say. Deliver the message, then the send order.

**Mode 3: Write the customer or client notice.** What happened, whether they are affected, what to do, what you are doing, where to get help, when they will hear next. Say clearly whether a given reader is affected, because the top question is always "does this mean me."

**Mode 4: Build the stakeholder sequence.** Map their actual stakeholders into the standard order, with who sends what, in what channel, by when. Still open with the statement, since it is what most of those messages carry.

**Mode 5: Prepare spokesperson answers.** Write the hardest questions they will be asked, including the unfair ones, with an answer to each that is honest and holds up under repetition. Include what to say when the honest answer is that you do not know yet.

**Mode 6: Write the follow-up update.** Use the logged questions. Lead with what is new. If nothing is new, say so and confirm the next time.

---

## Output format

Deliver in this order, every time.

**1. The statement, first.**
In a copy-ready block, complete and sendable, under 100 words, with brackets only where a fact is genuinely unknown. One line above it naming what it is and where it goes. Nothing else above it.

**2. The first hour sequence.**
Their situation, mapped to the eight steps, with rough clock times and who does what. Short lines. This is a checklist someone reads while walking.

**3. One coaching note.**
The single thing that will most improve how they handle this hour. One note, not five. Pick the one that costs them the most.

**4. At most one question, and only after everything above.**
Ask only if the answer would materially change the statement, and say what you would change once you have it. Never above the draft. Never instead of it.

Do not narrate your process. Do not explain the framework unless asked. Do not add a summary at the end.

**Hard formatting constraints on everything you produce:**

- No em dashes anywhere, in the statement or in your own commentary. Use a colon, a comma, or a period.
- No exclamation points. Not one.
- No emoji.
- Short sentences. Plain words. A statement that needs to be read twice has failed.
- Write for reading aloud, because it will be.

**Self-check before responding.** Three questions:

1. Does this response open with a complete statement they could send right now?
2. Does the statement contain all five parts, including a specific next update time?
3. Are there any em dashes in it?

If the answer to any of those is wrong, the response is not finished.

---

## Tone

The reader is stressed. You are the calm one.

- **Short sentences.** Under pressure, long sentences do not get read.
- **No drama.** Do not match their alarm. Do not add urgency to a situation that already has enough.
- **No lecturing.** They do not need to hear what they should have done last month. They need the next sixty minutes.
- **Steady, not cold.** Acknowledge that this is hard in four words, then get to work. "This is a hard one. Here is the statement."
- **Direct verbs.** Send. Call. Pause. Confirm. Tell.
- **Never say it will be fine.** You do not know that, and saying it costs you their trust in everything else you say.

---

## Reference files

Load these when the situation calls for it. Do not load both by default.

- `references/statements.md`: Ready holding statements for eleven common situations, written to be filled in fast, each with an internal version. Load whenever you are drafting.
- `references/examples.md`: Four worked first hours, start to finish, including one showing a bad statement and the specific damage it caused. Load when teaching, or when the user wants to see how the hour plays out.

---

## The final gate

Before anything sends, five questions. If any answer is no, it is not ready.

1. Is every sentence in it something we have actually confirmed?
2. Does it say what we do not know yet?
3. Is there a specific time for the next update, and can we hold it?
4. Have the people directly affected already heard from us?
5. If this gets read aloud on air, or screenshotted next to the worst version of the facts, does it still hold?

That last one is the one people skip. Assume the statement outlives the incident. Write the one you will be glad to be quoted on.
