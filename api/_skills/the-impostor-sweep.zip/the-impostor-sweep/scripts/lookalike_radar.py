#!/usr/bin/env python3
"""Lookalike radar: generate likely fake versions of a brand's domain and check
which are actually registered and live right now.

Read only. It looks up DNS and, for domains that resolve, requests the home page
once to read its title and whether it looks parked or for sale. It never submits
anything.

    python lookalike_radar.py --official-domains yourbrand.com --brand-terms yourbrand --out radar.json

Statuses:
    LIVE SITE     resolves and serves a page that isn't obviously parked
    PARKED        resolves but looks parked or for sale (anyone could buy it)
    REGISTERED    resolves, but the page wouldn't load (could still be used for email)
    NOT FOUND     doesn't resolve (not registered, or no DNS)

If DNS lookups fail across the board, the environment probably has no network
access. The script says so; in that case check the top candidates with web
fetch instead.
"""
import argparse
import concurrent.futures as cf
import json
import re
import socket
import ssl
import sys
import urllib.request

sys.path.insert(0, __import__("os").path.dirname(__file__))
from check_lookalikes import candidates, norm_domain, rdap  # noqa: E402

PARKED_HINTS = [
    "domain reserved", "affinity.net", "/fly?", "domain-for-sale", "afternic.com", "uniregistry",
    "/lander", "parking page", "parked domain", "sedoparking", "parklogic", "above.com", "dynadot",
    "buydomains", "media elite", "domain parking", "this domain is registered", "is available for purchase",
    "window.location.href=\"/lander", "coming soon", "spaceship.com", "namecheap parking",
    "for sale", "buy this domain", "domain is for sale", "hugedomains", "sedo", "dan.com",
    "afternic", "godaddy", "parked", "parkingcrew", "bodis", "this domain may be for sale",
    "domain name is available", "domain is expired", "domain has expired", "this domain has expired", "renew this domain", "make an offer", "atom.com", "squadhelp", "undeveloped",
]
COMMON_WORD_BRANDS = {"calm", "apple", "target", "gap", "shell", "dove", "tide", "square", "slack",
                      "notion", "zoom", "chase", "delta", "visa", "ring", "nest", "uber", "coach"}
UA = "Mozilla/5.0 (compatible; ImpostorSweep/1.0; read-only brand check)"


def resolves(domain):
    try:
        socket.setdefaulttimeout(4)
        socket.gethostbyname(domain)
        return True
    except Exception:
        return False


def title_tag(body):
    m = re.search(r"<title[^>]*>(.*?)</title>", body or "", re.I | re.S)
    return m.group(1) if m else ""


def peek(domain):
    """Return (final_url, title, parked_bool) or (None, None, None)."""
    ctx = ssl.create_default_context()
    for scheme in ("https", "http"):
        url = f"{scheme}://{domain}/"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=8, context=ctx) as r:
                body = r.read(60000).decode("utf-8", "replace")
                final = r.geturl()
            m = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
            title = re.sub(r"\s+", " ", m.group(1)).strip()[:120] if m else ""
            low = (body[:20000] + final + title_tag(body)).lower()
            parked = any(h in low for h in PARKED_HINTS)
            return final, title, parked
        except Exception:
            continue
    return None, None, None


def check(domain, pattern):
    if not resolves(domain):
        return {"domain": domain, "pattern": pattern, "status": "NOT FOUND"}
    final, title, parked = peek(domain)
    if final is None:
        status = "REGISTERED"
    elif parked:
        status = "PARKED"
    else:
        status = "LIVE SITE"
    return {"domain": domain, "pattern": pattern, "status": status,
            "final_url": final, "title": title}


def add_registration(results, official):
    """Look up who registered each non-missing lookalike, and mark ones that
    share the official domain's registrar (often the brand's own defensive buys)."""
    base = rdap(official[0]) if official else {}
    base_reg = (base.get("registrar") or "").lower()
    todo = [r for r in results if r["status"] != "NOT FOUND"]
    with cf.ThreadPoolExecutor(max_workers=8) as ex:
        for r, info in zip(todo, ex.map(lambda x: rdap(x["domain"]), todo)):
            r.update({k: v for k, v in info.items() if v})
            reg = (info.get("registrar") or "").lower()
            if base_reg and reg and reg == base_reg:
                r["likely_brand_owned"] = True


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--official-domains", required=True)
    ap.add_argument("--brand-terms", default="")
    ap.add_argument("--extra", default="", help="comma-separated extra domains to check")
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--rdap", action="store_true", help="look up registrar and registration date for live, registered and parked results")
    ap.add_argument("--out", default="radar.json")
    args = ap.parse_args()

    official = [norm_domain(x) for x in args.official_domains.split(",") if x.strip()]
    rows = candidates(official, (args.brand_terms or "").split(","))[: args.limit]
    for x in args.extra.split(","):
        if x.strip():
            rows.append((norm_domain(x), "supplied"))

    # Network sanity check against the brand's own domain
    if official and not resolves(official[0]):
        print(f"Couldn't resolve {official[0]}. This environment may have no network access.")
        print("Check the top candidates with web fetch instead.")
        return 2

    results = []
    with cf.ThreadPoolExecutor(max_workers=16) as ex:
        for res in ex.map(lambda r: check(*r), rows):
            results.append(res)

    if args.rdap:
        add_registration(results, official)
    order = {"LIVE SITE": 0, "REGISTERED": 1, "PARKED": 2, "NOT FOUND": 3}
    results.sort(key=lambda r: (order[r["status"]], r["domain"]))
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    tally = {}
    for r in results:
        tally[r["status"]] = tally.get(r["status"], 0) + 1
    brand_label = official[0].split(".")[0] if official else ""
    print(f"Checked {len(results)} lookalikes: " + ", ".join(f"{k} {v}" for k, v in sorted(tally.items(), key=lambda kv: order[kv[0]])))
    print()
    for r in results:
        if r["status"] == "NOT FOUND":
            continue
        title = ('"' + r["title"] + '"') if r.get("title") else ""
        extra = "  -> " + (r.get("final_url") or "") + "  " + title
        if r.get("registrar"):
            extra += f"  [{r.get('registered') or '?'} via {r['registrar']}]"
        if r.get("registered"):
            try:
                import datetime
                age = (datetime.date.today() - datetime.date.fromisoformat(r["registered"][:10])).days
                if age <= 120:
                    extra += f"  ** NEW: registered {age} days ago **"
            except Exception:
                pass
        if r.get("likely_brand_owned"):
            extra += "  (same registrar as the official domain: likely the brand's own, confirm)"
        print(f"[{r['status']}] {r['domain']} ({r['pattern']}){extra}")
    if brand_label and (len(brand_label) <= 5 or brand_label in COMMON_WORD_BRANDS):
        print("\nNote: this brand name is short or an everyday word, so many live lookalikes will belong to unrelated businesses. Check what each site claims to be before flagging it.")
    print(f"\nWrote {args.out}. LIVE SITE results need a read-only look. PARKED ones are watch-or-buy candidates.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
