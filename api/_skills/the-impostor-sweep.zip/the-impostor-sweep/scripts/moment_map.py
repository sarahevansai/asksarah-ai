#!/usr/bin/env python3
"""Customer moment map and rerun diff.

Map: a grid of customer moments (rows) by assistant (columns), showing the worst
verdict each assistant gave for that moment. One look shows where customers are
safe and where they're being sent somewhere else.

    python moment_map.py checked.json --out moment_map.md

Diff: compare this sweep to the last one.

    python moment_map.py checked.json --previous last_checked.json --out moment_map.md

Moments are inferred from prompt wording (refund, cancel, login, support...).
Add --moments-file prompts.json ({"prompt text": "Moment name"}) to set them by hand.
"""
import argparse
import json
import sys

MOMENT_WORDS = [
    ("Refunds and disputes", ["refund", "money back", "charged twice", "return", "chargeback", "dispute", "unauthori", "fraud"]),
    ("Cancellations and closing", ["cancel", "unsubscribe", "auto-renew", "auto renew", "close my", "close account",
                                   "closing", "delete my", "delete account", "deactivate"]),
    ("Login and account", ["login", "log in", "sign in", "password", "locked out", "account"]),
    ("Support contact", ["phone", "customer service", "support", "real person", "email", "chat", "contact"]),
    ("Official and regional sites", ["official", "site", "website", "uk", "canada", "country"]),
    ("Where to buy and discounts", ["buy", "discount", "coupon", "outlet", "sale", "cheaper", "store"]),
    ("Is this legit", ["legit", "real", "scam", "fake"]),
    ("Apps and downloads", ["download", "app", "update", "install"]),
]
RANK = {"SUSPECTED IMPOSTOR": 5, "WRONG ANSWER": 4, "OUTDATED": 3, "UNKNOWN": 2,
        "THIRD PARTY": 1, "PARTNER": 1, "OFFICIAL": 0}
SYMBOL = {5: "IMPOSTOR", 4: "WRONG", 3: "OUTDATED", 2: "CHECK", 1: "3RD PARTY", 0: "OK"}


def moment_of(prompt, overrides):
    if prompt in overrides:
        return overrides[prompt]
    p = prompt.lower()
    for name, words in MOMENT_WORDS:
        if any(w in p for w in words):
            return name
    return "Other"


def grid(items, overrides):
    g = {}
    for it in items:
        m = moment_of(it.get("prompt", ""), overrides)
        a = it.get("assistant", "unknown")
        r = RANK.get(it.get("verdict", "UNKNOWN"), 2)
        g.setdefault(m, {})
        g[m][a] = max(g[m].get(a, 0), r)
    return g


def key(it):
    return (it.get("type"), it.get("digits") or (it.get("domain") if it.get("type") != "url" else it.get("value")))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("checked")
    ap.add_argument("--previous")
    ap.add_argument("--moments-file")
    ap.add_argument("--out", default="moment_map.md")
    args = ap.parse_args()

    items = json.load(open(args.checked, encoding="utf-8"))
    overrides = json.load(open(args.moments_file)) if args.moments_file else {}
    g = grid(items, overrides)
    assistants = sorted({it.get("assistant", "unknown") for it in items})
    order = [m for m, _ in MOMENT_WORDS] + sorted(set(overrides.values()) - {m for m, _ in MOMENT_WORDS}) + ["Other"]

    if assistants and all(a.lower().startswith(("quick", "web", "unknown")) for a in assistants):
        note = ["_Quick read: one column from web search. Run the prompts in each assistant to fill in the rest._", ""]
    else:
        note = []
    lines = ["## Customer moment map", ""] + note + [
             "| Moment | " + " | ".join(assistants) + " |",
             "|---|" + "---|" * len(assistants)]
    for m in order:
        if m not in g:
            continue
        cells = [SYMBOL[g[m][a]] if a in g[m] else "not run" for a in assistants]
        lines.append(f"| {m} | " + " | ".join(cells) + " |")
    lines += ["", "OK: every link and number matched the official record. 3RD PARTY: a known outside site; check it's accurate. "
              "CHECK: unknown item, needs a look. OUTDATED, WRONG, IMPOSTOR: see the findings table.", ""]

    if args.previous:
        prev = json.load(open(args.previous, encoding="utf-8"))
        bad = lambda xs: {key(x): x for x in xs if RANK.get(x.get("verdict"), 2) >= 2}
        now_bad, prev_bad = bad(items), bad(prev)
        new = [now_bad[k] for k in now_bad if k not in prev_bad]
        gone = [prev_bad[k] for k in prev_bad if k not in now_bad]
        still = [now_bad[k] for k in now_bad if k in prev_bad]
        lines += ["## Since the last sweep", ""]
        for label, xs in (("New", new), ("Gone", gone), ("Still showing up", still)):
            lines.append(f"**{label}** ({len(xs)})")
            for x in xs:
                lines.append(f"- {x.get('value')} [{x.get('verdict')}] via {x.get('assistant')} on \"{x.get('prompt','')}\"")
            lines.append("")
        pg, ng = grid(prev, overrides), g
        changed = []
        for m in set(pg) | set(ng):
            for a in set(pg.get(m, {})) | set(ng.get(m, {})):
                b, c = pg.get(m, {}).get(a), ng.get(m, {}).get(a)
                if b is not None and c is not None and b != c:
                    changed.append(f"- {m} in {a}: {SYMBOL[b]} to {SYMBOL[c]}")
        if changed:
            lines += ["**Moments that changed**"] + sorted(changed) + [""]

    out = "\n".join(lines)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(out)
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
