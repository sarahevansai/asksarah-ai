#!/usr/bin/env python3
"""Sort extracted links, numbers and emails against a brand's official record,
and flag lookalike domains.

Check mode (default):
    python check_lookalikes.py findings.json \
        --official-domains "yourbrand.com,yourbrand.co.uk" \
        --brand-terms "yourbrand" \
        --official-phones "+1 800 555 0100" \
        --partners "yourbrand.zendesk.com,amazon.com" \
        --out checked.json

Generate mode (a defensive watch list, not a list of existing fakes):
    python check_lookalikes.py --generate --official-domains yourbrand.com --brand-terms yourbrand

Every result is a lead for a human to confirm. A pattern match is not proof a
site is fraudulent, and a non-match is not proof it's safe.
"""
import argparse
import json
import re
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

FREE_HOSTS = [
    "wixsite.com", "wix.com", "blogspot.com", "weebly.com", "webflow.io", "netlify.app",
    "vercel.app", "pages.dev", "github.io", "notion.site", "carrd.co", "godaddysites.com",
    "square.site", "framer.website", "framer.app", "sites.google.com", "wordpress.com",
    "000webhostapp.com", "glitch.me", "firebaseapp.com", "web.app", "herokuapp.com",
    "azurewebsites.net", "s3.amazonaws.com", "myshopify.com", "tilda.ws", "jimdosite.com",
    "strikingly.com", "mystrikingly.com", "site123.me", "linktr.ee", "beacons.ai",
]
# Large, well-known third parties. Not impostors, but a human should still check
# whether what they say is right (marked THIRD PARTY).
FREE_MAIL = {"gmail.com", "googlemail.com", "yahoo.com", "outlook.com", "hotmail.com", "live.com",
             "aol.com", "proton.me", "protonmail.com", "icloud.com", "gmx.com", "mail.com", "yandex.com"}
SUPPORT_PHONE_WORDS = re.compile(
    r"24/7|refund|helpline|hotline|help ?line|support|call us|call (the )?(team|number)|member services|"
    r"customer (care|service)|dispute|unauthori[sz]ed|fraud|recover|verification|verify|identity|"
    r"locked|unlock|toll.?free|claims|live (agent|person|representative)|speak (to|with)|billing|cancel",
    re.I)
PATH_HOSTS = ("sites.google.com", "hackmd.io", "notion.site", "medium.com", "github.io", "linktr.ee",
              "docs.google.com", "drive.google.com", "qualtrics.com", "wixsite.com", "blogspot.com")
THIRD_PARTY = [
    "wikipedia.org", "reddit.com", "youtube.com", "facebook.com", "instagram.com", "x.com",
    "twitter.com", "linkedin.com", "tiktok.com", "trustpilot.com", "bbb.org", "yelp.com",
    "amazon.com", "ebay.com", "walmart.com", "target.com", "bestbuy.com", "apple.com",
    "play.google.com", "apps.apple.com", "google.com", "bing.com", "microsoft.com",
    "quora.com", "medium.com", "nerdwallet.com", "forbes.com", "nytimes.com", "cnet.com",
    "pcmag.com", "g2.com", "capterra.com", "glassdoor.com", "indeed.com", "sitejabber.com",
    "consumeraffairs.com", "retailmenot.com", "groupon.com", "tripadvisor.com",
]
SUPPORT_WORDS = [
    "support", "help", "helpdesk", "helpcenter", "help-center", "care", "service", "services",
    "customer", "customerservice", "contact", "refund", "refunds", "return", "returns",
    "cancel", "billing", "login", "signin", "sign-in", "account", "accounts", "secure",
    "verify", "verification", "official", "outlet", "store", "shop", "sale", "deals",
    "discount", "app", "download", "update", "online", "portal", "my", "get", "team", "hq",
    "bank", "card", "pay", "money", "wallet", "member", "members", "dispute",
]
GENERATE_TLDS = ["com", "net", "org", "co", "io", "app", "shop", "store", "online", "site",
                 "info", "us", "top", "xyz", "support", "help", "cm", "om"]
HOMOGLYPHS = {"0": "o", "1": "l", "3": "e", "5": "s", "@": "a", "$": "s", "vv": "w", "rn": "m", "cl": "d"}
KEYBOARD = {
    "q": "wa", "w": "qes", "e": "wrd", "r": "etf", "t": "ryg", "y": "tuh", "u": "yij", "i": "uok",
    "o": "ipl", "p": "ol", "a": "qsz", "s": "awdz", "d": "sefx", "f": "drgc", "g": "fthv",
    "h": "gyjb", "j": "hukn", "k": "jilm", "l": "kop", "z": "asx", "x": "zsdc", "c": "xdfv",
    "v": "cfgb", "b": "vghn", "n": "bhjm", "m": "njk",
}
# Multi-part public suffixes so yourbrand.co.uk splits correctly
MULTI_SUFFIX = {"co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.nz",
                "com.br", "com.mx", "co.jp", "co.in", "co.za", "com.sg", "com.hk", "com.tr",
                "com.co", "co.kr", "com.ar", "com.cn"}


def norm_domain(d):
    d = (d or "").strip().lower()
    d = re.sub(r"^https?://", "", d).split("/")[0].split(":")[0].rstrip(".")
    return d[4:] if d.startswith("www.") else d


def split_domain(d):
    """Return (subdomain_part, label, suffix) e.g. help.yourbrand.co.uk -> ('help','yourbrand','co.uk')."""
    parts = d.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in MULTI_SUFFIX:
        suffix, rest = ".".join(parts[-2:]), parts[:-2]
    else:
        suffix, rest = parts[-1], parts[:-1]
    if not rest:
        return "", "", suffix
    return ".".join(rest[:-1]), rest[-1], suffix


def registrable(d):
    sub, label, suffix = split_domain(d)
    return f"{label}.{suffix}" if label else d


def on_list(d, lst):
    return any(d == x or d.endswith("." + x) for x in lst)


def deglyph(s):
    for k, v in HOMOGLYPHS.items():
        s = s.replace(k, v)
    return s


def lev(a, b):
    if a == b:
        return 0
    if abs(len(a) - len(b)) > 3:
        return 9
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def brand_tokens(terms):
    toks = set()
    for t in terms:
        t = t.lower().strip()
        if not t:
            continue
        toks.add(re.sub(r"[^a-z0-9]", "", t))
        toks.add(re.sub(r"[^a-z0-9-]", "", t.replace(" ", "-")))
    return {t for t in toks if len(t) >= 3}


def classify_domain(d, official, partners, brands, path=""):
    d = norm_domain(d)
    if not d:
        return "UNKNOWN", ["empty domain"]
    if on_list(d, official):
        return "OFFICIAL", ["matches an official domain"]
    if on_list(d, partners):
        return "PARTNER", ["on the partner list"]

    reasons = []
    host = next((h for h in FREE_HOSTS if d == h or d.endswith("." + h) or d.startswith(h)), None)
    sub, label, suffix = split_domain(d)
    flat_label = re.sub(r"[^a-z0-9]", "", label)
    flat_full = re.sub(r"[^a-z0-9]", "", sub + label)
    off_labels = {split_domain(o)[1] for o in official}
    off_suffixes = {split_domain(o)[2] for o in official}

    has_brand = any(b.replace("-", "") in flat_full for b in brands)
    flat_path = re.sub(r"[^a-z0-9]", "", (path or "").lower())
    brand_in_path = any(b.replace("-", "") in flat_path for b in brands)

    if host or any(d == h or d.endswith("." + h) for h in PATH_HOSTS):
        host = host or next(h for h in PATH_HOSTS if d == h or d.endswith("." + h))
        if brand_in_path and not has_brand:
            return "SUSPECTED IMPOSTOR", [f"brand name in a page on a shared host ({host}); report it to {host}, not the registrar"]
    if host:
        if has_brand:
            return "SUSPECTED IMPOSTOR", [f"brand name on free hosting ({host})"]
        return "UNKNOWN", [f"free hosting ({host}), brand name not in address"]

    if on_list(d, THIRD_PARTY):
        return "THIRD PARTY", ["well-known third-party site; check that what it says is right"]

    if label in off_labels and suffix not in off_suffixes:
        reasons.append(f"official name on a different ending (.{suffix})")
    elif has_brand:
        extra = flat_label
        for b in brands:
            extra = extra.replace(b.replace("-", ""), "")
        words = [w for w in SUPPORT_WORDS if w.replace("-", "") in extra]
        if words:
            reasons.append(f"brand name plus '{words[0]}'")
        elif label not in off_labels:
            reasons.append("brand name inside a domain the brand doesn't own")
    else:
        for b in brands:
            bf = b.replace("-", "")
            if len(bf) < 4:
                continue
            g = deglyph(flat_label)
            dist = lev(g, bf)
            if g != flat_label and g == bf:
                reasons.append("look-alike characters (for example 0 for o, rn for m)")
                break
            if 0 < dist <= (1 if len(bf) <= 6 else 2):
                reasons.append(f"one or two letters off from '{b}'")
                break
            # misspelling plus a support word
            for w in SUPPORT_WORDS:
                stripped = g.replace(w.replace("-", ""), "")
                if stripped != g and 0 < lev(stripped, bf) <= 1:
                    reasons.append(f"misspelled brand name plus '{w}'")
                    break
            if reasons:
                break

    if reasons:
        return "SUSPECTED IMPOSTOR", reasons
    return "UNKNOWN", ["not on the brand card; look at the page"]


def classify_phone(dg, official_phones):
    if not dg:
        return "UNKNOWN", ["no digits"]
    tail = dg[-10:]
    for p in official_phones:
        if p[-10:] == tail or p == dg:
            return "OFFICIAL", ["matches an official number"]
    for p in official_phones:
        if len(p) >= 10 and lev(p[-10:], tail) == 1:
            return "UNKNOWN", ["one digit off from an official number: a typo, a real second line or a fake; confirm with the brand"]
    if not official_phones:
        return "UNKNOWN", ["no official numbers on the brand card to compare"]
    return "UNKNOWN", ["doesn't match the brand card; search it with the brand name and 'scam'"]


def http_status(url):
    import urllib.request, urllib.error
    if not url.startswith("http"):
        url = "https://" + url
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; ImpostorSweep/1.0; read-only)"})
        with urllib.request.urlopen(req, timeout=8) as r:
            body = r.read(30000).decode("utf-8", "replace").lower()
            return r.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return None, ""


def rdap(domain):
    import urllib.request
    try:
        with urllib.request.urlopen(f"https://rdap.org/domain/{registrable(domain)}", timeout=8) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        created = next((e.get("eventDate", "")[:10] for e in data.get("events", []) if e.get("eventAction") == "registration"), "")
        registrar, abuse = "", ""
        for ent in data.get("entities", []):
            if "registrar" in ent.get("roles", []):
                v = ent.get("vcardArray", [None, []])[1]
                registrar = next((x[3] for x in v if x[0] == "fn"), "")
                for sub in ent.get("entities", []):
                    if "abuse" in sub.get("roles", []):
                        sv = sub.get("vcardArray", [None, []])[1]
                        abuse = next((x[3] for x in sv if x[0] == "email"), "")
        return {"registered": created, "registrar": registrar, "abuse_email": abuse}
    except Exception:
        return {}


def live_check(items, use_rdap):
    """Read-only liveness check: DNS, one GET, optional registration lookup."""
    import socket
    from lookalike_radar import PARKED_HINTS
    cache = {}
    for it in items:
        if it["type"] == "phone":
            continue
        dom = norm_domain(it.get("domain", ""))
        target = it["value"] if it["type"] == "url" else dom
        if target in cache:
            info = cache[target]
        else:
            info = {}
            try:
                socket.setdefaulttimeout(4)
                socket.gethostbyname(dom)
                info["dns"] = True
            except Exception:
                info["dns"] = False
            if info["dns"] and it["type"] != "email":
                st, body = http_status(target)
                info["status"] = st
                info["parked"] = any(h in body for h in PARKED_HINTS) if body else False
            shared = (any(dom == h or dom.endswith("." + h) for h in FREE_HOSTS + list(PATH_HOSTS))
                      or dom in FREE_MAIL or on_list(dom, THIRD_PARTY))
            brandish = any(r_.startswith(("brand name plus", "official name on", "one or two letters",
                                          "look-alike", "misspelled", "brand name inside")) for r_ in it["reasons"])
            if use_rdap and info["dns"] and not shared and brandish:
                info.update(rdap(dom))
            cache[target] = info
        it["live"] = info
        v = it["verdict"]
        if v in ("THIRD PARTY", "PARTNER"):
            continue
        if not info["dns"]:
            if v == "OFFICIAL":
                it["verdict"], it["reasons"] = "OUTDATED", ["official address, but it doesn't resolve (dead subdomain or retired domain)"]
            elif v in ("SUSPECTED IMPOSTOR", "UNKNOWN") and it["type"] != "email":
                it["reasons"].append("NOT REGISTERED right now: AI is citing a domain anyone can buy; register it defensively or watch it")
        elif info.get("status") in (404, 410):
            if v == "OFFICIAL":
                it["verdict"], it["reasons"] = "OUTDATED", [f"official page returns {info['status']} (dead)"]
            else:
                it["reasons"].append(f"page returns {info['status']} right now (domain still held, can come back)")
        elif info.get("status") in (401, 403, 429, 503):
            it["reasons"].append(f"returned {info['status']} to a script (usually bot protection); check it with web fetch")
        elif info.get("status") and info["status"] >= 400:
            it["reasons"].append(f"page returns {info['status']} right now")
        elif info.get("parked"):
            if v == "SUSPECTED IMPOSTOR" and it["reasons"] and "free hosting" not in it["reasons"][0]:
                it["verdict"] = "UNKNOWN"
            it["reasons"].append("parked or for sale: a watch-or-buy candidate, not a live fake today")
        if v not in ("OFFICIAL", "OUTDATED") and it["type"] == "url" and not any(
                r_.startswith(("brand name", "official name", "one or two", "look-alike", "misspelled")) for r_ in it["reasons"]):
            it["reasons"].append("if this page carries fake details, report it to the site's owner or platform, not the domain registrar")
        if info.get("registrar"):
            it["reasons"].append(f"registered {info.get('registered') or '?'} via {info['registrar']}" +
                                 (f", abuse contact {info['abuse_email']}" if info.get("abuse_email") else ""))


def run_check(args):
    official = [norm_domain(x) for x in args.official_domains.split(",") if x.strip()]
    partners = [norm_domain(x) for x in (args.partners or "").split(",") if x.strip()]
    brands = brand_tokens((args.brand_terms or "").split(",") + [split_domain(o)[1] for o in official])
    phones = [re.sub(r"\D", "", x) for x in (args.official_phones or "").split(",") if re.sub(r"\D", "", x)]

    with open(args.findings, encoding="utf-8") as f:
        items = json.load(f)

    for it in items:
        if it["type"] == "phone":
            v, r = classify_phone(it.get("digits", ""), phones)
            if v == "UNKNOWN" and "one digit off" not in r[0] and SUPPORT_PHONE_WORDS.search(it.get("snippet", "")):
                v, r = "SUSPECTED IMPOSTOR", ["presented with support or refund wording, but not on the brand card; search it with the brand name and 'scam', never call it"]
        else:
            path = re.sub(r"^https?://[^/]+", "", it["value"]) if it["type"] == "url" else ""
            path = path if path != it["value"] else re.sub(r"^[^/]+", "", it["value"])
            v, r = classify_domain(it.get("domain", ""), official, partners, brands, path)
            if it["type"] == "email" and v == "UNKNOWN" and it.get("domain") in FREE_MAIL:
                v, r = "SUSPECTED IMPOSTOR", ["support email on a free mail provider"]
            if it["type"] == "email" and v == "OFFICIAL":
                local = it["value"].split("@")[0]
                if not re.search(r"support|help|care|hello|info|contact|service|billing|press|media|privacy|team|returns|orders|security|fraud|abuse|feedback|members?", local):
                    v, r = "UNKNOWN", ["a person's address on the official domain, not a support channel; keep it out of the official record"]
        it["verdict"], it["reasons"] = v, r

    if args.check_live:
        live_check(items, args.rdap)

    order = {"SUSPECTED IMPOSTOR": 0, "OUTDATED": 1, "UNKNOWN": 2, "THIRD PARTY": 3, "PARTNER": 4, "OFFICIAL": 5}
    items.sort(key=lambda x: (order.get(x["verdict"], 9), x.get("assistant", ""), x.get("prompt", "")))

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2, ensure_ascii=False)

    tally = {}
    for it in items:
        tally[it["verdict"]] = tally.get(it["verdict"], 0) + 1
    print("Verdicts: " + ", ".join(f"{k} {v}" for k, v in sorted(tally.items(), key=lambda kv: order.get(kv[0], 9))))
    print()
    for it in items:
        if it["verdict"] in ("OFFICIAL",):
            continue
        print(f"[{it['verdict']}] {it['value']}  ({it.get('assistant','?')} | {it.get('prompt','')[:60]})")
        print(f"    why: {'; '.join(it['reasons'])}")
    print(f"\nWrote {args.out}. Every flag is a lead to confirm, not a verdict on its own.")


def candidates(official, brand_terms):
    """Return [(domain, pattern)] of likely lookalikes for the main brand label."""
    brands = sorted(brand_tokens(list(brand_terms) + [split_domain(o)[1] for o in official]),
                    key=len, reverse=True)
    if not brands:
        return []
    b = brands[0].replace("-", "")
    out = {}

    def add(label, tld, why):
        dom = f"{label}.{tld}"
        if dom not in official and label and re.fullmatch(r"[a-z0-9-]+", label):
            out.setdefault(dom, why)

    typos = set()
    for i in range(len(b)):
        typos.add(b[:i] + b[i + 1:])                       # missing letter
        typos.add(b[:i] + b[i] + b[i:])                    # doubled letter
        if i < len(b) - 1:
            typos.add(b[:i] + b[i + 1] + b[i] + b[i + 2:])  # swapped letters
        for k in KEYBOARD.get(b[i], ""):
            typos.add(b[:i] + k + b[i + 1:])               # neighbor key
    for k, v in HOMOGLYPHS.items():
        if v in b and re.fullmatch(r"[a-z0-9]+", k):
            typos.add(b.replace(v, k, 1))
    typos.discard(b)
    for t in sorted(typos):
        add(t, "com", "misspelling")
    for w in ["support", "help", "refund", "refunds", "login", "account", "care", "service",
              "official", "outlet", "store", "shop", "app", "secure", "billing", "bank", "card",
              "pay", "verify", "member", "online"]:
        add(f"{b}{w}", "com", "brand plus a word")
        add(f"{b}-{w}", "com", "brand plus a word")
        add(f"{w}{b}", "com", "word plus brand")
    for tld in GENERATE_TLDS:
        add(b, tld, "different ending")
    rank = {"different ending": 0, "brand plus a word": 1, "word plus brand": 2, "misspelling": 3}
    return sorted(out.items(), key=lambda kv: (rank[kv[1]], kv[0]))


def generate(args):
    official = [norm_domain(x) for x in args.official_domains.split(",") if x.strip()]
    rows = candidates(official, (args.brand_terms or "").split(","))
    if not rows:
        print("Need --brand-terms or --official-domains")
        return 1
    limit = args.limit
    print(f"Watch list ({min(limit, len(rows))} of {len(rows)} candidates).")
    print("Possible lookalikes to monitor or register. Run lookalike_radar.py to see which are live.\n")
    for dom, why in rows[:limit]:
        print(f"{dom:40s} {why}")
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump([{"domain": d, "pattern": w} for d, w in rows], f, indent=2)
        print(f"\nWrote {args.out}")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("findings", nargs="?", help="findings.json from extract_contacts.py")
    ap.add_argument("--official-domains", required=True)
    ap.add_argument("--brand-terms", default="")
    ap.add_argument("--official-phones", default="")
    ap.add_argument("--partners", default="")
    ap.add_argument("--out", default=None)
    ap.add_argument("--generate", action="store_true")
    ap.add_argument("--check-live", action="store_true", help="read-only DNS and page check on every domain and URL")
    ap.add_argument("--rdap", action="store_true", help="with --check-live, look up registrar and registration date for flagged domains")
    ap.add_argument("--limit", type=int, default=60)
    args = ap.parse_args()
    if args.generate:
        return generate(args)
    if not args.findings:
        ap.error("findings file required unless --generate")
    args.out = args.out or "checked.json"
    run_check(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
