#!/usr/bin/env python3
"""Pull every link, domain, phone number and email out of pasted AI answers.

Input: a text file of AI answers. Start each answer with a header line naming
the assistant and the prompt, in any of these forms:

    === ChatGPT | How do I get a refund from YourBrand? ===
    ## Perplexity: YourBrand login
    [Gemini] YourBrand customer service phone number

Text before the first header is filed under assistant "unknown".

Output: JSON list of items, one per (assistant, prompt, value), with a short
snippet of surrounding text so a person can see how the AI presented it.

Usage:
    python extract_contacts.py answers.txt --out findings.json
"""
import argparse
import json
import re
import sys

HEADER_RES = [
    re.compile(r"^\s*={2,}\s*(?P<a>[^|:=]+?)\s*[|:]\s*(?P<p>.*?)\s*={0,}\s*$"),
    re.compile(r"^\s*#{1,4}\s*(?P<a>[^|:]+?)\s*[|:]\s*(?P<p>.+?)\s*$"),
    re.compile(r"^\s*\[(?P<a>[^\]]+)\]\s*(?P<p>.*)$"),
]

URL_RE = re.compile(r"https?://[^\s<>()\[\]\"'`]+", re.I)
EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,24}\b")
# Bare domains like yourbrand-help.com or support.yourbrand.co.uk
BARE_DOMAIN_RE = re.compile(
    r"(?<![@\w./-])((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:[a-z]{2,24}))(?![\w-])(/[^\s<>()\[\]\"'`]*)?",
    re.I,
)
PHONE_RE = re.compile(
    r"(?<![\w.])(\+?\d{1,3}[\s.-]?)?(\(?\d{2,4}\)?[\s.-]?)\d{3,4}[\s.-]?\d{3,4}(?:\s*(?:x|ext\.?)\s*\d{1,5})?(?!\w)(?!\.\d)"
)
# Toll-free vanity numbers like 1-800-FLOWERS
VANITY_RE = re.compile(r"(?<!\w)(?:\+?1[\s.-]?)?\(?8(?:00|33|44|55|66|77|88)\)?[\s.-]?[A-Z0-9]{3}[\s.-]?[A-Z0-9]{4}(?!\w)")

# Words that look like domains but aren't (file names, abbreviations)
NOT_DOMAINS = {
    "e.g", "i.e", "u.s", "a.m", "p.m", "etc.",
}
FILE_EXTS = {"pdf", "png", "jpg", "jpeg", "gif", "md", "txt", "csv", "json", "html", "htm",
             "exe", "dmg", "zip", "docx", "xlsx", "pptx", "js", "py"}
# A short allow list of common TLDs helps avoid matching ordinary words like "end.Then"
COMMON_TLDS = set("""
com net org co io ai app biz info us uk ca au de fr es it nl be ch at se no dk fi ie pt pl cz
in jp cn kr sg hk tw nz za br mx ar cl pe ru ua tr il ae sa qa eg ng ke ph my id th vn
shop store online site top xyz club live today support help services service world tech
dev page pages me tv cc ly gg ws to link click website space store cloud global inc llc
gov edu mil int eu asia travel bank insurance health care finance money pay
""".split())


def split_blocks(text):
    assistant, prompt, buf = "unknown", "", []
    blocks = []
    for line in text.splitlines():
        header = None
        for rx in HEADER_RES:
            m = rx.match(line)
            if m and m.group("a").strip() and len(m.group("a")) < 40:
                header = m
                break
        if header:
            if buf:
                blocks.append((assistant, prompt, "\n".join(buf)))
            assistant = header.group("a").strip()
            prompt = header.group("p").strip()
            buf = []
        else:
            buf.append(line)
    if buf:
        blocks.append((assistant, prompt, "\n".join(buf)))
    return [b for b in blocks if b[2].strip()]


def snippet(text, start, end, width=90):
    s = max(0, start - width)
    e = min(len(text), end + width)
    return re.sub(r"\s+", " ", text[s:e]).strip()


def domain_of(url):
    d = re.sub(r"^https?://", "", url, flags=re.I).split("/")[0].split("?")[0].split("#")[0]
    d = d.split("@")[-1].split(":")[0].lower().rstrip(".")
    return d[4:] if d.startswith("www.") else d


def clean_url(u):
    return u.rstrip(".,;:!?)]}'\"")


def digits(s):
    return re.sub(r"\D", "", s)


def looks_like_phone(raw):
    """Filter out IDs, prices, coordinates and dates that the broad pattern catches."""
    raw = raw.strip()
    if not re.search(r"[\s().+-]", raw):
        return False  # a bare run of digits is an ID or order number
    groups = [g for g in re.split(r"[^\d]+", raw) if g]
    if not groups:
        return False
    if raw.startswith("+"):
        return len(groups[-1]) >= 2 and 8 <= len(digits(raw)) <= 15
    # North American and most local formats end in a 4-digit group
    if len(groups[-1]) != 4:
        return False
    if "." in raw and any(len(g) < 3 for g in groups[1:]):
        return False
    return 7 <= len(digits(raw)) <= 15


def extract(text):
    items = []
    taken = []  # spans already used, so domains inside URLs/emails aren't double counted

    def overlaps(a, b):
        return any(not (b <= s or a >= e) for s, e in taken)

    for m in URL_RE.finditer(text):
        u = clean_url(m.group(0))
        taken.append((m.start(), m.start() + len(u)))
        items.append({"type": "url", "value": u, "domain": domain_of(u),
                      "snippet": snippet(text, m.start(), m.end())})
    for m in EMAIL_RE.finditer(text):
        if overlaps(m.start(), m.end()):
            continue
        taken.append((m.start(), m.end()))
        e = m.group(0)
        items.append({"type": "email", "value": e.lower(), "domain": e.split("@")[1].lower(),
                      "snippet": snippet(text, m.start(), m.end())})
    for m in BARE_DOMAIN_RE.finditer(text):
        if overlaps(m.start(), m.end()):
            continue
        d = m.group(1).lower().rstrip(".")
        tld = d.rsplit(".", 1)[-1]
        if d in NOT_DOMAINS or tld in FILE_EXTS or tld not in COMMON_TLDS:
            continue
        if re.fullmatch(r"[\d.]+", d):
            continue
        taken.append((m.start(), m.end()))
        d = d[4:] if d.startswith("www.") else d
        path = clean_url(m.group(2) or "")
        if path and path != "/":
            items.append({"type": "url", "value": d + path, "domain": d,
                          "snippet": snippet(text, m.start(), m.end())})
        else:
            items.append({"type": "domain", "value": d, "domain": d,
                          "snippet": snippet(text, m.start(), m.end())})
    for rx in (VANITY_RE, PHONE_RE):
        for m in rx.finditer(text):
            if overlaps(m.start(), m.end()):
                continue
            raw = m.group(0).strip()
            dg = digits(raw)
            if rx is PHONE_RE:
                if not looks_like_phone(raw):
                    continue
                if re.fullmatch(r"(19|20)\d{2}", dg[:4]) and len(dg) <= 8:
                    continue  # looks like a year or date
            taken.append((m.start(), m.end()))
            items.append({"type": "phone", "value": raw, "digits": dg,
                          "snippet": snippet(text, m.start(), m.end())})
    return items


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("answers", help="text file of pasted AI answers")
    ap.add_argument("--out", default="findings.json")
    args = ap.parse_args()

    with open(args.answers, encoding="utf-8", errors="replace") as f:
        text = f.read()

    results, seen = [], set()
    blocks = split_blocks(text)
    for assistant, prompt, body in blocks:
        for it in extract(body):
            key = (assistant.lower(), prompt.lower(), it["type"], it.get("digits") or it["value"])
            if key in seen:
                continue
            seen.add(key)
            it.update({"assistant": assistant, "prompt": prompt})
            results.append(it)

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    counts = {}
    for r in results:
        counts[r["type"]] = counts.get(r["type"], 0) + 1
    assistants = sorted({b[0] for b in blocks})
    print(f"Blocks read: {len(blocks)} | Assistants: {', '.join(assistants) or 'none'}")
    print("Found: " + ", ".join(f"{v} {k}s" for k, v in sorted(counts.items())) if counts else "Found nothing")
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    sys.exit(main())
