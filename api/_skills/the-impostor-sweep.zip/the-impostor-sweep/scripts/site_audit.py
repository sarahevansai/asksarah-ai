#!/usr/bin/env python3
"""Site audit: check the brand's own official pages for the gaps that let fakes in.

1. AI crawler access: reads robots.txt and reports whether the major AI search
   and answer crawlers are blocked from the site or from the help pages.
2. Consistency: pulls every phone number and email from the official pages and
   flags conflicts (two different "support" numbers is how an old one survives).
3. Plain-text answers: notes pages where no number, email or URL is written out.
4. Dead pages: flags official pages that return an error.

Live mode (needs network):
    python site_audit.py --domain yourbrand.com --pages "https://yourbrand.com/contact,https://help.yourbrand.com/refunds"

File mode (when the site blocks scripts or there's no network): save each page's
text with web fetch, then pass the files. Name robots.txt "robots.txt".
    python site_audit.py --domain yourbrand.com --files robots.txt contact.txt refunds.txt

Read only. One GET per page, plus robots.txt for every host in --pages
(so help.brand.com is checked separately from brand.com).

File mode caveat: web fetch tools often return a summary, not the raw page. If
robots.txt came back summarized, say crawler access is unconfirmed.
"""
import argparse
import json
import os
import re
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
from extract_contacts import PHONE_RE, EMAIL_RE, digits, looks_like_phone  # noqa: E402

AI_BOTS = {
    "GPTBot": "OpenAI training crawler",
    "OAI-SearchBot": "ChatGPT search",
    "ChatGPT-User": "ChatGPT fetching a page for a user",
    "ClaudeBot": "Anthropic crawler",
    "Claude-SearchBot": "Claude search",
    "Claude-User": "Claude fetching a page for a user",
    "PerplexityBot": "Perplexity search",
    "Perplexity-User": "Perplexity fetching a page for a user",
    "Google-Extended": "Gemini use of Google-crawled content",
    "Googlebot": "Google Search, AI Overviews and AI Mode",
    "Bingbot": "Bing and Copilot",
    "Applebot-Extended": "Apple Intelligence",
    "CCBot": "Common Crawl (used to train many models)",
}
UA = "Mozilla/5.0 (compatible; ImpostorSweep/1.0; read-only brand check)"
HELP_PATHS = ["/help", "/support", "/contact", "/hc", "/returns", "/refund", "/faq", "/pages/help", "/pages/contact"]
# Blocking these is normal and fine: they're behind a login anyway.
PRIVATE_PATHS = ("/account", "/login", "/checkout", "/cart", "/orders", "/admin", "/my-")


def fetch(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, r.read(400000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception as e:
        return None, str(e)


def parse_robots(text):
    """Return {agent_lower: [(allow_bool, path)]}."""
    groups, current, last_was_agent = {}, [], False
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or ":" not in line:
            continue
        k, v = [x.strip() for x in line.split(":", 1)]
        k = k.lower()
        if k == "user-agent":
            if not last_was_agent:
                current = []
            current.append(v.lower())
            groups.setdefault(v.lower(), [])
            last_was_agent = True
        elif k in ("allow", "disallow"):
            last_was_agent = False
            for a in current:
                groups.setdefault(a, []).append((k == "allow", v))
    return groups


def blocked(rules, path):
    """Longest-match robots logic. Returns True if path is disallowed."""
    best, verdict = -1, False
    for allow, p in rules:
        if p == "":
            if not allow and best < 0:
                verdict = False  # empty Disallow means allow all
            continue
        pat = re.escape(p).replace(r"\*", ".*")
        if pat.endswith(r"\$"):
            pat = pat[:-2] + "$"
        if re.match(pat, path) and len(p) > best:
            best, verdict = len(p), not allow
    return verdict


def strip_html(html):
    html = re.sub(r"(?is)<(script|style|noscript|svg|template|path)\b.*?</\1>", " ", html)
    html = re.sub(r"(?is)<(path|polygon|circle|rect|line|polyline)\b[^>]*/?>", " ", html)
    html = re.sub(r'(?i)\s(data-[\w-]+|value|content|id|class|href|src)="[^"]*"', " ", html)
    html = re.sub(r"(?i)<br\s*/?>|</p>|</li>|</div>|</h\d>", "\n", html)
    text = re.sub(r"<[^>]+>", " ", html)
    text = re.sub(r"&nbsp;", " ", text)
    text = re.sub(r"&amp;", "&", text)
    return re.sub(r"[ \t]+", " ", text)


def contacts(text):
    phones = {}
    for m in PHONE_RE.finditer(text):
        raw = m.group(0)
        dg = digits(raw)
        if not looks_like_phone(raw):
            continue
        if 10 <= len(dg) <= 15:
            phones.setdefault(dg[-10:], m.group(0).strip())
    emails = {m.group(0).lower() for m in EMAIL_RE.finditer(text)}
    return phones, emails


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--domain", required=True)
    ap.add_argument("--pages", default="", help="comma-separated official page URLs")
    ap.add_argument("--files", nargs="*", default=[], help="saved page text files (file mode)")
    ap.add_argument("--out", default="site_audit.json")
    args = ap.parse_args()

    dom = args.domain.lower().replace("https://", "").replace("http://", "").strip("/")
    report = {"domain": dom, "robots": {}, "pages": [], "phones": {}, "emails": {}, "notes": []}

    # Load pages
    pages = []
    robots_text = None
    if args.files:
        for p in args.files:
            with open(p, encoding="utf-8", errors="replace") as f:
                t = f.read()
            if os.path.basename(p).lower().startswith("robots"):
                robots_text = t
            else:
                pages.append({"url": os.path.basename(p), "status": "file", "text": strip_html(t) if "<" in t else t})
    else:
        urls = [u.strip() for u in args.pages.split(",") if u.strip()] or [f"https://{dom}/"]
        hosts = []
        for u in [f"https://{dom}/"] + urls:
            h = re.sub(r"^https?://", "", u).split("/")[0].lower()
            if h not in hosts:
                hosts.append(h)
        robots_by_host = {}
        for h in hosts:
            st, txt = fetch(f"https://{h}/robots.txt")
            if st is None and h == hosts[0]:
                print("Couldn't reach the site. Use file mode: save pages with web fetch and pass --files.")
                return 2
            robots_by_host[h] = (st, txt if st == 200 else None)
            if st != 200:
                report["notes"].append(f"robots.txt on {h} returned {st}; crawler access there is UNKNOWN, check it in a browser")
        for u in urls:
            st, body = fetch(u)
            pages.append({"url": u, "status": st, "text": strip_html(body) if body else ""})
        robots_text = None

    # 1. Robots
    if args.files:
        robots_by_host = {dom: (200, robots_text)} if robots_text is not None else {}
    for host, (st, rtext) in robots_by_host.items():
        if rtext is None:
            for bot, what in AI_BOTS.items():
                report["robots"].setdefault(host, {})[bot] = {"what": what, "state": "UNKNOWN (robots.txt not readable)"}
            continue
        groups = parse_robots(rtext)
        star = groups.get("*", [])
        help_paths = HELP_PATHS + [re.sub(r"^https?://[^/]+", "", p["url"]) or "/" for p in pages
                                   if p["url"].startswith("http") and host in p["url"]]
        for bot, what in AI_BOTS.items():
            rules = groups.get(bot.lower())
            named = rules is not None
            rules = rules if named else star
            if blocked(rules, "/"):
                state = "BLOCKED (whole site)"
            else:
                hb = sorted({hp for hp in help_paths if blocked(rules, hp) and not hp.startswith(PRIVATE_PATHS)})
                state = ("BLOCKED on " + ", ".join(hb)) if hb else "allowed"
            report["robots"].setdefault(host, {})[bot] = {"what": what, "named_in_robots": named, "state": state}
    if not robots_by_host:
        report["notes"].append("No robots.txt checked")

    # 2-4. Pages
    all_phones, all_emails = {}, {}
    for p in pages:
        ph, em = contacts(p["text"])
        has_url = bool(re.search(r"https?://|www\.|\b[a-z0-9-]+\.(com|net|org|co|io|app)\b", p["text"], re.I))
        entry = {"url": p["url"], "status": p["status"], "phones": list(ph.values()), "emails": sorted(em),
                 "plain_text_contact": bool(ph or em)}
        if p["status"] in (404, 410):
            entry["problem"] = f"official page returns {p['status']} (dead)"
        elif p["status"] in (401, 403, 429, 503):
            entry["problem"] = f"returned {p['status']} to a script: usually bot protection, not a dead page. Check it with web fetch or a browser"
        elif isinstance(p["status"], int) and p["status"] >= 400:
            entry["problem"] = f"official page returns {p['status']}"
        elif p["status"] == 200 and not p["text"].strip():
            entry["problem"] = "page loaded but had no readable text (may need JavaScript, which many AI crawlers don't run)"
        elif not entry["plain_text_contact"]:
            entry["problem"] = "no phone number or email written out in plain text (AI can only repeat what it can read)"
        report["pages"].append(entry)
        for k, v in ph.items():
            all_phones.setdefault(k, {"as_written": v, "pages": []})["pages"].append(p["url"])
        for e in em:
            all_emails.setdefault(e, []).append(p["url"])
    report["phones"], report["emails"] = all_phones, all_emails
    off_emails = [e for e in all_emails if not e.endswith("@" + dom) and not e.endswith("." + dom)]
    if any(p.get("problem", "").startswith("returned 4") or "bot protection" in p.get("problem", "") for p in report["pages"]):
        report["notes"].append("some pages blocked the script; their contact details weren't checked")
    if len(all_phones) > 1:
        report["notes"].append(f"{len(all_phones)} different phone numbers across official pages; confirm each one is current and labeled")
    if off_emails:
        report["notes"].append("emails on other domains appear on official pages: " + ", ".join(sorted(off_emails)))

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # Print summary
    print(f"SITE AUDIT | {dom}\n")
    for host, bots in report["robots"].items():
        print(f"AI crawler access, {host} (robots.txt):")
        for bot, r in bots.items():
            print(f"  {bot:18s} {r['state']:40s} {r['what']}")
        print()
    print("Official pages:")
    for e in report["pages"]:
        print(f"  {e['url']}  [{e['status']}]  phones: {', '.join(e['phones']) or 'none'}  emails: {', '.join(e['emails']) or 'none'}")
        if e.get("problem"):
            print(f"      problem: {e['problem']}")
    if report["notes"]:
        print("\nNotes:")
        for n in report["notes"]:
            print(f"  - {n}")
    print(f"\nWrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
