#!/usr/bin/env python3
"""Record your final call on an item, so the moment map and the next rerun diff
use your verdict, not the script's first guess.

    python set_verdict.py checked.json "allbirds-outlet.shop" "SUSPECTED IMPOSTOR" "registered May 2026, fake outlet store"
    python set_verdict.py checked.json "help.brand.com" OUTDATED "subdomain no longer resolves"

Matches on the item's value, domain or phone digits. Updates every match.
Verdicts: OFFICIAL, PARTNER, THIRD PARTY, OUTDATED, WRONG ANSWER, UNKNOWN, SUSPECTED IMPOSTOR
"""
import json
import re
import sys

VALID = {"OFFICIAL", "PARTNER", "THIRD PARTY", "OUTDATED", "WRONG ANSWER", "UNKNOWN", "SUSPECTED IMPOSTOR"}


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return 1
    path, target, verdict = sys.argv[1], sys.argv[2].lower(), sys.argv[3].upper()
    reason = sys.argv[4] if len(sys.argv) > 4 else ""
    if verdict not in VALID:
        print("Verdict must be one of: " + ", ".join(sorted(VALID)))
        return 1
    items = json.load(open(path, encoding="utf-8"))
    tdig = re.sub(r"\D", "", target)
    n = 0
    for it in items:
        hit = target in (it.get("value", "").lower(), it.get("domain", "").lower()) or \
            (tdig and len(tdig) >= 7 and it.get("digits", "").endswith(tdig[-10:]))
        if hit:
            it["script_verdict"] = it.get("script_verdict", it.get("verdict"))
            it["verdict"] = verdict
            if reason:
                it["reasons"] = [reason] + [r for r in it.get("reasons", []) if r != reason]
            it["final"] = True
            n += 1
    json.dump(items, open(path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    print(f"Updated {n} item(s) to {verdict}." if n else "No match. Check the value as it appears in the file.")
    return 0 if n else 2


if __name__ == "__main__":
    sys.exit(main())
