# The Impostor Sweep: start here

Thanks for picking this up. Here's how to run your first sweep in about 20 minutes.

## Install

1. Open Claude and find Skills in your settings.
2. Add the file `the-impostor-sweep.skill`.
3. Make sure it's switched on.

## Your first sweep

Start a new chat and type:

> Run the impostor sweep for [brand].

That's all you need. Claude builds the brand card for you from the brand's own website: the official domains, login page, support contacts, refund page and regional sites. You fix anything that's off. Then Claude writes the prompts customers actually type when they need help, gets the answers from the AI assistants, and checks every link, phone number and email against the real record.

Then it goes past what any search can show you:

- **Lookalike radar:** checks 100+ likely fake versions of your domain and tells you which are registered and live right now.
- **Live checks:** every link and number AI gave out is checked for whether it resolves, whether it's parked, and who registered it, with the abuse contact for the takedown.
- **Site audit:** whether AI crawlers are blocked from your help pages, whether your own pages list conflicting numbers, and which official pages are dead or have no contact details AI can read.
- **Customer moment map:** every customer moment by every assistant, in one grid.

You get a verdict (CLEAR, WATCH or ACT NOW), the findings, the gaps, and a filled-in response kit for whatever turned up.

## Three ways to run it

- **Claude runs it.** If you use Claude in Chrome, Claude can open each assistant and run the prompts itself.
- **You paste, Claude checks.** Claude hands you the prompts ready to copy. Run them in ChatGPT, Gemini, Perplexity, Copilot and Google, then paste the answers back.
- **Quick read.** Short on time? Claude uses its own web search for a partial check of the riskiest prompts.

## What to expect

Most brands won't find an impostor. Most will find a gap: a refund page AI can't locate, an old support number still floating around, a regional site nobody kept up. Those gaps are how fakes get in, so they're the most useful part of the report.

## A few things I'd do

- **Run it before your busiest week.** A launch, a sale, an outage or Black Friday is when customers go looking for refunds and support.
- **Start with refunds and logins.** That's where impostors show up most in AI answers.
- **Don't touch suspected sites.** Don't call the numbers, log in or fill in forms. Claude only reads the pages, and you should too.
- **Fix the pages first.** A clear official answer in your customers' words is the defense that lasts.
- **Rerun it monthly.** AI answers change. Claude can save your brand card and compare each sweep to the last one.

## The commands

| Say | What happens |
|---|---|
| quick sweep | The riskiest prompts, plus the radar and site audit |
| radar | Just the lookalike radar for a domain |
| audit our site | Just the site audit |
| full sweep | Every customer moment, every assistant you can reach |
| check this | Paste any link, number or email and get a verdict |
| draft the kit | Platform reports, abuse reports, support script, holding statement, customer warning |
| fix the pages | Official-answer copy for every gap, ready for your web team |
| rerun | Same brand, new snapshot, compared to the last one |

## Running it for clients

Ask the client for their list of official domains and partners before you start. It cuts false alarms way down. The report is written so it can go to the client as is.

Questions or feedback: asksarah.ai

Sarah
