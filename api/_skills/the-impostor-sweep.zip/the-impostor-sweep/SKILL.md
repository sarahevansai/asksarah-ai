---
name: the-impostor-sweep
description: Sarah Evans' guided check of what AI assistants tell customers when they need a refund, login, support number or the official site. Claude builds the brand's official record, gets the AI answers, checks every link, number and email with live read-only lookups, scans 100+ lookalike domains for ones registered and live, audits the brand's site for blocked AI crawlers, conflicting contacts and dead pages, maps every customer moment by assistant, and drafts the filled-in response kit. Reruns compare to the last sweep. Use whenever someone says "impostor sweep," "fake website," "fake support number," "lookalike domain," "brand impersonation," "is AI sending customers to a scam," or wants to check what ChatGPT, Gemini, Perplexity, Copilot or Google AI tells customers about refunds, logins or support. Also for agencies running it for clients. When in doubt, run it.
---

# The Impostor Sweep

A guided check of what AI tells your customers when they need help, by Sarah Evans (asksarah.ai).

## Why I built this

AI doesn't check whether a page is official. It uses whatever page answers the prompt best. Scammers figured that out, and they're building fake refund pages, login pages and support numbers worded to match what customers type. In Scrunch's study of AI answers from May to October 2026, impostor sites were cited for 83 Fortune 500 brands, and about three out of four of those answers presented the fake as the brand's official source.

Most brands won't find an impostor. What almost every brand finds is a gap: a refund policy AI can't locate, an old support number still floating around, a contact page with no phone or email written out, a help subdomain that died years ago. Those gaps are exactly where fakes get in.

This is a comms job. Comms owns the official version of a brand's facts, and AI answers are now where customers read them.

## What this does that a search can't

Anyone can type "[brand] refund" into ChatGPT. That shows one answer from one assistant on one day. This sweep goes further, and the report should make that visible:

1. **Checks every detail against the official record.** Every link, number and email from every answer is compared with facts taken from the brand's own domain, then checked live: does the domain resolve, does the page load, is it parked, who registered it and when.
2. **Lookalike radar.** Generates the most likely fake versions of the brand's domain and checks which are registered and live today, including ones no assistant has cited yet.
3. **Site audit.** Reads the brand's robots.txt to see whether AI crawlers are blocked from help pages, pulls every phone and email from official pages to catch conflicts, and flags official pages that are dead or have no contact details in plain text.
4. **Customer moment map.** Every customer moment by every assistant in one grid.
5. **The response kit, filled in.** Real URLs, numbers, registrars and abuse contacts, not templates.
6. **Rerun diff.** What's new, what's gone and what's still showing up since the last sweep.

## How to run it (four rules that make it work)

1. **Do the work for them.** The person may be a comms lead with twenty minutes. Build the record, write the prompts, run the checks. Show your work for them to confirm. They should never have to guess what to type next.
2. **The official record comes from the brand, never from AI.** Every check compares AI answers against facts from the brand's own domain or from the person. An AI answer can't confirm another AI answer, and a third-party directory isn't the brand.
3. **Look, don't touch.** Never call a phone number, send an email, fill in a form, log in, download a file or enter any information on a suspected site. Reading a page, DNS and registration lookups are enough. Say this to the person too.
4. **Say "suspected" until it's confirmed.** A lookalike domain is a lead, not a verdict. A login form is not proof of phishing. Resellers, affiliates, review sites and authorized partners are not impostors. Keep language careful in every draft, because these reports travel.

## The run of show

Six steps. Tell the person where they are ("Step 3 of 6"). Match the path to what they asked:

- **Full sweep** (default): all six steps.
- **Quick sweep**: Step 1, then only the five starred prompts (don't build or show the full list), quick read in Step 3, then Steps 4 to 6. Still run the radar and site audit; they're fast and they're what search can't do.
- **They already pasted answers**: build the card (Step 1), go straight to Step 4, and put the full prompt set in the rerun section.
- **"Assume the card is right" or no time to confirm**: build the card, show it, mark it "not confirmed by the brand," and keep going.

### Step 1: Set the brand card

Open with a short welcome, then build the card yourself.

> Welcome to The Impostor Sweep. I'm going to check what AI assistants tell your customers when they need a refund, a login, a phone number or your official site, and whether any of it points somewhere it shouldn't. Plan on about 20 minutes. First, here's what I know about the brand. Fix anything that's off.

If the person said how much time they have, use their number instead of "about 20 minutes" and fit the path to it.

Fill the card from what the person said, from memory or profile details if you have them, and from the brand's own website with web search and fetch. Take official facts from the brand's domain only: help center, contact page, refund or returns policy, terms, login page, store locator or country selector, phishing or security page. If the brand's site blocks fetches, try the help center subdomain, search result snippets from the brand's own pages, and the person. Mark anything inferred "(guessed)" and anything missing "(not found)". A "(not found)", such as no support phone anywhere on the site, is itself a finding.

```
BRAND CARD
Brand:                [name]  |  Type: [ecommerce / SaaS / financial / travel / healthcare / B2B / local / other]
Official domain(s):   [domain.com, plus regional, product and help-desk domains]
Login page:           [URL]
Support contact:      [phone, email, chat URL]  (or "no phone support, says so on [page]")
Refund / cancel page: [URL]
Regional sites:       [list, or "one global site"]
Where to buy:         [own store, authorized retailers, app stores]
Official socials:     [handles]
Known partners:       [help-desk vendor, returns portal, resellers, agencies]
Countries that matter:[list]
```

> Reply "looks right" or tell me what to change. If you have a list of official domains or authorized sellers, paste it and I'll use it.

Agencies running this for a client should ask once for the client's domain and partner lists, which cuts false alarms sharply. For a prospect, note that the card isn't confirmed and keep going.

Save the card as `brand-record.md` if you can write files.

### Step 2: Build the sweep

Read `references/prompt-library.md`. Pick 12 to 18 prompts weighted toward the moments where impostors cluster: refunds and cancellations first, then login and account, support contact, regional sites, where to buy or discounts, "is this legit" checks, and app or software downloads. Fit them to the brand type and write them the way a customer types. Add two or three longer prompts of the kind AI writes for itself when it searches on the customer's behalf. Star the five highest-risk prompts. Show the list grouped by moment.

### Step 3: Run it

Recommend the first option that's available:

1. **I run it for you.** With a browser tool that reaches the assistants (for example Claude in Chrome), open each assistant in a fresh, logged-out or temporary chat. Run each starred prompt on its own, then the batch prompt. Cover ChatGPT, Google (AI Mode or AI Overviews), Gemini, Perplexity and Copilot where you can. Record the full answer and every link, link card and footnote. Don't click through to suspected sites from inside the assistant.
2. **You paste, I check.** Hand over the starred prompts and the batch prompt, ready to copy. Ask the person to run them in a temporary or logged-out chat in each assistant and paste the full answers back, labeled with the assistant, including the sources list.
3. **Quick read.** Use your own web search on the starred prompts. Then open the top third-party pages that come back (contact directories, "how to cancel" services, review sites) and copy their text, because that's where wrong numbers live and search snippets won't show them. Say clearly this is what a search-grounded assistant would find, not what customers see in each assistant.

Note the assistants covered, the date and whether chats were logged out.

### Step 4: Check everything

Save the answers to `answers.txt`, one block per assistant and prompt, headed like `=== ChatGPT | How do I get a refund from YourBrand? ===`. In quick read, use `=== Quick read | [prompt] ===` and put each source's URL on the first line of its block, then the page text. Then run these. Each is read only.

```
python scripts/extract_contacts.py answers.txt --out findings.json
python scripts/check_lookalikes.py findings.json --official-domains "brand.com,brand.co.uk" --brand-terms "brand" --official-phones "+1 800 555 0100" --partners "brand.zendesk.com,returnsvendor.com" --check-live --rdap --out checked.json
python scripts/lookalike_radar.py --official-domains "brand.com" --brand-terms "brand" --rdap --out radar.json
python scripts/site_audit.py --domain brand.com --pages "https://brand.com/contact,https://help.brand.com/hc/refunds" --out site_audit.json
python scripts/moment_map.py checked.json --out moment_map.md
```

The site audit reads robots.txt on every host in `--pages`, so include help-center and login subdomains. A 403, 429 or 503 from a brand's own page usually means bot protection, not a dead page: confirm with web fetch before calling it OUTDATED. The radar marks domains registered in the last 120 days as NEW and flags ones that share the official domain's registrar (often the brand's own defensive buys, so confirm before flagging them).

If the environment has no network access, the scripts say so. Then do the live checks with web fetch instead, and for the site audit save each page's text with web fetch and use `site_audit.py --files`. Web fetch often returns a summary rather than the raw page, so in file mode say crawler access is unconfirmed unless you saw the raw robots.txt. If you can't run scripts at all, do the same checks by hand and say which ones you skipped.

The scripts sort and flag. They don't decide. Then classify every item yourself, using `references/impostor-patterns.md`:

| Verdict | Meaning |
|---|---|
| OFFICIAL | Matches the brand card and the page loads |
| PARTNER / THIRD PARTY | A known reseller, help-desk vendor, review site, marketplace or directory that openly says who it is |
| OUTDATED | Belongs to the brand but is dead or wrong now: an old number, a 404, a subdomain that doesn't resolve |
| WRONG ANSWER | No bad link, but AI or an independent site states a false policy, price, number or fact |
| UNKNOWN | Not on the card and not clearly anyone; needs a look |
| SUSPECTED IMPOSTOR | Lookalike domain, brand name on free hosting, a support or refund phone number or free-mail address that isn't the brand's, copied branding, or a login or payment form on a domain the brand doesn't own |

Calls the scripts can't make:

- **Phone numbers.** A number that isn't on the card and is presented with support or refund wording ("24/7 refund line") is SUSPECTED even with no public scam reports. A number on an openly independent site (a "cancel it for you" service, a directory) is a WRONG ANSWER, high risk if money is involved. A number one digit off an official one, or a second official-looking line, needs the brand to confirm.
- **Parked and unregistered domains.** If AI is citing a domain that isn't registered or is for sale, it's still a finding: anyone can buy it and inherit the traffic. The fix is defensive registration, not a takedown.
- **Everyday-word brands** (Calm, Square, Target): most lookalikes on the radar belong to unrelated businesses. Only flag ones that present themselves as the brand.
- **People's emails on the official domain** aren't support channels. Don't put them in the official record.
- **Leads outside the answers.** If your own searching turns up a likely impostor no assistant cited, include it as an extra lead, clearly labeled.
- **Planted content on trusted sites.** Fake numbers often sit in uploaded files, forum posts, quote pages or free-site pages on someone else's trusted domain, sometimes right next to the brand's real number to look credible. These aren't lookalike domains. Report them to the site's owner or platform, not the domain registrar (the response kit has a template).
- **Quick read has no assistant columns.** The moment map shows one column; say the assistant columns fill in once the prompts run in each assistant.

Once you've decided, record your final call so the moment map and the next rerun use it, not the script's first guess:

```
python scripts/set_verdict.py checked.json "value or domain or number" "SUSPECTED IMPOSTOR" "one-line reason"
```

For each UNKNOWN, SUSPECTED and LIVE SITE radar hit, read the page with web fetch (rule 3). If a page won't load (removed, behind a sign-in, blocked), judge it on what the search result or AI answer showed, say that's what you did, and keep it on the list: search indexes and AI answers can keep citing a page after it's gone. Note what it claims to be, what it asks for (login, card, phone call, download), whether it uses the brand's logo or copied text, and whether it says who runs it. Search the domain and any phone number with the brand name plus "scam" or "fake."

Then the gaps. For each customer moment, does the brand have one clear official page that answers it in the customer's words, with the real link or number in plain text, crawlable by AI? Use the site audit for this, and compare policies across pages: a returns page and the terms that disagree count as a gap even when every link is fine. Read `references/official-answers.md` for what a good answer looks like.

### Step 5: The report

Lead with the verdict. People skim, and the first screen decides whether this goes to legal today.

```
IMPOSTOR SWEEP  |  [Brand]  |  [date]
Verdict: CLEAR / WATCH / ACT NOW
Assistants checked: [list]   Prompts run: [n]   Items checked: [n]   Lookalikes scanned: [n]

What AI is telling your customers
  [2 to 4 plain sentences: the headline finding, the riskiest moment, the biggest gap]
```

- **CLEAR**: every link and number checked out, no live lookalikes presenting as the brand, no major gaps.
- **WATCH**: no live impostor in an answer, but outdated details, wrong answers, unregistered or parked cited domains, live lookalikes on the radar, or real gaps.
- **ACT NOW**: at least one suspected impostor (site, number or email) in an answer about money, login or personal data.

Then, in this order:

1. **Customer moment map** (from `moment_map.md`).
2. **Findings table.** One row per item that isn't OFFICIAL: assistant, prompt, what it showed, verdict, why (including live status and registrar), risk.
3. **Lookalike radar.** Live sites and registered domains that matter, with what each one shows. Parked ones as a buy-or-watch list. Say plainly which ones are unrelated businesses.
4. **Site audit.** AI crawler access, conflicting or missing contact details, dead official pages.
5. **The gaps**, with what AI said instead.
6. **What's working.** Moments where every assistant sent people to the right place, so the team knows what to protect.
7. **Response kit.** Read `references/response-kit.md`. Draft only what the findings call for, filled with real details. Use the correction request for honest third parties and defensive registration for unregistered or parked domains AI is citing.
8. **Page fixes.** Official-answer copy for each gap, ready for the web team.

Write in plain language. The reader may forward this to a CEO who has never heard the phrase "impostor citation." If the person is an agency, keep internal notes in a separate, clearly labeled section at the end. If you can't save files, show the full report in the conversation.

### Step 6: Make it a habit

- **The rerun.** Save the brand card, prompt set and `checked.json` (with your final verdicts recorded). Offer a monthly rerun as a scheduled task if the person's Claude supports it, plus one right after any takedown and before a launch, a sale, an outage or Black Friday. On a rerun, use `moment_map.py checked.json --previous last_checked.json` and lead the report with what changed.
- **Claim the verified profiles** where they exist (ChatGPT Business Hub, Google Business Profile, Bing Places, Apple Business Connect), with the same contact details as the official pages.
- **One next step.** The single most important thing to do today.

## Commands

| Say | What happens |
|---|---|
| quick sweep | Starred prompts, radar and site audit: the fastest path to a verdict |
| full sweep | Every moment, every assistant you can reach |
| radar | Just the lookalike radar for a domain |
| audit our site | Just the site audit |
| check this | Paste any link, number or email and get a verdict with live status |
| draft the kit | Response kit for the current findings |
| fix the pages | Official-answer copy for every gap |
| rerun | Same brand card and prompts, new snapshot, compared to the last one |

## Things to get right

- **Small and mid-size brands** mostly land on WATCH because of gaps, not impostors. That's normal and useful. The gaps are the work.
- **Regulated industries** (financial services, healthcare, pharma, insurance): any suspected impostor asking for account numbers, Social Security numbers or health details is ACT NOW, routed to security and legal before any public statement.
- **Don't overstate the research.** The studies behind this are early and come partly from vendors that sell detection tools. Use the numbers in `references/impostor-patterns.md` with their sources.
