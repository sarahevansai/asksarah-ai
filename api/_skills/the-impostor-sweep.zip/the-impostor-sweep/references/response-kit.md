# Response kit

Draft only what the findings call for. Fill every real detail from the findings and the brand card. Use "suspected" for anything not confirmed by the brand's security or legal team. Recommend that legal or security review anything that names a third party before it goes out.

## Contents
1. Order of operations
2. Where to report
3. Report to an AI platform
3b. Correction request to an honest third party
3c. Defensive registration
3d. Planted content on someone else's site
4. Abuse report to a registrar or host
5. Phishing report
6. FTC report notes
7. Internal alert
8. Support team script
9. Holding statement
10. Customer warning post
11. Tracking log

## 1. Order of operations

For a SUSPECTED IMPOSTOR in a money, login or personal-data answer:
1. Internal alert to security, legal and support (same day)
2. Capture evidence: the AI answer text, the prompt, the assistant, the date, the URL, and a description of what the page asks for. Archive the page if the team has a tool for it.
3. Reports: registrar and host abuse (the abuse contact from the live check), phishing report, AI platform report. Defensive registration for any cited domain that isn't registered or is parked
4. Support script live, so agents can recognize affected customers
5. Official page fix published (the fastest lasting defense)
6. Holding statement ready; customer warning only if customers are likely being harmed now
7. Rerun the sweep after takedown and again in two weeks

For WATCH findings (outdated details, gaps, wrong answers): page fixes first, correction requests to third parties showing wrong details, defensive registration of cited domains anyone could buy, then a platform report for any wrong answer that touches money or safety.

## 2. Where to report

Give these routes in the kit. If a route has changed, tell the person to use the organization's current official reporting page.

- **The AI assistant**: use the report or feedback option on the answer itself (thumbs down or "report" in ChatGPT, Gemini, Copilot and Perplexity; "Feedback" on Google AI Overviews and AI Mode). Include the impostor URL and the official URL in the note.
- **Domain registrar**: find it with ICANN's lookup at lookup.icann.org. The record lists the registrar's abuse email.
- **Web host**: the hosting company's abuse contact, found from the site's IP address. For free-hosting subdomains (wixsite, blogspot, sites.google, netlify, vercel and so on), use that platform's own abuse or report form.
- **Phishing**: Google Safe Browsing (safebrowsing.google.com/safebrowsing/report_phish), Microsoft's report-an-unsafe-site page, and the Anti-Phishing Working Group (reportphishing@apwg.org).
- **US consumers harmed**: ReportFraud.ftc.gov. Outside the US, the national consumer protection or cybercrime authority.

## 3. Report to an AI platform

```
Subject: Answer directs customers to a suspected impostor of [Brand]

When asked "[exact prompt]" on [date], [assistant] cited [suspected URL] as [Brand]'s [refund page / login / support number]. [Brand]'s official [page / number] is [official URL or number]. The cited site is not operated by [Brand] and [asks for login details / lists a phone number [Brand] doesn't use / offers a download outside our official channels].

Please stop citing [suspected URL] for [Brand] and point customers to [official URL].

Contact: [name, title, Brand, work email]
```

## 3b. Correction request to an honest third party

For directories, "cancel it for you" services, review sites, news articles and consumer advocates that openly say who they are but list a wrong number, a dead link or an old policy. Polite and specific. These sites usually fix it, and AI picks up the correction.

```
Subject: Outdated [Brand] [phone number / support details / policy] on [page URL]

Your page at [URL] lists [wrong detail] for [Brand]. [That number isn't ours / That page no longer exists / Our policy is now X]. [Brand]'s current [support / refund / login] details are [official details, with URLs written out]. Could you update the page? Happy to confirm anything.

[name, title, Brand, work email]
```

If a third-party site charges customers for something the brand offers free (cancelling a subscription, filing a refund), add a line on the brand's own page saying it's free and how to do it, so AI has the official version to repeat.

## 3c. Defensive registration

For domains AI is citing that aren't registered, or are parked or for sale. There's nothing to take down, but whoever buys the domain next gets customers sent to it by AI.

- Register it (or buy it from the parking marketplace if the price is reasonable) and redirect it to the right official page.
- Prioritize cited domains first, then live-risk radar results in the refund, support, login and outlet patterns.
- Hand the list to whoever manages the brand's domains, with the page each one should redirect to.

## 3d. Planted content on someone else's site

For fake numbers or support pages planted on a trusted site the brand doesn't own: a university file upload, a forum post, a quote or review page, a free-site page (Google Sites, Notion, HackMD), a survey tool. The site owner didn't write it and usually wants it gone. Report it to the site or platform through its report link or its security or abuse contact. The domain registrar is the wrong recipient here.

```
Subject: Fraudulent [Brand] support details posted on [site]

A page on your site, [URL], lists [fake phone number / fake support page] as [Brand]'s [support / refund / account recovery] line. [Brand] doesn't operate it. Our only [support number / help page] is [official]. It looks like content planted to be picked up by search engines and AI assistants, and customers could be scammed.

Please remove it, and check for similar posts: we've also seen [other URLs, if any]. Seen [date].

[name, title, Brand, work email]
```

Universities, nonprofits and government sites usually route this to their IT security team. Search the site's domain plus "report abuse" or "security" for the right contact.

## 4. Abuse report to a registrar or host

```
Subject: Abuse report: [suspected domain] impersonating [Brand]

[suspected domain] is impersonating [Brand] ([official domain]). The site uses [Brand]'s name [and logo / copied site text] and [asks visitors for passwords / payment details / to call a support number [Brand] doesn't operate]. AI assistants are citing it to customers looking for [Brand]'s [refund / login / support] page.

Evidence:
- URL: [full URL]
- Seen: [date and time, time zone]
- What it asks for: [description]
- Official [Brand] site: [official URL]

[Brand] has not authorized this site. Please investigate and suspend it under your abuse policy.

[name, title, Brand, work email, phone]
```

If the brand has a registered trademark, legal may add the registration details and a formal notice. Leave that to them.

## 5. Phishing report

Short and factual. The URL, the brand it imitates, the official URL, and what it asks for. Submit to each phishing route in section 2.

## 6. FTC report notes

The brand files only if it has been harmed or is reporting on behalf of customers; customers who lost money should file their own reports. Give the brand a short paragraph its support team can share with affected customers:

```
If you shared payment or login details with a site or phone number that claimed to be [Brand], contact your bank or card issuer right away, change your [Brand] password at [official login URL], and report it at ReportFraud.ftc.gov. [Brand]'s only official support number is [number].
```

## 7. Internal alert

```
Subject: [ACT NOW / WATCH] AI assistants citing suspected [Brand] impostor

What we found: On [date], [assistant(s)] sent customers asking "[prompt]" to [suspected URL / number], which we don't own. It [asks for / shows] [what]. [n] of [n] assistants checked did this.

Risk: [who could be hurt and how]

Doing now: [reports filed, page fix in progress]
Need from you:
- Security: confirm and take over the takedown
- Legal: review before any public statement
- Support: watch for customers mentioning [URL / number]; script attached

Full sweep report attached.
```

## 8. Support team script

```
If a customer mentions [suspected URL / number] or says they got help from a [Brand] number they found through an AI assistant or search:
- Tell them that isn't an official [Brand] site or number, and that [Brand] will never ask for [what the fake asks for].
- Our only official [support number / login page / refund page] is [official].
- If they shared card or login details, tell them to contact their bank and reset their password at [official login URL].
- Log the contact with the tag [tag] and the URL or number they used.
```

## 9. Holding statement

For use if a reporter, partner or customer asks. Plain, human, no blame on the customer.

```
We're aware of a website [and phone number] falsely presenting itself as [Brand]. It isn't run by us, and we're working to have it taken down. [Brand]'s official site is [domain] and our support team is reachable at [official contact]. We'll never ask for [password / full card number / one-time code] by phone or email. If you think you shared information with this site, please contact your bank and reach us at [official contact] so we can help.
```

## 10. Customer warning post

Only when customers are likely being harmed now. Keep it short enough to post on social and pin in the help center.

```
Heads up: a fake site [and phone number] using the [Brand] name is showing up in some search and AI assistant results. It isn't us.

Our only official site is [domain]. Our support number is [number]. We'll never ask for your password or full card number.

If you think you were affected, contact your bank and reach us at [official contact].
```

## 11. Tracking log

| Item | Assistant(s) | First seen | Reported to | Date reported | Status | Last checked |
|---|---|---|---|---|---|---|
| [URL or number] | | | | | Open / Down / Still cited | |

Keep it with the brand card so the next sweep can compare.
