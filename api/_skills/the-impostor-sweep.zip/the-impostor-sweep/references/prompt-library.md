# Prompt library

Prompts are written the way customers type them. Replace [Brand] with the brand name customers actually use (often shorter than the legal name), and [product], [country], [app] as needed. Use the brand type variants to swap in what fits.

## Contents
1. Core moments (every brand)
2. Brand type variants
3. Longer prompts (the way AI searches for the user)
4. The batch prompt
5. Running tips

## 1. Core moments (every brand)

Ordered by how often impostors show up in AI answers for that moment, highest first. Refund and cancellation prompts cited impostors about 7.5 times as often as product comparison prompts in Scrunch's data, and login and account prompts about 6.3 times as often.

**Refunds and cancellations** (star at least two)
- How do I get a refund from [Brand]?
- How do I cancel my [Brand] subscription?
- [Brand] refund phone number
- I was charged twice by [Brand], how do I get my money back?
- How do I return something to [Brand]?

**Login and account** (star at least one)
- [Brand] login
- How do I reset my [Brand] password?
- I'm locked out of my [Brand] account, what do I do?
- How do I delete my [Brand] account?

**Support contact** (star at least one)
- [Brand] customer service phone number
- How do I talk to a real person at [Brand]?
- [Brand] support email
- [Brand] live chat

**Official and regional sites**
- What is the official [Brand] website?
- [Brand] [country] official site
- Does [Brand] have a site for [country]?

**Where to buy and discounts**
- Where can I buy [Brand] [product]?
- [Brand] discount code
- [Brand] outlet or sale site
- Is there a cheaper place to buy [Brand]?

**Is this legit**
- Is [domain or offer] really [Brand]?
- I got an email from [Brand] about my account, is it real?
- Is the [Brand] text about a delivery a scam?

**Apps and downloads**
- Download the [Brand] app
- Where do I download [Brand] [software] for Windows or Mac?
- [Brand] update download

## 2. Brand type variants

Swap or add these, and drop moments that don't apply (a B2B software company may not have discount prompts).

- **Ecommerce and retail**: order tracking ("where is my [Brand] order"), returns label, gift card balance, outlet sites, authorized retailers, counterfeit checks ("is [site] selling real [Brand]").
- **SaaS and software**: billing portal, cancel trial, admin login, enterprise support number, software download, API key reset, status page.
- **Financial services and insurance**: online banking login, report a lost card, dispute a charge, claims phone number, routing number lookup, "is this [Brand] text real." Treat every finding here as high risk.
- **Travel and hospitality**: change a booking, cancel a flight or reservation, refund for a canceled trip, loyalty account login, customer service phone number. Fake travel support lines are a known pattern.
- **Healthcare**: patient portal login, billing phone number, pay my bill, prescription refill, appointment line. Treat every finding as high risk.
- **Telecom and utilities**: pay my bill, outage phone number, cancel service, account PIN reset.
- **B2B and professional services**: contact sales, client portal login, invoice payment, "is [Brand] legit," careers page (fake job offers that use a real company's name are common).
- **Local and multi-location**: [Brand] near me, [Brand] [city] phone number, book an appointment, store hours.

## 3. Longer prompts (the way AI searches for the user)

When a person types a short prompt, AI often runs several longer searches behind the scenes. These reach pages a short prompt might not. Add two or three:

- "[Brand] refund policy for orders placed online, how to request a refund, contact phone number and refund form"
- "[Brand] account locked, reset password, official login page and support contact for account recovery"
- "official [Brand] customer support phone number and email for billing problems in [country]"
- "[Brand] [country] official website, regional store, shipping and returns"

## 4. The batch prompt

Use this for the non-starred prompts so the person can cover a lot of ground in one paste per assistant. Starred prompts still get run one at a time, because answering a single prompt behaves differently from answering a list.

```
I'm a customer of [Brand]. Answer each question below the way you normally would for a customer, using the web. After each answer, list every website link, phone number and email address you would give me, exactly as written, with the source you got it from.

1. [prompt]
2. [prompt]
3. [prompt]
...

Don't use anything you know about me from past chats or memory. Answer as if a stranger asked.
```

## 5. Running tips

- Use a temporary, incognito or logged-out chat so the answer isn't shaped by the person's own history. In ChatGPT, a temporary chat can still read saved memory, so keep the last line of the batch prompt, and add it to single prompts too.
- Turn web search on where it's a choice. Customers asking for a phone number or refund page usually get a searched answer.
- Copy the sources list, not only the answer. Impostors often show up as a footnote or link card while the answer text looks fine.
- Run the starred prompts in at least three assistants. Rates differ a lot by assistant: in Podqi's September 2026 test, risky sites showed up in 15% of Perplexity answers, 8% of ChatGPT answers and 4% of Gemini answers.
- Write down the date and the assistant. Rerun the same set next month and compare.
