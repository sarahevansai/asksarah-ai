# Official answers: closing the gaps

AI uses whatever page answers the prompt best. A brand closes the door on impostors by being that page for every customer moment.

## The eight pages every brand should have

1. **Refunds**: how to request one, the timeline, the real form or contact
2. **Cancellations**: how to cancel, in the fewest steps, with the real link
3. **Login help**: the official login URL, password reset, locked-out steps
4. **Support contacts**: every real phone number, email and chat link, with hours
5. **Regional sites**: the list of official country and regional sites, and a line saying there are no others
6. **Authorized sellers**: where to buy, and a line saying how to spot unauthorized sellers
7. **Is this really us**: how the brand contacts customers, what it will never ask for, and the real domains it sends email from
8. **Report a scam**: where customers report fake sites, numbers or messages using the brand's name

Not every brand needs all eight. A B2B firm may fold 1, 2 and 6 into one billing page. But every customer moment in the sweep needs a clear official answer somewhere.

## How to write them so AI finds and trusts them

- **Use the customer's words.** Title and open the page with the phrasing from the prompts ("How to get a refund from [Brand]"), not internal names ("Remittance policy"). The leading explanation for why impostors win is that they match the question's wording better.
- **Answer in the first two sentences.** State the real number, link or steps right away, in plain text. Don't hide the phone number in an image or behind a "contact us" form.
- **One answer per moment, the same everywhere.** If the help center, the footer and the app all list different numbers, AI may pick any of them, including an old one. Retire old numbers and pages, and redirect them.
- **Say what's not official.** A line like "[Brand] only uses brand.com and brand.co.uk. We'll never ask for your password by phone" gives AI something to repeat when a customer asks "is this real."
- **Keep the pages public and crawlable.** A help center behind a login, or blocked from search engines and AI crawlers, can't be cited.
- **Keep the brand's old domains.** Expired brand domains are a top impostor source. Renew campaign and regional domains instead of letting them lapse, and redirect them to the main site.
- **Back it with consistent facts elsewhere.** The same support details on the brand's verified business profiles, app store listings and social bios make the official answer the obvious one.

## Verified profiles to claim

AI platforms are starting to lean on verified brand sources. Claim and verify where they exist, and keep the details identical to the official pages:
- ChatGPT Business Hub (launched November 2026; verified profiles via business phone, business email or a website DNS record)
- Google Business Profile
- Bing Places for Business
- Apple Business Connect
- Official app store listings and verified social accounts

## Writing the page fixes in the report

For each gap, give the web team:
- The page title, in customer words
- The first two sentences, with the real details from the brand card
- Where it should live and what to redirect to it
- Anything to retire (old numbers, dead pages)

Mark any detail you couldn't confirm from the brand card as [confirm].
