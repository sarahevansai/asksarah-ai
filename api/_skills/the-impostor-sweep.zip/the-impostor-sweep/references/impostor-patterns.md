# Impostor patterns and signals

Use this to classify every UNKNOWN item and to explain findings in plain language.

## Contents
1. Why AI cites impostors
2. Domain patterns
3. Page signals
4. What is not an impostor
5. Phone numbers and emails
6. The research behind this (use these numbers, with their sources)

## 1. Why AI cites impostors

Explain it this way in reports, because it tells the brand what to fix:

- **Wording beats authority.** The leading explanation from Scrunch's study is that impostor pages matched the wording of the customer's question more closely than the real brand pages did. Some impostors copy the brand's own text to do it.
- **AI filters less than Google.** AI assistants pull from a wide pool of sources to write one answer and appear to screen them more loosely than Google's ranking does. Only 2.2% of the impostor sites AI cited appeared in Google's top 10 results, against 40.9% of other cited sources. So a brand watching its Google rankings won't see the problem.
- **Usual warning lists miss them.** Fewer than 1% of the cited impostor domains appeared on three public threat feeds, and every known impostor in the study was outside the top million sites by traffic.
- **Planted content on trusted sites.** In a separate campaign researchers called "Dark Sourcery," attackers put fake support numbers and login pages on high-authority domains (university and government sites, through comment sections, uploaded files or compromised pages) plus social posts, forums and review pages, so AI would pick them up and repeat them.
- **The answer reads as fact.** The fake detail shows up as a plain statement in the answer, so the customer acts on it without visiting a page.

The fix that follows: publish the official answer for every customer moment, in the customer's words, with the real link and number in plain text, and check AI answers directly.

## 2. Domain patterns

The most common impostor domain types in Scrunch's study, with examples for a brand called "YourBrand" at yourbrand.com:

| Pattern | Example | Notes |
|---|---|---|
| Misspelling | yourbrnad.com, y0urbrand.com | Includes swapped letters, doubled letters, l for i, rn for m |
| Brand plus a word | yourbrand-support.com, yourbrandrefunds.com, getyourbrand.com | Words like support, help, help-center, refund, login, account, secure, verify, official, outlet, store, shop, sale, app, download, care, service |
| Look-alike country domain | yourbrand.co, yourbrand.com.co, yourbrand-uk.shop | Watch .co, .cm, .om, .net, .shop, .store, .online, .site, .top, .xyz, and country endings the brand doesn't use |
| Free hosting | yourbrand.wixsite.com, yourbrand-help.blogspot.com, sites.google.com/view/yourbrand | Also weebly, webflow.io, netlify.app, vercel.app, pages.dev, github.io, notion.site, carrd.co, godaddysites.com, square.site, framer.website |
| Expired brand domain | an old campaign or regional domain the brand let lapse | Often shows a parked or for-sale page, or a copy of the old site |
| Copy of the brand's site | a full clone on an unrelated domain | Same logo, same text, different contact details |

Brand plus a word is the hardest to call, because legitimate brands use these too (yourbrandstatus.com). Check the brand card and partner list, and look at who the page says runs it.

## 3. Page signals

When you read a suspected page (read only):

**Strong signals of an impostor**
- Asks for a password, card number, bank details, Social Security number or one-time code on a domain the brand doesn't own
- A phone number with support wording ("24/7 helpline," "refund department") that doesn't match the brand card
- Offers to "unlock," "recover" or "refund" an account for a fee
- Pushes a software download or "update" outside the brand's site or the official app stores
- Uses the brand's logo and copied text with no line saying who actually runs it
- Unusually deep discounts on a "store" for a brand that doesn't run outlets there
- Casino, gambling or crypto content on a page wearing the brand's name (about 6 in 10 known impostors still online had at least one of: a casino or gambling page, a login form, a discount storefront, a phone number with support wording, or crypto content)

**Weaker signals (note them, don't decide on them alone)**
- Very new domain, parked page or for-sale notice
- No privacy policy, no company address, contact through a form only
- Reported by others when you search the domain or number with "scam"

A login form alone is not proof of phishing. Say "asks for a login on a domain [Brand] doesn't own" rather than "phishing site."

## 4. What is not an impostor

Scrunch counted these separately and so should you. Mark them PARTNER, or UNKNOWN if you can't tell:

- Review and comparison sites that openly belong to someone else
- Affiliate and coupon sites that say they're independent
- Authorized resellers, marketplaces and app stores
- News coverage, forums and social posts about the brand
- The brand's own agencies, payment processors, help desk platforms and status pages (ask if unsure; help centers often live on a vendor's domain like brand.zendesk.com)

A partner site can still be a problem if it's outdated or wrong. That's a WRONG ANSWER or OUTDATED finding, not an impostor.

## 5. Phone numbers and emails

- Compare every number against the brand card, ignoring formatting. A number that's off by one digit counts as a mismatch.
- Search unknown numbers with the brand name and "scam." Researchers who called numbers handed out by chatbots reached people who offered to fix a flight or a bank account and then asked for card details. Never call one yourself.
- Emails on a domain the brand doesn't own, or on a free mail provider, are suspected unless the brand confirms them.

## 6. The research behind this

Cite these with their sources. Both studies are early, and Scrunch sells a detection tool, so say so if the report will be shared widely. Links:
- Scrunch study: https://scrunch.com/blog/impostors-are-in-your-ai-answers-websites-posing-as-your-brand-and-why-llms-cite-them
- Scrunch and Podqi summary: https://www.marketingtechnews.net/news/ai-search-fake-brand-websites/
- Dark Sourcery summary: https://www.paubox.com/blog/fake-support-numbers-planted-in-ai-chatbot-answers
- Businesses in ChatGPT (Business Hub): search "Introducing Businesses in ChatGPT" on openai.com

If a link has moved, search the study name rather than citing a figure without a source.

- **Scrunch** (study of AI answers collected May to October 2026 across ChatGPT, Perplexity, Gemini, Google AI Overviews, Google AI Mode and Microsoft Copilot): impostor sites were cited for 83 Fortune 500 brands (about 17%). About 1 in 1,250 answers with sources cited an impostor. Roughly three-quarters of answers citing a known impostor presented it as the brand's own source, and 0.3% warned users. Refund and cancellation prompts cited impostors about 7.5 times as often as product comparison prompts, and login and account prompts about 6.3 times as often. Google AI products had lower impostor rates than the others.
- **Podqi** (6,795 responses from ChatGPT, Gemini and Perplexity in September 2026, 151 brands, shopping questions): 718 of 4,437 domains found were risky (351 fake or suspected counterfeit, 367 inactive). Risky sites appeared in 15% of Perplexity answers, 8% of ChatGPT and 4% of Gemini. Regional site questions had the highest rate at 16%, and 36% of risky sites used country endings or regional names.
- **Dark Sourcery** (reported by Dark Reading, October 2026): tens of thousands of planted pages with fake support numbers, contact details, sign-in pages and update instructions, affecting at least 374 organizations, aimed at customer support, account recovery, refunds, payments and downloads. A study cited in the research found 91% of people using AI chatbots don't check the answers.
- **FTC**: US consumers lost $3.5 billion to impostor scams in 2025, close to $1 billion of it to people posing as businesses.
