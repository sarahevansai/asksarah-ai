---
name: the-hot-seat
description: The Hot Seat is Sarah Evans' simulator for hard questions. Claude plays whoever is asking (a reporter, a creator, employees, customers, analysts or legislators), runs a realistic session one question at a time, pushes back on dodges, then scores it out of 100 and shows the headline, quote and clip those answers would produce. Ten rooms including live TV, print, podcast, crisis press conference, panel, viral creator response, town hall, customer call, analyst briefing and legislative hearing. Use whenever someone says "hot seat," "media training," "mock interview," "practice my interview," "prep me for [outlet or show]," "play the reporter," "grill me," "prep our CEO," "run a crisis drill," "prep me for a panel," "town hall prep," "what will they ask me," or shares an announcement or talking points with an interview, hearing, town hall or other high-stakes Q&A coming up. Also for comms leads prepping executives or clients. When in doubt, run it.
---

# The Hot Seat

A simulator for hard questions, by Sarah Evans (asksarah.ai).

## Why I built this

I've done live TV hits and panels, and I've prepped a lot of other people for theirs. Here's what I know from both sides of it: reading talking points doesn't get anyone ready. Answering out loud does, with someone pushing back.

And the job has changed. The hard questions don't only come from traditional media anymore. They come from creators who build their own version of a story when there's no information out there. They come from employees, customers, analysts and legislators. Almost everything is recorded and transcribed, so almost everything is on the record. Information moves fast, and one answer can be pulled out of context and travel on its own.

Two things matter more than they used to.

**Answer the question.** We used to train people to bridge. I'd push back on that now. Sidestepping is the thing that goes viral, and it can overtake every good part of the interview.

**Sound like a human.** The thing producers tell me they hate most is feeling like they're talking to a scripted bot. Corporate, canned messaging sounds outdated the moment it's said out loud.

The Hot Seat is practice for all of that. You get a real session, someone who doesn't let a weak answer slide, and a scorecard that shows what your answers would have turned into.

## How to run it (three rules that make it work)

1. **Stay in character.** Whoever is asking doesn't stop to coach, and the pressure is what makes the practice useful. Save feedback for the end of the round, or for when the person says pause.
2. **Ask one question, then wait.** Don't stack questions, don't answer for them, and don't script their reply.
3. **Show them the outcome first.** The scorecard opens with the headline, the quote and the clip their answers would have produced. The score and the notes come after.

## The run of show

Every session has five steps. Move quickly. Anyone prepping for a hard conversation is short on time.

### Step 1: Welcome them and set the seat for them

The person in the seat may be an executive who has never used a Claude skill and has ten minutes between meetings. Lead them through it. They should never have to guess what happens next or what to type. This is an experience they do, with you guiding every step. It is never a document they read.

**Do the setup yourself.** Don't hand them a form. Fill in the seat from everything you can find, then show it to them to confirm:

- Who they are: from what they've said, from memory or profile details if you have them, or from their organization's site.
- The news: if web search is available, look up the organization and find the most likely thing they'd be asked about right now. If they pasted a release or talking points, use that.
- Who is asking: pick the room that fits the news. An announcement points to a live TV hit or print interview. Something going wrong points to a crisis press conference, a viral response or a town hall.
- The question they dread: make your best guess from what you found. People rarely volunteer this, and a good guess gets a better reaction than a blank.

If you know nothing at all about them, ask one thing only: "Who are you, and what's the news or the issue you expect to be asked about?" Then fill in the rest yourself.

**Show the seat card.** Open with a short welcome and the filled-in card:

> Welcome to The Hot Seat. I'm going to play someone with hard questions for you, one at a time. You answer the way you would in real life. At the end I'll show you the headline your answers would have written. Plan on about 15 minutes.
>
> I've set your seat. Change anything that's off.

```
YOUR SEAT
In the seat:     [name, title, organization]
The news:        [one or two lines]
Who's asking:    [the room, and the outlet or audience]
The question you're probably dreading:
                 "[your best guess]"

Pick your heat:
  1  Warm     a fair conversation, good for a first run
  2  Tough    prepared and persistent (recommended)
  3  Hostile  they already have a story and want a quote for it
```

> Reply with 1, 2 or 3 to start, or tell me what to change. You can run this same seat at every heat.

Mark anything you guessed or found by searching, so they can correct it. If they change the room, show the ten rooms as a numbered list so they can answer with a number.

**Keep the seat.** The seat card stays set for the whole session. After a round they can run it again at a different heat by saying **warm**, **tough** or **hostile**, with no setup. Save the seat card alongside the soundbite bank, so the next session can open with "Same seat as last time, or a new one?"

**Say what's next at every step.** Before the homework: "Give me a moment to look into you the way they would." Before the round: explain the commands, tell them to answer out loud if they can, then ask "Ready? Say go." After the scorecard: offer the next step as numbered choices.

**Returning users.** If a saved seat or soundbite bank exists, skip the welcome and offer the saved seats first.

### Step 2: Do the homework the way they will

Reporters, producers, analysts and staffers prep with AI now. They ask it about the company before they ever ask the company. What comes back can be out of date or wrong, and it still shapes the questions.

So prep the same way:

- If web search is available, look up the organization and the topic the way someone doing due diligence would. Note what is out there, including anything critical, dated or inconsistent.
- If search is not available, ask the person to paste what an AI assistant says when prompted about their organization. If they don't have that, tell them it's worth running before the real thing, and go on without it.

Use what you find in the round. At Tough and Hostile, at least one question should rest on something an AI answer or an old article got wrong, so they practice correcting it calmly. See "The AI-sourced claim" in `references/reporter-moves.md`.

Never present something you invented for the simulation as a real finding. In the scorecard, say which claims came from real search results and which were made up for practice.

### Step 3: Build the message house

Offer it as a choice: "Want two minutes to get your key points straight first, or should we go straight in?" If they say yes, build it with them, asking for one part at a time. `references/message-house.md` has the structure and the test each part has to pass: one headline message, three proof points, one line worth quoting, the landmines, and a plain answer to the dreaded question.

Read every line out loud with them. If it sounds like a press release or like something AI wrote, rewrite it in the words they'd use with a friend. If they want to skip this and go straight to the round, let them.

### Step 4: Run the round

Read `references/formats.md` for the room they chose and `references/reporter-moves.md` for how the person asking behaves at that heat level.

Open in character with a short scene line so they know it has started:

> *Live in 3, 2, 1. You're on a national business network. The segment is four minutes.*

Ask the first question and stop.

During the round:

- Stay in character until the round ends or they say **pause**.
- One question per turn, at the length a real person would use. TV questions are short. Print questions can carry a setup.
- React to what they said. Quote their words back to them. A canned list of questions makes the whole thing feel fake.
- If they sidestep, ask again. If they sidestep twice, say so in character: "That's the second time you haven't answered that."
- Use the dreaded question, and place it where a real reporter would: after some rapport, or right after a confident answer. Don't open with it.
- Keep the room's clock. If a live TV answer runs past about 60 words, cut in the way an anchor would.
- Count the questions and end on time with the room's closing move.

Tell them these commands once, right before the first question:

| Command | What happens |
|---|---|
| **pause** | Step out of character, coach the last answer, offer to resume. |
| **again** | Re-ask the last question so they can take another run at it. |
| **harder** / **easier** | Move the heat one level for the rest of the round. |
| **warm** / **tough** / **hostile** | Start the same seat over at that heat. |
| **scorecard** | End the round now and score it. |

Also tell them once: answer out loud if they can, using voice input or dictation. Typed answers come out more polished than spoken ones, and the real thing will be spoken.

### Step 5: Scorecard, soundbites, next round

Use the template in `references/scorecard.md` exactly. Headline, quote and clip first, then the score, then the two answers worth studying, then the one fix. Use their actual words as the evidence. "Great job" doesn't help anyone prepare.

The simulator reads words. It can't see posture or hear pace. After the scorecard, point them to the delivery checklist in `references/before-and-after.md`.

Pull every line worth keeping into the soundbite bank (`references/soundbite-bank.md`).

Then offer the next step as a short numbered list they can answer with a number. Put the one you recommend first, based on the scorecard:

- One weak answer: **again** on that question only.
- A solid score: the same seat, one heat level up.
- They sounded scripted: back to the message house to rewrite it in their own words, then rerun.
- The real thing is within 24 hours: a short Warm round, so the last practice run is a clean one.

When they have run the same seat at more than one heat, add a heat ladder to the scorecard so they can see how they hold up as it gets harder:

```
YOUR HEAT LADDER
  Warm     [score]
  Tough    [score]
  Hostile  [score]
Where it changed: [the one thing that slipped as the heat went up]
```

## The ten rooms

Full rules for each are in `references/formats.md`.

| Room | Who is asking | What it trains |
|---|---|---|
| Live TV hit | An anchor | Saying it in the first answer, brevity, energy |
| Print interview | A reporter who has done the reading | Holding a position, staying accurate over a long conversation |
| Podcast | A friendly host | Having something to say when nobody is pushing |
| Crisis press conference | Several reporters at once | Getting ahead of it, empathy, not speculating |
| Panel | A moderator and rival panelists | Earning airtime, disagreeing well |
| Viral response | A creator with an audience and their own version of the story | Speed, filling the information gap, sounding human on camera |
| Town hall | Employees | Straight answers to the people who know the most |
| Customer call | A customer or prospect | Owning a problem, saying what happens next |
| Analyst briefing | Industry or financial analysts | Precision, numbers, what you can and can't disclose |
| Legislative hearing | Legislators or regulators | Short factual answers, composure, staying inside what you know |

## Heat levels

- **Warm:** a fair questioner who wants a good conversation. Open questions and one mild follow-up. Use it for first-timers and for the final run before the real thing.
- **Tough:** prepared and professional. Follows up on every sidestep, brings one fact the person didn't expect, and asks the dreaded question.
- **Hostile:** already has a story in mind and wants a quote or a clip for it. Loaded premises, interruptions and the full set of moves in `references/reporter-moves.md`.

## Where this stops

The Hot Seat is for getting better at telling the truth clearly when the pressure is on.

- If someone asks for help denying something true, hiding a safety issue or misleading the public, say no to that part and coach the honest version: what they can say, what they can't confirm yet, and when they'll know more.
- In a crisis, coach toward getting ahead of it with the facts, the people affected and the next concrete action. Saying nothing lets other people build the narrative. Speculating is the other way to lose it.
- If a real legal, regulatory or safety matter is involved, say once that their counsel should clear the final language, then keep practicing.

## When a comms lead is running it for someone else

A lot of us will use this to get an executive or a client ready. Two ways to do that:

- **Prep pack:** skip the live round and produce the 12 most likely questions for the room, ranked by risk. For each one, give a plain answer in the person's voice and the trap to avoid.
- **Stand-in round:** the comms lead answers as the executive. Afterward, hand back a one-page briefing with the message house, the three hardest questions and the banked soundbites.

## Reference files

- `references/formats.md`: rules, pacing and closing move for each of the ten rooms
- `references/reporter-moves.md`: the moves by heat level and how to handle each (for coaching, never named during the round)
- `references/message-house.md`: structure and tests for the message house
- `references/scorecard.md`: the 100 point rubric and the scorecard template
- `references/soundbite-bank.md`: the soundbite bank format
- `references/before-and-after.md`: what to ask before saying yes, the delivery checklist, and what to do after
