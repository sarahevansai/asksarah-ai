# The Hot Seat

A simulator for hard questions. Claude plays whoever is asking (a reporter, a creator, your employees, a customer, an analyst or a legislator), asks one question at a time, pushes back, and shows you the headline your answers would have written.

Built by Sarah Evans. Available at [asksarah.ai](https://asksarah.ai).

---

Thanks for picking this up. Here's how to get into your first round in about five minutes.

## Install

**Claude apps (claude.ai, desktop, mobile)**

Upload `the-hot-seat.zip` in your skills settings and make sure it's switched on.

**Claude Code**

Unzip the folder into your skills directory:

```
~/.claude/skills/the-hot-seat/
```

## Your first round

Start a new chat and type:

> Put me in the hot seat.

That's all you need to know. Claude sets your seat for you: who you are, the news you're likely to be asked about, who's asking, and its best guess at the question you're dreading. You fix anything that's off and pick a heat: Warm, Tough or Hostile.

Then the round starts. It asks one question, you answer, and it reacts to what you said. At the end you get your scorecard, and you can run the same seat again at a different heat by saying "warm," "tough" or "hostile."

You don't need to prepare anything or read the rest of this page first.

## The ten rooms

Live TV hit, print interview, podcast, crisis press conference, panel, viral response (when a creator has posted their own version of your story), town hall, customer call, analyst briefing and legislative hearing.

## A few things I'd do

- **Answer out loud.** Use voice input or dictation if you have it. You'll be speaking in the real thing, and typed answers are always tidier than spoken ones.
- **Answer the question.** If you were trained to bridge, this will feel different. Sidestepping is what gets clipped and shared now, so the scorecard rewards a straight answer.
- **Check what AI says about you first.** The people interviewing you are doing it. Paste in what you find and Claude will use it in the round.
- **Run all three heats.** Same seat, Warm then Tough then Hostile. Your heat ladder shows where your answers change as the pressure goes up.
- **Run the same round twice.** The second score is the one that tells you where you are.
- **Keep your soundbite bank.** Claude builds it at the end of each session. Paste it back in next time, or let Claude save it if you're working in a project folder.

## The commands

| Say | What happens |
|---|---|
| pause | Claude steps out of character and coaches your last answer |
| again | Same question, another try |
| harder / easier | The heat moves one level |
| warm / tough / hostile | Same seat, started over at that heat |
| scorecard | The round ends and you get your score |

## Prepping someone else

Say "build a prep pack for [name] for [outlet or audience]" and you'll get the likely questions ranked by risk, with a plain answer for each. Or run the round yourself as the executive and hand them the one-page briefing.

Questions or feedback: asksarah.ai

Sarah
