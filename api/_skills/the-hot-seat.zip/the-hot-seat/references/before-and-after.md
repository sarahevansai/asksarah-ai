# Before and after

The round covers what gets said. These three checklists cover everything around it. They are written for media interviews, and most of it applies to any room.

## Before you say yes

Find these out before agreeing to any interview. A reporter or producer expects to be asked.

- What is the story about, and what prompted it?
- Who else are you talking to?
- What do you need from us specifically?
- Is it live or taped? If taped, how long will the finished piece run?
- In person, in studio or on a video call?
- When does it run, and what is your deadline?
- Who is doing the interview? (Then read or watch their last three pieces.)
- Can we send background or data ahead of time?

Assume you are being recorded and transcribed from the first hello. Almost everything is on the record now.

Off the record and on background still exist, and they still work with the right reporters, depending on what is happening. Agree the terms out loud before you say the thing, and say exactly what you mean by them, because the terms mean different things to different people.

Keep your own recording of every interview. If your words are taken out of context, or a fake clip or cloned voice shows up later, having the original is the fastest way to set the record straight.

It is fine to say: "Let me get back to you in an hour." It is fine to decline.

## Delivery checklist

The simulator can only read words. Check these by recording a practice answer on a phone, or by asking a colleague to watch.

**On camera**
- Look at the interviewer, or at the camera lens on a remote hit. Do not look at your own image on screen.
- Sit forward slightly. Feet flat. Hands visible and still unless you are making a point.
- Finish the answer and stop. Hold your expression for two seconds after you finish, because the camera is still on you.
- Plain, solid colors. Nothing that makes noise when you move.

**On a video call**
- Camera at eye level. Light in front of you, not behind.
- Wired headphones or a tested microphone. Close everything that can ping.
- Notes are fine if they sit right beside the lens and hold only the message house.

**Voice**
- Slower than feels natural. Nerves speed everyone up.
- Drop your pitch at the end of a sentence so it sounds like a statement.
- A pause before the answer reads as thoughtful. Use it.

**Audio only (radio, podcast)**
- Smile when you start. It changes how you sound.
- Use the host's name once or twice.
- Say the organization's name instead of "we." Listeners tune in mid-segment.

## After the interview

- Write down what you said while you remember it, especially any number.
- If you got a fact wrong, tell the reporter right away with the correct one. Reporters respect a fast correction.
- Send anything you promised (data, a photo, a spelling) within the hour.
- A short thank-you note is good practice. Asking to approve the story is not.
- Watch for clips. Short cuts of the interview will circulate separately from the full piece, sometimes for weeks.
- When the piece runs, check the facts. Ask for a correction only on errors of fact, with the evidence attached. Tone and emphasis are the reporter's call.
- If an interviewer cited something wrong from an AI answer or an old article, get the source corrected. The next person will see the same thing.
- Add what worked to the soundbite bank, and note the question you did not see coming so it goes into the next round.
