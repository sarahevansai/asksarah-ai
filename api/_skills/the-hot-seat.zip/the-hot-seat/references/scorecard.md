# The scorecard

Deliver this at the end of every round. Use the template exactly, in this order. The headline, the quote and the clip go first so the person sees what their answers produced before they see the score.

## Scoring: 100 points

Score from what they actually said. Quote their words as evidence for every category.

### Answered the question (25)
Did they answer what was asked, in the first sentence?
- 22 to 25: direct answers throughout. When they couldn't answer, they said so and said why.
- 15 to 21: mostly direct, with one or two sidesteps.
- 8 to 14: several questions never got an answer, or the answer came after a long wind-up.
- 0 to 7: sidestepped throughout. This is the round that gets clipped and shared.

### The message landed (20)
Would the audience know what they came to say?
- 17 to 20: the headline message was clear early, came back in different words, and had proof behind it.
- 11 to 16: it landed, late or only once.
- 5 to 10: pieces of it appeared, never as one clear statement.
- 0 to 4: an audience member could not say what the message was.

### Sounded like a human (20)
Did it sound like a person talking, or like a script?
- 17 to 20: plain words, a real example or story, some warmth, answers that responded to what was actually asked.
- 11 to 16: mostly natural, with stretches that sounded rehearsed.
- 5 to 10: corporate phrasing, repeated lines word for word, little reaction to the questions.
- 0 to 4: read like a press release or an AI draft.

### Held up under pressure (15)
How did they handle the hard moments?
- 13 to 15: steady tone, corrected false premises and wrong facts calmly, handled interruptions and silence.
- 8 to 12: held together, with visible defensiveness or drift once or twice.
- 0 to 7: rattled, irritable, or talked themselves into trouble.

### Clear and brief (10)
Would the audience follow it, and did it fit the room's clock?
- 9 to 10: easy to follow, right length.
- 5 to 8: some jargon, or some answers ran long.
- 0 to 4: hard to follow or consistently over time.

### What they protected (10)
Start at 10 and subtract for each giveaway. Minimum 0.
- Repeated the interviewer's negative word or frame: minus 2 each
- Speculated on a hypothetical: minus 3
- Offered an unconfirmed number or fact: minus 3
- Characterized a competitor, a critic or a person: minus 2
- Said something they flagged as a landmine: minus 4
- Treated something as off the record with no terms agreed beforehand: minus 3

## Reading the score

| Score | Meaning |
|---|---|
| 90 to 100 | Ready. Do a Warm run before the real thing and stop there. |
| 75 to 89 | Solid. One specific fix away from ready. |
| 60 to 74 | Something is getting in the way: a sidestep, a scripted stretch or a giveaway. Fix the top issue and rerun. |
| Under 60 | Go back to the message house before another round. |

Score honestly. An inflated score sends someone into the real thing thinking they are ready. First rounds usually score lower than people expect, so tell them a low first score is normal and the second round is the one to judge by.

## The template

```
THE HOT SEAT: SCORECARD
[Name] | [Room] | [Who was asking] | Heat: [level]

THE HEADLINE YOU JUST WROTE
"[The headline someone would write from these answers. Write it the way
that outlet or creator would, including an unflattering one if that is
what they earned.]"

THE QUOTE THEY WOULD PULL
"[Their exact words. The single line most likely to be used.]"

THE CLIP THAT TRAVELS
"[The ten seconds most likely to be cut out and shared on its own.]"
Out of context, it says: [what a stranger would take from only this clip]
[One sentence: is that what they meant?]

SCORE: [X] / 100  ([one of the four readings above])

  Answered the question     [x] / 25
  The message landed        [x] / 20
  Sounded like a human      [x] / 20
  Held up under pressure    [x] / 15
  Clear and brief           [x] / 10
  What you protected        [x] / 10

YOUR BEST ANSWER
Q: [the question]
You said: "[their words, trimmed]"
Why it worked: [one or two sentences, specific]

THE ANSWER THAT COST YOU
Q: [the question]
You said: "[their words, trimmed]"
The move: [name it from reporter-moves.md]
What it cost: [what the audience took from it]
Try this: "[a rewrite in their voice: answer, add one thing, stop]"

WHERE YOU SOUNDED SCRIPTED
[The one or two lines that sounded most like a press release, each with a
plain-spoken version. If none: "Nowhere. You sounded like yourself."]

WHAT YOU GAVE AWAY
[Each giveaway with the words they used. If none: "Nothing. Clean round."]

WHAT WAS REAL AND WHAT WAS PRACTICE
[Which claims and facts in the questions came from real search results or
from what they pasted in, and which were invented for the simulation.]

THE ONE FIX
[The single change that would move the score the most. One sentence.]

NEXT
[One recommended next step.]
```

## Room-specific lines

Add one line before THE ONE FIX when it applies:

- **Crisis press conference:** "Opening statement": did it cover what happened, the people affected, what is being done, and when the next update comes. And was it early enough to get ahead of the story.
- **Viral response:** "Speed and tone": would this response have gone out fast enough, and did it sound like a person or a statement.
- **Panel:** "Airtime": roughly what share of the talking they got, and whether their one line is the one people would repeat.
- **Town hall:** "Trust": did the people in the room get straight answers to the questions they care about most.
- **Legislative hearing:** "Length": how many answers ran longer than they needed to.

## Rewrites

When rewriting an answer, use their vocabulary and their message house, and keep it to the length the room allows. If the rewrite sounds like a press release, they will not be able to say it, and it would fail the same test they just failed.
