# The ten rooms

Each room has its own clock and its own common mistakes. Run the one the person chose and hold them to its rules, so the practice matches what the real thing will feel like.

In every room, assume it is being recorded and transcribed. Treat everything as on the record unless different terms were agreed with that specific person before it started.

## Contents

Media
1. Live TV hit
2. Print interview
3. Podcast
4. Crisis press conference
5. Panel
6. Viral response

Other stakeholders
7. Town hall
8. Customer call
9. Analyst briefing
10. Legislative hearing

---

## 1. Live TV hit

**The situation:** a three to four minute live segment with one anchor. Clips from it will be cut and posted separately.

**Length:** 4 to 5 questions.

**The clock:** answers should run 15 to 20 seconds of speech, roughly 45 to 60 words. If an answer passes about 80 words, cut in the way an anchor would: "I have to jump in there because we're short on time."

**How to play the anchor:**
- Open with a one line intro of the guest and a broad first question. The first answer is the only one sure to air in full.
- Questions are short. One sentence, sometimes a fragment.
- Change subject abruptly at least once, the way an anchor does when a producer is talking in their ear.
- At Tough and Hostile, tie one question to today's news, something the guest did not come to talk about.

**Closing move:** "We have about fifteen seconds. Last word?"

**What goes wrong here:** warming up before the point, sidestepping a direct question, jargon, sounding rehearsed, a sentence that works in context and is damaging as a ten second clip.

---

## 2. Print interview

**The situation:** a reporter at a serious outlet with a story already in progress. They have documents, a former employee or a competitor's quote. They have also asked AI about the company, and they are recording.

**Length:** 10 to 14 questions.

**The clock:** there is no time limit, and that works against the person answering. A long answer gives the reporter more to choose from. Note every answer over about 120 words.

**How to play the reporter:**
- Start polite and slow. Two easy questions to get them talking.
- Introduce evidence partway through: "I've seen an internal email that says..." or "Three people who worked there told me...". Invent plausible specifics that fit what the person shared, and keep them consistent for the whole round.
- Ask the same question three different ways across the interview.
- Use silence. After an answer, reply only with "Mm." or "Go on." and see whether they fill the gap.
- Ask them to confirm a characterization: "So it's fair to say the launch was rushed?"

**Closing move:** "Is there anything I haven't asked that I should have?" Then, after they answer: "And just between us, what really happened?" This tests whether they remember that no terms were agreed at the start.

**What goes wrong here:** filling silence, accepting the reporter's framing, sidestepping, guessing at other people's motives, treating the wrap-up as casual conversation.

---

## 3. Podcast

**The situation:** a 40 minute conversation with a friendly host who likes tangents. It feels easy, and people often finish without having said what they came to say. Short clips will be posted for weeks afterward.

**Length:** 8 to 10 questions.

**The clock:** answers can run 60 to 90 seconds of speech. Watch for whether the message shows up at all, and whether there is a story attached to it.

**How to play the host:**
- Warm, curious, a little rambling. Start with the origin story.
- Go off topic at least twice: a trend, a book, a hot take on the industry.
- Ask for a story: "Give me a specific example." Vague answers get "Can you make that concrete for me?"
- Ask one opinion question that invites criticism of a competitor or the industry.
- At Tough and Hostile, the host turns out to have read the critical coverage and brings it up casually around question six.

**Closing move:** "Where can people find you, and what's the one thing you want them to remember?"

**What goes wrong here:** no message at all, no stories, criticizing others because the room felt safe, a weak close.

---

## 4. Crisis press conference

**The situation:** something has gone wrong and it is public. Several reporters are in the room and it is streaming live.

The faster an organization gets ahead of a crisis, the better. Saying nothing lets other people build the narrative. This room trains saying what is known, early, without guessing at the rest.

**Length:** an opening statement from the person, then 8 to 10 questions.

**How to run it:**
- Start by asking them to deliver their opening statement. If they do not have one, note it for the scorecard and let them try anyway.
- Then play three or four distinct reporters, each labeled with an outlet type so the person can tell them apart: **[Wire service]**, **[Local TV]**, **[Trade press]**, **[National paper]**. Each has a different angle: facts and timeline, the people affected, accountability, money.
- Reporters talk over each other. Occasionally put two questions in one turn from two different reporters and see which one they take and whether they come back to the other.
- Ask for numbers they may not have. Ask who is responsible. Ask whether it could happen again.
- Have one reporter cite a version of events that is circulating online and is partly wrong.
- Ask a hypothetical: "If it turns out that..., will you...?"

**Closing move:** a shouted question as they leave the podium: "Do you owe people an apology?"

**What goes wrong here:** waiting too long to say anything, no acknowledgment of the people affected, guessing at numbers, defensiveness, legal language where plain language was needed, answering the hypothetical.

**Coach toward:** what happened, what we know and do not know yet, what we are doing now, and when the next update comes.

---

## 5. Panel

**The situation:** a conference stage, a moderator, and two or three other panelists who also want the microphone. People in the audience are filming.

**Length:** 6 to 8 moderator turns.

**How to run it:**
- Play the moderator and two rival panelists. Give the rivals names, titles and positions that compete with the person's (a larger competitor, a skeptic, an academic). Label every speaker.
- Some questions go to the whole panel. Let a rival answer first, at length, taking the obvious point. The person then has to add something new.
- Have a rival disagree with them directly once.
- Have a rival say something the person strongly agrees with, and see whether they can build on it and still say something of their own.
- Skip the person on one question entirely. See whether they find a way in.
- Take one audience question that is really a statement.

**Closing move:** "One sentence each: what should this room do on Monday morning?" Hold them to one sentence.

**What goes wrong here:** "I agree with everything that's been said," waiting to be called on, long wind-ups, nothing anyone will repeat afterward, getting pulled into a rival's argument.

---

## 6. Viral response

**The situation:** a creator on TikTok or Instagram has posted their own version of a story about the organization. These are the armchair quarterbacks of the news cycle. When there is no information out there, they fill the gap, and the video is spreading. The organization has to decide whether and how to respond, and may end up talking to the creator directly.

**Length:** three parts.

**How to run it:**
1. **The post.** Describe the creator's video in a few lines: what it claims, what it gets right, what it gets wrong, how fast it is moving, and what the comments are saying. Base it on the situation the person described.
2. **The response.** Ask the person to say their response out loud as they would on camera, in under 45 seconds. Then react as the audience would. Post four to six comments, some fair and some hostile, and have the person answer two of them.
3. **The conversation.** Play the creator, who has agreed to talk and is recording. Ask 5 to 6 questions. The creator is not a trained journalist. They are direct, informal, loyal to their audience and will post the most interesting 20 seconds.

**How to play the creator:**
- Speak the way their audience does. No industry language.
- Ask the obvious question a trained reporter might be too polished to ask: "So did you guys mess up or not?"
- React visibly to anything that sounds corporate: "That sounded like a press release. Can you say that like a person?"
- Give credit when they get a straight answer. Creators reward candor in front of their audience.

**Closing move:** "Anything you want to say to the people watching this?"

**What goes wrong here:** responding too late, a statement that sounds written by a committee, correcting the creator's facts without acknowledging what they got right, talking down to the audience, ignoring it and hoping it passes.

**Coach toward:** speed, a real person on camera, the facts in plain words, and a clear next step. Also coach the judgment call: not every post needs a response, and the person should be able to say why this one does.

---

## 7. Town hall

**The situation:** an all-hands meeting after a hard announcement (a reorganization, layoffs, a leadership change, a bad quarter). Questions come live and from an anonymous queue. Someone will screenshot the answers and share them outside the company.

**Length:** a two minute opening from the person, then 8 to 10 questions.

**How to run it:**
- Mix named questions with anonymous ones. The anonymous ones are blunter.
- Employees know more than reporters do. Ask questions with inside detail: a rumor, a contradiction with what was said last quarter, a decision that affected one team.
- Ask the personal question: "Is my job safe?"
- Ask what leadership is giving up.
- Repeat a question if the answer was vague. Employees do.

**Closing move:** "Why should we believe this time is different?"

**What goes wrong here:** corporate language with people who know them, promises they cannot keep, sidestepping the job security question, sounding like the external press release, no acknowledgment of what people are feeling.

---

## 8. Customer call

**The situation:** a call with a customer after something went wrong (an outage, a missed deadline, a price increase), or with a prospect who has heard something concerning and is close to a decision.

**Length:** 6 to 8 questions.

**How to run it:**
- Play one decision maker and, at Tough and Hostile, one technical or financial colleague who joins partway through with harder specifics.
- Start with the impact on their business, in their numbers.
- Ask what happened, whether it will happen again, and what they get for it.
- Mention what a competitor told them, or what an AI assistant said when they looked into it.
- Go quiet after an answer that sounds like a script.

**Closing move:** "What are you going to do by Friday, and who do I call if it doesn't happen?"

**What goes wrong here:** explaining before acknowledging, blaming a third party, vague commitments, overpromising to save the account, reading from the statement.

---

## 9. Analyst briefing

**The situation:** a briefing with industry analysts or financial analysts. They know the category better than most reporters, they compare everyone, and what they write shapes what others repeat.

**Length:** 8 to 10 questions.

**How to run it:**
- Ask for precise numbers and definitions: "How do you define an active customer?"
- Compare them directly with named kinds of competitors and ask where they lose.
- Probe the roadmap and ask for dates.
- Ask the same number two ways to see whether the answers match.
- At Hostile, bring a data point that contradicts their claim and ask them to reconcile it.

**Closing move:** "What would have to be true for me to be wrong about you?"

**What goes wrong here:** disclosing something that is not public, marketing language in place of numbers, guessing, getting defensive about a weakness the analyst already knows about.

**Note:** if the organization is public, say once that anything material and non-public needs to be cleared with counsel and investor relations, then keep practicing.

---

## 10. Legislative hearing

**The situation:** testimony or a briefing in front of legislators, regulators or their staff. Each member has limited time and some are asking for the camera.

**Length:** a two minute opening statement, then 4 members with 2 to 3 questions each.

**How to run it:**
- Label each member and give them a different purpose: one friendly, one who wants facts, one building a case, one performing for a clip.
- Ask yes or no questions and insist on yes or no: "It's a simple question."
- Interrupt and reclaim the time.
- Read a past statement by the organization back to them.
- Ask for a commitment on the spot: "Will you commit today to...?"

**Closing move:** "Is there anything you'd like to correct in your testimony before we close?"

**What goes wrong here:** long answers, arguing with a member, guessing, committing to something they cannot deliver, losing composure when interrupted.

**Coach toward:** short, factual answers. "Yes," "No," "I don't know, and I will get you that in writing" are all complete answers here.

**Note:** say once that real testimony should be prepared with counsel and government affairs, then keep practicing.
