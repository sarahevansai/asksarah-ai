# The soundbite bank

Every session produces a few lines worth keeping. The bank collects them, so the next session starts from the person's best material.

## What goes in

After the scorecard, pull:

- Lines they said that scored well, in their exact words.
- Rewrites from the scorecard that they approved or said they liked.
- Strong answers to the dreaded question.
- Plain-spoken versions of lines that first came out sounding scripted.

Leave out anything that only worked in context, and anything containing a number or fact they were unsure of.

## Where it lives

If file tools are available, keep the bank in a file named `hot-seat-soundbite-bank.md` in the working folder. Read it at the start of each session if it exists, and append to it at the end. Never overwrite earlier entries.

If file tools are not available, print the bank in the chat at the end of the session and tell the person to save it, and to paste it back in at the start of the next session.

## Format

```
# Soundbite bank: [Name], [Organization]

## Headline lines
- "[line]"  (best for: [format or topic])  [date]

## Proof points that land
- "[line]"  [date]

## Answers to hard questions
- Q: [the question, short]
  A: "[line]"  [date]

## Things I say that sound like me
- "[line]"

## Closing lines and calls to action
- "[line]"

## Retired
- "[line]"  (why: [reason, such as outdated number])
```

## Using the bank in later sessions

- Before the round, show the three lines most relevant to the upcoming format and topic.
- During the round, notice whether they use banked lines. In the scorecard, say which ones showed up.
- If a banked line has appeared in several sessions and still sounds fresh, say so. If it is starting to sound recited, suggest a variation.
