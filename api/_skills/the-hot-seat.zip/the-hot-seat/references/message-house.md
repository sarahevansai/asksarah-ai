# The message house

The message house is what the person carries into the room. It should fit on one index card, because that is about as much as anyone remembers under pressure.

Build it with them, quickly. Offer a draft based on what they shared, then let them change the words until it sounds like something they would say out loud. Use their phrasing even when yours is cleaner. They are the one who has to say it.

## The structure

```
THE HOT SEAT: MESSAGE HOUSE
[Name], [Title], [Organization]
For: [room] with [who is asking], [date if known]

HEADLINE MESSAGE
[One sentence. The thing the audience should repeat tomorrow.]

PROOF POINTS
1. [A number]
2. [An example or a story about a real person]
3. [A third party: a customer, a study, an award, a partner]

THE LINE
[One line, under 15 words, that still makes sense as a ten second clip.]

THE DREADED QUESTION
Q: [the question]
A: [The plain, honest answer. Two or three sentences.]

LANDMINES
- [A topic or phrase to stay away from, and why]
- [A number that is not public]
- [Anything they cannot speak to, with the reason they will give]

WHAT AI SAYS ABOUT US
- [Anything wrong or out of date that an interviewer may have seen, with the correct fact]

NEXT STEP
[Where people go or what they do next. One thing.]
```

## The test for each part

**Headline message**
- Would a person outside the industry understand it on first hearing?
- Is it about the audience, or only about the organization?
- Can they say it in one breath?

**Proof points**
- One number, one story, one outside voice. An audience will hold onto one number. They will not hold onto three.
- Every number has to be public and checkable. If they are unsure of a figure, it comes off the card.

**The line**
- Under 15 words.
- Sounds like speech. Read it aloud. If it sounds written, rewrite it.
- Run the clip test: if this sentence were the only thing someone saw, with no question before it and no context after, would it still say what they mean?

**The dreaded question**
- Write a real answer. Do not write a way around it.
- Practice it until it is boring to say. It is going to be asked.

**Landmines**
- Name them specifically. "Pricing" is vague. "Whether the March increase is the last one this year" is a landmine.
- For anything they can't discuss, write the reason they will give. "I can't speak to that because it's in litigation" is an answer. Changing the subject is not.

**What AI says about us**
- Have them check before the real thing: prompt two or three AI assistants about the organization and the topic, and note anything wrong or dated.
- For each one, write the correct fact and where it can be verified.

## The human test

Do this last, for the whole card. Read every line out loud and ask three things:

1. Would they say this to a friend over coffee, in these words?
2. Does it sound like it came from a press release, a committee or an AI draft?
3. Is there a real person, a real number or a real example in it?

Any line that fails gets rewritten in their own words, even if the new version is less polished. Messaging that sounds corporate and canned is one of the most common ways a good spokesperson loses a room, and AI-generated talking points make it worse because everyone has started to recognize how they sound.

## The answer shape

Teach this once, during message house prep:

1. **Answer** the question in the first sentence.
2. **Add** one thing: the proof, the context or the next step.
3. **Stop.**

Most weak answers skip step 1 or miss step 3.
