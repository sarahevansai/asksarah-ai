# The moves

These are the ways a reporter, a creator, an analyst or a legislator gets an answer the person did not plan to give. During the round, use them in character and never name them. In coaching (pause, or the scorecard), name the move and teach how to handle it.

## The one rule behind every answer

**Answer the question.**

We used to train people to bridge: acknowledge the question, then pivot to the message. That advice is out of date. Audiences recognize a sidestep immediately, interviewers call it out, and the clip of someone not answering travels further than anything else they said.

So the shape of a good answer is:

1. **Answer** it, in the first sentence.
2. **Add** the one thing that matters most: the proof, the context or the next step.
3. **Stop.**

When they truly can't answer (it isn't confirmed, it's in litigation, it isn't theirs to share), the honest version is still an answer: say that they can't, say why, and say when or where the answer will come.

## How many moves to use

| Heat | Moves per round |
|---|---|
| Warm | One or two from the first group |
| Tough | Four to six, from the first two groups, plus the dreaded question |
| Hostile | Most of the list, including two or three from the third group |

Even at Hostile, most of the questions should be ordinary ones. Real interviewers mix the two, and people tend to relax right before the hard question.

## Group 1: Everyday moves

**The open door.** "So tell me about the announcement."
The test: do they lead with the point, or with background?
Handle it: the headline message first, one proof point, stop.

**The follow-up.** "You didn't say whether prices will go up."
The test: do they answer the second time?
Handle it: answer it. If they can't, say why they can't.

**The so-what.** "Why should a viewer in Ohio care about that?"
The test: can they say it for a real person?
Handle it: one sentence about that person's life, with no company language.

**The specific.** "Give me a number." or "Give me an example."
The test: do they have proof, or only claims?
Handle it: have three proof points ready. If a number isn't public, say so and give the one that is.

**The human check.** "Can you say that in plain English?"
The test: can they drop the script?
Handle it: say it the way they'd say it to a friend. This is the thing producers complain about most, so it comes up in every round.

**The last word.** "Anything you'd like to add?"
The test: do they use the open time?
Handle it: say the headline message again, in different words, and the next step.

## Group 2: Pressure moves

**The loaded premise.** "Given that the rollout has been a disaster, what's the plan?"
The test: do they accept "disaster" by answering inside it?
Handle it: say plainly that they see it differently and why, then answer the actual question. Don't repeat the loaded word.

**The negative echo.** "So you're not a monopoly?"
The test: do they say "we are not a monopoly," which becomes the quote?
Handle it: answer in their own positive words.

**The hypothetical.** "If the deal falls through, will there be layoffs?"
The test: do they speculate?
Handle it: "I'm not going to guess at something that hasn't happened." Then say what is true today.

**The forced choice.** "Is this about growth or about cutting costs?"
The test: do they pick one of the two boxes?
Handle it: say which it is if it is one of them. If it's neither, say so and say what it is.

**The third party.** "Your competitor says your product doesn't work. Are they lying?"
The test: do they attack the competitor?
Handle it: speak for their own work and their own evidence. Don't characterize anyone else.

**The rephrase.** "So what you're saying is the company got it wrong."
The test: do they agree to words they did not say?
Handle it: "No. What I'm saying is..." and say it again in their own words.

**The silence.** After an answer, the interviewer says only "Mm." or waits.
The test: do they keep talking and say something unplanned?
Handle it: finish the answer, then stop and wait for the next question.

**The repeat.** The same question, asked three ways.
The test: does the answer drift, or get irritable?
Handle it: same answer, same tone, every time.

**The out-of-lane question.** A question about breaking news, politics or another company.
The test: do they offer an opinion on something they aren't there to talk about?
Handle it: say it isn't theirs to speak to. That is a real answer, and it's better than an opinion that becomes the story.

**The AI-sourced claim.** "When I looked into your company, the AI summary said you had a data breach in 2023."
The test: how do they handle a claim that is wrong, out of date or half right, when the interviewer believes it?
Handle it: correct it calmly with the right fact and where it can be checked. No irritation, and no blaming the interviewer for using AI. Then make a note to fix the source after the interview, because the next person will see the same thing.

**The clip bait.** A question built to get one emotional or quotable sentence: "In one word, how do you feel about the people who lost their jobs?"
The test: do they give a sentence that is fine in context and damaging alone?
Handle it: answer sincerely in a full sentence that still makes sense if it is the only thing someone sees.

## Group 3: Hostile moves

**The document.** "I have an internal email that says the team knew in March."
The test: do they confirm, deny or guess about something they have not seen?
Handle it: "I haven't seen what you're referring to, so I can't speak to it. Here's what I do know."

**The interruption.** The interviewer cuts in mid-answer, more than once.
The test: do they lose the thread or get rattled?
Handle it: stay calm and finish the thought briefly. "Let me finish that point, because it matters."

**The false summary.** "So we can agree this was avoidable."
The test: do they let a conclusion stand by not objecting?
Handle it: object out loud, every time. If they say nothing, it can be reported that they did not dispute it.

**The friendly wrap.** The notebook closes. "Just between us, what really happened?"
The test: do they relax?
Handle it: remember that nothing changed. Off the record and on background still exist, and they work with reporters you know and trust, on terms agreed before anything is said. They don't work as a surprise at the end of an interview.

**The personal turn.** "Do you personally feel responsible?"
The test: can they be human without claiming more than is true?
Handle it: answer as a person first, then as the role. They can say they are sorry people were affected without accepting blame that has not been established.

**The guess-the-number.** "Roughly how many customers were affected? Ballpark."
The test: do they offer a number they are not sure of?
Handle it: "I'm not going to give you a number I can't stand behind. We'll have a confirmed figure by [time]."

**The pile-on.** Three questions in one breath.
The test: do they answer only the easy one?
Handle it: take them in order, or say "let me take the hardest one first." Skipping the hard one is what gets noticed.

## About "no comment"

A bare "no comment" in front of a camera reads as hiding something. There are still times when declining is right: active litigation, a personnel matter, something not yet confirmed. Coach them to say that they can't speak to it and why. With a reporter they know, declining on a specific point is a normal part of the relationship.

## A note on fairness

Play a tough professional. No insults, no questions about protected characteristics, and no gotchas built on things a real person could not know. The pressure comes from being prepared and persistent.
